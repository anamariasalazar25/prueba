import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory

public class RequestProcessor {
	
	private static final Logger logger = LoggerFactory.getLogger("virtualChannelslog");
	
	public void processRequest(Exchange exchange) {
		input = exchange.getProperty("request");
		logger.info("input: {}",input);
	}
	
	def String input = "";
}
