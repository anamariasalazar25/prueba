package virtualChannels.groovy.tools.checks;

import java.lang.reflect.Field
import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonParseException;

import java.util.HashMap;
import java.util.ArrayList;

import java.lang.IllegalArgumentException;

import virtualChannels.exceptions.VirtualChannelsException;
import virtualChannels.groovy.model.Transaction;
import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.exceptions.VirtualChannelsException;
import virtualChannels.groovy.tools.values.Segments;
import virtualChannels.groovy.model.sas.interfaces.SASInterface;
import virtualChannels.groovy.model.sas.enums.SASTransaction;
import virtualChannels.groovy.model.sas.enums.SASPayeer;
import virtualChannels.groovy.model.sas.enums.SASPayee;
import virtualChannels.groovy.model.sas.enums.SASBiocatchScore;
import virtualChannels.groovy.model.sas.enums.SASGenuineDevice;
import virtualChannels.groovy.model.sas.enums.SASGenuineLocation;
import virtualChannels.groovy.model.sas.enums.SASBehaviorAnomaly;
import virtualChannels.groovy.model.sas.enums.SASBrowserAnomaly;
import virtualChannels.groovy.model.sas.enums.SASCriminalBehavior;
import virtualChannels.groovy.model.sas.enums.SASExpertUser;
import virtualChannels.groovy.model.sas.enums.SASImmatureProfile;
import virtualChannels.groovy.model.sas.enums.SASLowDataFamiliarity;
import virtualChannels.groovy.model.sas.enums.SASNetworkAnomaly;
import virtualChannels.groovy.model.sas.enums.SASRiskyDevice;
import virtualChannels.groovy.model.sas.enums.SASRiskyLinking;
import virtualChannels.groovy.model.sas.enums.SASRiskyLocation;
import virtualChannels.groovy.model.sas.enums.SASRiskyEvent;
import virtualChannels.groovy.model.sas.enums.SASEmailAge;
import virtualChannels.groovy.model.sas.enums.SASEmailAgeScore;
import virtualChannels.groovy.model.sas.enums.SASMarketplace;
import virtualChannels.groovy.model.sas.enums.SASMultitransferencias;
import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.tools.Common;


public class Checks {
	
	private static final Logger logger = LoggerFactory.getLogger("virtualChannelslog");
	
	/**
	 * List with SAS enumerations values
	 * key -> Name of enumaration representation (SAS mappers) (virtualChannels.groovy.model.sas.enums)
	 * value -> Enumeration class 
	 */
	private static enumsList = [
		
		"transaction": SASTransaction,
		"payeer": SASPayeer,
		"payee": SASPayee,
		"biocatchScoreInformation": SASBiocatchScore,
		"genuineDevice": SASGenuineDevice,
		"genuineLocation": SASGenuineLocation,
		"behaviorAnomaly": SASBehaviorAnomaly,
		"browserAnomaly": SASBrowserAnomaly,
		"criminalBehavior": SASCriminalBehavior,
		"expertUser": SASExpertUser,
		"immatureProfile": SASImmatureProfile,
		"lowDataFamiliarity": SASLowDataFamiliarity,
		"networkAnomaly": SASNetworkAnomaly,
		"riskyDevice": SASRiskyDevice,
		"riskyLinking": SASRiskyLinking,
		"riskyLocation": SASRiskyLocation,
		"riskyEvent": SASRiskyEvent,
		"emailAge": SASEmailAge,
		"emailAgeScoreInformation": SASEmailAgeScore,
		"marketplace": SASMarketplace,
		"multitransferencias": SASMultitransferencias, //adicion multitransferencias
		];
	
	/**
	 * The content of an object is deconstructed (excepting date type)
	 * @param object Object that wants to be deconstruyed
	 * @return HashMap with object attributes
	 */
	private static HashMap getObjectAttList(Object object) {
		if(object instanceof java.util.Date) return null;
		return Common.getObjectAttList(object);
	}

	/**
	 * Get if an object has attributes with null values
	 * @param object Object to analyze
	 * @return true or false depending if at least one of object attribute value is null
	 */
	private static boolean getObjectNullAtt(Object object) {
		try {			
			
			def atts = getObjectAttList(object);
			
			if(atts!= null && atts.size() > 0) {
				for (attribute in atts) {					
					if(attribute.value.equals(null)) {
						return true;
					}	
					
					if(getObjectNullAtt(attribute.value) ) {
						return true;
					}
				}
			}
			return false;
			
		}

		catch(Exception e) {
			e.printStackTrace();			
			return true;
		}
	}
	
	/**
	 * 
	 * Validate if an object is null
	 * @param object Object to evaluate
	 * @param errorMess Error Message to show if an object is null
	 * @throws VirtualChannelsException If an object is null
	 */
	public static void checkNull(Object object, String errorMess) throws VirtualChannelsException {
		
		if(object == null) {
			throw new VirtualChannelsException(errorMess);
		}
			
	}
	
	/**
	 * Validate if an object has attributes with null values
	 * @param object Object to evaluate
	 * @throws VirtualChannelsException If the object has attributes with null values
	 */
	public static void checkNull(Object object) throws VirtualChannelsException {

		if(getObjectNullAtt(object)) {
			throw new VirtualChannelsException(111) ;
		}
		
	}
	
	/**
	 * Verify if attributes of an SASTemplate object are valid: Length and segments
	 * @param object SASTemplate object to evaluate 
	 * @param validSegments List of object valid segments (account type + activity type) eg. CSBF: ["SMH", "RQO", "RUA", ... ]
	 * @param enumValue Key of enumsList, representing enumeration mapper
	 * @return HashMap Map of object representation
	 * @throws VirtualChannelsException If an attribute value min size is not valid
	 */
	public static HashMap checkFields(SASTemplate object, ArrayList validSegments, String enumValue) throws VirtualChannelsException {

		def attrsMap = Common.getObjectAttList(object);
		def finalAttrsMap = attrsMap.clone();
		
		for(att in attrsMap) {

			def key = att.key;
			def value = att.value;

			if(value instanceof SASTemplate == false) {
				
				try {

					def enumType = enumsList[enumValue];
					
					if(enumType != null) {
					
						def enumAtt = enumType.valueOfElement(key.toString());
						
						if(enumAtt != null) {
						
							String attSegement = enumAtt.getSegment();
			
							if(validSegments.contains(attSegement)) {
								evalValue(key, value, enumAtt, finalAttrsMap)
							}
						}
					}
				}
				catch(IllegalArgumentException e) {
					logger.error("Attribute not found in given enumeration: " + key);
				}
			}
			
			else {
				finalAttrsMap[key] = checkFields(value, validSegments, key);
			}
		}

		return finalAttrsMap;
	}
	
	/**
	 * Verify fields values
	 * @param key Field key (object attribute name)
	 * @param value Field value (object attribute value)
	 * @param enumAtt SASTemplate enum of object  
	 * @param finalAttrsMap Final hashmap with object values
	 */
	private static void evalValue(key, value, enumAtt, finalAttrsMap) throws VirtualChannelsException {
		
		if(value == null) {
			finalAttrsMap[key] = "";
		}
		
		else {
			if(value instanceof String) {
				
				int valueLength = value.length();
	
				if(value.equals("true") || value.equals("false")) {
					boolean valueBool = Boolean.parseBoolean(value);
					finalAttrsMap[key] = Common.boolToInt(valueBool);
				}
				
				else{
					
					if(valueLength >= 1) {
						finalAttrsMap[key] = Common.truncateString(value, enumAtt.getMaxLength());
					}
				}
			}
			
			else if(value instanceof Boolean) {
				finalAttrsMap[key] = Common.boolToInt(value);
			}
			
			else if(value instanceof Integer) {
				String val = Common.truncateString(value.toString(), enumAtt.getMaxLength());
				finalAttrsMap[key] = Integer.valueOf(val);
			}
		}
	}
}




