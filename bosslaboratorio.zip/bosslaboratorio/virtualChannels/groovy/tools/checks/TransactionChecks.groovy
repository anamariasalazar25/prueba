package virtualChannels.groovy.tools.checks

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.apache.commons.lang.time.DateUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sas.davivienda.efm.commons.util.FMUtils
import com.fasterxml.jackson.databind.DeserializationFeature;

import virtualChannels.groovy.model.Transaction;
import virtualChannels.groovy.model.Multitransferencias;
import virtualChannels.groovy.model.enums.*;
import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.tools.checks.Checks;
import virtualChannels.groovy.tools.values.Segments;
import virtualChannels.groovy.tools.Common;

public class TransactionChecks {
	
	private static final Logger logger = LoggerFactory.getLogger("virtualChannelslog");
	
	/**
	 * Verify if transactions attributes are valid: Length and segment
	 * @param transaction Transaction object
	 */
	public static Transaction checkTransAttributes(Transaction transaction) {
		
		ArrayList validSegments = Segments.getTransSegms(transaction);
		
		if(validSegments != null) {
			HashMap transMap = Checks.checkFields(transaction, validSegments, "transaction");
			Transaction newTransaction = hashMapToObject(transMap, Transaction.class);
			
			String trxDate = newTransaction.getTransactionDate();
			String trxTime = newTransaction.getTransactionTime();

			Date date = new SimpleDateFormat("yyyyMMdd HH:mm:ss.SS").parse(trxDate + " " + trxTime);

			// GMT date-time
			Date gmtDate = getCompleteTransactionDateGMT(trxDate, trxTime);
			
			newTransaction.setTransactionDate(formatTransactionDateGMT(date));
			newTransaction.setTransactionTime(formatTransactionTimeGMT(date));

			newTransaction.setTransactionDateGMT(formatTransactionDateGMT(gmtDate));
			newTransaction.setTransactionTimeGMT(formatTransactionTimeGMT(gmtDate));
			
			String creaMTDate;
			String editMTDate;
			try {
				creaMTDate = newTransaction.multiTransfer.getBatchFileCreationDate();
				if(creaMTDate != null) {
					newTransaction.multiTransfer.setBatchFileCreationDate(formatMTFileDates(creaMTDate));
				}	
			} catch (Exception e) {
				creaMTDate = null;
			}

			try {
				editMTDate = newTransaction.multiTransfer.getBatchFileEditionDate();
				if(editMTDate != null) {
					newTransaction.multiTransfer.setBatchFileEditionDate(formatMTFileDates(editMTDate));
				}	
			} catch (Exception e) {
				editMTDate = null;
			}
			
			return newTransaction;
		}
		return null;
	}
	
	private static checkPayeeFields(Transaction transaction, HashMap attsMap) {
		
		String payeeInfoPresent = ActivityTypeName.valueOf(transaction.activityType.activityType + "_" + transaction.activityName.activityName).payeeInfoPresent;
		boolean transfer = false;

		if("Y".equals(payeeInfoPresent)) {
			
			String trxPayeeAccountType = transaction.payee.getAccountType();
			String enrPayeeAccountType = "";
			
			try {
				AccountTypePayee payeeAccountType = AccountTypePayee.valueOf(trxPayeeAccountType);
				enrPayeeAccountType = payeeAccountType.enrAccountType;
				transfer = true;
			}catch(Exception e) {
				logger.info("Tipo de cuenta destino {}, no definido - {}",trxPayeeAccountType, trxPayeeAccountType);
				enrPayeeAccountType = "";
			}
			
			attsMap.put("payeeAccountType", enrPayeeAccountType);
			attsMap.put("payeeAccountNumber", transaction.payee.accountNumber);
			
		}else{
			attsMap.remove("tpp_name");
			attsMap.remove("tpp_acct_type");
			attsMap.remove("tpp_bank_num");
			attsMap.remove("tpp_acct_num");
		}
		
		attsMap.put("transfer", transfer);
	}

	private static void enrichmentParams(Transaction transaction, HashMap attsMap){
		
		String trxPayerAccountType = transaction.payeer.getAccountType();
		
		boolean enrichByAccount = false;
		 
		if(FMUtils.hasValue(trxPayerAccountType)){
			AccountType payerAccountType = AccountType.valueOf(transaction.payeer.accountType);
			attsMap.put("trxMean", payerAccountType.trxMean);
			attsMap.put("productId", transaction.payeer.accountNumber);
			attsMap.put("productType", payerAccountType.enrAccountType);
			attsMap.put("aqd_acct_relationship", payerAccountType.accountRelationship);
			enrichByAccount = true;
		}
		
		attsMap.put("enrichByAccount", enrichByAccount);
	}

	private static checkCustomFields(Transaction transaction, HashMap attsMap) {

		String enrIdType = attsMap.get("dbenr_id_type");
		String enrNum = attsMap.get("dbenr_id_number");
		
		def activityType = attsMap.get("smh_activity_type");
		def custType = attsMap.get("smh_cust_type");
		String custNumber = transaction.payeer.getCustNum();
		
		/* 
		 * CC 53
		 * Se requiere que en el campo xqo_cust_num (Tipo Id + Id Cliente) siempre se mapee la informacion
		 * de cliente generada por la consulta de enriquecimiento a partir del numero de producto 
		 * y que en los campos rua_2byte_string_002 (Tipo id) y rua_20byte_string_002 (Id Cliente) 
		 * 
		 * Con el cambio se garantiza que para la integracion con orquestador para persona juridica 
		 * se cuente con el numero de identificacion de la empresa (para perfil de cliente) 
		 * y con el numero de identificacion del usuario de la empresa que se loguea en el canal virtual
		 */
		if("B".equals(custType) && FMUtils.hasValue(enrIdType) && FMUtils.hasValue(enrNum)) {
			custNumber = enrIdType.concat(enrNum);
		}
		
		attsMap.put("xqo_cust_num",custNumber);
	}
	
	private static checkNonMonFields(Transaction transaction, HashMap attsMap) {

		String sasActivityType = attsMap.get("smh_activity_type");
		String tranId = transaction.transactionId;
		
		if("NM".equals(sasActivityType)){
			attsMap.put("dua_80byte_string_004", tranId);
		}
		if("DP".equals(sasActivityType)){
			attsMap.put("tdp_ref_num", tranId);
		}
	}

	/**
	 * Add extra transaction activity amount fields
	 * @param attsMap Hashmap with SAS transaction attributes (SAS mapper)
	 * @param activityAmount activityAmount transaction value
	 * @param accAct transaction AccountType+ActivityType
	 */
	public static void manageaActivityAmount(HashMap attsMap, Double activityAmount, Transaction transaction) {
		
		def validSegments = Segments.getTransSegms(transaction);
		
		if(validSegments != null) {
			String activityAmountStr = String.valueOf(activityAmount);
			
			if(validSegments.contains("TSH")) {
				attsMap.put("tsh_client_amt", activityAmountStr);
			}

			if(validSegments.contains("TBT")) {
				attsMap.put("tbt_tran_amt", activityAmountStr);
				attsMap.put("tbt_mod_amt", activityAmountStr);
			}

			if(validSegments.contains("TDP")) {
				attsMap.put("tdp_client_amt", activityAmountStr);
			}
		}
	}
	
	
	/**
	 * Transform HashMap into SASTemplate object
	 * @param map HashMap to transform
	 * @param sasClass SASTemplate instance class eg: Transaction.class
	 * @return SASTemplate object
	 */
	public static SASTemplate hashMapToObject(HashMap map, sasClass) {
		
		final ObjectMapper mapper = new ObjectMapper();
		
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		
		return mapper.convertValue(map, sasClass);
		
	}
	
	/**
	 *
	 * @param transaction
	 * @return
	 */
	public static ArrayList<String> getTransactionAccAct(Transaction transaction) {
	
		ArrayList<String> listAccAct = new ArrayList<String>();
		String payeerAccountType = transaction.payeer.getAccountTypeSMH();
		String activityType = transaction.getActivityTypeSMH();
		
		if(activityType != null) {
			listAccAct.add(payeerAccountType);
			listAccAct.add(activityType);
		}
		
		return listAccAct;
	}
	
	/**
	 *
	 * @param accountType
	 * @return
	 */
	public static obtainAccountTypeValue(String accountType) {
		AccountType accountTypeEnum = AccountType.valueOf(accountType);
		if(accountTypeEnum != null) return accountTypeEnum.accountType;
		
		return null;
	}
	
	private static Date getCompleteTransactionDateGMT(String transactionDate, String transactionTime) {
		
		if(transactionDate != null && transactionTime != null) {
			Date date = new SimpleDateFormat("yyyyMMdd HH:mm:ss.SS").parse(transactionDate + " " + transactionTime);
			Date gmtDate = DateUtils.addHours(date, 5);
			
			return gmtDate;
		}
		
		return null;
	}
	
	private static String formatTransactionDateGMT(Date date) {
		
		String patternDate = "yyyyMMdd";
		DateFormat df = new SimpleDateFormat(patternDate);
		
		if(date != null) {
			return df.format(date);
		}
		
		return null;
	}
	
	private static String formatTransactionTimeGMT(Date date) {

		String patternTime = "HH:mm:ss.SS";
		DateFormat df = new SimpleDateFormat(patternTime);
		
		if(date != null) {
			return df.format(date);
		}
		
		return null;
	}
	
	private static String formatMTFileDates(String mtFileDate) {
		
		Date   filedatein  = new SimpleDateFormat("yyyy-MM-dd").parse(mtFileDate);
		String filedateout = new SimpleDateFormat("yyyyMMdd").format(filedatein);
		return filedateout;
		
	}

}
