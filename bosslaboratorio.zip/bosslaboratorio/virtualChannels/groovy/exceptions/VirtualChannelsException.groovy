package virtualChannels.groovy.exceptions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class VirtualChannelsException extends Exception {
	
	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory.getLogger("virtualChannelslog");

	private int codError;
	private String message;

	public VirtualChannelsException(int codError){
		super();
		this.codError = codError;
	}
	
	public VirtualChannelsException(String message){
		super();
		this.message = message;
	}
	
	public VirtualChannelsException(int codError, String message){
		super();
		this.codError = codError;
		this.message = message;
	}


	@Override
	public String getMessage(){
		
		switch(this.codError){
			
			case 111:
				this.message = "Not null values are accepted on mandatory fields: " + this.message;
				break;
			case 222:
				this.message = "Invalid input: " + this.message;
				break;
		}

		return this.message;
	}
}
