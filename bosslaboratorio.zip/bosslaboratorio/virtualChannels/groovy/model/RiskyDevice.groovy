package virtualChannels.groovy.model

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASRiskyDevice;
import virtualChannels.groovy.tools.Common;

public class RiskyDevice extends SASTemplate {

	public RiskyDevice() {}
	
	def recentRiskyDevice;
	def riskyGlobalUniqueDeviceId;
	def rareCoresAnomaly;
	def deviceChangeAnomaly;
	def newDevice;
	def newDeviceConsistentIp;
	def rareCores;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASRiskyDevice);
	}
	
	
	@Override
	public String toString() {
		return new StringJoiner(", ", RiskyDevice.class.getSimpleName() + "[", "]")
			.add("recentRiskyDevice='" + this.recentRiskyDevice + "'")
			.add("riskyGlobalUniqueDeviceId='" + this.riskyGlobalUniqueDeviceId + "'")
			.add("rareCoresAnomaly='" + this.rareCoresAnomaly + "'")
			.add("deviceChangeAnomaly='" + this.deviceChangeAnomaly + "'")
			.add("newDevice='" + this.newDevice + "'")
			.add("newDeviceConsistentIp='" + this.newDeviceConsistentIp + "'")
			.add("rareCores='" + this.rareCores + "'")
			.toString();
	}
	
}


