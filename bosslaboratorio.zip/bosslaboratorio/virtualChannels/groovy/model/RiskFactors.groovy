package virtualChannels.groovy.model

import virtualChannels.groovy.model.sas.SASTemplate;

public class RiskFactors extends SASTemplate {
	
	public RiskFactors() {}
	
	def BehaviorAnomaly behaviorAnomaly;
	def BrowserAnomaly browserAnomaly;
	def CriminalBehavior criminalBehavior;
	def ExpertUser expertUser;
	def ImmatureProfile immatureProfile;
	def LowDataFamiliarity lowDataFamiliarity;
	def NetworkAnomaly networkAnomaly;
	def RiskyDevice riskyDevice;
	def RiskyLinking riskyLinking;
	def RiskyLocation riskyLocation;
	def RiskyEvent riskyEvent;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, null);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", RiskFactors.class.getSimpleName() + "[", "]")
			.add("behaviorAnomaly=" + this.behaviorAnomaly)
			.add("browserAnomaly=" + this.browserAnomaly)
			.add("criminalBehavior=" + this.criminalBehavior)
			.add("expertUser=" + this.expertUser)
			.add("immatureProfile=" + this.immatureProfile)
			.add("lowDataFamiliarity=" + this.lowDataFamiliarity)
			.add("networkAnomaly=" + this.networkAnomaly)
			.add("riskyDevice=" + this.riskyDevice)
			.add("riskyLinking=" + this.riskyLinking)
			.add("riskyLocation=" + this.riskyLocation)
			.add("riskyEvent=" + this.riskyEvent)
			.toString();
	}
	
}
