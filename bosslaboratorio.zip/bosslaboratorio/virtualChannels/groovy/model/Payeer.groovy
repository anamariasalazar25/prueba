package virtualChannels.groovy.model;

import java.util.StringJoiner;

import com.google.gson.annotations.SerializedName

import java.util.Map;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.enums.TpoPersona;
import virtualChannels.groovy.model.enums.AccountType;
import virtualChannels.groovy.model.sas.enums.SASPayeer;
import virtualChannels.groovy.tools.Common;

public class Payeer extends SASTemplate {
		
	public Payeer() {}
	
	def String idType;
	def String idNumber;
	def String accountNumber;
	def String accountType;
	def TpoPersona brand;

	public String getAccountTypeSMH() { 
		
		if(this.accountType != null) {

			try {
				AccountType at = AccountType.valueOf(this.accountType);
				return at.accountType;
			}
			
			catch(Exception e) {
				// No existe el valor
				return AccountType.DEFAULT.accountType;
				
			}
		}
		return AccountType.DEFAULT.accountType;
	}

	public String getCustNum(){
		String custNum = "";
		if(this.idType != null && this.idNumber != null){
			custNum = this.idType.concat(String.valueOf(idNumber));
		}
		return custNum;
	}
	
	public String getTipoBrandSMH() {
		
		if(this.brand != null) {
			return this.brand.tpoPersonaSMH;
		}
		
		return TpoPersona.I.tpoPersonaSMH;
	}

	public String getTipoBrandMulti() {
		
		if(this.brand != null) {
			return this.brand.tpoPersonaMulti;
		}
		
		return TpoPersona.I.tpoPersonaMulti;
	}
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASPayeer);	
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", Payeer.class.getSimpleName() + "[", "]")
			.add("idType='" + this.idType + "'")
			.add("idNumber='" + this.idNumber + "'")
			.add("accountNumber='" + this.accountNumber + "'")
			.add("accountType='" + this.accountType + "'")
			.add("brand='" + this.brand + "'")
			.toString();
	}

}
