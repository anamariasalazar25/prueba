package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASBehaviorAnomaly;

public class BehaviorAnomaly extends SASTemplate {
	
	public BehaviorAnomaly() {}
	
	def isLongSession;
	def keyMouseAnomaly;
	def loginImportAnomaly;
	def osChangeAnomaly;
	def privateBrowsingAnomaly;
	def rareTypingPatternsAnomaly;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASBehaviorAnomaly);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", BehaviorAnomaly.class.getSimpleName() + "[", "]")
			.add("isLongSession='" + this.isLongSession + "'")
			.add("keyMouseAnomaly='" + this.keyMouseAnomaly + "'")
			.add("loginImportAnomaly='" + this.loginImportAnomaly + "'")
			.add("osChangeAnomaly='" + this.osChangeAnomaly + "'")
			.add("privateBrowsingAnomaly='" + this.privateBrowsingAnomaly + "'")
			.add("rareTypingPatternsAnomaly='" + this.rareTypingPatternsAnomaly + "'")
			.toString();
	}
}
