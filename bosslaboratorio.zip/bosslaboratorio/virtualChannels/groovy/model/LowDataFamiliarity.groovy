package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASLowDataFamiliarity;

public class LowDataFamiliarity extends SASTemplate {
	
	public LowDataFamiliarity() {}
	
	def importData;
	def riskyImport;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASLowDataFamiliarity);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", LowDataFamiliarity.class.getSimpleName() + "[", "]")
			.add("importData='" + this.importData + "'")
			.add("riskyImport='" + this.riskyImport + "'")
			.toString();
	}
}
