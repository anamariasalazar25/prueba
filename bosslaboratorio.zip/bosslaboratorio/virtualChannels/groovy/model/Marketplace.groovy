package virtualChannels.groovy.model;

import java.util.StringJoiner;

import com.google.gson.annotations.SerializedName

import java.util.Map;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.enums.TpoPersona;
import virtualChannels.groovy.model.enums.AccountType;
import virtualChannels.groovy.model.sas.enums.SASMarketplace;
import virtualChannels.groovy.tools.Common;

public class Marketplace extends SASTemplate {
		
	public Marketplace() {}
	
	def String numPointsUsed  = "";
	def String numAvailPoints = "";

	public String getNumPointsUsed() { 
		
		if(this.numPointsUsed != null) {

			try {
				String pointsUsed = this.numPointsUsed;
				return pointsUsed;
			}
			
			catch(Exception e) {
				// No se recibieron los puntos usados
				return null;
				
			}
		}
		return null;
	}

	public String getNumAvailPoints() { 
		
		if(this.numAvailPoints != null) {

			try {
				String availPoints = this.numAvailPoints;
				return availPoints;
			}
			
			catch(Exception e) {
				// No se recibieron los puntos disponibles
				return null;
				
			}
		}
		return null;
	}

	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASMarketplace);	
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", Marketplace.class.getSimpleName() + "[", "]")
			.add("numPointsUsed='" + this.numPointsUsed + "'")
			.add("numAvailPoints='" + this.numAvailPoints + "'")
			.toString();
	}

}
