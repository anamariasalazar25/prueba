	package virtualChannels.groovy.model;

import java.util.StringJoiner;

public class ApiResponse {
	
	public ApiResponse(Integer code, String type, String message) {
		
		this.code = code;
		this.type = type;
		this.message = message;
	}
	
	/**
	 *
	 * @param codResponse
	 */
	public ApiResponse(Integer code) {
		
		this.code = code;
	}
	
	public ApiResponse() {}

	def Integer code;
	def String type;
	def String message;
	
	@Override
	public String toString() {
		return new StringJoiner(", ", ApiResponse.class.getSimpleName() + "[", "]")
			.add("code=" + this.code + "'")
			.add("type=" + this.type + "'")
			.add("message='" + this.message + "'")
			.toString();
	}	
	
}
