package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASCriminalBehavior;

public class CriminalBehavior extends SASTemplate {
	
	public CriminalBehavior() {}
	
	def isSocialEngineeringRat;
	def nonHumanMouseBehaviour;
	def concurrentSessions;
	def exportData;
	def riskyBrowser;
	def riskyImportExport;
	def riskyKeyCombo;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASCriminalBehavior);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", CriminalBehavior.class.getSimpleName() + "[", "]")
			.add("isSocialEngineeringRat='" + this.isSocialEngineeringRat + "'")
			.add("nonHumanMouseBehaviour='" + this.nonHumanMouseBehaviour + "'")
			.add("concurrentSessions='" + this.concurrentSessions + "'")
			.add("exportData='" + this.exportData + "'")
			.add("riskyBrowser='" + this.riskyBrowser + "'")
			.add("riskyImportExport='" + this.riskyImportExport + "'")
			.add("riskyKeyCombo='" + this.riskyKeyCombo + "'")
			.toString();
	}
}
