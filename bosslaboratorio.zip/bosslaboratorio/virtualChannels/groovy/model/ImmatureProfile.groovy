package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASImmatureProfile;

public class ImmatureProfile extends SASTemplate {
	
	public ImmatureProfile() {}
	
	def newUser;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASImmatureProfile);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", ImmatureProfile.class.getSimpleName() + "[", "]")
			.add("newUser='" + this.newUser + "'")
			.toString();
	}
}
