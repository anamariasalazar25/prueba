package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASBrowserAnomaly;

public class BrowserAnomaly extends SASTemplate {
	
	public BrowserAnomaly() {}
	
	def newBrowser;
	def rareBrowser;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASBrowserAnomaly);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", BrowserAnomaly.class.getSimpleName() + "[", "]")
			.add("newBrowser='" + this.newBrowser + "'")
			.add("rareBrowser='" + this.rareBrowser + "'")
			.toString();
	}
}
