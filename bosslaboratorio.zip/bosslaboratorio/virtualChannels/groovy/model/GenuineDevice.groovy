package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASGenuineDevice;

public class GenuineDevice extends SASTemplate {
	
	public GenuineDevice() {}
	
	def consistentDevice;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASGenuineDevice);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", GenuineDevice.class.getSimpleName() + "[", "]")
			.add("consistentDevice='" + this.consistentDevice + "'")
			.toString();
	}
}
