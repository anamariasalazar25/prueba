package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASRiskyEvent;

public class RiskyEvent extends SASTemplate {
	
	public RiskyEvent() {}
	
	def riskyAmount;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASRiskyEvent);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", RiskyEvent.class.getSimpleName() + "[", "]")
			.add("riskyAmount='" + this.riskyAmount + "'")
			.toString();
	}
}
