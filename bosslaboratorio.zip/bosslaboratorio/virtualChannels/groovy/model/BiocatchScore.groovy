package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASBiocatchScore;

public class BiocatchScore extends SASTemplate {
	
	public BiocatchScore() {}
	
	private String score2;
	
	def GenuineFactors genuineFactors;
	def String ipGeoASN;
	def String ipGeoCity;
	def isBot;
	def isEmulator;
	def isRat;
	def isRecentRat;
	def String muid;
	def String policyAction;
	def Integer policyID;
	def String policyName;
	def RiskFactors riskFactors;
	def Integer score;
		
	/**
	 * Get scoreBiocatch
	 * @return
	 */
	public Integer getScore2() {
		
		if(this.score2 != null) {
			
			try {
				return Integer.parseInt(this.score2);
			}
			
			catch(Exception e) {
				// No puede convertirse a int (valor inválido)
				return -1;
			}
		}
		return -1;
	}
		
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASBiocatchScore);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", BiocatchScore.class.getSimpleName() + "[", "]")
			.add("genuineFactors=" + this.genuineFactors)
			.add("ipGeoASN='" + this.ipGeoASN + "'")
			.add("ipGeoCity='" + this.ipGeoCity + "'")
			.add("isBot='" + this.isBot + "'")
			.add("isEmulator='" + this.isEmulator + "'")
			.add("isRat='" + this.isRat + "'")
			.add("isRecentRat='" + this.isRecentRat + "'")
			.add("muid='" + this.muid + "'")
			.add("policyAction='" + this.policyAction + "'")
			.add("policyID='" + this.policyID + "'")
			.add("policyName='" + this.policyName + "'")
			.add("riskFactors=" + this.riskFactors)
			.add("score='" + this.score + "'")
			.add("score2='" + this.score2 + "'")
			.toString();
	}
}


