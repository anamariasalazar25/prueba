package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASNetworkAnomaly;

public class NetworkAnomaly extends SASTemplate {
	
	public NetworkAnomaly() {}
	
	def ipMismatchAnomaly;
	def newAsn;
	def newIp;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASNetworkAnomaly);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", NetworkAnomaly.class.getSimpleName() + "[", "]")
			.add("ipMismatchAnomaly='" + this.ipMismatchAnomaly + "'")
			.add("newAsn='" + this.newAsn + "'")
			.add("newIp='" + this.newIp + "'")
			.toString();
	}
}
