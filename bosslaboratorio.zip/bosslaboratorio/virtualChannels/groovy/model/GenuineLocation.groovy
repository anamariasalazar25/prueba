package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASGenuineLocation;

public class GenuineLocation extends SASTemplate {
	
	public GenuineLocation() {}
	
	def consistentIP;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASGenuineLocation);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", GenuineLocation.class.getSimpleName() + "[", "]")
			.add("consistentIP='" + this.consistentIP + "'")
			.toString();
	}
}
