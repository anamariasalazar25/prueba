package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASRiskyLinking;

public class RiskyLinking extends SASTemplate {
	
	public RiskyLinking() {}
	
	def isRecentHighRiskSession;
	def recentLinkedDevice;
	def recentLinkedIp;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASRiskyLinking);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", RiskyLinking.class.getSimpleName() + "[", "]")
			.add("isRecentHighRiskSession='" + this.isRecentHighRiskSession + "'")
			.add("recentLinkedDevice='" + this.recentLinkedDevice + "'")
			.add("recentLinkedIp='" + this.recentLinkedIp + "'")
			.toString();
	}
}
