package virtualChannels.groovy.model;

import java.util.StringJoiner;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASAuthenRes;

public class AuthenticationResult extends SASTemplate {
	
	public AuthenticationResult() {}
	
	def String authenticationResult;
	def String authMethodUsed;
	def Integer facialScoreValue;
	def String scoreValue2;
	
	// 	Valores validos en el fingerprint
	def ArrayList validSegments;
	
	@Override
	public Map<String,Object> obtainSASFormat() {	
		return super.sasValidation(this, SASAuthenRes);
		
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", AuthenticationResult.class.getSimpleName() + "[", "]")
			.add("authenticationResult='" + this.authenticationResult + "'")
			.add("authMethodUsed='" + this.authMethodUsed + "'")
			.add("facialScoreValue='" + this.facialScoreValue + "'")
			.add("scoreValue2='" + this.scoreValue2 + "'")
			.add("validSegment='s" + this.validSegments + "'")
			.toString();
	}

}