package virtualChannels.groovy.model

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASRiskyLocation;

public class RiskyLocation extends SASTemplate {
	
	public RiskyLocation() {}
	
	def fastTraveler;
	def riskyIp;
	def riskyISP;
	def timeZoneMismatch;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASRiskyLocation);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", RiskyLocation.class.getSimpleName() + "[", "]")
			.add("fastTraveler='" + this.fastTraveler + "'")
			.add("riskyIp='" + this.riskyIp + "'")
			.add("riskyISP='" + this.riskyISP + "'")
			.add("timeZoneMismatch='" + this.timeZoneMismatch + "'")
			.toString();
	}
}
