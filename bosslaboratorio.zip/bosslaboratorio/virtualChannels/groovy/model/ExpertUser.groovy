package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASExpertUser;

public class ExpertUser extends SASTemplate {
	
	public ExpertUser() {}
	
	def advancedKeyCombo;
	def appToggle;
	def developerTools;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASExpertUser);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", ExpertUser.class.getSimpleName() + "[", "]")
			.add("advancedKeyCombo='" + this.advancedKeyCombo + "'")
			.add("appToggle='" + this.appToggle + "'")
			.add("developerTools='" + this.developerTools + "'")
			.toString();
	}
}
