package virtualChannels.groovy.model.sas.interfaces;

public interface SASInterface  {
	
	public String getAtt();
	
	public Integer getMinLength();
	
	public Integer getMaxLength();
	
	public String getSegment();
	
	public Boolean getReq();
	
}
