package virtualChannels.groovy.model.sas.enums

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASRiskyLocation implements SASInterface {
	
	fastTraveler("rua_numeric_045", 8, 8, "RUA", false),
	riskyIp("rua_numeric_046", 8, 8, "RUA", false),
	riskyISP("rua_numeric_047", 8, 8, "RUA", false),
	timeZoneMismatch("rua_numeric_048", 8, 8, "RUA", false)
	
	private final String riskyLocation;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;

	private SASRiskyLocation(final String riskyLocation, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.riskyLocation = riskyLocation;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	
	public static SASInterface valueOfElement(String name) {
		try {
			def val = SASRiskyLocation.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.riskyLocation;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}
