package virtualChannels.groovy.model.sas.enums

import java.util.Map;
import java.util.HashMap;

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASEmailAge implements SASInterface {
	
	email("dua_80byte_string_003", 80, 80, "DUA", false),
	name("xqo_cust_name", 100, 100, "XQO", false),
	phone("hqo_pb_userid", 50, 50, "HQO", false),
	billAddress("xqo_address", 100, 100, "HQO", false),
	billCity("dua_20byte_string_004", 20, 20, "DUA", false),
	billCountry("rua_10byte_string_005", 10, 10, "RUA", false)
	
	private final String emailAgeAtt;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	

	private SASEmailAge(final String emailAgeAtt, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.emailAgeAtt = emailAgeAtt;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}
	
	
	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASEmailAge.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}

	@Override
	public String getAtt() {
		return this.emailAgeAtt;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}
