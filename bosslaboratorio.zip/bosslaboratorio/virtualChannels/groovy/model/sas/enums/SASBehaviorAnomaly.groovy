package virtualChannels.groovy.model.sas.enums

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASBehaviorAnomaly implements SASInterface {
	
	isLongSession("rua_ind_005", 1, 1, "RUA", false),
	keyMouseAnomaly("rua_ind_006", 1, 1, "RUA", false),
	loginImportAnomaly("rua_ind_007", 1, 1, "RUA", false),
	osChangeAnomaly("rua_ind_008", 1, 1, "RUA", false),
	privateBrowsingAnomaly("rua_ind_009", 1, 1, "RUA",false),
	rareTypingPatternsAnomaly("rua_ind_010", 1, 1, "RUA", false)
	
	private final String behaviorAnomaly;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;

	private SASBehaviorAnomaly(final String behaviorAnomaly, final Integer minLength, final Integer maxLength, final String segment, 
		final Boolean req) {
		
		this.behaviorAnomaly = behaviorAnomaly;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	
	public static SASInterface valueOfElement(String name) {
		try {
			def val = SASBehaviorAnomaly.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.behaviorAnomaly;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}
