package virtualChannels.groovy.model.sas.enums

import java.util.Map;
import java.util.HashMap;

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASAuthenRes implements SASInterface {
	
	authenticationResult("dua_8byte_string_008", 8, 8, "DUA", false),
	authMethodUsed("dee_entity_id_6", 80, 80, "DEE", false),
	facialScoreValue("rua_numeric_003", 8, 8, "RUA", false),
	scoreValue2("rua_numeric_060", 8, 8, "RUA", false)
	
	
	private final String authenResAtt;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	

	private SASAuthenRes(final String authenResAtt, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.authenResAtt = authenResAtt;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}
	
	
	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASAuthenRes.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.authenResAtt;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}
