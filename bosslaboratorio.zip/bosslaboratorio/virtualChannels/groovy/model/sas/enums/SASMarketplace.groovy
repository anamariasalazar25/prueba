package virtualChannels.groovy.model.sas.enums;

import java.util.Map;
import java.util.HashMap;

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASMarketplace implements SASInterface {
	
	numPointsUsed("dua_numeric_001", 8, 8, "DUA", false),
	numAvailPoints("dua_numeric_002", 8, 8, "DUA", false)
	
	
	private final String marketplaceAtt;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;

	private SASMarketplace(final String marketplaceAtt, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.marketplaceAtt = marketplaceAtt;
		this.minLength = minLength;
		this.maxLength = maxLength;		
		this.segment = segment;
		this.req = req;
	}
	
	
	public static SASInterface valueOfElement(String name) {

		try {
			def val = SASMarketplace.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.marketplaceAtt;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}

	@Override
	public Boolean getReq() {
		return this.req;
	}
}


