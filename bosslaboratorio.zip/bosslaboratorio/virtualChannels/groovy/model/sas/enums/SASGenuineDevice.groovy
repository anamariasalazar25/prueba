package virtualChannels.groovy.model.sas.enums

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASGenuineDevice implements SASInterface {
	
	consistentDevice("rua_numeric_049", 8, 8, "RUA", false)
	
	private final String genuineDevice;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	

	private SASGenuineDevice(final String genuineDevice, final Integer minLength, final Integer maxLength, final String segment, 
		final Boolean req) {
		
		this.genuineDevice = genuineDevice;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}
	
	
	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASGenuineDevice.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.genuineDevice;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}
