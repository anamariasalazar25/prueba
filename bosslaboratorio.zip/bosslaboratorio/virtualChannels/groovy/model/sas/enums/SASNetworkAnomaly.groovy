package virtualChannels.groovy.model.sas.enums

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASNetworkAnomaly implements SASInterface {
	
	ipMismatchAnomaly("rua_ind_026", 1, 1, "RUA", false),
	newAsn("rua_ind_027", 1, 1, "RUA", false),
	newIp("rua_ind_028", 1, 1, "RUA", false)
	
	private final String networkAnomaly;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;

	private SASNetworkAnomaly(final String networkAnomaly, final Integer minLength, final Integer maxLength, final String segment, 
		final Boolean req) {
		
		this.networkAnomaly = networkAnomaly;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	
	public static SASInterface valueOfElement(String name) {
		try {
			def val = SASNetworkAnomaly.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.networkAnomaly;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}
