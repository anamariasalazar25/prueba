package virtualChannels.groovy.model.sas.enums

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASLowDataFamiliarity implements SASInterface {
	
	importData("rua_ind_024", 1, 1, "RUA",false),
	riskyImport("rua_ind_025", 1, 1, "RUA", false)
	
	
	private final String lowDataFamiliarity;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;

	private SASLowDataFamiliarity(final String lowDataFamiliarity, final Integer minLength, final Integer maxLength, final String segment, 
		final Boolean req) {
		
		this.lowDataFamiliarity = lowDataFamiliarity;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	
	public static SASInterface valueOfElement(String name) {
		try {
			def val = SASLowDataFamiliarity.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.lowDataFamiliarity;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}
