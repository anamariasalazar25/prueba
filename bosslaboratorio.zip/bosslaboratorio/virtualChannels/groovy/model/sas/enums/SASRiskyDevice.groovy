package virtualChannels.groovy.model.sas.enums;

import java.util.Map;
import java.util.HashMap;

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASRiskyDevice implements SASInterface {
	
	recentRiskyDevice("rua_numeric_040", 8, 8, "RUA", false),
	riskyGlobalUniqueDeviceId("rua_numeric_041", 8, 8, "RUA",false),
	rareCoresAnomaly("rua_numeric_055", 8, 8, "RUA", false),
	deviceChangeAnomaly("rua_ind_029", 1, 1, "RUA", false),
	newDevice("rua_ind_030", 1, 1, "RUA", false),
	newDeviceConsistentIp("rua_ind_031", 1, 1, "RUA", false),
	rareCores("rua_ind_032", 1, 1, "RUA", false)
	
	private final String riskDeviceAtt;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	

	private SASRiskyDevice(final String riskDeviceAtt, final Integer minLength,  final Integer maxLength, final String segment, final Boolean req) {
		this.riskDeviceAtt = riskDeviceAtt;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}
	
	
	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASRiskyDevice.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.riskDeviceAtt;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}


