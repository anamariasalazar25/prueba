package virtualChannels.groovy.model.sas.enums

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASCriminalBehavior implements SASInterface {
	
	isSocialEngineeringRat("rua_numeric_053", 8, 8, "RUA",false),
	nonHumanMouseBehaviour("rua_numeric_054", 8, 8, "RUA", false),
	concurrentSessions("rua_ind_015", 1, 1, "RUA", false),
	exportData("rua_ind_016", 1, 1, "RUA", false),
	riskyBrowser("rua_ind_017", 1, 1, "RUA", false),
	riskyImportExport("rua_ind_018", 1, 1, "RUA",false),
	riskyKeyCombo("rua_ind_019", 1, 1, "RUA", false)
	
	private final String criminalBehavior;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;

	private SASCriminalBehavior(final String criminalBehavior, final Integer minLength, final Integer maxLength, final String segment, 
		final Boolean req) {
		
		this.criminalBehavior = criminalBehavior;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	
	public static SASInterface valueOfElement(String name) {
		try {
			def val = SASCriminalBehavior.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.criminalBehavior;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}
