package virtualChannels.groovy.model.sas.enums;

import java.util.Map;
import java.util.HashMap;

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASEmailAgeScore implements SASInterface {
	
	phone_status("rua_8byte_string_003", 8, 8, "RUA", false),
	ip_riskreasonid("rua_numeric_011",  8, 8, "RUA", false),
	EARiskBand("rua_numeric_005", 8, 8, "RUA", false),
	emailAgeDate("hdf_dev_date", 8, 8, "HDF", false),
	emailAgeTime("hdf_dev_time", 8, 8, "HDF", false),
	source_industry("dnu_u_string1", 40, 40, "DNU", false),
	totalhits("rua_numeric_038", 8, 8, "RUA", false),
	domainname("dee_entity_id_5", 60, 60, "DEE", false),
	EAReasonID("rua_numeric_006", 8, 8, "RUA", false),
	domainrisklevelID("rua_numeric_008", 8, 8, "RUA", false),
	ip_corporateProxy("rua_8byte_string_002", 8, 8, "RUA", false),
	ipcountrymatch("dua_8byte_string_003", 8, 8, "DUA", false),
	ipaddress("hdf_dev_ip_address", 23, 23, "HDF", false),
	ip_region("dua_40byte_string_003", 40, 40, "DUA", false),
	domaincorporate("dua_8byte_string_006", 8, 8, "DUA", false),
	ip_netSpeedCell("rua_10byte_string_004", 10, 10, "RUA", false),
	domainrelevantinfo("rua_numeric_009", 8, 8, "RUA", false),
	uniquehits("rua_numeric_039", 8, 8, "RUA", false),
	ip_longitude("dnu_u_amt2", 22, 22, "DNU", false),
	ip_org("hob_ip_isp", 40, 40, "HOB", false),
	ip_userType("dnu_u_string3",40, 40, "DNU", false),
	lastflaggedon("dua_20byte_string_003", 20, 20, "DUA", false),
	ip_reputation("dua_20byte_string_002", 20, 20, "DUA", false),
	EAAdviceID("rua_numeric_007", 8, 8, "RUA", false),
	company("dnu_u_string4", 40, 40, "DNU", false),
	ip_anonymousdetected("dua_8byte_string_007", 8, 8, "DUA", false),
	fraud_type("dnu_u_string2", 40, 40, "DNU", false),
	ip_risklevelid("rua_numeric_010", 8, 8, "RUA", false),
	EARiskBandID("rua_numeric_005", 8, 8, "RUA", false),
	emailExists("dua_20byte_string_001", 20, 20, "DUA", false),
	EAScore("rua_4byte_string_001", 4, 4, "RUA", false),
	ip_city("dua_40byte_string_004", 40, 40, "DUA", false),
	ip_latitude("dnu_u_amt1", 22, 22, "DNU", false),
	domainrelevantinfoID("rua_numeric_009", 8, 8, "RUA", false),
	domainAge("dee_entity_id_1", 20, 20, "DEE", false),
	ipdomain("dua_80byte_string_005", 80, 80, "DUA", false),
	ip_countryconf("rua_numeric_012", 8, 8, "RUA", false),
	ip_regionconf("rua_numeric_013", 8, 8, "RUA", false),
	ip_cityconf("rua_numeric_014", 8, 8, "RUA", false),
	ip_postalconf("rua_numeric_015", 8, 8, "RUA", false),
	ip_riskscore("rua_numeric_016", 8, 8, "RUA", false),
	phoneownertype("dua_40byte_string_005", 40, 40, "DUA", false),
	issuerCountry("rua_2byte_string_005", 2, 2, "RUA", false),
	deviceIdRiskLevel("rua_20byte_string_004", 20, 20, "RUA", false),
	overallDigitalIdentityScore("rua_numeric_017", 8, 8, "RUA", false),
	emailToIpConfidence("rua_numeric_018", 8, 8, "RUA", false),
	emailToPhoneConfidence("rua_numeric_019", 8, 8, "RUA", false),
	emailToBillAddressConfidence("rua_numeric_020", 8, 8, "RUA", false),
	emailToShipAddressConfidence("rua_numeric_021", 8, 8, "RUA", false),
	emailToFullNameConfidence("rua_numeric_022", 8, 8, "RUA", false),
	emailToLastNameConfidence("rua_numeric_023", 8, 8, "RUA", false),
	ipToPhoneConfidence("rua_numeric_024", 8, 8, "RUA", false),
	ipToBillAddressConfidence("rua_numeric_025", 8, 8, "RUA", false),
	ipToShipAddressConfidence("rua_numeric_026", 8, 8, "RUA", false),
	ipToFullNameConfidence("rua_numeric_027", 8, 8, "RUA", false),
	ipToLastNameConfidence("rua_numeric_028", 8, 8, "RUA", false),
	phoneToBillAddressConfidence("rua_numeric_029", 8, 8, "RUA", false),
	phoneToShipAddressConfidence("rua_numeric_030", 8, 8, "RUA", false),
	phoneToFullNameConfidence("rua_numeric_031", 8, 8, "RUA", false),
	phoneToLastNameConfidence("rua_numeric_032", 8, 8, "RUA", false),
	billAddressToFullNameConfidence("rua_numeric_033", 8, 8, "RUA", false),
	billAddressToLastNameConfidence("rua_numeric_034", 8, 8, "RUA", false),
	shipAddressToBillAddressConfidence("rua_numeric_035", 8, 8, "RUA", false),
	shipAddressToFullNameConfidence("rua_numeric_036", 8, 8, "RUA", false),
	shipAddressToLastNameConfidence("rua_numeric_037", 8, 8, "RUA", false)
	
	private final String emailAgeScoreAtt;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	

	private SASEmailAgeScore(final String emailAgeScoreAtt, final Integer minLength, final Integer maxLength, final String segment,  
		final Boolean req) {
		
		this.emailAgeScoreAtt = emailAgeScoreAtt;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}
	
	
	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASEmailAgeScore.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.emailAgeScoreAtt;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}

