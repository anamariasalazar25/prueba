package virtualChannels.groovy.model.sas.enums

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASExpertUser implements SASInterface {
	
	advancedKeyCombo("rua_ind_020", 1, 1, "RUA", false),
	appToggle("rua_ind_021", 1, 1, "RUA", false),
	developerTools("rua_ind_022", 1, 1, "RUA", false)
	

	private final String SASExpertUser;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;

	private SASExpertUser(final String SASExpertUser, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.SASExpertUser = SASExpertUser;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	
	public static SASInterface valueOfElement(String name) {
		try {
			def val = SASExpertUser.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.SASExpertUser;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
	
}

