package virtualChannels.groovy.model.sas.enums

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASRiskyLinking implements SASInterface {
	
	isRecentHighRiskSession("rua_numeric_042", 8, 8, "RUA", false),
	recentLinkedDevice("rua_numeric_043", 8, 8, "RUA",false),
	recentLinkedIp("rua_numeric_044", 8, 8, "RUA", false),
	
	
	private final String riskyLinking;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	
	private SASRiskyLinking(final String riskyLinking, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.riskyLinking = riskyLinking;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	
	public static SASInterface valueOfElement(String name) {
		try {
			def val = SASRiskyLinking.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.riskyLinking;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}
