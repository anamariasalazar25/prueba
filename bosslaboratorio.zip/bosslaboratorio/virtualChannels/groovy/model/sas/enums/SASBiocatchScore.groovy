package virtualChannels.groovy.model.sas.enums;

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASBiocatchScore implements SASInterface {
	
	ipGeoASN("dua_80byte_string_002", 80, 80, "DUA", false),
	ipGeoCity("hob_ip_city", 60, 60, "HOB", false),
	isBot("rua_ind_001", 1, 1, "RUA", false),
	isEmulator("rua_ind_002", 1, 1, "RUA", false),
	isRat("rua_ind_003", 1, 1, "RUA", false),
	isRecentRat("rua_ind_004", 1, 1, "RUA", false),
	muid("hqo_device_id", 100, 100, "HQO", false),
	policyAction("rua_20byte_string_003", 20, 20, "RUA", false),
	policyID("rua_numeric_004", 8, 8, "RUA", false),
	policyName("dee_entity_id_4", 60, 60, "DEE", false),
	score("rua_numeric_001", 8, 8, "RUA", false),
	score2("rua_numeric_002", 8, 8, "RUA", false)
	
	
	private final String bioScoreeAtt;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	

	private SASBiocatchScore(final String bioScoreeAtt, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.bioScoreeAtt = bioScoreeAtt;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}
	
	
	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASBiocatchScore.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.bioScoreeAtt;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}


