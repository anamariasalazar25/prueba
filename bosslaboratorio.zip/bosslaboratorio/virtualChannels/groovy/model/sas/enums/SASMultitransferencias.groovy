package virtualChannels.groovy.model.sas.enums;

import java.util.Map;
import java.util.HashMap;

import virtualChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASMultitransferencias implements SASInterface {
	
	//adicion multitransferencias
	activityAmountTotal("tbt_group_amt", 5, 22, "TBT", false),
	batchFilePayeesNumber("tbt_group_cnt", 1, 3, "TBT", false),
	batchFileCreationDate("dmx_date_01", 8, 8, "DMX", false),
	batchFileEditionDate("dmx_date_02", 8, 8, "DMX", false)
	
	
	private final String multitransferenciasAtt;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;

	private SASMultitransferencias(final String multitransferenciasAtt, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.multitransferenciasAtt = multitransferenciasAtt;
		this.minLength = minLength;
		this.maxLength = maxLength;		
		this.segment = segment;
		this.req = req;
	}
	
	
	public static SASInterface valueOfElement(String name) {

		try {
			def val = SASMultitransferencias.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.multitransferenciasAtt;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}

	@Override
	public Boolean getReq() {
		return this.req;
	}
}
