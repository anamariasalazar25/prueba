package virtualChannels.groovy.model;

import java.util.StringJoiner;
import java.util.Map;
import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonIgnore;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASEmailAge;

public class EmailAge extends SASTemplate {
	
	public EmailAge() {}

	def String email;
	def String firstName;
	def String lastName;
	def String phone;
	def String billAddress;
	def String billCity;
	def String billCountry;
	
	
	public String getName() {
		if(this.firstName == null || this.lastName == null ) return '';
		return this.firstName + " " + this.lastName;
	} 
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		
		return super.sasValidation(this, SASEmailAge);
		
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", EmailAge.class.getSimpleName() + "[", "]")
			.add("email='" + this.email + "'")
			.add("firstName='" + this.firstName + "'")
			.add("lastName='" + this.lastName + "'")
			.add("name='" + this.getName() + "'")
			.add("mobilePhoneNumber='" + this.phone + "'")
			.add("billAddress='" + this.billAddress + "'")
			.add("billCity='" + this.billCity + "'")
			.add("billCountry='" + this.billCountry + "'")
			.toString();
	}

}

