package virtualChannels.groovy.model.enums;

import com.fasterxml.jackson.annotation.JsonCreator
import com.google.gson.annotations.SerializedName;
 
public enum TpoPersona {
	
	CO_DAVIVIENDA_PN("CO_DAVIVIENDA_PN", "I","CV_PERSONAS"),
	CO_DAVIVIENDA_PJ("CO_DAVIVIENDA_PJ", "B","CV_EMPRESAS"),
	DEFAULT("", "","")
	
	
	private final String tpoPersonaName;
	private final String tpoPersonaSMH;
	private final String tpoPersonaMulti;
	
	private TpoPersona(final String tpoPersonaName, final String tpoPersonaSMH,final String tpoPersonaMulti) {
		this.tpoPersonaName = tpoPersonaName;
		this.tpoPersonaSMH = tpoPersonaSMH;
		this.tpoPersonaMulti = tpoPersonaMulti;
	}
	
	@Override
	public String toString() {
		return this.tpoPersonaName;
	}
	
	@JsonCreator
	public static TpoPersona fromValue(String value) {
		
		if(value != null && value != "") {
			return TpoPersona.valueOf(value)
		}
		
		return TpoPersona.DEFAULT;
	}
}
