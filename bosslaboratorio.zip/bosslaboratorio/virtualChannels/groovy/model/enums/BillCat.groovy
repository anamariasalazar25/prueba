package virtualChannels.groovy.model.enums;

public enum BillCat {

	UT("UT"),
	CA("CA"),
	SV("SV"),
	OT("OT"),
	Blank("")
	
	
	private final String billCat;
	
	private BillCat(final String billCat) {
		this.billCat = billCat;
	}
	
	@Override
	public String toString() {
		return this.billCat;
	}

}
