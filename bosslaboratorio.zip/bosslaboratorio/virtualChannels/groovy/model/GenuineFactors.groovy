package virtualChannels.groovy.model

import com.google.gson.annotations.SerializedName;

import virtualChannels.groovy.model.sas.SASTemplate;

public class GenuineFactors extends SASTemplate {
	
	public GenuineFactors() {}
	
	def GenuineDevice genuineDevice;
	def GenuineLocation genuineLocation;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, null);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", GenuineFactors.class.getSimpleName() + "[", "]")
			.add("genuineDevice=" + this.genuineDevice)
			.add("genuineLocation=" + this.genuineLocation)
			.toString();
	}
}
