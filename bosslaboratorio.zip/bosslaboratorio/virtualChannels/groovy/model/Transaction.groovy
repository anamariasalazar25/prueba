package virtualChannels.groovy.model;

import java.util.StringJoiner;

import java.util.Map;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonIgnore
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken
import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.JsonAdapter;

import virtualChannels.groovy.tools.GsonBuilderFormat;
import virtualChannels.groovy.tools.Common;
import virtualChannels.groovy.model.enums.ActivityName;
import virtualChannels.groovy.model.enums.ActivityType;
import virtualChannels.groovy.model.enums.ActivityTypeName;
import virtualChannels.groovy.model.sas.enums.SASTransaction;
import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.tools.deserializers.Base64TypeAdapterFactory;

public class Transaction extends SASTemplate {
	
	public Transaction() {}
		
	def Payeer payeer;
	def Payee payee;
	def String enterpriseCustomerId;
	def String sessionId;
	def String platformType;
	def ActivityName activityName;
	def ActivityType activityType;
	def Double activityAmount;
	def String transactionId;
	def String cusPSE; 
	def String referenceNumber1;
	def String referenceNumber2; 
	def String selfCustomerTransferIndicator;
	def String agreementId; 
	def String transactionDate;
	def String transactionTime;
	def String transactionDateGMT;
	def String transactionTimeGMT;
	def String ipAddress;
	def String userType;
	def String userAgent;
	def Marketplace marketPlace;
	def Multitransferencias multiTransfer; //adicion multitransferencias
	def hasBiocatchResponse;
	@JsonAdapter(Base64TypeAdapterFactory.class)
	def BiocatchScore biocatchScoreInformation; 
	def EmailAge emailAge;
	@JsonAdapter(Base64TypeAdapterFactory.class)
	def List<EmailAgeScore> emailAgeScoreInformation;
	
	// 	Valores válidos en el fingerprint
	def ArrayList validSegments;
		
	public String getActivityTypeSMH() {
		
		String actName = this.activityName.toString();
		String actType = this.activityType.toString();
		
		if(actName.equals('null') || actType.equals('null') ) return null;
		
		try {
			return ActivityTypeName.valueOf(actType + "_" + actName).activityTypeSMH;
		}
		
		catch(Exception e) {
			return "";
		}
	}
	
	public String getActivityTypeTBT() {
		if(this.activityType != null) {
			return this.activityType.tranTypeTBT;
		}
		return "";
	}
	
	public String getBankTypeTPP() {
		
		String actName = this.activityName.toString();
		String actType = this.activityType.toString();
		
		if(actName.equals('null') || actType.equals('null') ) return null;
		
		try {
			return ActivityTypeName.valueOf(actType + "_" + actName).bankTypeTPP;
		}
		
		catch(Exception e) {
			return "";
		}
	}
	
	public Double getTranAmountTBT() {
		return this.activityAmount;
	}
	
	public Double getTranAmountModTBT() {
		return this.activityAmount;
	}
	
	public Double getTranAmountTDP() {
		return this.activityAmount;
	}
	
	public Double getTranAmountModTDP() {
		return this.activityAmount;
	}
	
	public String getUtcIndicator() {
		return "Y";
	}
	
	public String getAuthMethod() {
		return "NC";
	}
	
	public String getChannelType() {
		return "W";
	}
	
	public String getBillCat() {
		
		if(this.activityName != null) {
			return this.activityName.billCat.toString();
		}
		
		return "";
	}
	
	public String getActivityDetail1SMH() {
		
		String actDetail1 = "DMX";
		
		String activityType = this.getActivityTypeSMH();
		
		if(activityType != null) {
			
			if(activityType.equals("NM")) {
				actDetail1 = "DNU"
			}
		}
		
		return actDetail1;
	}
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		
		return super.sasValidation(this, SASTransaction);
	}
	
	public String getTppPayeePayerInd() {
		
		if(this.activityTypeSMH.equals("BF")) {
			return "E";
		}
		
		if(this.activityTypeSMH.equals("DP")) {
			return "R";
		}
		
		return null;
	}
		
	@Override
	public String toString() {
		return new StringJoiner(", ", Transaction.class.getSimpleName() + "[", "]")
			.add("payeer=" + this.payeer)
			.add("payee=" + this.payee)
			.add("enterpriseCustomerId='" + this.enterpriseCustomerId + "'")
			.add("sessionId=" + this.sessionId + "'")
			.add("platformType='" + this.platformType + "'")
			.add("activityName='" + this.getActivityName() + "'")
			.add("activityType='" + this.getActivityType() + "'")
			.add("activityTypeSMH='" + this.getActivityTypeSMH() + "'")
			.add("activityAmount='" + this.activityAmount+ "'")
			.add("transactionId='" + this.transactionId + "'")
			.add("cusPSE=" + this.cusPSE + "'")
			.add("referenceNumber1='" + this.referenceNumber1 + "'")
			.add("referenceNumber2='" + this.referenceNumber2 + "'")
			.add("selfCustomerTransferIndicator=" + this.selfCustomerTransferIndicator + "'")
			.add("agreementId='" + this.agreementId + "'")
			.add("transactionDate='" + this.transactionDate + "'")
			.add("transactionTime='" + this.transactionTime + "'")
			.add("ipAddress='" + this.ipAddress + "'")
			.add("marketPlace=" + this.marketPlace)
			.add("multiTransfer=" + this.multiTransfer) //adicion multitransferencias
			.add("hasBiocatchResponse='" + this.hasBiocatchResponse + "'")
			.add("biocatchScoreInformation='" + this.biocatchScoreInformation + "'")
			.add("emailAge=" + this.emailAge + "'")
			.add("emailAgeScoreInformation='" + this.emailAgeScoreInformation + "'")
			.toString();
	}

}


