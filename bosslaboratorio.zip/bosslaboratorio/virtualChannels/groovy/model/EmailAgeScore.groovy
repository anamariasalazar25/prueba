package virtualChannels.groovy.model

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonFormat;

import virtualChannels.groovy.model.sas.SASTemplate;
import virtualChannels.groovy.model.sas.enums.SASEmailAgeScore;
import virtualChannels.groovy.tools.deserializers.DatesFormats;

public class EmailAgeScore extends SASTemplate {
	
	public EmailAgeScore() {}
	
	def String phone_status;
	def Integer ip_riskreasonid;
	@JsonProperty("EARiskBand")
	def String EARiskBand;
	def Date emailAge;	
	def String source_industry;
	def Integer totalhits;
	def String domainname;
	def String ip_riskreason;
	@JsonProperty("EAReasonID")
	def EAReasonID;
	def Integer domainrisklevelID;
	def String ip_corporateProxy;
	def String ipcountrymatch;
	def String ipaddress;
	def String ip_region;
	def String domaincorporate;
	def String ip_netSpeedCell;
	def String domainrelevantinfo;
	def Integer uniquehits;
	def String ip_longitude;
	def String ip_org;
	def String ip_userType;
	def String lastflaggedon;
	def String ip_reputation;
	@JsonProperty("EAAdviceID")
	def Integer EAAdviceID ;
	def String company;
	def String ip_anonymousdetected;
	def String fraud_type;
	def Integer ip_risklevelid;
	@JsonProperty("EARiskBandID")
	def Integer EARiskBandID;
	def String emailExists;
	@JsonProperty("EAScore")
	def String EAScore;
	def String ip_city;
	def String ip_latitude;
	@JsonProperty("EAAdvice")
	def String EAAdvice;
	def Integer domainrelevantinfoID;
	def Date domainAge;
	def String ipdomain;
	def String ip_countryconf;
	def String ip_regionconf;
	def String ip_cityconf;
	def String ip_postalconf;
	def String ip_riskscore;
	def String phoneownertype;
	def String issuerCountry;
	def String deviceIdRiskLevel;
	def Integer overallDigitalIdentityScore;
	def Integer emailToIpConfidence;
	def Integer emailToPhoneConfidence;
	def Integer emailToBillAddressConfidence;
	def Integer emailToShipAddressConfidence;
	def Integer emailToFullNameConfidence;
	def Integer emailToLastNameConfidence;
	def Integer ipToPhoneConfidence;
	def Integer ipToBillAddressConfidence;
	def Integer ipToShipAddressConfidence;
	def Integer ipToFullNameConfidence;
	def Integer ipToLastNameConfidence;
	def Integer phoneToBillAddressConfidence;
	def Integer phoneToShipAddressConfidence;
	def Integer phoneToFullNameConfidence;
	def Integer phoneToLastNameConfidence;
	def Integer billAddressToFullNameConfidence;
	def Integer billAddressToLastNameConfidence;
	def Integer shipAddressToBillAddressConfidence;
	def Integer shipAddressToFullNameConfidence;
	def Integer shipAddressToLastNameConfidence;
	
	public String getEmailAgeDate() {
		if(this.emailAge != null) {
			return DatesFormats.changeDateFormat(DatesFormats.DATE_FORMAT_A, this.emailAge);
		}
		return "";
	}
	
	public String getEmailAgeTime() {
		if(this.emailAge != null) {
			return DatesFormats.changeDateFormat(DatesFormats.TIME_FORMAT_A, this.emailAge);
		}
		return "";
	}
	
	public String getDomainAgeDate() {
		if(this.domainAge != null) {
			return DatesFormats.changeDateFormat(DatesFormats.DATE_FORMAT_A, this.domainAge);
		}
		return "";
	}
	
	public String getDomainAgeTime() {
		if(this.domainAge != null) {
			return DatesFormats.changeDateFormat(DatesFormats.TIME_FORMAT_A, this.domainAge);
		}
		return "";
	}
	
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASEmailAgeScore);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", EmailAgeScore.class.getSimpleName() + "[", "]")
			.add("phone_status='" + this.phone_status + "'")
			.add("ip_riskreasonid='" + this.ip_riskreasonid + "'")
			.add("EARiskBand='" + this.EARiskBand + "'")
			.add("emailAge='" + this.emailAge + "'")
			.add("emailAgeTime'=" + this.getEmailAgeTime() + "'")
			.add("source_industry='" + this.source_industry + "'")
			.add("totalhits='" + this.totalhits + "'")
			.add("domainname='" + this.domainname + "'")
			.add("ip_riskreason='" + this.ip_riskreason + "'")
			.add("EAReasonID='" + this.EAReasonID + "'")
			.add("domainrisklevelID='" + this.domainrisklevelID + "'")
			.add("ip_corporateProxy='" + this.ip_corporateProxy + "'")
			.add("ipcountrymatch='" + this.ipcountrymatch + "'")
			.add("ipaddress='" + this.ipaddress + "'")
			.add("ip_region='" + this.ip_region + "'")
			.add("domaincorporate='" + this.domaincorporate + "'")
			.add("ip_netSpeedCell='" + this.ip_netSpeedCell + "'")
			.add("domainrelevantinfo='" + this.domainrelevantinfo + "'")
			.add("uniquehits='" + this.uniquehits + "'")
			.add("ip_longitude='" + this.ip_longitude + "'")
			.add("ip_org='" + this.ip_org + "'")
			.add("ip_userType='" + this.ip_userType + "'")
			.add("lastflaggedon='" + this.lastflaggedon + "'")
			.add("ip_reputation='" + this.ip_reputation + "'")
			.add("EAAdviceID='" + this.EAAdviceID + "'")
			.add("company='" + this.company + "'")
			.add("ip_anonymousdetected='" + this.ip_anonymousdetected + "'")
			.add("fraud_type='" + this.fraud_type + "'")
			.add("ip_risklevelid='" + this.ip_risklevelid + "'")
			.add("EARiskBandID='" + this.EARiskBandID + "'")
			.add("emailExists='" + this.emailExists + "'")
			.add("EAScore='" + this.EAScore + "'")
			.add("ip_city='" + this.ip_city + "'")
			.add("ip_latitude='" + this.ip_latitude + "'")
			.add("EAAdvice='" + this.EAAdvice + "'")
			.add("domainrelevantinfoID='" + this.domainrelevantinfoID + "'")
			.add("domainAge='" + this.domainAge + "'")
			.toString();
	}
}



