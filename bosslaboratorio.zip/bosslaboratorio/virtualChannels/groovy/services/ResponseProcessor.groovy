package virtualChannels.groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

import java.util.Map;
import org.json.JSONObject;

import com.sas.davivienda.efm.commons.util.FMResponseHelper
import virtualChannels.groovy.model.AuthorizationResult;
import virtualChannels.groovy.tools.GsonBuilderFormat;
import virtualChannels.groovy.tools.Common;
import com.sas.davivienda.efm.commons.util.FMUtils;

public class ResponseProcessor implements Processor {
	
	private static final Logger logger = LoggerFactory.getLogger("virtualChannelslog");
		
	public void process(Exchange exchange) {

		//JM -start
		Gson gson = GsonBuilderFormat.getGson();
		
		Map<String,String> odeResponse = exchange.getIn().getBody();
		// -end
		String responseCode = "";
		String cmxTranId = "";
		String acctType = "";
		String activityType = "";
		String tranId = "";
		String scoreBiocatch = "-1";
		String scoreSAS = "-1";
		
		try {
			Map<String,String> inputMsg = exchange.getProperty("inputMsg");
			if(inputMsg != null) {
				scoreBiocatch= inputMsg.get("rua_numeric_001");
			}
			
			if(odeResponse != null){
				acctType = odeResponse.get("smh_acct_type");
				activityType = odeResponse.get("smh_activity_type");
				tranId = odeResponse.get("cmx_tran_id");
				// Set scores values scoreSAS, scoreBiocatch
				scoreSAS = odeResponse.get("rrr_score_2");
			}
						
			String errorType = exchange.getProperty("errorType", String.class);
			responseCode = FMResponseHelper.getResponseCode(exchange);
			
			// ScoreSAS correct value
			if(FMUtils.isNullOrEmpty(scoreSAS) || (scoreSAS != null && "000".equals(scoreSAS)) ) {
				scoreSAS = "-1";
			}
			
			if(FMUtils.isNullOrEmpty(scoreBiocatch)) {
				scoreBiocatch = "-1";
			}
			
			if(FMUtils.hasValue(tranId) && ("00".equals(responseCode) || "02".equals(responseCode) || "76".equals(responseCode))){
				cmxTranId = acctType + activityType + tranId;
			}

			AuthorizationResult response = new AuthorizationResult(cmxTranId, responseCode, scoreSAS, scoreBiocatch);

			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			exchange.getIn().setBody(gson.toJson(response));
		}catch(Exception e) {
			e.printStackTrace();
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			AuthorizationResult resError = new AuthorizationResult("", "96", "-1", "-1");
			exchange.getIn().setBody(gson.toJson(resError));
		}finally {
			exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
			
			String trxInfoLog = exchange.getProperty("trxInfoLog",String.class);
			StringBuilder trxInfoLogTemp = new StringBuilder();
			trxInfoLogTemp.append(trxInfoLog).append(", resp-code:").append(responseCode).append(", cmx-tran-id:").append(cmxTranId);
			exchange.setProperty("trxInfoLog", trxInfoLogTemp.toString());
		}
	}
}
