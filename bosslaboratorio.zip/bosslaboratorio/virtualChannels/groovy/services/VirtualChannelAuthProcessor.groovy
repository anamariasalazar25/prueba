package virtualChannels.groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;

import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;

import virtualChannels.groovy.tools.Common;
import virtualChannels.groovy.tools.checks.Checks;
import virtualChannels.groovy.tools.checks.TransactionChecks;
import virtualChannels.groovy.tools.values.Segments;
import virtualChannels.groovy.tools.GsonBuilderFormat;
import virtualChannels.groovy.model.Transaction;
import virtualChannels.groovy.model.AuthorizationResult;
import virtualChannels.groovy.exceptions.VirtualChannelsException;
import com.sas.davivienda.efm.commons.util.FMUtils;
import com.sas.davivienda.efm.commons.exceptions.EFMException;

public class VirtualChannelAuthProcessor implements Processor {
		
	private static final Logger logger = LoggerFactory.getLogger("virtualChannelslog");
	
	public void process(Exchange exchange) {
		
		try {

			String body = exchange.getIn().getBody(String.class);

			Gson gson = GsonBuilderFormat.getGson();
			
			// Json String body to java object
			Transaction transaction = gson.fromJson(body, new TypeToken<Transaction>() {}.getType());

			if(transaction == null) {
				throw new VirtualChannelsException(222, "Invalid FingerPrint");
			}

			StringBuilder trxInfoLog = new StringBuilder();
			trxInfoLog.append("mti:0200")
						.append(", platform-type:").append(transaction.platformType)
						.append(", act-type:").append(transaction.activityType)
						.append(", act-Name:").append(transaction.activityName)
						.append(", date:").append(transaction.transactionDate)
						.append(", time:").append(transaction.transactionTime)
						.append(", ref-num:").append(transaction.transactionId)
						.append(", amt:").append(transaction.activityAmount);
			
			logger.info("Orq-auth-request: {}",trxInfoLog.toString());
			exchange.setProperty("trxInfoLog", trxInfoLog);
			
			// --- Add extra fields
			//Add activityAmount
			HashMap attsMap = new HashMap<String, String>();
			TransactionChecks.manageaActivityAmount(attsMap, transaction.activityAmount, transaction);

			transaction = TransactionChecks.checkTransAttributes(transaction);
			logger.info("transaction: {}",transaction);
			// SAS mapped transaction
			def sasTransactionMap = transaction.obtainSASFormat();
			
			TransactionChecks.checkPayeeFields(transaction, sasTransactionMap);
			TransactionChecks.checkNonMonFields(transaction, sasTransactionMap);
			TransactionChecks.enrichmentParams(transaction, sasTransactionMap);
			
			// -- Join final map with extra fields
			sasTransactionMap.putAll(attsMap);

			sasTransactionMap.put("hqo_msg_type", "0200");

			exchange.setProperty("inputMsg",sasTransactionMap);
			exchange.setProperty("transaction",transaction);
		}catch(Exception e) {
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			e.printStackTrace();
			exchange.getIn().setBody(null);
			String message = "Error al procesar la transaccion: " + e.getMessage();
			exchange.setProperty("errorType", "PROCESSING_ERROR");
			throw new EFMException(message);
		}
	}
	
	public void enrichDatabaseInfo(Exchange exchange) {
		def transaction = exchange.getProperty("transaction");
		def sasTransactionMap = exchange.getProperty("inputMsg");
		
		try {
			TransactionChecks.checkCustomFields(transaction, sasTransactionMap);
			exchange.getIn().setBody(sasTransactionMap);
		}catch(Exception e) {
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			exchange.getIn().setBody(null);
			String message = "Error al procesar la transaccion: " + e.getMessage();
			exchange.setProperty("errorType", "PROCESSING_ERROR");
			throw new EFMException(message);
		}
	}
}
