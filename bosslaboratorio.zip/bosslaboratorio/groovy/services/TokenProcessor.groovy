package groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import groovy.controller.Token;
import groovy.controller.TokenChecks;
import groovy.controller.Common;

public class TokenProcessor implements Processor {

	private static final Logger logger = LoggerFactory.getLogger("RequestProcessor");

	public void process(Exchange exchange) {
		
		try {			
			String generalTokenString = exchange.getProperty("DE127StructuredData", String.class);
			
			def tokenTypeAndValuesMap = TokenChecks.getTokenTypeAndValues(generalTokenString);
						
			if(tokenTypeAndValuesMap != null) {
				Map <String, Map <String, String>> sasMapTokens = new HashMap <String, Map <String, String>>();
				
				for (Map.Entry<String, String> tokenTypeAndValue : tokenTypeAndValuesMap.entrySet()) {
				
					String tokenCode = tokenTypeAndValue.key; 
					String tokenValue = tokenTypeAndValue.value;
					Token tokenObject = new Token(tokenCode.substring(6), tokenValue);
					
					Map <String, String> sasMapToken = TokenChecks.checkTokenValues(tokenObject);
					
					sasMapTokens.put(tokenCode, sasMapToken);
				}
                
                Map<String,Object> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
                for (Map.Entry<String, String> set :  sasMapTokens.entrySet()) {
                    enrichedMsgBody.putAll(set.getValue());
                }
                
				logger.info(sasMapTokens.toString())
			}
			
			else {
				logger.error("------------------------ Invalid token --------------------");
			}
		}

		catch(Exception e) {
			e.printStackTrace()
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
		}

		finally {
			exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
		}
		
	}

}
