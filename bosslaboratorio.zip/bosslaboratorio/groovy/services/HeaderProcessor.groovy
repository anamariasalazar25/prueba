package groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.sas.davivienda.efm.commons.util.FMUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Exchanger


public class HeaderProcessor implements Processor {

	private static final Logger logger = LoggerFactory.getLogger("HeaderProcessor");
	private static final String NAT_CARD_MON_MULTIORG = "NACIONAL";
	private static final String INT_CARD_MON_MULTIORG = "INTERNAL";
	private static final String CARD_NON_MON_MULTIORG = "NO_TX_TC_TD";
	private static final String DAVIPLATA_MULTIORG = "TARJ_DAVIPLATA";
	private static final String DAVIPLATA_BIN = "524708";

	public void process(Exchange exchange) {
		
		Map<String,Object> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
		try {
			
			String authenticateMethod = exchange.getProperty("authenticateMethod", String.class);
			
			String activityType = enrichedMsgBody.get("smh_activity_type");
			String issuerBin = enrichedMsgBody.get("rua_8byte_string_001");
			
			enrichedMsgBody.put("smh_authenticate_mtd", authenticateMethod);
			enrichedMsgBody.put("smh_multi_org_name", getMultiOrgNodeName(exchange, activityType,issuerBin));
			enrichedMsgBody.put("smh_resp_req", getResponseRequiredIndicator(exchange));
			
			enrichedMsgBody.put("smh_activity_detail1", "DMX");
			enrichedMsgBody.put("smh_activity_detail2", "DEE");
			enrichedMsgBody.put("smh_activity_detail3", "DUA");
	
		}catch(Exception e) {
			logger.error("ERR: {}",e.toString());
		}finally{
			logger.info("enrichedMsgBody: {}",enrichedMsgBody);
			exchange.getIn().setBody(enrichedMsgBody);
                }
	}
	
	/**
	 * 
	 * @param exchange
	 * @return
	 */
	public String getNatIntIndicator(Exchange exchange) {
		String nationalInternational = exchange.getProperty("NatInt",String.class);
		
		if(FMUtils.isNullOrEmpty(nationalInternational)){
			
			String countryIso = exchange.getProperty("merchantCountryIso",String.class);
			nationalInternational = "170".equals(countryIso) || FMUtils.isNullOrEmpty(countryIso) ? "N" : "I";
		}
		
		return nationalInternational;
	}
	
	/**
	 * 
	 * @param exchange
	 * @return
	 */
	public String getResponseRequiredIndicator(Exchange exchange) {
		
		String messageType = exchange.getProperty("mti", String.class);
		
		String respReq = "0200".equals(messageType) ? "1" :"0";
		exchange.setProperty("respRequired",respReq);
		
		return respReq;
	}
	
	/**
	 * 
	 */
	public String getMultiOrgNodeName(Exchange exchange, String activityType, String issuerBin) {
		String multiOrgName = CARD_NON_MON_MULTIORG;
		
		String nationalInternational = getNatIntIndicator(exchange);
		
		if("CA".equals(activityType)) {
			multiOrgName = "N".equals(nationalInternational) ? NAT_CARD_MON_MULTIORG: INT_CARD_MON_MULTIORG;
		}
		
		if(DAVIPLATA_BIN.equals(issuerBin)) {
			multiOrgName = DAVIPLATA_MULTIORG;
		}
		
		return multiOrgName;
	}
}
