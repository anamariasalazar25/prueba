import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.sas.davivienda.efm.commons.exceptions.EFMException;
import com.sas.davivienda.efm.commons.util.FMTrackDataParser;
import com.sas.davivienda.efm.commons.util.FMUtils;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sas.davivienda.efm.commons.dto.TableTerminalType;

public class ISOMapper {

	private static final Logger logger = LoggerFactory.getLogger("ISOMapper");
	//GMT-5
	private static final ZoneId LOCAL_TIME_ZONE = ZoneId.of("-5");
	private static final String SAS_DATETIME_FORMAT_STRING = "yyyyMMddHH:mm:ss";
	private static final String DATETIME_FORMAT_STRING = "yyyyMMddHHmmss";
	private static final DateTimeFormatter SAS_DATETIME_FORMAT = DateTimeFormatter.ofPattern(SAS_DATETIME_FORMAT_STRING);
	private static final DateTimeFormatter DATETIME_FORMATER = DateTimeFormatter.ofPattern(DATETIME_FORMAT_STRING);

	@Resource
	@Qualifier("cardPresentFromPosEntryMode")
	private Map<String, String> cardPresentFromPosEntryMode;

	@Resource
	@Qualifier("channelTypeFromTerminalType")
	private List<TableTerminalType> channelTypeFromTerminalType;

	@Resource
	@Qualifier("terminalIdList")
	private List<String> terminalIdList;

	public ISOMapper() {
		logger.info("Init ISOMapper");
	}

	/**
	 * Almacena los valores originales de la mensajeria requeridos para enriquecimiento   
	 * @param exchange
	 * @throws EFMException
	 */
	public void retrieveFieldsFromISO(Exchange exchange) throws EFMException {

		Map<String,String> enrichedMsgBody = new HashMap<String, String>();
		Map<String,String> isoMap = exchange.getProperty("8583MsgMap",Map.class);
		String mti = isoMap.get("0");
		String responseCode = isoMap.get("39");
		//Issue trackdata separator
		String productNumber = "";
		enrichedMsgBody.put("rua_2byte_string_003",responseCode);
		exchange.setProperty("responseCode", responseCode);
		exchange.setProperty("messageType", getMessageType(mti,responseCode));
		exchange.setProperty("mti", mti);
		enrichedMsgBody.put("hqo_msg_type", mti);
		exchange.setProperty("isResponseRequired", isResponseRequired(mti));

		String messageType = "";
		if("0800".equals(mti)) {
			messageType = "ECHO_TEST";
		}else {

			try {
				exchange.setProperty("smhTranType", "TRX");
				productNumber = isoMap.get("2");

				String procCode = isoMap.get("3");
				exchange.setProperty("procCode", procCode);
				enrichedMsgBody.put("rua_10byte_string_001", procCode);

				String trxAmt = isoMap.get("4");
				String settlementAmt = isoMap.get("5");
				String trxCurrencyCode = isoMap.get("49");
				String settlementCurrencyCode = isoMap.get("50");

				if(FMUtils.isNullOrEmpty(settlementAmt)){
					settlementAmt = trxAmt;
					settlementCurrencyCode = trxCurrencyCode;
				}

				exchange.setProperty("amountTransaction", settlementAmt);
				enrichedMsgBody.put("client_amt", FMUtils.addDecimalSeparator(settlementAmt));
				enrichedMsgBody.put("client_curr_code", settlementCurrencyCode);
				enrichedMsgBody.put("merch_amt", FMUtils.addDecimalSeparator(trxAmt));
				enrichedMsgBody.put("merch_curr_code", trxCurrencyCode);
				exchange.setProperty("referenceNumber", isoMap.get("37"));
				//requerimiento DCI Diners
				//String uniqueSeqNum = ""; 
				//if(isoMap.get("37").length() > 5) {
				//	uniqueSeqNum = isoMap.get("37").substring(5);
				//	enrichedMsgBody.put("dua_8byte_string_006", uniqueSeqNum);
				//}
				exchange.setProperty("dateTimeTransmission", isoMap.get("7"));
				enrichedMsgBody.put("dua_8byte_string_003", isoMap.get("11"));
				exchange.setProperty("timeLocal", isoMap.get("12"));
				exchange.setProperty("dateLocal", isoMap.get("13"));
				exchange.setProperty("merchantType", isoMap.get("18"));
				String posEntryMode = isoMap.get("22");
				exchange.setProperty("posEntryMode", posEntryMode);

				String posConditionCode = isoMap.get("25");
				exchange.setProperty("posConditionCode", posConditionCode);
				enrichedMsgBody.put("rua_3byte_string_001", posConditionCode);

				exchange.setProperty("acquiringIntCode", isoMap.get("32"));
				String trackii = isoMap.get("35");

				//Issue trackdata separator
				if(FMUtils.isNullOrEmpty(productNumber) && FMUtils.isNullOrEmpty(trackii)) {
					throw new EFMException("No es posible extraer información del producto");
				}

				String restrictionCode = "";
				String panTrackData = "";

				if(FMUtils.hasValue(trackii)){
					int separatorPosition =  FMTrackDataParser.getTrackSeparatorPosition(trackii);
					panTrackData = trackii.substring(0, separatorPosition);
					//ServiceCode
					restrictionCode = FMTrackDataParser.getRestrictionCode(trackii, separatorPosition+1);
				}

				if(FMUtils.isNullOrEmpty(productNumber)) {
					productNumber = panTrackData;
				}

				String serviceRestrCode = isoMap.get("40");

				if(FMUtils.isNullOrEmpty(serviceRestrCode) && FMUtils.hasValue(restrictionCode)) {
					serviceRestrCode = restrictionCode;
				}

				enrichedMsgBody.put("rua_3byte_string_003", serviceRestrCode);
				exchange.setProperty("productId", productNumber);
				enrichedMsgBody.put("card_num", productNumber);
				String issuerBin = productNumber.substring(0, 6);
				enrichedMsgBody.put("rua_8byte_string_001", issuerBin);

				String authRespone = isoMap.get("38");
				exchange.setProperty("authorizationIdResponse", authRespone);

				String cardAcceptorTerminalID = isoMap.get("41");
				if(cardAcceptorTerminalID == null) {
					cardAcceptorTerminalID = "";
				}

				exchange.setProperty("cardAcceptorTerminalID", cardAcceptorTerminalID);
				exchange.setProperty("cardAcceptorNameLocation", isoMap.get("43"));

				String pinData = isoMap.get("52");

				boolean isPinDataPresent = FMUtils.isNullOrEmpty(pinData) ? false : true;
				exchange.setProperty("isPinDataPresent", isPinDataPresent);
				exchange.setProperty("pinData", pinData);

				exchange.setProperty("additionalAmounts", isoMap.get("54"));

				String echoData = isoMap.get("59");
				echoData = !FMUtils.isNullOrEmpty(echoData) && echoData.length() > 6 ? echoData.substring(0,5) : echoData;
				exchange.setProperty("echoData", echoData);

				String posDataCode =  (String) isoMap.get("123");
				String terminalType = "";

				if(FMUtils.hasValue(posDataCode)){
					terminalType = posDataCode.substring(posDataCode.length()-2, posDataCode.length());
				}
				exchange.setProperty("posDataCode", posDataCode);

				String privateData = (String) isoMap.get("127");
				exchange.setProperty("postilionPrivate", privateData);

				enrichedMsgBody.put("rua_8byte_string_002", cardAcceptorTerminalID);

				String sasChannelType = getSASChannelTypeFromTerminal(terminalType,cardAcceptorTerminalID,procCode,posEntryMode,exchange);
				enrichedMsgBody.put("smh_channel_type", sasChannelType);

				//exchange.setProperty("isPossibleATM", isPossibleATM);
				exchange.setProperty("terminalType", terminalType);

				boolean isPresentPrivateData = !FMUtils.isNullOrEmpty(privateData);
				exchange.setProperty("isPresentPrivateData", isPresentPrivateData);

			}catch(Exception e) {

				logger.error("ERROR: {}",e.toString());
				if(FMUtils.isNullOrEmpty(productNumber)) {
					exchange.setProperty("errorType", "PROCESSING_ERROR");
					throw new EFMException(e.getMessage());
				}
			}
		}

		exchange.setProperty("enrichedMsgBody", enrichedMsgBody);
	}

	public void retrievePrivateFieldsFromISO(Exchange exchange) {

		Map<String,String> isoMap = (Map<String, String>) exchange.getProperty("DE127MsgMap");
		Map<String,String> enrichedMsgBody = (Map<String, String>) exchange.getProperty("enrichedMsgBody");

		String structuredData = isoMap.get("22");

		if(FMUtils.hasValue(structuredData)){
			exchange.setProperty("DE127StructuredData", structuredData);
		}

		//Nodo Source	DE-127	OK	Campo 127.3 (primeras 12 posiciones)	rua	rua_20byte_string_001	char	20
		String nodoSource = isoMap.get("3");
		if(FMUtils.hasValue(nodoSource)) {
			enrichedMsgBody.put("rua_20byte_string_001", nodoSource.substring(0, 11));
		}

		String cvvValidation = isoMap.get("27");
		//Issue: Data Validation
		if(FMUtils.hasValue(cvvValidation)) {
			enrichedMsgBody.put("rua_ind_006", cvvValidation);
			enrichedMsgBody.put("ucm_cvv2_resp", cvvValidation);
		}

	}

	public void enrichment(Exchange exchange) {

		Map<String,String> enrichedMsgBody = (Map<String, String>) exchange.getProperty("enrichedMsgBody");

		String messageType = exchange.getProperty("mti", String.class);
		String productId = enrichedMsgBody.remove("card_num");
		String balanceType = exchange.getProperty("balanceType",String.class);

		//RQO
		retrieveGeneralTransactionDataFromISO(exchange);
		enrichedMsgBody.put("aqo_acct_num", productId);
		enrichedMsgBody.put("hqo_card_num", productId);

		String additionalAmounts = exchange.getProperty("additionalAmounts", String.class);

		if(FMUtils.hasValue(balanceType)  && FMUtils.hasValue(additionalAmounts)) {
			String available = additionalAmounts.substring(9, 20);
			enrichedMsgBody.put(balanceType, FMUtils.addDecimalSeparator(available));
		}

		String nationalInternational = exchange.getProperty("NatInt",String.class);
		String merchantName = exchange.getProperty("merchantName",String.class);
		//Issue: location
		String countryIso = exchange.getProperty("merchantCountryIso",String.class);

		if(FMUtils.isNullOrEmpty(nationalInternational)){
			nationalInternational = "170".equals(countryIso) || FMUtils.isNullOrEmpty(countryIso) ? "N" : "I";
		}

		//Merchant Information
		String merchantId = exchange.getProperty("merchantId",String.class);

		mapCChannelInformation(exchange,enrichedMsgBody,merchantId,merchantName,messageType,countryIso);

		if("0320".equals(messageType)) {
			String echoData = exchange.getProperty("echoData", String.class);
			enrichedMsgBody.put("rua_10byte_string_003", echoData);
		}

		String activityType = enrichedMsgBody.get("smh_activity_type");
		String refNumber = exchange.getProperty("referenceNumber",String.class);
		//reversal indicator
		String reversalIndicator = "0420".equals(messageType)? "R": "N";

		String multiOrgName = "NO_TX_TC_TD";

		String clientAmt = enrichedMsgBody.remove("client_amt");
		String clientCurrCode = enrichedMsgBody.remove("client_curr_code");
		String merchAmt = enrichedMsgBody.remove("merch_amt");
		String merchCurrCode = enrichedMsgBody.remove("merch_curr_code");

		switch(activityType){
			case "CA":
				String responseCode = exchange.getProperty("responseCode",String.class);
				responseCode = FMUtils.isNullOrEmpty(responseCode) ? "00" : responseCode;
				String sysDecision = "00".equals(responseCode) ? "1" : "4";
				enrichedMsgBody.put("tca_auth_sys_dec", sysDecision);
				enrichedMsgBody.put("tca_ref_num", refNumber);

				enrichedMsgBody.put("tca_client_amt", clientAmt);
				enrichedMsgBody.put("tca_client_curr_code", clientCurrCode);
				enrichedMsgBody.put("tca_merch_amt", merchAmt);
				enrichedMsgBody.put("tca_merch_curr_code", merchCurrCode);
				enrichedMsgBody.put("tca_mod_amt", clientAmt);

				enrichedMsgBody.put("tca_reversal_ind", reversalIndicator);
				multiOrgName = "N".equals(nationalInternational) ? "NACIONAL": "INTERNAL";
			break;
			case "DP":
				enrichedMsgBody.put("tdp_ref_num", refNumber);
				enrichedMsgBody.put("tdp_client_amt", clientAmt);
				enrichedMsgBody.put("tdp_client_curr_code", clientCurrCode);
				enrichedMsgBody.put("tdp_mod_amt", clientAmt);
				enrichedMsgBody.put("tdp_reversal_ind", reversalIndicator);
				enrichedMsgBody.put("tdp_type", "W");
			break;
			default:
			break;
		}

		String authenticateMethod = exchange.getProperty("authenticateMethod", String.class);
		enrichedMsgBody.put("smh_authenticate_mtd", authenticateMethod);
		enrichedMsgBody.put("smh_multi_org_name", multiOrgName);

		String respReq = "0200".equals(messageType) ? "1" :"0";

		enrichedMsgBody.put("smh_resp_req", respReq);
		exchange.setProperty("respRequired",respReq);
		enrichedMsgBody.put("smh_activity_detail1", "DMX");
		enrichedMsgBody.put("smh_activity_detail2", "DEE");
		enrichedMsgBody.put("smh_activity_detail3", "DUA");

		exchange.getIn().setBody(enrichedMsgBody);
	}

	public void mapCChannelInformation(Exchange exchange, Map<String,String> enrichedMsgBody, String merchantId, String merchantName, String messageType, String countryIso) {

		String authId = exchange.getProperty("authorizationIdResponse",String.class);
		enrichedMsgBody.put("rua_10byte_string_002", authId);
		String merchantType = exchange.getProperty("merchantType",String.class);

		if(FMUtils.hasValue(merchantType)) {
			enrichedMsgBody.put("hct_mer_mcc", merchantType);
		}

		FMUtils.truncateIfHasWrongLenght(merchantId, 15);
		enrichedMsgBody.put("hct_term_owner_id", merchantId);

		boolean isPossiblePOS = (boolean) exchange.getProperty("isPossiblePOS");

		if(isPossiblePOS) {
			String acquiringIntCode = exchange.getProperty("acquiringIntCode",String.class);
			enrichedMsgBody.put("hct_acq_id", acquiringIntCode);
		}

		String terminalId = exchange.getProperty("cardAcceptorTerminalID",String.class);
		enrichedMsgBody.put("hct_term_id", terminalId);
		String cardHolderCountryCode = enrichedMsgBody.get("xqo_cust_cntry_code");
		enrichedMsgBody.put("hct_ch_cntry_code", cardHolderCountryCode);

		String cardMedia = exchange.getProperty("cardMedia",String.class);
		enrichedMsgBody.put("hct_media", cardMedia);

		if("0220".equals(messageType)) {
			enrichedMsgBody.put("hct_asso_dec_code", authId);
		}

		String merchantCityName = exchange.getProperty("merchantCity",String.class);
		String merchantState = exchange.getProperty("merchantState",String.class);

		//Issue: location
		if("170".equals(countryIso)) {
			String colombianCityName = exchange.getProperty("colombianCityName",String.class);
			
			if(FMUtils.hasValue(colombianCityName)){
				String colombianCityCode = exchange.getProperty("colombianCityCode",String.class);
				enrichedMsgBody.put("hct_term_post_code", colombianCityCode);
				merchantCityName = colombianCityName;
				merchantState = exchange.getProperty("colombianMerchantState",String.class);
			}
		}

		//Issue: location null
		if(FMUtils.hasValue(merchantState)) {
			enrichedMsgBody.put("hct_term_state", merchantState);
		}

		enrichedMsgBody.put("hct_term_owner_name", merchantName);

		if(FMUtils.hasValue(countryIso)) {
			enrichedMsgBody.put("hct_term_cntry_code", countryIso);
		}

		enrichedMsgBody.put("hct_term_city", merchantCityName);
	}

	public void retrieveGeneralTransactionDataFromISO(Exchange exchange) {

		Map<String,Object> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
		String dateTimeTransmission = exchange.getProperty("dateTimeTransmission",String.class);
		String timeLocal = exchange.getProperty("timeLocal", String.class);
		String dateLocal = exchange.getProperty("dateLocal", String.class);
		String datetimeLocal = "";

		ZonedDateTime localDateTime = ZonedDateTime.now(LOCAL_TIME_ZONE);
		if(!FMUtils.isNullOrEmpty(dateLocal) && !FMUtils.isNullOrEmpty(timeLocal)){
			datetimeLocal = dateLocal.concat(timeLocal);
		}else{
			datetimeLocal = localDateTime.format(SAS_DATETIME_FORMAT);
		}

		String year = String.valueOf(localDateTime.getYear());
		String tranDatetime = LocalDateTime.from(DATETIME_FORMATER.parse(year.concat(dateTimeTransmission))).format(SAS_DATETIME_FORMAT);
		String datetimealt = LocalDateTime.from(DATETIME_FORMATER.parse(year.concat(datetimeLocal))).format(SAS_DATETIME_FORMAT);

		//RQO - Segment
		enrichedMsgBody.put("rqo_tran_date", tranDatetime.substring(0, 8));
		enrichedMsgBody.put("rqo_tran_time", tranDatetime.substring(8, 16));

		//"M: Timestamp is available, but from an unknown time zone.
		enrichedMsgBody.put("rqo_tran_utc_flag", "Y");

		String tranTimeLocal = datetimealt.substring(8, 16);

		exchange.setProperty("tranDateLocal", datetimealt.substring(6, 8).concat("/").concat(datetimealt.substring(4, 6)).concat("/").concat(datetimealt.substring(0, 4)));
		exchange.setProperty("tranTimeLocal", "01/01/1970 ".concat(tranTimeLocal));

		// local transmission datetime
		enrichedMsgBody.put("rqo_tran_date_alt", datetimealt.substring(0, 8));
		enrichedMsgBody.put("rqo_tran_time_alt", datetimealt.substring(8, 16));

		exchange.getIn().setBody(enrichedMsgBody);
	}


	//issue: terminal type conversion
	public String getSASChannelTypeFromTerminal(String terminalType, String terminalID, String procCode, String posEntryMode, Exchange exchange) {

		//default channel type
		String sasChannelType = "C";
		boolean isPossibleATM = false;
		boolean isPossiblePOS = false;
		//get channel info
		String pan = !FMUtils.isNullOrEmpty(posEntryMode) && posEntryMode.length() > 2 ? posEntryMode.substring(0,2) : "";
		String cardPresent = cardPresentFromPosEntryMode.get(pan);

		String trxType = procCode.substring(0, 2);

		if(!terminalIdList.contains(terminalID)) {
			terminalID = "OTROS";
		}

		TableTerminalType tableterminalType = new TableTerminalType(terminalType.trim(),terminalID,trxType,cardPresent);
		int index = channelTypeFromTerminalType.indexOf(tableterminalType);

		if(index > -1) {
			TableTerminalType trxTerminalType = channelTypeFromTerminalType.get(index);

			sasChannelType = trxTerminalType.getSasChannelType();
			isPossibleATM =  ("ATM".equalsIgnoreCase(trxTerminalType.getDescription()) || "POSIBLE ATM".equalsIgnoreCase(trxTerminalType.getDescription())) && "0".equals(cardPresent);
			isPossiblePOS =  ("POS".equalsIgnoreCase(trxTerminalType.getDescription()) || "POSIBLE POS".equalsIgnoreCase(trxTerminalType.getDescription()));
		}

		exchange.setProperty("isPossibleATM", isPossibleATM);
		exchange.setProperty("isPossiblePOS", isPossiblePOS);

		return sasChannelType;
	}

	public String getMessageType(String mti, String respCode) {

		String messageType = "";

		switch(mti) {
			case "0800":
				messageType = "Administrative";
				break;
			case "0200":
				messageType = "Authorization";
				break;
			case "0220":
				messageType = "00".equals(respCode) ? "AdviceAuthorization" : "Advice";
				break;
			default:
				messageType = "Advice";
				break;
		}

		return messageType;
	}

	public boolean isResponseRequired(String mti) {
		return "0800".equals(mti) || "0200".equals(mti);
	}
	
}
