package com.efm.tcp.consumer.groovy

import java.text.DateFormat
import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import org.apache.camel.Exchange
import org.apache.log4j.lf5.util.DateFormatManager
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class PostilionAdministrativeMessagesManager {

	public static final Logger logger = LoggerFactory.getLogger("PostilionAdministrativeMessage");	
	public static final String POST_DATETIME_FORMAT_STRING = 'MMddHHmmss';
	public static final SimpleDateFormat POST_DATETIME_FORMAT = new SimpleDateFormat(POST_DATETIME_FORMAT_STRING);
	public static final String INFO_CODE_ECHO_TEST = 301;
	public static final String INFO_CODE_SING_IN = 001;
	public static final String INFO_CODE_SING_OFF = 002;
	public static final String INFO_CODE_TARGET_SYSTEM_UNAVAILABLE = 003;
		
	static void createAdvice(Exchange exchange, String infoCodeType) {
		
		Map<String,String> adminMsg = new HashMap<String,String>();
		
		Date date = new Date();
		
		//mti: 0800
		adminMsg.put("0","0800");
		//DE - 7
		String transDateTime = POST_DATETIME_FORMAT.format(date);
		adminMsg.put("7", transDateTime);
		//DE - 11
		String sysTraceAuditNumber = "111111"; 
		adminMsg.put("11", sysTraceAuditNumber);
		//DE - 12
		String timeLocalTrx = transDateTime.substring(4,transDateTime.length());
		adminMsg.put("12", timeLocalTrx);
		//DE - 13
		String dateLocalTrx = transDateTime.substring(0,4);
		adminMsg.put("13", dateLocalTrx);
		//DE - 70
		String networkManagementInfoCode = INFO_CODE_ECHO_TEST; 
		adminMsg.put("70", networkManagementInfoCode);
		//DE - 100
		String institutionIDCode = "1234"; 
		adminMsg.put("100", institutionIDCode);
				
		exchange.getIn().setBody(adminMsg);
			   
	}
}
