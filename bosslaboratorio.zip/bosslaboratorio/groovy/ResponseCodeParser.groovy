import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.sas.davivienda.efm.commons.util.FMUtils

class ResponseCodeParser {
	
	private static final Logger logger = LoggerFactory.getLogger("POSEntryModeParser");
	
	private ResponseCodeParser() {
		logger.info("ResponseCodeParser...");
	}
	
	static void getPinVerify(Exchange exchange) {
		
		Map<String,Object> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
		
		String responseCode = exchange.getProperty("responseCode",String.class);
		responseCode = FMUtils.isNullOrEmpty(responseCode) ? "00" : responseCode;
		boolean isPossibleATM = exchange.getProperty("isPossibleATM");
		
		//ATM
		if(isPossibleATM) {
			String pinVerify = "55".equals(responseCode) ? "I": "V";
			enrichedMsgBody.put("ucm_pin_vrfy", pinVerify);
                        enrichedMsgBody.put("hct_mer_mcc", "6011");
		}
		
		exchange.getIn().setBody(enrichedMsgBody);
		
	}
		
	
}
