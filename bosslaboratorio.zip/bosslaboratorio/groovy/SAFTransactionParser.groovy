package com.efm.tcp.consumer.groovy

import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.sas.davivienda.efm.commons.exceptions.EFMException
import com.sas.davivienda.efm.commons.mapper.ISOCountryMapper
import com.sas.davivienda.efm.commons.util.FMUtils

class SAFTransactionParser {

	private static final Logger logger = LoggerFactory.getLogger("SAFTransactionParser");

	private SAFTransactionParser() {
		logger.info("SAFTransactionParser...");
	}

	static void processIncomingSAFTransaction(Exchange exchange) {

		Map<String,Object> enrichedMsgBody = exchange.getIn().getBody();
		
		String tranType = enrichedMsgBody.get("smh_tran_type");
		enrichedMsgBody.put("smh_source", "SAF");
		enrichedMsgBody.put("smh_resp_req", "0");
		
		if("TRX".equalsIgnoreCase(tranType)) {
			processISOPostMessage(enrichedMsgBody,exchange);
			exchange.getIn().setBody(enrichedMsgBody);
		}else {
			exchange.getIn().setBody(null);
		}

	}

	static void processISOPostMessage(Map<String,Object> enrichedMsgBody, Exchange exchange) {
		
		String mti = enrichedMsgBody.get("hqo_msg_type");
	
		//extract fields required to update advice message
		if("0220".equals(mti)) {
			String productId = enrichedMsgBody.get("hqo_card_num");
			String tranDateAlt = enrichedMsgBody.get("rqo_tran_date_alt");
			String tranTimeAlt = enrichedMsgBody.get("rqo_tran_time_alt");
			String activityType = enrichedMsgBody.get("smh_activity_type");
			String authorizationIdResponse = enrichedMsgBody.get("rua_10byte_string_002");
			exchange.setProperty("authorizationIdResponse", authorizationIdResponse);
			
			exchange.setProperty("productId", productId);
			exchange.setProperty("sasActivityType", activityType);
			exchange.setProperty("referenceNumber", retrieveReferenceNumber(enrichedMsgBody,activityType));
			exchange.setProperty("tranDateLocal", tranDateAlt.substring(6, 8).concat("/").concat(tranDateAlt.substring(4, 6)).concat("/").concat(tranDateAlt.substring(0, 4)));
			exchange.setProperty("tranTimeLocal", "01/01/1970 ".concat(tranTimeAlt.substring(0,8)));
			exchange.setProperty("isAdviceAuthorization", true);
		}
		
	}
	
	static String retrieveReferenceNumber(Map<String,Object> enrichedMsgBody, String activityType) {
		
		String referenceNumber = null;
		
		switch(activityType) {
			case "CA":
				referenceNumber = enrichedMsgBody.get("tca_ref_num");
			break;
			case "DP":
				referenceNumber = enrichedMsgBody.get("tdp_ref_num");
			break;
			default:
				referenceNumber = "";
			break;
		}
		
		return referenceNumber;
	}
	
}
