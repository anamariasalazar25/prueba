package stratus.groovy.model.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientInfoLogger {

    private static final Logger logger = LoggerFactory.getLogger("ClientInfoLogger");

     public String maskWithFirst4Last4(String parametro) {
        if (isNullOrEmpty(parametro) == "N/A" || parametro.length() < 10 || parametro.replaceAll("0", "").isEmpty()) return "****";
        return parametro.substring(0, 4) + "****" + parametro.substring(parametro.length() - 4);
    }

    public String maskWithFirst3Last3(String parametro) {
        if (isNullOrEmpty(parametro) == "N/A" || parametro.length() < 8 || parametro.replaceAll("0", "").isEmpty()) return "***";
        return parametro.substring(0, 3) + "***" + parametro.substring(parametro.length() - 3);
    }
	
	public String formatAndMask(String idNumber, String idType) {
		if (isNullOrEmpty(idNumber) == "N/A" || isNullOrEmpty(idType) == "N/A" || idNumber.replaceAll("0", "").isEmpty()) {
			return "N/A";
		}
		idNumber = idNumber.replaceFirst("^0+", "");
		String custNum = idType + idNumber;
		return maskWithFirst3Last3(custNum);
	}
	
    public String isNullOrEmpty(String parametro) {
        return (parametro == null || parametro.isEmpty()) ? "N/A" : parametro;
    }
}
