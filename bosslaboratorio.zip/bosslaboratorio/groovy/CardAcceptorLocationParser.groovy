import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;

import com.sas.davivienda.efm.commons.mapper.DIANComplementaryCodeMapper;
import com.sas.davivienda.efm.commons.dto.DIANComplementaryCode;
import com.sas.davivienda.efm.commons.dto.ISOCountry;
import com.sas.davivienda.efm.commons.mapper.ISOCountryMapper;
import com.sas.davivienda.efm.commons.util.*; 

public class CardAcceptorLocationParser {

	private static final Logger logger = LoggerFactory.getLogger("POSEntryModeParser");
	
	@Resource
	@Qualifier("xmlISOCountryMapper")
	private ISOCountryMapper isoCountries;

	@Resource
	@Qualifier("xmlDIANMapper")
	private DIANComplementaryCodeMapper colombianCities;

	public POSEntryModeParser() {
		logger.info("CardAcceptorLocationParser...");
	}

	public void retrieveMerchantInformationFromISO(Exchange exchange) {

		String cardAcceptorLocation = exchange.getProperty("cardAcceptorNameLocation",String.class);

		if(!FMUtils.isNullOrEmpty(cardAcceptorLocation)) {
			
			Map<String,Object> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
			//Merchant Name - positions 1 - 23
			//hct_term_owner_name
			String merchantName = cardAcceptorLocation.substring(0, 22);
			exchange.setProperty("merchantName", merchantName);
			//stores merchant name in rua for deposits
			enrichedMsgBody.put("rua_30byte_string_002", merchantName);
			
			String merchantCountryCode = cardAcceptorLocation.substring(38, 40);
			exchange.setProperty("merchantCountry", merchantCountryCode);
			
			ISOCountry isoCountry = isoCountries.getCountryByAlpha2Code(merchantCountryCode);
			
			if(isoCountry != null) {
				exchange.setProperty("merchantCountryIso", isoCountry.getNumericCode());
				FMAPIFieldMapper.mapStringValueByLen(isoCountry.getName(), "rua_30byte_string_001", 30, enrichedMsgBody);
			}
						
			//for Colombian card acceptors, retrieve ciiu code
			if("CO".equals(merchantCountryCode)) {
				String colombianCityCode = cardAcceptorLocation.substring(22, 27);
				DIANComplementaryCode colombianCityInfo = colombianCities.getCityByNumericCode(colombianCityCode);
				
				if(colombianCityInfo != null){
					exchange.setProperty("colombianCityCode", colombianCityCode);
					exchange.setProperty("colombianCityName", colombianCityInfo.getName());
					exchange.setProperty("colombianMerchantState", cardAcceptorLocation.substring(22, 24));
				}
			}
	
			exchange.setProperty("merchantState", cardAcceptorLocation.substring(36, 38));
			exchange.setProperty("merchantCity", cardAcceptorLocation.substring(22, 36));
			exchange.getIn().setBody(enrichedMsgBody);
		}
	}

}
