package groovy.controller;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.sas.davivienda.efm.commons.util.DAVTokenizedDataParser;

import groovy.controller.Token;
import groovy.controller.TokenTypes;
import groovy.controller.enums.TokenCZ;
import groovy.controller.enums.TokenSC;
import groovy.controller.enums.TokenTK;

public class TokenChecks {
	
	private static final Logger logger = LoggerFactory.getLogger("RequestProcessor");
	
	private static final tokensValue = [
		
		"CZ": TokenCZ,
		"SC": TokenSC,
		"TK": TokenTK
	];
		
	public static Map <String, String> createTokensValues(String tokenInfo, String tokenType) {
		
		Map <String, String> sasMap = new HashMap <String, String>();

		def tokensEnum = tokensValue[tokenType].values();
		
		for(def tokenValue: tokensEnum) {
			sasMap.put(tokenValue.sasValue, tokenInfo.substring(tokenValue.startPos - 1, tokenValue.finalPos))
		}
			
		return sasMap;
	}
	
	public static Map <String, String> checkTokenValues(Token token) {

		// Check token type
		TokenTypes tokenType = TokenTypes.tokenValueOf(token.getCode());
				
		if(tokenType == null) {
			return null;
		}
		
		// Check token info size
		/*int tokenInfoSize = token.getInfo().length();
		
		if(tokenInfoSize != tokenInfoSize) {
			return null;
		}*/
		
		return createTokensValues(token.getInfo(), tokenType.code);
	}
	
	public static getTokenTypeAndValues(String tokenString) {
		
		def Map<String, String> validTokens = new HashMap<String, String>();
		def tokensCodesList = ["TOKEN_TK", "TOKEN_SC", "TOKEN_CZ"];
		
		for(String tokenCode : tokensCodesList) {
			
			String tokenValue = DAVTokenizedDataParser.getPostilionTokenData(tokenString, tokenCode);
			
			if(tokenValue != null && tokenValue.length() > 0) {
				validTokens.put(tokenCode, tokenValue)
			}
		}
		
		return validTokens;
		
	}
	
}
