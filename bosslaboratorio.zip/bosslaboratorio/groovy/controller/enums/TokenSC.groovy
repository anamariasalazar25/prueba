package groovy.controller.enums;

public enum TokenSC {
	
	TOKEN_ASSURANCE_LEVEL("AN", 2, 22, 23, "dmx_2byte_string_01_tag"),
	TOKEN_REQUESTOR_ID("N", 11, 24, 34, "rua_numeric_057"),
	
	
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	private TokenSC(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
