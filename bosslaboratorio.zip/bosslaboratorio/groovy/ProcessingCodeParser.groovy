import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class ProcessingCodeParser {

	private static final Logger logger = LoggerFactory.getLogger("POSEntryModeParser");
	private String procCode;
	private Map<String, String> accountTypes = new HashMap();
	private Map<String, String> activityTypes = new HashMap();
	private static final String NON_MON_MULTI_ORG = "NO_TX_TC_TD";
	private static final String ADVANCE_BALANCE_FIELD = "aqc_cash_bal";
	private static final String PURCHASE_BALANCE_FIELD = "aqc_bal";

	private ProcessingCodeParser() {
		logger.info("Init ProcessingCodeParser");

		//Init AccountTypes
		accountTypes.put("10", "CS");
		accountTypes.put("20", "CS");
		accountTypes.put("30", "CC");
		accountTypes.put("00", "CC");

		//Init ActivityTypes
		activityTypes.put("00", "CA");
		activityTypes.put("01", "CA");
		activityTypes.put("18", "NM");
		activityTypes.put("20", "CA");
		activityTypes.put("90", "NM");
		activityTypes.put("22", "DP");
		activityTypes.put("31", "NM");
		activityTypes.put("32", "NM");
		activityTypes.put("91", "NM");
		activityTypes.put("92", "NM");

	}

	public void enrichDataFromProcessingCode(Exchange exchange) {

		Map<String,Object> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
		String messageType = exchange.getProperty("mti", String.class);
		String procCode = exchange.getProperty("procCode",String.class);

		String isoTrantype = procCode.substring(0, 2);
		String isoAccountType = procCode.substring(2, 4);
		String sasTransactionType = getSASTransactionType(isoTrantype);
		
		enrichedMsgBody.put("smh_acct_type", getSASAccountType(isoAccountType));
		enrichedMsgBody.put("smh_activity_type", sasTransactionType);
		exchange.setProperty("balanceType", getBalanceType(isoTrantype));
		exchange.setProperty("sasActivityType", sasTransactionType);
	
		if("NM".equals(sasTransactionType)) {
			String nonMonTranType = getNonMonetaryTranType(sasTransactionType, messageType);
			enrichedMsgBody.put("tng_tran_type", nonMonTranType);
			enrichedMsgBody.put("smh_multi_org_name", NON_MON_MULTI_ORG);
		}
	}

	public String getSASAccountType(String isoAccountType) {
		return accountTypes.get(isoAccountType);
	}

	public String getSASTransactionType(String isoTranType) {
		return activityTypes.get(isoTranType);
	}

	public String getNonMonetaryTranType(String tranType, String mti) {
		switch(tranType) {
			case "91": case "90": case "92":
				return "NV";
				break;
			case "31": case "32":
				if("0320".equals(mti)) {
					return "DR";
				}else {
					return "BE";
				}
				break;
		}
	}
	
	/*
	 * determinar el tipo de saldo disponible de acuerdo al tipo de transaccion
	 * */
	public String getBalanceType(String isoTranType) {
		
		String balanceType = "";
		switch(isoTranType) {
			case "00": case "91": case "20": //compras - anulaciones
				balanceType = PURCHASE_BALANCE_FIELD ;
			break;
			case "01": //avance
				balanceType = ADVANCE_BALANCE_FIELD;
			break;
			default:
				balanceType = "";
			break;
		}
	}
}
