import javax.annotation.Resource

import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.context.ApplicationContext
import org.springframework.context.support.ClassPathXmlApplicationContext
import org.springframework.beans.factory.annotation.Qualifier
import com.sas.davivienda.efm.commons.dto.TableCardMedia
import com.sas.davivienda.efm.commons.util.FMUtils

public class POSEntryModeParser {

	@Resource
	@Qualifier("cardPresentFromPosEntryMode")
	private Map<String, String> cardPresentFromPosEntryMode;
	
	@Resource
	@Qualifier("cardMediaFromPOSEntryMode")
	private List<TableCardMedia> cardMediaFromPOSEntryMode;
	
	@Resource
	@Qualifier("authenticateMethodFromCardMedia")
	private Map<String, String> authenticateMethodFromCardMedia;
	
	private static final Logger logger = LoggerFactory.getLogger("POSEntryModeParser");
	
	private POSEntryModeParser() {
		if(cardPresentFromPosEntryMode == null) {
			ApplicationContext appCtx = new ClassPathXmlApplicationContext("classpath:spring/postilion-beans.xml");
			cardPresentFromPosEntryMode = appCtx.getBean("cardPresentFromPosEntryMode");
		}
		
		if(cardMediaFromPOSEntryMode == null) {
			ApplicationContext appCtx = new ClassPathXmlApplicationContext("classpath:spring/postilion-beans.xml");
			cardMediaFromPOSEntryMode = appCtx.getBean("cardMediaFromPOSEntryMode");
		}
		
		if(authenticateMethodFromCardMedia == null) {
			ApplicationContext appCtx = new ClassPathXmlApplicationContext("classpath:spring/postilion-beans.xml");
			authenticateMethodFromCardMedia = appCtx.getBean("authenticateMethodFromCardMedia");
		}
		
		logger.info("POSEntryModeParser... {}, {}, {}",cardPresentFromPosEntryMode,cardMediaFromPOSEntryMode,authenticateMethodFromCardMedia);
	}
	
	public void enrichDataFromPOSEntryMode(Exchange exchange) {
		
		String posEntryMode = exchange.getProperty("posEntryMode",String.class);
		
		//PAN Entry Mode
		String pan = posEntryMode.substring(0,2);
		//PIN Entry Capability
		String pin = posEntryMode.substring(2,3);
		
		String cardMedia = getCardMedia(pan, pin);
		exchange.setProperty("cardMedia", cardMedia);
		
		String authenticateMethod = getAuthenticateMethodFromCardMedia(cardMedia);
		exchange.setProperty("authenticateMethod", authenticateMethod);
		exchange.setProperty("panEntryMode", pan);
		exchange.setProperty("pinEntryCapability", pin);
				
	}
	
	public String getCardMedia(String panEntryMode, String pinEntryMode) {
		
		String cardMedia = "";
		String pinEntry = "";
		if("05".equals(panEntryMode) || "07".equals(panEntryMode)) {
			pinEntry = pinEntryMode;
		}
		
		TableCardMedia tableCardMedia = new TableCardMedia(panEntryMode, pinEntry);
		int index = cardMediaFromPOSEntryMode.indexOf(tableCardMedia);
		
		if(index > -1) {
			TableCardMedia inputCardMedia = cardMediaFromPOSEntryMode.get(index);
			cardMedia = inputCardMedia.getCardMedia();
		}
		
		return cardMedia;
	}
	
	public String getCardPresent(String pan) {
		
		String cardPresent = "";
		cardPresent = cardPresentFromPosEntryMode.get(pan);
		
		return FMUtils.hasValue(cardPresent) ? cardPresent: "";		
	}
	
	public String getAuthenticateMethodFromCardMedia(String cardMedia) {
		String authenticateMethod = "";
		authenticateMethod = authenticateMethodFromCardMedia.get(cardMedia);
		
		return FMUtils.hasValue(authenticateMethod) ? authenticateMethod : "CD"; 
	}
	
	public void getUCMPosEntryEquivalent(Exchange exchange) {
		
		Map<String,Object> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
		String panEntryMode = exchange.getProperty("panEntryMode");
		String pinEntryCapability = exchange.getProperty("pinEntryCapability");
		String cardPresent = getCardPresent(panEntryMode);

		enrichedMsgBody.put("ucm_pos", panEntryMode);
		enrichedMsgBody.put("ucm_term_pin_entry_cap", pinEntryCapability);
		enrichedMsgBody.put("ucm_card_present", cardPresent);
		
		exchange.getIn().setBody(enrichedMsgBody);
	}
}
