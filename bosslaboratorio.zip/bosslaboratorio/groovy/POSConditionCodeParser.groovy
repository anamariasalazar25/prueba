package com.efm.tcp.consumer.groovy

import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class POSConditionCodeParser {
	
	private static final Logger logger = LoggerFactory.getLogger("POSEntryModeParser");
	
	private POSConditionCodeParser() {
		logger.info("POSConditionCodeParser...");
	}
	
	static void enrichDataFromPOSConditionCode(Exchange exchange) {
		
		Map<String,Object> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
		
		String posConditionCode = exchange.getProperty("posConditionCode",String.class);
		enrichedMsgBody.put("rua_3byte_string_001", posConditionCode);
		
		String tranType = getTCATranTypeByPOSCondCode(posConditionCode);
		enrichedMsgBody.put("tca_tran_type", tranType);
		
		exchange.getIn().setBody(enrichedMsgBody);
		
	}
	
	static void getCustomerPresentDetails(Exchange exchange) {
		
		Map<String,Object> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
		
		String posConditionCode = exchange.getProperty("posConditionCode",String.class);
		String customerPresentDetail = "1";
		
		switch(posConditionCode) {
			case "00": case "02": case "03": case "05": case "71":
				customerPresentDetail = "0";
			break;
			case "01":
				customerPresentDetail = "1";
			break;
			case "08":
				customerPresentDetail = "4";
			break;
			case "51": case "59":
				customerPresentDetail = "5";
			break;
			default:
				customerPresentDetail = "";
			break;
		}
		
		enrichedMsgBody.put("ucm_cust_present", customerPresentDetail);
		exchange.getIn().setBody(enrichedMsgBody);
	}
	
	static String getTCATranTypeByPOSCondCode(String posCondCode) {
		
		switch(posCondCode) {
			//Retail/Merchandise
			case "00": case "02": case "03":
				return "R";
			break;
			//MOTO
			case "01": case "08":
				return "M";
			break;
			//E-Commerce
			case "05": case "59": case "71":
				return "E";
			break;
			//Other, not specified, use MCC
			case "51":
				return "O";
			break;
			default:
				return "";
			break;
		}
	}
}
