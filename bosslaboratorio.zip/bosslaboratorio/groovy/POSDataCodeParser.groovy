import javax.annotation.Resource

import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.ApplicationContext
import org.springframework.context.support.ClassPathXmlApplicationContext
import com.sas.davivienda.efm.commons.util.FMUtils

public class POSDataCodeParser {
	
	@Resource
	@Qualifier("ucmCatFromTerminalType")
	private Map<String,String> ucmCatFromTerminalType;
	private static final Logger logger = LoggerFactory.getLogger("POSDataCodeParser");
	
	public POSDataCodeParser() {
		
		if(ucmCatFromTerminalType == null) {
			ApplicationContext appCtx = new ClassPathXmlApplicationContext("classpath:spring/postilion-beans.xml");
			ucmCatFromTerminalType = appCtx.getBean("ucmCatFromTerminalType");
		}
		
		logger.info("init POSDataCodeParser... {}",ucmCatFromTerminalType);
	}
	
	public void enrichDataFromPOSDataCode(Exchange exchange) {
		
		Map<String,Object> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
		String posData = exchange.getProperty("posDataCode",String.class);
		String terminalType = exchange.getProperty("terminalType", String.class);
		
		if(FMUtils.hasValue(posData)) {
			String inputMode = posData.getAt(6);
			enrichedMsgBody.put("ucm_term_pan_entry_cap", posData.getAt(0));
			//pan entry cap
			enrichedMsgBody.put("rua_ind_005", inputMode);
		}
		
		//issue: terminal type 2 digits
		if(FMUtils.hasValue(terminalType)) {
			enrichedMsgBody.put("ucm_cat", getUcmCatFromTerminalType(terminalType));
			enrichedMsgBody.put("rua_2byte_string_004", terminalType);
		}
		
		exchange.getIn().setBody(enrichedMsgBody);
	}
	
	public String getUcmCatFromTerminalType(String terminalType) {
		
		String ucmCat = ucmCatFromTerminalType.get(terminalType);
		return FMUtils.hasValue(ucmCat) ? ucmCat :""; 
		
	}
	
}
