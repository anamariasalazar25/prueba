package com.efm.tcp.consumer.groovy;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;
import com.sas.davivienda.efm.commons.util.FMResponseHelper
import com.sas.davivienda.efm.commons.util.FMUtils
import io.netty.buffer.ByteBuf;
import org.apache.camel.Exchange
import org.apache.commons.codec.binary.Hex;
import java.lang.StringBuilder;

import javax.annotation.Resource

public class ResponseProcessor {

	private static final Logger logger = LoggerFactory.getLogger(ResponseProcessor.class);
	private static final String SUCCESS_RESPONSE_CODE = "00";
	private static final String DECLINED_RESPONSE_CODE = "76"; //declined fraud risk
	private static final String SYS_MALFUNCTION_RESPONSE_CODE = "96";
	private static final String TIMEOUT_RESPONSE_CODE = "91";
	
	private static final String AUTH_NUMBER_SUCCESS = "000000";
	
	public ResponseProcessor() {
		logger.info("ResponseProcessor...");
	}

	public void updateResponse(Exchange exchange) {

		Map<String,Object> initialMap = exchange.getProperty("8583MsgMap",Map.class);
		
		String smhTranType = exchange.getProperty("smhTranType", String.class);
		String errorType = exchange.getProperty("errorType", String.class);

		String field39 = SUCCESS_RESPONSE_CODE;
		String field38 = "";
		
		if("TRX".equals(smhTranType)) {
            field39 = FMResponseHelper.getResponseCode(exchange);
        
			field38 = FMUtils.hasValue(errorType) && "CONNECT_TIMEOUT".equals(errorType) ? "      ": AUTH_NUMBER_SUCCESS; 
			initialMap.put("38", field38);
		}else{
            Map<String, Object> outputMap = (Map<String, Object>) exchange.getIn().getBody();
            String rtnCode = (String) outputMap.get("smh_rtn_code");
            field39 = "00".equals(rtnCode) ? SUCCESS_RESPONSE_CODE : SYS_MALFUNCTION_RESPONSE_CODE;
        }
		
		initialMap.put("39", field39);

		// UPdate MTI for the response
		String mti = initialMap.get("0");
		mti = updateMTICode(mti);
		
		initialMap.put("0", mti);
		exchange.setProperty("responseCode", field39);
		exchange.setProperty("mti", mti);
		exchange.getIn().setBody(initialMap);
	}
	
	public String updateMTICode(String mti) {
		
		if(mti.length() == 4){
			mti = mti.charAt(3) == '1' ? mti.substring(0,3) + '0' : mti;
		}

		return String.format("%04d", (mti as Integer) + 10);
	}

}
