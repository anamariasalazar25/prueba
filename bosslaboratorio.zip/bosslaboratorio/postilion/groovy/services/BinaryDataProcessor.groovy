package com.efm.tcp.consumer.groovy

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.dto.ISOFieldStructure

import io.netty.buffer.ByteBuf;
import org.apache.camel.Exchange
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang.StringUtils

import java.lang.StringBuilder;

public class BinaryDataProcessor {

	static Logger logger = LoggerFactory.getLogger("BinaryDataProcessor");
	// because 2byte length is not stip off
	private static final int BYTE_LEN = 2;
	private static final int DE52_LEN = 8;
	private static final int DE53_LEN = 48;
	private static final int MTI_LEN = 4;
	
	public void mainBitmapDecoder(Exchange exchange) {
		
		byte[] inputMsg = exchange.getIn().getBody();
		exchange.setProperty("inputMsgByteArray", inputMsg);
		
		String mti = new String(inputMsg,BYTE_LEN,MTI_LEN);
		
		// primary and secondary bitmaps
		byte[] bitmapBin = new byte[16];
		
		// 2byte length + 4byte mti
		System.arraycopy(inputMsg,6,bitmapBin,0,16);
		
		String bitmapHex = Hex.encodeHexString(bitmapBin).toUpperCase();
		
		// 22: 2byte length + 4byte mti + 16byte primary and secondary bitmaps
		int dataLen = inputMsg.length - 22;
		String dataStr = new String(inputMsg,22,dataLen);
		exchange.setProperty("mti", mti);
		
		boolean respReq = "0200".equals(mti) || "0800".equals(mti);
		exchange.setProperty("isResponseRequired", respReq);
				
		exchange.setProperty("bitmap", bitmapHex);
		
		int pinDataPresent = getPinDataPresent(bitmapHex);
		if(pinDataPresent > 0) {
			exchange.setProperty("hasPinData", true);
			exchange.setProperty("pinDataPresent", pinDataPresent);
			exchange.setProperty("dataStr", dataStr);
			
			byte[] dataByteArray = new byte[dataLen];
			// 22: 2byte length + 4byte mti + 16byte primary and secondary bitmaps
			System.arraycopy(inputMsg,22,dataByteArray,0,dataLen);
			exchange.setProperty("dataByteArray", dataByteArray);
		}
		
		StringBuilder convertedMsg = new StringBuilder().append(mti).append(bitmapHex).append(dataStr);
		exchange.getIn().setBody(convertedMsg.toString());
	}
	
	public void mainBitmapEncoder(Exchange exchange) {
		
		String stringResponse = exchange.getIn().getBody(String.class);
		
		// 4len mti
		byte[] mtiByteArray = stringResponse.substring(0,MTI_LEN).getBytes();
		// 36 = 4len mti + 32len hexbitmap primary and secondary
		String hexBitmap = stringResponse.substring(MTI_LEN,36);
		byte[] bitmapByteArray = Hex.decodeHex(hexBitmap.toCharArray());
		byte[] privateFieldByteArray = exchange.getProperty("privateFieldByteArray", byte[].class);
		
		ByteArrayOutputStream dataByteArrayStream = new ByteArrayOutputStream();
		
		//logger.info("privateFieldByteArray: {}",privateFieldByteArray);
		
		if(privateFieldByteArray == null) {
			dataByteArrayStream.write(stringResponse.substring(36, stringResponse.length()).getBytes());
		}else {
		
			// 36 = 4byte mti + 32 Hex primary and secondary bitmaps
			byte[] dataByte = stringResponse.substring(36, stringResponse.length() - privateFieldByteArray.length).getBytes();
			
			boolean hasPinData = exchange.getProperty("hasPinData");
			
			//logger.info("hasPinData: {}",hasPinData);
			
			if(hasPinData) {
				// 44 = 4 mti + 32 Hex primary and secondary bitmaps + 6 DE38 + 2 DE39
				// this amount should be added because pin data position is calculated without first 36 bytes
				// after that the len of DE38 and DE39 sould be added because are additional fields in response
				int pinDataPosition = exchange.getProperty("pinDataPosition") + 44;
				byte[] dataByteBeforePin = stringResponse.substring(36, pinDataPosition);
				
				String mti = exchange.getProperty("mti", String.class);
				if("0230".equals(mti)||"0630".equals(mti)) {
					dataByteBeforePin = exchange.getProperty("dataBeforePinData");
				}

				byte[] dataFromPinDataPosition = exchange.getProperty("dataFromPinDataPosition");
				
				dataByteArrayStream.write(dataByteBeforePin);
				//logger.info("dataByteArrayStream-beforePIN: {}",new String(dataByteArrayStream.toByteArray()));
				dataByteArrayStream.write(dataFromPinDataPosition);
				//logger.info("dataByteArrayStream-fromPIN: {}",new String(dataByteArrayStream.toByteArray()));
			}else {
				dataByteArrayStream.write(dataByte);
				dataByteArrayStream.write(privateFieldByteArray);
			}
			
		}
		
		byte[] dataByteArray = dataByteArrayStream.toByteArray();
		//logger.info("dataByteArray: {}", new String(dataByteArray));
		
		Short frameLength = Short.valueOf((short) (mtiByteArray.length + bitmapByteArray.length + dataByteArray.length));
		byte[] responseByteArray = new byte[frameLength + BYTE_LEN];
		byte[] frameLenByteArray = retrieveByteLength(frameLength);
		
		System.arraycopy(frameLenByteArray, 0, responseByteArray, 0, frameLenByteArray.length);
		System.arraycopy(mtiByteArray, 0, responseByteArray, BYTE_LEN, mtiByteArray.length);
		System.arraycopy(bitmapByteArray, 0, responseByteArray, BYTE_LEN + mtiByteArray.length, bitmapByteArray.length);
		System.arraycopy(dataByteArray, 0, responseByteArray, BYTE_LEN + mtiByteArray.length + bitmapByteArray.length, dataByteArray.length);
		
		//logger.info("binaryResp:{}",new String(responseByteArray));

		exchange.getOut().setBody(io.netty.buffer.Unpooled.wrappedBuffer(responseByteArray));
		
	}
	
	public byte[] retrieveByteLength(Short frameLen) {
		
		byte firstByte = (byte)((frameLen & 0xFF00)>>8);
		byte secondByte = (byte)(frameLen & 0x00FF);
		
		return [firstByte,secondByte] as byte[];
	}
	
	public void privateDataBitmapDecoder(Exchange exchange) {
		Map<String,Object> isoMap = exchange.getProperty("8583MsgMap",Map.class);
		
		byte[] inputMsgByteArray = exchange.getProperty("inputMsgByteArray",byte[].class);
		
		String privateField = isoMap.get("127");
		int privateFieldLen = privateField.length();
		byte[] privateFieldByteArray = new byte[privateField.length()];
		System.arraycopy(inputMsgByteArray, inputMsgByteArray.length - privateFieldLen, privateFieldByteArray, 0, privateFieldLen);
		exchange.setProperty("privateFieldByteArray", privateFieldByteArray);
		
		byte[] bitmapBinArray = new byte[8];
		
		System.arraycopy(privateFieldByteArray, 0, bitmapBinArray, 0, 8);
		String bitmapHex = Hex.encodeHexString(bitmapBinArray).toUpperCase();
		StringBuilder privateFieldStr = new StringBuilder().append(bitmapHex).append(new String(privateFieldByteArray, 8, privateFieldByteArray.length - 8));
		exchange.setProperty("de127bitmap", bitmapHex);
		exchange.getIn().setBody(privateFieldStr);
		
	}

	public void pinDataDecoder(Exchange exchange) {
		
		String mti = exchange.getProperty("mti", String.class);
		String bitmapHex = exchange.getProperty("bitmap", String.class);
		String dataStr = exchange.getProperty("dataStr", String.class);

		byte[] dataByteArray = exchange.getProperty("dataByteArray");
		
		Map<Object,ISOFieldStructure> isoFields = exchange.getProperty("isoFields");
		int pinDataPosition = getPinDataPosition(bitmapHex, dataStr, isoFields);
		
		exchange.setProperty("pinDataPosition", pinDataPosition);
		int pinDataPresent = exchange.getProperty("pinDataPresent");
		int pinDataLen = pinDataPresent == 1 ? DE52_LEN : (DE52_LEN + DE53_LEN);
		
		byte[] dataBeforePinData = new byte[pinDataPosition];
		
		int lenDataAfterPin = dataByteArray.length - pinDataPosition - pinDataLen;
		byte[] dataAfterPinData = new byte[lenDataAfterPin];

		//Store the original data from pinData position because of bytes on response
		int lenDataFromPinDataPosition = dataByteArray.length - pinDataPosition;
		byte[] dataFromPinDataPosition = new byte[lenDataFromPinDataPosition];
		System.arraycopy(dataByteArray,pinDataPosition,dataFromPinDataPosition,0,lenDataFromPinDataPosition);
		exchange.setProperty("dataFromPinDataPosition", dataFromPinDataPosition);
		
		System.arraycopy(dataByteArray,0,dataBeforePinData,0,pinDataPosition);
		exchange.setProperty("dataBeforePinData", dataBeforePinData);
		System.arraycopy(dataByteArray,pinDataPosition+pinDataLen,dataAfterPinData,0,lenDataAfterPin);
		//Biuld a frame with a hardcoded pin
		
		String hardcodedPinData = "FFFFFFFF";
		if(pinDataPresent == 2) {
			hardcodedPinData += StringUtils.leftPad("FFFFFFFF", 48, "0"); 
		}
		
		StringBuilder convertedMsg = new StringBuilder().append(mti).append(bitmapHex).append(new String(dataBeforePinData)).append(hardcodedPinData).append(new String(dataAfterPinData));
		exchange.getIn().setBody(convertedMsg.toString());
	}
	
	public int getPinDataPosition(String bitmap, String data, Map<Object,ISOFieldStructure> isoPosLen) {
		
		String binaryBitmap = hexToBin(bitmap);
		int fieldNumber = 1;
		int positionOnMessage = 0;
		int pinDataPosition = 0;
		
		for (char bitmapIndex : binaryBitmap.toCharArray()) {
						
			if('1' == bitmapIndex && fieldNumber > 1 && fieldNumber <= 52 ) {
				
				ISOFieldStructure isoField = isoPosLen.get(String.valueOf(fieldNumber));
				char isoFieldType = isoField.getIsoFieldType();
				int isoFieldLen = isoField.getIsoFieldLenght();
				
				switch(isoFieldType) {
					case 'F':
						if (fieldNumber == 52) {
							pinDataPosition = positionOnMessage;
						}
						
						positionOnMessage = positionOnMessage + isoFieldLen;
					break;
					case 'V':
						String valuePos = data.substring(positionOnMessage, positionOnMessage + isoFieldLen);
						positionOnMessage = positionOnMessage + Integer.parseInt(valuePos) + isoFieldLen;
					break;
					default:
					break;
				}
			}
			fieldNumber++;
		}
		return pinDataPosition;
	}
	
	/**
	 *
	 * @param hexBitmap
	 * @return 0: there is no data present, 1: DE52 is present, 2:DE52 and DE53 is present
	 */
	public int getPinDataPresent(String hexBitmap) {
		int pinDataPresent = 0;
		String binaryBitmap = hexToBin(hexBitmap);
		if(binaryBitmap.charAt(51) == '1')pinDataPresent++;
		if(binaryBitmap.charAt(52) == '1')pinDataPresent++;
		return pinDataPresent;
	}
	
	/**
	 * Return the binary representation of the hexadecimal bitmap
	 * @param hex
	 * @return
	 */
	public String hexToBin(String hex){
		
		hex = hex.replace("0", "0000");
		hex = hex.replace("1", "0001");
		hex = hex.replace("2", "0010");
		hex = hex.replace("3", "0011");
		hex = hex.replace("4", "0100");
		hex = hex.replace("5", "0101");
		hex = hex.replace("6", "0110");
		hex = hex.replace("7", "0111");
		hex = hex.replace("8", "1000");
		hex = hex.replace("9", "1001");
		hex = hex.replace("A", "1010");
		hex = hex.replace("B", "1011");
		hex = hex.replace("C", "1100");
		hex = hex.replace("D", "1101");
		hex = hex.replace("E", "1110");
		hex = hex.replace("F", "1111");
		
		return hex;
	}
}
