package groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import postilion.groovy.controller.Token;
import postilion.groovy.controller.TokenChecks;
import postilion.groovy.tools.checks.TransactionChecks;
import postilion.groovy.controller.Common;

public class TokenProcessor implements Processor {

	private static final Logger logger = LoggerFactory.getLogger("RequestProcessor");

	public void process(Exchange exchange) {
		
		try {
			String generalTokenString = exchange.getProperty("DE127StructuredData", String.class);
			
			def tokenTypeAndValuesMap = TokenChecks.getTokenTypeAndValues(generalTokenString);
						
			if(tokenTypeAndValuesMap != null) {
				Map <String, Map <String, String>> sasMapTokens = new HashMap <String, Map <String, String>>();
				
				for (Map.Entry<String, String> tokenTypeAndValue : tokenTypeAndValuesMap.entrySet()) {
				
					String tokenCode = tokenTypeAndValue.key; 
					String tokenValue = tokenTypeAndValue.value;
					//println tokenCode;
					//println tokenValue;
					
					//Validacion token completo Diners DCI//
					if(tokenCode.startsWith("TOKEN")) {					
						tokenCode=java.lang.String.valueOf(tokenCode.substring(6));
					}

					Token tokenObject = new Token(tokenCode, tokenValue);
					
					Map <String, String> sasMapToken = TokenChecks.checkTokenValues(tokenObject);
					
					sasMapTokens.put(tokenCode, sasMapToken);
				}

				Map<String,Object> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
				for (Map.Entry<String, String> set :  sasMapTokens.entrySet()) {
					//println "set.Value:"+set.getValue();
					enrichedMsgBody.putAll(set.getValue());
				}

	
				String dciAmt = enrichedMsgBody.get("dmx_n22_01");
				//println "dciAmt:"+dciAmt;
				if(dciAmt != null) {
					dciAmt = TransactionChecks.getDci54Amount(dciAmt);
					enrichedMsgBody.put("dmx_n22_01", dciAmt);
				}
				
				// Impresion sasMapTokens DCI
				logger.info("sasMapTokens: {}", sasMapTokens);
				
			}else {
				logger.error("Invalid token Data");
			}
		}catch(Exception e) {
			logger.info("Error on tokenization: {}",e.getMessage());
			e.printStackTrace()
		}
		
	}

}
