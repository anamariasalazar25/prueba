package postilion.groovy.model.services;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.FMUtils

import org.apache.camel.Exchange;
import postilion.groovy.model.sas.ASystemComponent;
import postilion.groovy.tools.checks.TransactionChecks;

import javax.annotation.Resource

public class InputProcessor {

	private static final Logger logger = LoggerFactory.getLogger("InputProcessor");
	
	public void process(Exchange exchange) {

		Map<String,String> initialMap = exchange.getProperty("8583MsgMap",Map.class);
		
		String mti = initialMap.get("0");
		exchange.setProperty("mti", mti);
		String responseCode = initialMap.get("39");
		String authorizationNumber = initialMap.get("38");
		String pan = initialMap.get("2");
		String trackii = initialMap.get("35");
		
		exchange.setProperty("authorizationNumber", authorizationNumber);
		
		if(FMUtils.isNullOrEmpty(responseCode)) {responseCode = "00"}
		String msgType = "FINANCIAL_MSG"
		
		if("0800".equals(mti) || "0320".equals(mti)) {
			msgType = "ADMINISTRATIVE_MSG";
			exchange.setProperty("smhTranType", "CMD");
		}else {
			exchange.setProperty("smhTranType", "TRX");
			String subType = mti.substring(2);
			if("20".equals(subType) && "00".equals(responseCode)) {
				TransactionChecks.mapRequiredInfoForUpdate(exchange);
				msgType = "FINANCIAL_ADV_MSG";
			}
			String prodId = TransactionChecks.getProductId(pan, trackii);
			//logger.info("pan:{},prodId:{}",pan,prodId);
			exchange.setProperty("productId",prodId);
		}
		exchange.getIn().setHeader("msgType", msgType);
	}
	
}
