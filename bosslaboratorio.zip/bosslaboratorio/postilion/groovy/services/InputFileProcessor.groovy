package postilion.groovy.model.services;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.FMUtils

import org.apache.camel.BeanInject;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.sas.davivienda.efm.commons.mapper.GlobalBeans;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;

public class InputFileProcessor {

	private static final Logger logger = LoggerFactory.getLogger("InputFileProcessor");
	@Autowired
	GlobalBeans globalBeans;
	
	public InputFileProcessor(){
		// logger.info("=============== InputFileProcessor");
	}
	
	public void process(Exchange exchange) {

		// logger.info("list-before: {}", globalBeans.toString());
		String entrada = exchange.getIn().getBody(String.class);
		
		List<String> newList = Arrays.asList(entrada.split("\\|"));
		
		globalBeans.setLista(newList);
		
	}
	
}
