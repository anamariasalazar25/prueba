package postilion.groovy.model.services;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.FMUtils

import org.apache.camel.Exchange
import postilion.groovy.model.sas.ASystemComponent;
import postilion.groovy.model.sas.AAccountComponent;
import postilion.groovy.model.sas.AChannelComponent;
import postilion.groovy.model.sas.AAuthenticationComponent;
import postilion.groovy.model.sas.AActivityComponent;
import postilion.groovy.model.implementation.FinancialTransactionSystem;
import postilion.groovy.model.implementation.CreditCardAccount;
import postilion.groovy.model.implementation.PaymentCardAtTerminalChannel;
import postilion.groovy.model.implementation.ChipCardAuthentication;
import postilion.groovy.model.implementation.PaymentCardAuthorizationActivity;
import postilion.groovy.model.implementation.DepositActivity;
import postilion.groovy.model.implementation.NonMonetaryActivity;
import postilion.groovy.tools.checks.TransactionChecks;
import javax.annotation.Resource;
import org.apache.camel.BeanInject;
import com.sas.davivienda.efm.commons.mapper.GlobalBeans;
import org.springframework.beans.factory.annotation.Qualifier;

public class FinancialMsgProcessor {

	private static final Logger logger = LoggerFactory.getLogger("InputProcessor");
	
	@Resource
	@Qualifier("globalBeans")
	GlobalBeans globalBeans;
	
	public void process(Exchange exchange) {

		Map<String,String> initialMap = exchange.getProperty("8583MsgMap",Map.class);
		Map<String,String> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
		Map<String,String> de127MsgMap = exchange.getProperty("DE127MsgMap",Map.class);
		String initialMti = exchange.getProperty("mti");
		String authorizationNumber = exchange.getProperty("authorizationNumber");
		
		initialMap.put("0", initialMti);
		
		if(FMUtils.hasValue(authorizationNumber)) {
			enrichedMsgBody.put("rua_10byte_string_002",authorizationNumber);
		}
		logger.info("enrichedMsgBody before: {}",enrichedMsgBody);
		
		AChannelComponent channelComponent = new PaymentCardAtTerminalChannel(initialMap,enrichedMsgBody,de127MsgMap);
		//logger.info("channelComponent: {}",channelComponent);
		enrichedMsgBody.putAll(channelComponent.getChannelComponents());
		
		//INICIO BIN 8 Digitos
		String productId = enrichedMsgBody.get("hqo_card_num");
		String issuerBin = productId.substring(0,8);
		
		logger.info("bin {} found: {}", issuerBin, globalBeans.containsValue(issuerBin));
		issuerBin = globalBeans.containsValue(issuerBin) ? issuerBin : productId.substring(0,6);
		enrichedMsgBody.put("rua_8byte_string_001", issuerBin);
		//FIN BIN 8 Digitos
		
		ASystemComponent systemComponent = new FinancialTransactionSystem(initialMap,enrichedMsgBody);
		//logger.info("systemComponent: {}",systemComponent);
		enrichedMsgBody.putAll(systemComponent.getSystemComponents());
		
		AAccountComponent accountComponent = new CreditCardAccount(initialMap,enrichedMsgBody);
		//logger.info("accountComponent: {}",accountComponent);
		enrichedMsgBody.putAll(accountComponent.getAccountComponents());
		
		AAuthenticationComponent authenticationComponent = new ChipCardAuthentication(initialMap,enrichedMsgBody,de127MsgMap);
		//logger.info("authenticationComponent: {}",authenticationComponent);
		enrichedMsgBody.putAll(authenticationComponent.getAuthenticationComponents());
		
		String sasActivityType = enrichedMsgBody.get("smh_activity_type");
		
		AActivityComponent activityComponent = getActivityComponent(sasActivityType, initialMap);
		//logger.info("activityComponent: {}",activityComponent);
		enrichedMsgBody.putAll(activityComponent.getActivityComponents());
		
		//TransactionChecks.mapTerminalTypeInformation(enrichedMsgBody);
		
		logger.info("enrichedMsgBody after: {}",enrichedMsgBody);
		exchange.getIn().setBody(enrichedMsgBody);
	}
	
	public AActivityComponent getActivityComponent(String sasActivityType, Map<String,String> initialMap) {
		
		switch(sasActivityType) {
			case "CA": return new PaymentCardAuthorizationActivity(initialMap);
			case "DP": return new DepositActivity(initialMap);
			case "NM": return new NonMonetaryActivity(initialMap);
		}
		
	}
	
}
