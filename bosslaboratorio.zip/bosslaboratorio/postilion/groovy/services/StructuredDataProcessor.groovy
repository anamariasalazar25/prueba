import javax.annotation.Resource
import org.apache.camel.Exchange
import org.apache.commons.codec.binary.StringUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.ApplicationContext
import org.springframework.context.support.ClassPathXmlApplicationContext
import org.springframework.util.NumberUtils
import com.sas.davivienda.efm.commons.util.DAVTokenizedDataParser
import com.sas.davivienda.efm.commons.util.FMAPIFieldMapper
import com.sas.davivienda.efm.commons.util.FMUtils

public class StructuredDataProcessor {

	private static final Logger logger = LoggerFactory.getLogger("StructuredDataParser");
	private static final String CODIGO_RED_LOCAL = "ACQ_NETWORK";
	private static final String APPROVAL_RULES_NAME_TK = "APPROVAL_RULES_NAME";
	private static final String AUTOMATIC_REDISTRIBUTION_TK = "AUTOMATIC_REDISTRIBUTION";
	private static final String POSTILION_METADATA = "Postilion:MetaData";
	private static final String STRUCTURED_DATA_PROPERTY_NAME = "DE127StructuredData";
	private static final String NATIONAL_INTERNATIONAL = "NATIONAL/INTERNATIONAL_TX";
	private static final String TRX_QR = "OrgTOKENF4";
	private static final String PAGO_RECURRENTE ="PAGO_RECURRENTE";
	private static final String PGM_PROTO = "FB_PGM_PROTO";
	private static final String E_COM_SEC_LVL_IND = "C0_E_COM_SEC_LVL_IND"; 
	
	
	@Resource
	@Qualifier("chVerifyFromEcomFlag")
	private Map<String, String> chVerifyFromEcomFlag;

	/**
	 * 
	 */
	public StructuredDataProcessor() {
		logger.info("Init StructuredDataParser");
	}

	/**
	 * 
	 * @param exchange
	 */
	public void removeMetadataFromStructuredData(Exchange exchange){
		String structuredData = exchange.getProperty(STRUCTURED_DATA_PROPERTY_NAME,String.class);
		
		if(structuredData != null && structuredData.contains(POSTILION_METADATA)) {
			String postMetadata = DAVTokenizedDataParser.getPostilionTokenData(structuredData, POSTILION_METADATA);
			if(postMetadata != null) {
				exchange.setProperty(STRUCTURED_DATA_PROPERTY_NAME,structuredData.replace(postMetadata,""));
			}
		}
	}

	/**
	 * 
	 * @param exchange
	 */
	public void retrieveAdditionalInfoFromStructuredData(Exchange exchange) {

		Map<String,Object> enrichedMsgBody = new HashMap();
		Map<String,Object> inputMsgMap = exchange.getProperty("8583MsgMap");
		
		String structuredData = exchange.getProperty("DE127StructuredData",String.class);
		
		//TOKEN_DATA
		String networkCode = DAVTokenizedDataParser.getPostilionTokenData(structuredData, CODIGO_RED_LOCAL);
		FMAPIFieldMapper.mapStringValueByLen(networkCode, "rua_8byte_string_003", 8, enrichedMsgBody);
		
		enrichedMsgBody.put("rua_ind_009", getNationalInternationalInd(structuredData));
		
		String orgTokenF4 = DAVTokenizedDataParser.getPostilionTokenData(structuredData, TRX_QR);
		FMAPIFieldMapper.mapStringValueByLen(orgTokenF4, "dua_8byte_string_005", 6, enrichedMsgBody);
		
		String recurrente = DAVTokenizedDataParser.getPostilionTokenData(structuredData, PAGO_RECURRENTE);
		if(FMUtils.hasValue(recurrente)) {
			recurrente = Boolean.valueOf(recurrente) ? "1" : "0";
			enrichedMsgBody.put("rua_ind_008", recurrente);
		}
		String pgmProto = DAVTokenizedDataParser.getPostilionTokenData(structuredData, PGM_PROTO);
		enrichedMsgBody.put("rua_ind_013", pgmProto);
		String ecomSecLvl = DAVTokenizedDataParser.getPostilionTokenData(structuredData, E_COM_SEC_LVL_IND);
		enrichedMsgBody.put("rua_3byte_string_004", ecomSecLvl);
		
		String approvalRules = DAVTokenizedDataParser.getPostilionTokenData(structuredData, APPROVAL_RULES_NAME_TK);
		FMAPIFieldMapper.mapStringValueByLen(approvalRules, "rur_8byte_string_001", 8, enrichedMsgBody);
		
		String automaticRedist = DAVTokenizedDataParser.getPostilionTokenData(structuredData, AUTOMATIC_REDISTRIBUTION_TK);
		FMAPIFieldMapper.mapStringValueByLen(automaticRedist, "rur_ind_001", 1, enrichedMsgBody);
		
		//XML_DATA
		String retailerData = DAVTokenizedDataParser.getXmlTagFromStructuredData(structuredData, "RetailerData");
		if(FMUtils.hasValue(retailerData)) {
			def retailerDataResponse = new XmlSlurper().parseText(retailerData);
			String retailerId = retailerDataResponse.@Retailer_Id;
			retailerId = FMUtils.truncateIfHasWrongLenght(retailerId, 15);
			enrichedMsgBody.put("hct_term_owner_id", retailerId);
			//exchange.setProperty("merchantId", retailerId);
		}
		
		String POSTrnData = DAVTokenizedDataParser.getXmlTagFromStructuredData(structuredData, "C0_POS_Trn_Data"); //TerminalDataPOS @Term_Owner_FIID
		if(FMUtils.hasValue(POSTrnData)) {
			def posTrnDataResponse = new XmlSlurper().parseText(POSTrnData);

			String termPostalCde = posTrnDataResponse.@"TERM-POSTAL-CDE";
			FMAPIFieldMapper.mapStringValueByLen(termPostalCde, "dmx_10byte_string_02", 10, enrichedMsgBody);

			String ecomFlag = posTrnDataResponse.@"E-COM-FLG";
			FMAPIFieldMapper.mapStringValueByLen(ecomFlag, "rua_ind_004", 1, enrichedMsgBody);
			enrichedMsgBody.put("ucm_ch_evrfy", getSASEcomFlagEquivalent(ecomFlag));
			
			String cvdFldPresent = posTrnDataResponse.@"CVD-FLD-PRESENT";
			FMAPIFieldMapper.mapStringValueByLen(cvdFldPresent, "rua_ind_015", 1, enrichedMsgBody);
			
			String sasOrForcePost = posTrnDataResponse.@"SAF-OR-FORCE-POST";
			FMAPIFieldMapper.mapStringValueByLen(sasOrForcePost, "rur_ind_002", 1, enrichedMsgBody);

			String authCollInd = "";
			if("CREDIBANCO".equals(networkCode)) {
				authCollInd = posTrnDataResponse.@"AUTHN-COLL-IND";
			}else {
				authCollInd = DAVTokenizedDataParser.getPostilionTokenData(structuredData, "AUTHN_COLL_IND");
			}
			FMAPIFieldMapper.mapStringValueByLen(authCollInd, "rua_ind_016", 1, enrichedMsgBody);

			String frdPrnFlg = posTrnDataResponse.@"FRD-PRN-FLG";
			FMAPIFieldMapper.mapStringValueByLen(frdPrnFlg, "rua_ind_031", 1, enrichedMsgBody);

			String cavvRsltCde = posTrnDataResponse.@"CAVV-AAV-RSLT-CDE";
			FMAPIFieldMapper.mapStringValueByLen(cavvRsltCde, "rua_ind_017", 1, enrichedMsgBody);
			
		}

		String tokenC4 = DAVTokenizedDataParser.getPostilionTokenData(structuredData, "OrgTOKENC4");
		if(FMUtils.hasValue(tokenC4)) {
			enrichedMsgBody.put("rua_ind_001", tokenC4.charAt(0).toString());	//TERM-ATTEND-IND
			enrichedMsgBody.put("rua_ind_002", tokenC4.charAt(1).toString());	//TERM-OPER-IND
			enrichedMsgBody.put("rua_ind_003", tokenC4.charAt(2).toString());	//TERM-LOC-IND
			enrichedMsgBody.put("rua_ind_020", tokenC4.charAt(3).toString());	//CRDHLDR-PRESENT-IND
			enrichedMsgBody.put("rua_ind_018", tokenC4.charAt(4).toString());	//CRD-PRESENT-IND
			enrichedMsgBody.put("rua_ind_019", tokenC4.charAt(5).toString());	//CRD-CAPTR-IND
			enrichedMsgBody.put("rua_ind_024", tokenC4.charAt(6).toString());	//TXN-STAT-IND
			enrichedMsgBody.put("rua_ind_010", tokenC4.charAt(7).toString());	//TXN-SEC-IND
			enrichedMsgBody.put("rua_ind_011", tokenC4.charAt(8).toString());	//TXN-RTN-IND
			enrichedMsgBody.put("rua_ind_021", tokenC4.charAt(9).toString());	//CRDHLDR-ACTVT-TERM-IND
			enrichedMsgBody.put("rua_ind_022", tokenC4.charAt(10).toString());	//TERM-INPUT-CAP-IND
			enrichedMsgBody.put("rua_ind_023", tokenC4.charAt(11).toString());	//CRDHLDR-ID-METHOD
		}

		String terminalDataPOS = DAVTokenizedDataParser.getXmlTagFromStructuredData(structuredData, "TerminalDataPOS");
		if(FMUtils.hasValue(terminalDataPOS)) {
			def terminalDataPOSResponse = new XmlSlurper().parseText(terminalDataPOS);
			String termOwnerFiid = terminalDataPOSResponse.@Term_Owner_FIID;
			FMAPIFieldMapper.mapStringValueByLen(termOwnerFiid, "rua_4byte_string_001", 4, enrichedMsgBody);
		}
		
		String qtCostoOper = DAVTokenizedDataParser.getXmlTagFromStructuredData(structuredData, "QT_COSTO-OPER-TKN");
		if(FMUtils.hasValue(qtCostoOper)) {
			def qtCostoOperResponse = new XmlSlurper().parseText(qtCostoOper);
			String reference1 = qtCostoOperResponse.@REFERENCIA;
			FMAPIFieldMapper.mapStringValueByLen(reference1, "dua_20byte_string_001", 20, enrichedMsgBody);
			
			String reference2 = qtCostoOperResponse.@"COSTO-TXN";
			FMAPIFieldMapper.mapStringValueByLen(reference2, "dmx_10byte_string_01", 10, enrichedMsgBody);
		}
		
		String cardAcceptorId = DAVTokenizedDataParser.getXmlTagFromStructuredData(structuredData, "CardAcceptorIdCode");
		if(FMUtils.hasValue(cardAcceptorId)) {
			def cardAcceptorIdResponse = new XmlSlurper().parseText(cardAcceptorId);
			String instalments = cardAcceptorIdResponse.@Instalments;
			try {
				int installmentsNum = FMUtils.getNumericValue(instalments);
				enrichedMsgBody.put("rua_numeric_001",String.valueOf(installmentsNum));
			} catch (NumberFormatException e) {
				logger.error("Instalments cannot be parsed to Integer.");
			}
		}
		
		mapB0TokenInformation(enrichedMsgBody, structuredData, networkCode);
		
		exchange.setProperty("enrichedMsgBody", enrichedMsgBody)
		
	}
	
	public void mapB0TokenInformation(Map<String,Object> enrichedMsgBody, String structuredData, String networkCode) {
		
		switch(networkCode) {
			case "REDEBAN":
				String tokenB0 = DAVTokenizedDataParser.getPostilionTokenData(structuredData, "OrigTOKENB0");
				int scoreLen = tokenB0.length();
				
				if(scoreLen > 213) {
					enrichedMsgBody.put("rua_3byte_string_006", tokenB0.substring(210, 213));
					enrichedMsgBody.put("dmx_ind_02_tag", tokenB0.substring(112, 114));
					enrichedMsgBody.put("rua_3byte_string_002", tokenB0.substring(0, 3));
					enrichedMsgBody.put("rur_4byte_string_002", tokenB0.substring(110, 114));
				}
				
			break;
			case "CREDIBANCO":
				String scoreVisa = DAVTokenizedDataParser.getXmlValueFromStructuredData(structuredData,"RSK-SCORE");
				String indIncremental = DAVTokenizedDataParser.getXmlValueFromStructuredData(structuredData,"MIS-CAS-CDE");
				
				String lgthType = DAVTokenizedDataParser.getXmlValueFromStructuredData(structuredData,"LGTH-TYPE");
				String rsnCde = DAVTokenizedDataParser.getXmlValueFromStructuredData(structuredData,"RSK-RSN-CDE");
				
				int scoreLen = scoreVisa.length();
				scoreVisa = scoreLen > 2 ? scoreVisa.substring(scoreLen-2,scoreLen): scoreVisa;
				enrichedMsgBody.put("rua_2byte_string_008", scoreVisa);
				
				FMAPIFieldMapper.mapStringValueByLen(indIncremental, "rur_4byte_string_001", 4, enrichedMsgBody);
				
				FMAPIFieldMapper.mapStringValueByLen(lgthType, "rua_3byte_string_002", 3, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(rsnCde, "dmx_ind_02_tag", 2, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(scoreVisa, "rur_4byte_string_002", 4, enrichedMsgBody);
			break;
			default:
			break;
		}
	}
	
	/**
	 * 
	 * @param ecomFlag
	 * @return
	 */
	public String getSASEcomFlagEquivalent(String ecomFlag) {
		String ecomFlagEquivalent = chVerifyFromEcomFlag.get(ecomFlag);
		return FMUtils.isNullOrEmpty(ecomFlagEquivalent) ? "2" : ecomFlagEquivalent;
	}
	
	public String getNationalInternationalInd(String structuredData) {
		String nationalInternationalInd = DAVTokenizedDataParser.getPostilionTokenData(structuredData, NATIONAL_INTERNATIONAL);
		
		return nationalInternationalInd == null ? "" : nationalInternationalInd;
	}
}