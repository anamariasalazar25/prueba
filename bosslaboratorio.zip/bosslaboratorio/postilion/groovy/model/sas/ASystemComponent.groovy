package postilion.groovy.model.sas

import postilion.groovy.model.enums.AccountType;
import postilion.groovy.model.enums.SMHTranType;
import postilion.groovy.model.enums.CustomerType;
import postilion.groovy.model.enums.ActivityType;
import postilion.groovy.model.enums.MultiOrgName;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.FMUtils;

abstract class ASystemComponent {
	
	static final String ATM_POS_CHANNEL_TYPE = "C";
	static final String ACTIVITY_DETAIL_1 = "DMX";
	static final String ACTIVITY_DETAIL_2 = "DEE";
	static final String ACTIVITY_DETAIL_3 = "DUA";
	static final String RESPONSE_REQUIRED = "1";
	static final String SOURCE = "ISO8583P";
	static final String DAVIPLATA_BIN = "524708";
	
	Map<String,String> systemComponents;
	static final Logger logger = LoggerFactory.getLogger("cards");
	
	ASystemComponent(Map<String, String> inputMsg, Map<String,String> enrichedMsgBody){
		systemComponents = new HashMap();
		
		String mti = inputMsg.get("0");
		String procCode = inputMsg.get("3");
		String custType = enrichedMsgBody.get("rua_ind_012");
		String natInternalInd = enrichedMsgBody.get("rua_ind_009");
		String postActivityType = procCode.substring(0, 2);
		String postAcctType = procCode.substring(2, 4);
		String issuerBin = enrichedMsgBody.get("rua_8byte_string_001");
		String nodoSource = enrichedMsgBody.get("rua_20byte_string_001");
        String indComercio = enrichedMsgBody.get("ind_comercio");
		String sasActivityType = getSASActivityType(postActivityType);
		
		systemComponents.put("smh_tran_type", getSASTranType(mti));
		systemComponents.put("smh_cust_type", getSASCustomerType(custType));
		systemComponents.put("smh_acct_type", geSAStAccountType(postAcctType));
		systemComponents.put("smh_channel_type", ATM_POS_CHANNEL_TYPE); 
		systemComponents.put("smh_activity_type", sasActivityType);
		systemComponents.put("smh_activity_detail1", ACTIVITY_DETAIL_1);
		systemComponents.put("smh_activity_detail2", ACTIVITY_DETAIL_2);
		systemComponents.put("smh_activity_detail3", ACTIVITY_DETAIL_3);
		systemComponents.put("smh_msg_type", mti);
		systemComponents.put("smh_resp_req", RESPONSE_REQUIRED);
		systemComponents.put("smh_source", SOURCE);
		systemComponents.put("smh_multi_org_name", getMultiorgName(sasActivityType, indComercio, issuerBin));
		systemComponents.put("rua_10byte_string_001", procCode);
		
		String auditTrace = inputMsg.get("11");
		systemComponents.put("dua_8byte_string_003",auditTrace);
		
		enrichedMsgBody.put("postActivityType", postActivityType);
	}
		
	public String getSASTranType(String mti) {
		SMHTranType tranTypeEq = SMHTranType.getIfPresent("MTI_"+mti);
		return tranTypeEq == null ? "TRX" : tranTypeEq.tranType;
	}
	public String getSASCustomerType(String custType) {
		if(FMUtils.isNullOrEmpty(custType)) { 
			return CustomerType.DEFAULT.custType; 
		}
		CustomerType custTypeEq = CustomerType.getIfPresent("CT_"+custType);
		return custTypeEq == null ? CustomerType.DEFAULT.custType: custTypeEq.custType;	
	}
		
	public String getSASActivityType(String postActivityType) {
		ActivityType activityEq = ActivityType.getIfPresent("AT_"+postActivityType);
		return activityEq == null ? ActivityType.DEFAULT.sasActivityType :activityEq.sasActivityType;
	}
	
	public String geSAStAccountType(String postAcctType) {
		AccountType acctTypeEq = AccountType.getIfPresent("ACC_"+postAcctType);
		return acctTypeEq == null ? AccountType.DEFAULT.accountType : acctTypeEq.accountType;
	}
	
	public String getMultiorgName(String sasActivityType, String indCom, String issuerBin) {
		
		String value = "";
				
		if(DAVIPLATA_BIN.equals(issuerBin)) {
			value = "BDAVIPLATA";
		}else{
			value = sasActivityType.concat("_").concat(indCom)
		}
		MultiOrgName multiOrgNameEq = MultiOrgName.getIfPresent(value);
		
		return multiOrgNameEq == null ? MultiOrgName.DEFAULT.multiOrgName : multiOrgNameEq.multiOrgName;
	}
	
	public String getValueByActivityType(String sasActivityType, String nationalIntIndicator, String nodoSource) {
		
		switch(sasActivityType){
			case "CA":
				if(FMUtils.isNullOrEmpty(nationalIntIndicator) && (FMUtils.hasValue(nodoSource) && ("CtmMsgSplSr".equals(nodoSource) || ("PsvOn2Src".equals(nodoSource))))) {
					return sasActivityType.concat("_").concat(nodoSource);
				}else {
					return sasActivityType.concat("_").concat(nationalIntIndicator);
				}
			break;
			default:
				return sasActivityType;
			break;
		}
	}
	
	public Map<String,String> getSystemComponents() {
		return systemComponents;
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", ASystemComponent.class.getSimpleName() + "[", "]")
		.add("systemComponents='" + systemComponents + "'")
		.toString();
	}
}
