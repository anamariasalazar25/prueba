package postilion.groovy.model.sas

import postilion.groovy.model.enums.AccountType;
import postilion.groovy.model.enums.SMHTranType;
import postilion.groovy.model.enums.CustomerType;
import postilion.groovy.model.enums.ActivityType;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.FMUtils;
import postilion.groovy.tools.checks.TransactionChecks;

abstract class AActivityComponent {
	
	static final Logger logger = LoggerFactory.getLogger("cards");
	static final String ENTITY_USE_CARD = "H";
	Map<String,String> activityComponents;
	
	AActivityComponent(Map<String, String> inputMsg){
		activityComponents = new HashMap();
	}
		
	@Override
	public String toString() {
		return new StringJoiner(", ", AActivityComponent.class.getSimpleName() + "[", "]")
		.add("activityComponents='" + activityComponents + "'")
		.toString();
	}
	
	public Map<String,String> getActivityComponents(){
		return activityComponents;
	}
}
