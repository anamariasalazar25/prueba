package postilion.groovy.model.sas

import postilion.groovy.model.enums.AccountType;
import postilion.groovy.model.enums.SMHTranType;
import postilion.groovy.model.enums.CustomerType;
import postilion.groovy.model.enums.ActivityType;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.FMUtils;
import postilion.groovy.tools.checks.TransactionChecks;

abstract class AChannelComponent {
	
	static final Logger logger = LoggerFactory.getLogger("cards");
	static final String ENTITY_USE_CARD = "H";
	Map<String,String> channelComponents;
	
	AChannelComponent(Map<String, String> inputMsg, Map<String,String> enrichedMsgBody, Map<String,String> de127MsgMap){
		channelComponents = new HashMap();
		
		String mti = inputMsg.get("0");
		String pan = inputMsg.get("2");
		String trackii = inputMsg.get("35");
		String productId = TransactionChecks.getProductId(pan, trackii);
		
		channelComponents.put("hqo_msg_type", mti);
		channelComponents.put("rua_8byte_string_001", getIssuerBin(productId));
		
		channelComponents.put("hqo_entity_use_card", ENTITY_USE_CARD);
		channelComponents.put("hqo_card_num", productId);
		
	}
	
	public String getIssuerBin(String productType) {
		return productType.subSequence(0, 6);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", AChannelComponent.class.getSimpleName() + "[", "]")
		.add("channelComponents='" + channelComponents + "'")
		.toString();
	}
	
	public Map<String,String> getChannelComponents(){
		return channelComponents;
	}
}
