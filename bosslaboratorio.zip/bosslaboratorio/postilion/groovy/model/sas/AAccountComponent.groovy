package postilion.groovy.model.sas;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.FMUtils;
import postilion.groovy.model.enums.ActivityType;

public abstract class AAccountComponent {
	
	def Map<String,String> accountTrxComponents;
	static final Logger logger = LoggerFactory.getLogger("cards");
	
	AAccountComponent(Map<String, String> inputMsg, Map<String,String> enrichedMsgBody){
		accountTrxComponents = new HashMap();
		
		String cardNum = enrichedMsgBody.get("hqo_card_num");						
		accountTrxComponents.put("aqo_acct_num", cardNum);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", AAccountComponent.class.getSimpleName() + "[", "]")
		.add("financialTrxComponents='" + getAccountTrxComponents() + "'")
		.toString();
	}
	
	public Map<String,String> getAccountComponents(){
		return accountTrxComponents;
	}
}
