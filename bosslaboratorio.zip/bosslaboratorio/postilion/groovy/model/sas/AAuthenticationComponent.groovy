package postilion.groovy.model.sas

import postilion.groovy.model.enums.CardPresent;
import postilion.groovy.model.enums.UcmCat;
import postilion.groovy.model.enums.TermPanEntryCap;
import postilion.groovy.model.enums.CustPresent;
import postilion.groovy.model.enums.UcmScheme;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.FMUtils;

abstract class AAuthenticationComponent {
	
	Map<String,String> authenticationComponents;
	static final Logger logger = LoggerFactory.getLogger("cards");
	
	AAuthenticationComponent(Map<String, String> inputMsg, Map<String,String> enrichedMsgBody, Map<String,String> de127MsgMap){
		authenticationComponents = new HashMap();
		
		String posDataCode = inputMsg.get("123");
		String terminalType = "";
				
		if(FMUtils.hasValue(posDataCode)){
			terminalType = posDataCode.substring(posDataCode.length()-2, posDataCode.length());
			authenticationComponents.put("rua_2byte_string_004", terminalType);
			String termPam = String.valueOf(posDataCode.charAt(0));
			authenticationComponents.put("ucm_term_pan_entry_cap", termPam);
			String inputMode = String.valueOf(posDataCode.charAt(6));
			authenticationComponents.put("rua_ind_005", inputMode);
		}
		
		if(de127MsgMap != null) {
			String cvvValidation = getCVVResponse(de127MsgMap);
			authenticationComponents.put("rua_ind_006", cvvValidation);
			authenticationComponents.put("ucm_cvv2_resp", cvvValidation);
		}
		
		String posEntryMode = inputMsg.get("22");
		String ucmPos = getUcmPos(posEntryMode);
		String termPinEntry = getUcmPos(posEntryMode);
		String posCondcode = inputMsg.get("25");
		String responseCode = inputMsg.get("39");
		String channel = inputMsg.get("41");
		
		authenticationComponents.put("ucm_pos", ucmPos);
		authenticationComponents.put("ucm_cat", getUcmCat(terminalType));
		authenticationComponents.put("ucm_term_pin_entry_cap", getTermPinEntry(posEntryMode));
		authenticationComponents.put("ucm_cust_present", getCustPresent(posCondcode));
		authenticationComponents.put("ucm_card_present", getCardPresent(ucmPos));
		authenticationComponents.put("ucm_pin_vrfy", getPinVerify(responseCode));
		authenticationComponents.put("rua_2byte_string_003", responseCode);
		authenticationComponents.put("rua_8byte_string_002", channel);
				
		String issuerBin = enrichedMsgBody.get("rua_8byte_string_001");
		String nationalInternalInd = enrichedMsgBody.get("rua_ind_009");
		
		authenticationComponents.put("ucm_scheme", getUcmScheme(issuerBin, nationalInternalInd));
		
	}
		
	public String getPinVerify(String responseCode) {
		if(FMUtils.isNullOrEmpty(responseCode)) {
			responseCode = "00";
		}
		return "55".equals(responseCode) ? "I" : "V";
	}
	
	public String getUcmPos(String posEntryMode) {
		return posEntryMode.substring(0, 2);
	}
	
	public String getTermPinEntry(String posEntryMode) {
		String pinEntry = posEntryMode.substring(2);
		
		switch(pinEntry) {
			case "1":case "2":case "8":case "9":
				return pinEntry;
			break;
			default:
				return "0";
			break;
		}
	}
	
	public String getCardPresent(String ucmPos) {
		CardPresent cardPstEq = CardPresent.getIfPresent("CP_"+ucmPos);
		return cardPstEq == null ? CardPresent.DEFAULT.cardPresent : cardPstEq.cardPresent;
	}
	
	public String getCustPresent(String posCond) {
		CustPresent custPresentEq = CustPresent.getIfPresent("PC_".concat(posCond));
		return custPresentEq == null ? CustPresent.DEFAULT.custPresent : custPresentEq.custPresent;
	}
	
	public String getUcmCat(String terminalType) {
		UcmCat ucmCatEq = UcmCat.getIfPresent("TT_".concat(terminalType));
		return ucmCatEq == null ? UcmCat.DEFAULT.ucmCat : ucmCatEq.ucmCat;
	}
	
	public String getUcmTermPanEntryCap(String termPam) {
		TermPanEntryCap termPanEntryCapEq = TermPanEntryCap.getIfPresent("TP_".concat(termPam));
		return termPanEntryCapEq == null ? TermPanEntryCap.DEFAULT.termPanEntryCap : termPanEntryCapEq.termPanEntryCap;
	}
	
	public String getCVVResponse(Map<String,String> de127) {
		
		String cvvValidation = de127.get("27");
		//Issue: Data Validation
		if(FMUtils.hasValue(cvvValidation) && "X".equals(cvvValidation) || "Y".equals(cvvValidation)) {
			cvvValidation = "";
		}
		return cvvValidation;
	}
	
	public getUcmScheme(String issuerBin, String nationalInternalInd) {
		
		String ucmScheme = "";
		String ibPos1 = String.valueOf(issuerBin.charAt(0));
				
		if(FMUtils.hasValue(nationalInternalInd)) {
			String value = nationalInternalInd;
			
			if("I".equals(nationalInternalInd) && ("2".equals(ibPos1)||"3".equals(ibPos1)||"4".equals(ibPos1)||"5".equals(ibPos1))) {
				value = value.concat("_").concat(ibPos1);
			}
			ucmScheme = UcmScheme.valueOf(value).ucmScheme;
		}
		return ucmScheme;
	}
		
	public Map<String,String> getAuthenticationComponents(){
		return authenticationComponents;
	} 
	
	@Override
	public String toString() {
		return new StringJoiner(", ", AAuthenticationComponent.class.getSimpleName() + "[", "]")
		.add("authenticationComponents='" + authenticationComponents + "'")
		.toString();
	}
}
