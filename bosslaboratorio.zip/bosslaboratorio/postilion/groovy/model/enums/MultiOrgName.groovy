package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum MultiOrgName {
	
	CA_NAL("NACIONAL"),
	CA_INT("INTERNAL"),
	NM_NAL("NO_TX_TC_TD"),
    NM_INT("NO_TX_TC_TD"),
	DP_NAL("NO_TX_TC_TD"),
    DP_INT("NO_TX_TC_TD"),
	BDAVIPLATA("TARJ_DAVIPLATA"),
	DEFAULT("TARJETAS"),
		
	private final String multiOrgName;
	 
	private MultiOrgName(final String multiOrgName) {
		this.multiOrgName = multiOrgName;
	}
	
	public static MultiOrgName getIfPresent(String name) {
		return Enums.getIfPresent(MultiOrgName.class, name).orNull();
	}
}
