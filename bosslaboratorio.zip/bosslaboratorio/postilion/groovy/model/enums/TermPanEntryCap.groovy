package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum TermPanEntryCap {
	
	TP_0("0"),
	TP_1("1"),
	TP_2("2"),
	TP_3("B"),
	TP_4("C"),
	TP_5("9"),
	TP_7("2"),
	TP_8("3"),
	TP_9("9"),
	DEFAULT(""),
		
	private final String termPanEntryCap;
	 
	private TermPanEntryCap(final String termPanEntryCap) {
		this.termPanEntryCap = termPanEntryCap;
	}
	
	public static TermPanEntryCap getIfPresent(String name) {
		return Enums.getIfPresent(TermPanEntryCap.class, name).orNull();
	}
}
