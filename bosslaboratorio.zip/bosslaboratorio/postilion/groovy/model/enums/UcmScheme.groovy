package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum UcmScheme {
	
	N("L"),
	I_2("5"),
	I_5("5"),
	I_3("6"),
	I_4("4"),
	I("O"),
	DEFAULT(""),
	
	private final String ucmScheme;
	 
	private UcmScheme(final String ucmScheme) {
		this.ucmScheme = ucmScheme;
	}
	
	public static UcmScheme getIfPresent(String name) {
		return Enums.getIfPresent(UcmScheme.class, name).orNull();
	}
}
