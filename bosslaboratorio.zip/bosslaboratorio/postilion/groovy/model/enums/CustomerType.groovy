package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum CustomerType {
	
	CT_P("I"),
	CT_E("B"),
	DEFAULT("I"),
	
	private final String custType;
	 
	private CustomerType(final String custType) {
		this.custType = custType;
	}
	
	public static CustomerType getIfPresent(String name) {
		return Enums.getIfPresent(CustomerType.class, name).orNull();
	}
}
