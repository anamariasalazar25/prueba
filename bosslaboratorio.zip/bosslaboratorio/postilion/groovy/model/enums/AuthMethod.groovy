package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum AuthMethod {
	
	V("CD"),
	M("CD"),
	X("CP"),
	C("CP"),
	DEFAULT("CD"),
	
	private final String authMethod;
	 
	private AuthMethod(final String authMethod) {
		this.authMethod = authMethod;
	}
	
	public static AuthMethod getIfPresent(String name) {
		return Enums.getIfPresent(AuthMethod.class, name).orNull();
	}
}
