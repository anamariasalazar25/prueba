package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum ActivityType {
	
	AT_00("CA","aqc_bal"),
	AT_01("CA","aqc_cash_bal"),
	AT_18("NM",""),
	AT_20("CA","aqc_bal"),
	AT_22("DP",""),
	AT_31("NM",""),
	AT_32("NM",""),
	AT_90("CA","aqc_bal"),
	AT_91("NM",""),
	AT_92("NM",""),
	AT_28("DP",""),
		
	private final String sasActivityType;
	private final String balanceType;
	 
	private ActivityType(final String sasActivityType, final String balanceType) {
		this.sasActivityType = sasActivityType;
		this.balanceType = balanceType;
	}
	
	public static ActivityType getIfPresent(String name) {
		return Enums.getIfPresent(ActivityType.class, name).orNull();
	}
}
