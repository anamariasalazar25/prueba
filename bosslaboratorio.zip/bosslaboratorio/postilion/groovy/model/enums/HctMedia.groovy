package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum HctMedia {
	
	UP_01_("V"),
	UP_10_("V"),
	UP_16_("V"),
	UP_17_("V"),
	UP_02_("M"),
	UP_90_("M"),
	UP_91_("M"),
	UP_80_("M"),
	UP_95_("M"),
	UP_05_0("X"),
	UP_05_1("C"),
	UP_05_2("X"),
	UP_05_8("X"),
	UP_07_0("X"),
	UP_07_1("C"),
	UP_07_2("X"),
	UP_03_("V"),
	UP_04_("V"),
	UP_00_(""),
	DEFAULT(""),
			
	private final String hctMedia;
	 
	private HctMedia(final String hctMedia) {
		this.hctMedia = hctMedia;
	}
	
	public static HctMedia getIfPresent(String name) {
		return Enums.getIfPresent(HctMedia.class, name).orNull();
	}
}
