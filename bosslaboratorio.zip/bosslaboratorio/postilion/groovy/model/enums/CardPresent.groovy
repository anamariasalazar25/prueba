package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum CardPresent {
	
	CP_01("1"),
	CP_10("1"),
	CP_16("1"),
	CP_17("1"),
	CP_00("0"),
	CP_03("0"),
	CP_02("0"),
	CP_04("0"),
	CP_05("0"),
	CP_07("0"),
	CP_80("0"),
	CP_90("0"),
	CP_91("0"),
	CP_95("0"),
	DEFAULT(""),
			
	private final String cardPresent;
	 
	private CardPresent(final String cardPresent) {
		this.cardPresent = cardPresent;
	}
	
	public static CardPresent getIfPresent(String name) {
		return Enums.getIfPresent(CardPresent.class, name).orNull();
	}
}
