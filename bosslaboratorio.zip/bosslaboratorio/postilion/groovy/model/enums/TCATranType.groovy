package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum TCATranType {
	
	PCC_00("R"),
	PCC_01("M"),
	PCC_02("R"),
	PCC_03("R"),
	PCC_05("E"),
	PCC_06(""),
	PCC_08("M"),
	PCC_51("O"),
	PCC_59("E"),
	PCC_71("E"),
	DEFAULT(""),
			
	private final String tcaTranType;
	 
	private TCATranType(final String tcaTranType) {
		this.tcaTranType = tcaTranType;
	}
	
	public static TCATranType getIfPresent(String name) {
		return Enums.getIfPresent(TCATranType.class, name).orNull();
	}
}
