package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum UcmCat {
	
	TT_00("0"),
	TT_01("0"),
	TT_02("1"),
	TT_03("2"),
	TT_04("0"),
	TT_05("6"),
	TT_06("6"),
	TT_07("2"),
	TT_08("5"),
	TT_09("8"),
	DEFAULT(""),
	
	private final String ucmCat;
	 
	private UcmCat(final String ucmCat) {
		this.ucmCat = ucmCat;
	}
	
	public static UcmCat getIfPresent(String name) {
		return Enums.getIfPresent(UcmCat.class, name).orNull();
	}
}
