package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum TNGTranType {
	
	PTT_90("NV"),
	PTT_91("NV"),
	PTT_92("NV"),
	PTT_31("BE"),
	PTT_32("BE"),
	PTT_31_0320("DR"),
	PTT_32_0320("DR"),
	DEFAULT(""),
		
	private final String tngTranType;
	 
	private TNGTranType(final String tngTranType) {
		this.tngTranType = tngTranType;
	}
	
	public static TNGTranType getIfPresent(String name) {
		return Enums.getIfPresent(TNGTranType.class, name).orNull();
	}
}
