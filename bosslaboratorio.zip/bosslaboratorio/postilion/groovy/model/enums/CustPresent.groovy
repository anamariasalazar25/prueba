package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum CustPresent {
	
	PC_00("0"),
	PC_01("1"),
	PC_02("0"),
	PC_03("0"),
	PC_05("0"),
	PC_08("4"),
	PC_51("5"),
	PC_59("5"),
	PC_71("0"),
	DEFAULT(""),
			
	private final String custPresent;
	 
	private CustPresent(final String custPresent) {
		this.custPresent = custPresent;
	}
	
	public static CustPresent getIfPresent(String name) {
		return Enums.getIfPresent(CustPresent.class, name).orNull();
	}
}
