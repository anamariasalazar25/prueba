package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum SMHTranType {
	
	MTI_0200("TRX"),
	MTI_0220("TRX"),
//	MTI_0230("TRX"),
	MTI_0600("TRX"),
	MTI_0620("TRX"),
//	MTI_0630("TRX"),
	MTI_0800("CMD"),
	DEFAULT("TRX"),
	
	private final String tranType;
	 
	private SMHTranType(final String tranType) {
		this.tranType = tranType;
	}
	
	public static SMHTranType getIfPresent(String name) {
		return Enums.getIfPresent(SMHTranType.class, name).orNull();
	}
}
