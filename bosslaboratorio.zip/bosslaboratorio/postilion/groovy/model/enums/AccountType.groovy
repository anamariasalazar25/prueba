package postilion.groovy.model.enums;

import com.google.common.base.Enums

public enum AccountType {
	
	ACC_30("CC","TARJETA_CREDITO"),
	ACC_20("CS","CUENTA_CORRIENTE"),
	ACC_10("CS","CUENTA_AHORROS"),
	ACC_00("CC","TARJETA_CREDITO"),
	DEFAULT("TC","TARJETA_CREDITO"),
	
	private final String accountType;
	private final String accountName;
	 
	private AccountType(final String accountType, final String accountName) {
		this.accountType = accountType;
		this.accountName = accountName;
	}
	
	public static AccountType getIfPresent(String name) {
		return Enums.getIfPresent(AccountType.class, name).orNull();
	}
	
}
