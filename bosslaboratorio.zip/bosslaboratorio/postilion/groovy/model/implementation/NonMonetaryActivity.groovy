package postilion.groovy.model.implementation

import java.util.Map;

import com.sas.davivienda.efm.commons.util.FMUtils;

import postilion.groovy.model.sas.AActivityComponent;
import postilion.groovy.model.enums.TNGTranType;


class NonMonetaryActivity extends AActivityComponent  {
	
	public NonMonetaryActivity(Map<String, String> inputMsg){
		super(inputMsg);

		String mti = inputMsg.get("0");
		String procCode = inputMsg.get("3");
		String referenceNumber = inputMsg.get("37");
		String postTranType = procCode.substring(0, 2);
		activityComponents.put("tng_tran_type", getTranType(mti, postTranType));
		activityComponents.put("dua_8byte_string_006", referenceNumber.substring(5));
		
	}
	
	public String getTranType(String mti, String postTranType) {
		String value = postTranType;
		if("0320".equals(mti)) {
			value = value.concat("_").concat(mti);
		}
		TNGTranType tngTranTypeEq = TNGTranType.getIfPresent("PTT_"+value);
		return tngTranTypeEq == null ? TNGTranType.DEFAULT.tngTranType: tngTranTypeEq.tngTranType;
	}

}
