package postilion.groovy.model.implementation

import java.util.Map;

import org.slf4j.Logger

import com.sas.davivienda.efm.commons.util.FMUtils;

import postilion.groovy.model.sas.AActivityComponent;
import postilion.groovy.model.enums.TCATranType;
import postilion.groovy.model.enums.SMHTranType;
import postilion.groovy.model.enums.CustomerType;
import postilion.groovy.model.enums.ActivityType;
import postilion.groovy.tools.checks.TransactionChecks;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

class PaymentCardAuthorizationActivity extends AActivityComponent  {
	
	public PaymentCardAuthorizationActivity(Map<String, String> inputMsg){
		super(inputMsg);

		String mti = inputMsg.get("0");
		String transactionAmount = inputMsg.get("4");
		String settlementAmount = inputMsg.get("5");
		
		String transactionCurrCode = inputMsg.get("49");
		String settlementCurrCode = inputMsg.get("50");
		String referenceNumber = inputMsg.get("37");
		String posCondCode = inputMsg.get("25");
		String responseCode = inputMsg.get("39");
				
		String [] amtTranInfo = TransactionChecks.getTranAmtInformation(transactionAmount, transactionCurrCode, settlementAmount, settlementCurrCode);
		//[clientAmount,clientCurrCode,merchAmount,merchCurrCode]
		activityComponents.put("tca_client_amt", amtTranInfo[0]);
		activityComponents.put("tca_client_curr_code", amtTranInfo[1]);
		activityComponents.put("tca_mod_amt", amtTranInfo[0]);
		activityComponents.put("tca_merch_amt", amtTranInfo[2]);
		activityComponents.put("tca_merch_curr_code", amtTranInfo[3]);
		
		activityComponents.put("tca_ref_num", referenceNumber);
		activityComponents.put("dua_8byte_string_006", referenceNumber.substring(5));
		activityComponents.put("tca_tran_type", getTranType(posCondCode));
		activityComponents.put("tca_auth_sys_dec", getAuthSysDec(responseCode));
		activityComponents.put("tca_reversal_ind", getReversalIndicator(mti));
		
	}
	
	public String getTranType(String posCondCode) {
		TCATranType tcaTranTypeEq = TCATranType.getIfPresent("PCC_"+posCondCode);
		return tcaTranTypeEq == null ? TCATranType.DEFAULT.tcaTranType : tcaTranTypeEq.tcaTranType;
	}
	
	public String getAuthSysDec(String responsecode) {
		if(FMUtils.isNullOrEmpty(responsecode)) {
			responsecode = "00";
		}
		return "00".equals(responsecode) ? "1" : "4"; 
	}
	
	public String getReversalIndicator(String mti) {
		return "0420".equals(mti) ? "R" : "N";
	}
}
