package postilion.groovy.model.implementation

import java.util.Map;

import org.slf4j.Logger

import com.sas.davivienda.efm.commons.util.FMUtils;

import postilion.groovy.model.sas.AActivityComponent;
import postilion.groovy.model.enums.TCATranType;
import postilion.groovy.model.enums.SMHTranType;
import postilion.groovy.model.enums.CustomerType;
import postilion.groovy.model.enums.ActivityType;
import postilion.groovy.tools.checks.TransactionChecks;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

class DepositActivity extends AActivityComponent  {
	
	public DepositActivity(Map<String, String> inputMsg){
		super(inputMsg);

		String mti = inputMsg.get("0");
		String transactionAmount = inputMsg.get("4");
		String settlementAmount = inputMsg.get("5");
		
		String transactionCurrCode = inputMsg.get("49");
		String settlementCurrCode = inputMsg.get("50");
		String referenceNumber = inputMsg.get("37");
		
		String responseCode = inputMsg.get("39");
				
		String [] amtTranInfo = TransactionChecks.getTranAmtInformation(transactionAmount, transactionCurrCode, settlementAmount, settlementCurrCode);
		
		//[clientAmount,clientCurrCode,merchAmount,merchCurrCode]
		activityComponents.put("tdp_client_amt", amtTranInfo[0]);
		activityComponents.put("tdp_client_curr_code", amtTranInfo[1]);
		activityComponents.put("tdp_mod_amt", amtTranInfo[0]);
				
		activityComponents.put("tdp_ref_num", referenceNumber);
		activityComponents.put("dua_8byte_string_006", referenceNumber.substring(5));
		activityComponents.put("tdp_type", getTranType());
		activityComponents.put("tdp_reversal_ind", getReversalIndicator(mti));
		
	}
	
	public String getTranType() {
		return "W";
	}
	
	public String getAuthSysDec(String responsecode) {
		
		if(FMUtils.isNullOrEmpty(responsecode)) {
			responsecode = "00";
		}
		return "00".equals(responsecode) ? "1" : "4"; 
	}
	
	public String getReversalIndicator(String mti) {
		return "0420".equals(mti) ? "R" : "N";
	}
}
