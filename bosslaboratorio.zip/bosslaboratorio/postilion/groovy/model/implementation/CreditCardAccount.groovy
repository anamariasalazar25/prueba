package postilion.groovy.model.implementation

import java.util.Map;

import org.slf4j.Logger

import com.sas.davivienda.efm.commons.util.FMUtils;

import postilion.groovy.model.sas.AAccountComponent;
import postilion.groovy.model.enums.AccountType;
import postilion.groovy.model.enums.SMHTranType;
import postilion.groovy.model.enums.CustomerType;
import postilion.groovy.model.enums.ActivityType;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

class CreditCardAccount extends AAccountComponent  {
	
	public CreditCardAccount(Map<String, String> inputMsg, Map<String,String> enrichedMsgBody){
		super(inputMsg,enrichedMsgBody);
		
		String additionalAmounts = inputMsg.get("54");
		String postActivityType = enrichedMsgBody.get("postActivityType");
		
		String [] availableInfo = getAvailBalance(postActivityType, additionalAmounts);
		
		if(availableInfo != null && availableInfo.length > 0 ) {
			String availableVal = FMUtils.addDecimalSeparator(availableInfo[1]);
			accountTrxComponents.put(availableInfo[0], availableVal);
		}
		
	}
	public String[] getAvailBalance(String postActivityType, String additionalAmounts) {
		
		if(FMUtils.hasValue(additionalAmounts)) {
			String availableValue = additionalAmounts.substring(9, 20);
			String balanceType = ActivityType.("AT_".concat(postActivityType)).balanceType;
			
			return [balanceType,availableValue] 
		}
		return null;
	}
	
}
