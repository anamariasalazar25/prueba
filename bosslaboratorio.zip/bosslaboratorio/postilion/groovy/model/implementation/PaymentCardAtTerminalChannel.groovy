package postilion.groovy.model.implementation

import java.util.Map;

import org.apache.camel.Exchange
import org.apache.commons.lang.StringUtils
import org.slf4j.Logger;
import com.sas.davivienda.efm.commons.util.FMUtils;
import postilion.groovy.tools.CardAcceptorLocationParser;
import postilion.groovy.model.sas.AChannelComponent;
import postilion.groovy.model.enums.HctMedia;
import postilion.groovy.model.enums.SMHTranType;
import postilion.groovy.model.enums.CustomerType;
import postilion.groovy.model.enums.ActivityType;
import postilion.groovy.model.enums.AuthMethod;
import org.slf4j.Logger
import org.slf4j.LoggerFactory;
import com.google.common.base.Stopwatch;
import java.util.concurrent.TimeUnit;

class PaymentCardAtTerminalChannel extends AChannelComponent  {
	
	public PaymentCardAtTerminalChannel(Map<String, String> inputMsg, Map<String,String> enrichedMsgBody, Map<String,String> de127MsgMap){
		super(inputMsg,enrichedMsgBody,de127MsgMap);
				
		String mcc = inputMsg.get("18");
		if(FMUtils.isNullOrEmpty(mcc)) {mcc = "6011";}
		
		String termId = inputMsg.get("41");
		String cardAcceptorLocation = inputMsg.get("43");
		String nationalInternalInd = enrichedMsgBody.get("rua_ind_009");
		String nodoSource = de127MsgMap.get("3");
		String acqId = inputMsg.get("32");
		String posEntryMode = inputMsg.get("22");
		String posData = inputMsg.get("123");
				
		if(FMUtils.hasValue(acqId)) {
			channelComponents.put("acq_id",acqId);
		}
		
		if(de127MsgMap != null && FMUtils.hasValue(nodoSource)) {
			nodoSource = nodoSource.substring(0, 11).trim();
			enrichedMsgBody.put("rua_20byte_string_001", nodoSource);
		}
				
		Stopwatch stopwatch = Stopwatch.createStarted();
		String [] locationInfo = CardAcceptorLocationParser.processCardAcceptorNameLocation(cardAcceptorLocation, nodoSource,  nationalInternalInd);
		stopwatch.stop();
		channelComponents.put("merchant_proc_time_ms", stopwatch.elapsed(TimeUnit.MILLISECONDS));
		channelComponents.put("merchant_proc_time_us", stopwatch.elapsed(TimeUnit.MICROSECONDS));
        
        //logger.info("########### locationInfo: {}",Arrays.asList(locationInfo));
		//logger.info("CardAcceptorLocation elapsedTime: {}ms, {}us",stopwatch.elapsed(TimeUnit.MILLISECONDS), stopwatch.elapsed(TimeUnit.MICROSECONDS));
		//logger.info("##### - nodoSource:{}, nationalInternalInd:{},cardAcceptorLocation:{},cardAcceptorLocation, locationInfo: {},termOwnerName:{},termCity:{},termCntryCode:{}",nodoSource,nationalInternalInd,cardAcceptorLocation,locationInfo[0],locationInfo[1],locationInfo[2],locationInfo[3]);
		
		String hctMedia = getHctMedia(posEntryMode, posData);
		channelComponents.put("hct_media", hctMedia);
		channelComponents.put("smh_authenticate_mtd", getAuthMethod(hctMedia));
		
		channelComponents.put("hct_mer_mcc", mcc);
		channelComponents.put("hct_term_id", termId);
		
		channelComponents.put("hct_term_owner_name", locationInfo[0]);
		channelComponents.put("hct_term_city", locationInfo[1]);
		channelComponents.put("hct_term_state", locationInfo[2]);
		if(StringUtils.isNumeric(locationInfo[4]) && "170".equals(locationInfo[3])) {
			channelComponents.put("hct_term_post_code", locationInfo[4]);
		}
		channelComponents.put("hct_term_cntry_code", locationInfo[3]);
		
		String countryName = locationInfo[5]
		if(FMUtils.hasValue(countryName) && countryName.length()>30) {
			countryName = countryName.substring(0, 29);
		}
		channelComponents.put("rua_30byte_string_001", countryName);
        channelComponents.put("ind_comercio", locationInfo[6]);
				
	}
	
	public String getHctMedia(String ucmPos, String posData) {
		
		if(FMUtils.isNullOrEmpty(ucmPos)|| FMUtils.isNullOrEmpty(posData)) {
			ucmPos = "00";	
		}
		
		ucmPos = ucmPos.substring(0,2);
				
		String value = "UP_".concat(ucmPos).concat("_");
		if(("05".equals(ucmPos) || "07".equals(ucmPos)) && FMUtils.hasValue(posData)) {
			String pinEntryCap = String.valueOf(posData.charAt(6));
			value = value.concat(pinEntryCap);
		}
		//logger.info("posEntryMode: {}, posData:{}, pinEntrycap:{}, value:{}",ucmPos,posData,pinEntryCap,value);
		
		HctMedia hctMediaEq = HctMedia.getIfPresent(value);
		
		return hctMediaEq == null ? HctMedia.DEFAULT.hctMedia : hctMediaEq.hctMedia;
	}
	
	public String getAuthMethod(String value) {
		AuthMethod authMethodEq = AuthMethod.getIfPresent(value); 
		return authMethodEq == null ? AuthMethod.DEFAULT.authMethod : authMethodEq.authMethod;
	}
}
