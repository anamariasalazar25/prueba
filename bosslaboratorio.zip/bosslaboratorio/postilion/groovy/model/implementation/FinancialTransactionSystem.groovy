package postilion.groovy.model.implementation

import java.time.LocalDate
import java.util.Map;

import com.sas.davivienda.efm.commons.util.FMUtils;
import com.sas.davivienda.efm.commons.util.PostilionTransactionDate;

import postilion.groovy.model.sas.ASystemComponent;


class FinancialTransactionSystem extends ASystemComponent  {
	
	public FinancialTransactionSystem(Map<String, String> inputMsg, Map<String,String> enrichedMsgBody){
		super(inputMsg,enrichedMsgBody);
		
		String trxTime = inputMsg.get("7");
		String trxLocalTime = inputMsg.get("12");
		String trxLocalDate = inputMsg.get("13");
		LocalDate dateNow = LocalDate.now();
				
		systemComponents.put("rqo_tran_utc_flag","Y");
		systemComponents.put("rqo_tran_date",PostilionTransactionDate.getSASTransactionDate(trxTime.substring(0, 4),dateNow));
		systemComponents.put("rqo_tran_time",PostilionTransactionDate.getSASTransactionTime(trxTime.substring(4)));
		systemComponents.put("rqo_tran_date_alt",PostilionTransactionDate.getSASTransactionDate(trxLocalDate,dateNow));
		systemComponents.put("rqo_tran_time_alt",PostilionTransactionDate.getSASTransactionTime(trxLocalTime));
	}
	
}
