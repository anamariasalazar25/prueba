package postilion.groovy.model.implementation

import java.util.Map;

import org.slf4j.Logger

import com.sas.davivienda.efm.commons.util.FMUtils;

import postilion.groovy.model.sas.AAuthenticationComponent;
import postilion.groovy.model.enums.AccountType;
import postilion.groovy.model.enums.SMHTranType;
import postilion.groovy.model.enums.CustomerType;
import postilion.groovy.model.enums.ActivityType;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

class ChipCardAuthentication extends AAuthenticationComponent  {
	
	public ChipCardAuthentication(Map<String, String> inputMsg, Map<String,String> enrichedMsgBody, Map<String,String> de127MsgMap){
		super(inputMsg,enrichedMsgBody,de127MsgMap);
	}
	
}
