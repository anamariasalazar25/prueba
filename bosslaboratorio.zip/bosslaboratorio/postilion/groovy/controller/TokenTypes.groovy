package postilion.groovy.controller;

public enum TokenTypes {
	
	// Token COF y MIT
	C4("C4"), // Se modifica estructura del token en el evolutivo COF y MIT
	C0("C0"),
	OrgTOKEN17("OrgTOKEN17"),
	
	// Token usados en trasacción anterior
	CZ("CZ"),
	SC("SC"),
	TK("TK"),
	B0("B0"), // Se modifica estructura del token en el evolutivo COF y MIT
	
	// Se agregran los 5 tokens de MoneySend del control de cambios, se adiciona la llave del TOKEN C4
	SI("SI"),
	SJ("SJ"),
	SK("SK"),
	CH("CH"), // Se modifica estructura del token en el evolutivo COF y MIT
	CRDHLDR_ACTVT_TERM_IND("CRDHLDR_ACTVT_TERM_IND"),

	// Se agregan las 5 llaves de Diners DCI
	DCI_POS_ENTRY_MODE("DCI_POS_ENTRY_MODE"),
	//DE_37("DE_37"),
	//FUNCCODE("FUNCCODE"),
	FuncCode("FuncCode"),
	DCI_DE54_ADD_AMOUNT("DCI_DE54_ADD_AMOUNT"),
	DCI_DE62_ADD_AUTH_DATA("DCI_DE62_ADD_AUTH_DATA"),

	//se agregan llaves Proyecto Diners 3DS
	DCI_DE122_ADD_AUT_DATA("DCI_DE122_ADD_AUT_DATA"),
	DCI_DE44_ADD_RES_DATA("DCI_DE44_ADD_RES_DATA"),
	DCI_DE25_MES_REA_CODE("DCI_DE25_MES_REA_CODE")
	
	private final String code;
	
	private TokenTypes(final String code) {
		this.code = code;
	}
	
	public static TokenTypes tokenValueOf(String code){

		for(TokenTypes value : values()) {
						
			if(value.code.equals(code)) {
				return value;
			}
		}
		return null;
	}
	
	@Override
	public String toString() {
		return this.code;
	}
	
	
}
