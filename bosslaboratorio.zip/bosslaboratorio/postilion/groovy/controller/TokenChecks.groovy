package postilion.groovy.controller;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.sas.davivienda.efm.commons.util.DAVTokenizedDataParser;

import postilion.groovy.controller.Token;
import postilion.groovy.controller.TokenTypes;
import postilion.groovy.controller.enums.TokenCZ;
import postilion.groovy.controller.enums.TokenSC;
import postilion.groovy.controller.enums.TokenTK;
import postilion.groovy.controller.enums.TokenSI;
import postilion.groovy.controller.enums.TokenSJ;
import postilion.groovy.controller.enums.TokenSK;
import postilion.groovy.controller.enums.TokenCH;
import postilion.groovy.controller.enums.TokenC4;
import postilion.groovy.controller.enums.TokenC0;
import postilion.groovy.controller.enums.Token17;
import postilion.groovy.controller.enums.TokenB0;
import postilion.groovy.controller.enums.TokenDCI22;
//import postilion.groovy.controller.enums.TokenDCI37;
import postilion.groovy.controller.enums.TokenDCI24;
import postilion.groovy.controller.enums.TokenDCI54;
import postilion.groovy.controller.enums.TokenDCI62;
import postilion.groovy.controller.enums.TokenDCI25; //3DS Diners
import postilion.groovy.controller.enums.TokenDCI44; //3DS Diners
import postilion.groovy.controller.enums.TokenDCI122; //3DS Diners

import org.apache.camel.spring.Main;


public class TokenChecks {
	
	private static final Logger logger = LoggerFactory.getLogger("RequestProcessor");
	
	private static final tokensValue = [
		
		// Token COF y MIT
		"C4": TokenC4, // Se modifica estructura del token en el evolutivo COF y MIT
		"C0": TokenC0,
		"OrgTOKEN17": Token17,
		"B0": TokenB0, // Se modifica estructura del token en el evolutivo COF y MIT
		
		// Tokens usados en la transaccion anterior
		"CZ": TokenCZ,
		"SC": TokenSC,
		"TK": TokenTK,
		
		// Se agregran los 5 tokens de MoneySend del control de cambios, se adiciona la llave del TOKEN C4
		"SI": TokenSI,
		"SJ": TokenSJ,
		"SK": TokenSK,
		"CH": TokenCH, // Se modifica estructura del token en el evolutivo COF y MIT
		"CRDHLDR_ACTVT_TERM_IND": TokenC4,
				
		// Se agregan las 5 llaves de Diners DCI
		"DCI_POS_ENTRY_MODE": TokenDCI22,
		//"DE_37": TokenDCI37,
		//"FUNCCODE": TokenDCI24,
		"FuncCode": TokenDCI24,
		"DCI_DE54_ADD_AMOUNT": TokenDCI54,
		"DCI_DE62_ADD_AUTH_DATA": TokenDCI62,
		
		//se agregan llaves Proyecto Diners 3DS
		"DCI_DE122_ADD_AUT_DATA": TokenDCI122,
		"DCI_DE44_ADD_RES_DATA": TokenDCI44,
		"DCI_DE25_MES_REA_CODE": TokenDCI25
	];
		
	public static Map <String, String> createTokensValues(String tokenInfo, String tokenType) {
		
		Map <String, String> sasMap = new HashMap <String, String>();
		try {
			def tokensEnum = tokensValue[tokenType].values();
			
			for(def tokenValue: tokensEnum) {
				sasMap.put(tokenValue.sasValue, tokenInfo.substring(tokenValue.startPos - 1, tokenValue.finalPos))
			}
		}catch(Exception e) {
			logger.info("Length of {} token received is less than expected - {}",tokenType,e.getMessage());	
		}
		return sasMap;
	}
	
	public static Map <String, String> checkTokenValues(Token token) {

		// Check token type
		TokenTypes tokenType = TokenTypes.tokenValueOf(token.getCode());
				
		if(tokenType == null) {
			return null;
		}
		
		// Check token info size
		/*int tokenInfoSize = token.getInfo().length();
		
		if(tokenInfoSize != tokenInfoSize) {
			return null;
		}*/
		
		return createTokensValues(token.getInfo(), tokenType.code);
	}
	
	public static getTokenTypeAndValues(String tokenString) {
		
		def Map<String, String> validTokens = new HashMap<String, String>();
		// def tokensCodesList = ["TOKEN_TK", "TOKEN_SC", "TOKEN_CZ", "TOKEN_SI", "TOKEN_SJ", "TOKEN_SK", "TOKEN_CH", "CRDHLDR_ACTVT_TERM_IND", "DCI_POS_ENTRY_MODE", "DE_37", "FUNCCODE", "DCI_DE54_ADD_AMOUNT", "DCI_DE62_ADD_AUTH_DATA"];
		def tokensCodesList = ["TOKEN_C4", "TOKEN_C0", "OrgTOKEN17", "TOKEN_B0", "TOKEN_TK", "TOKEN_SC", "TOKEN_CZ", "TOKEN_SI", "TOKEN_SJ", "TOKEN_SK", "TOKEN_CH", "CRDHLDR_ACTVT_TERM_IND", "DCI_POS_ENTRY_MODE", "FuncCode", "DCI_DE54_ADD_AMOUNT", "DCI_DE62_ADD_AUTH_DATA", "DCI_DE122_ADD_AUT_DATA", "DCI_DE44_ADD_RES_DATA", "DCI_DE25_MES_REA_CODE"];

		for(String tokenCode : tokensCodesList) {
			
			String tokenValue = DAVTokenizedDataParser.getPostilionTokenData(tokenString, tokenCode);
			
			if(tokenValue != null && tokenValue.length() > 0) {
				validTokens.put(tokenCode, tokenValue)
			}
		}
		
		return validTokens;
		
	}
	
	/*public static void main (String args []) {
		String tokenSI = "";
		TokenChecks test = new TokenChecks();
		test.getTokenTypeAndValues; 
	}*/
	
}
