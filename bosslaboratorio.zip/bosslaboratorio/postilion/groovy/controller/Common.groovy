package postilion.groovy.controller;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

public class Common {
	
	private static final Logger logger = LoggerFactory.getLogger("RequestProcessor");
	
	public static List<String> splitStringBySpace(String value) {
		return splitString(value, "\\s+");
	}
	
	public static List<String> splitString(String value, String splitBy) {
		String[] arrayValue = value.split(splitBy);
		return Arrays.asList(arrayValue);
	}
		
	public static String StrinArrayToStringBySpace(String valuesList) {
		return StringUtils.join(valuesList, " ");		
	}
	
	public static String getSubstringByChar(String value, String substringBy) {
		int fisrtAppea = value.indexOf(substringBy);
		
		if(fisrtAppea == -1) {
			return null;
		}
		
		return value.substring(fisrtAppea)
	}
	
}
