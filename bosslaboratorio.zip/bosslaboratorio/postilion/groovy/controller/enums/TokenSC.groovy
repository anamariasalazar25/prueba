package postilion.groovy.controller.enums;

public enum TokenSC {
	
	// Mapeo de los campos relacionados ya existentes en Tokenizacion - Control de cambios
	// Nombre del campo, tipo, longitud, posición inicial, posición final, campo sas
	TOKEN_ASSURANCE_LEVEL("AN", 2, 22, 23, "dmx_2byte_string_01_tag"),
	TOKEN_REQUESTOR_ID("N", 11, 24, 34, "rua_numeric_057") // MasterCard
	
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenSC(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
