package postilion.groovy.controller.enums;

public enum TokenDCI24 {
	
	 // Mapeo de los campos relacionados en el Excel Diners DCI
	 // Nombre del campo, tipo, longitud, posición inicial, posición final, campo sas 
	 FuncCode("N", 3, 1, 3, "dmx_n3_02");
	 		
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenDCI24(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
