package postilion.groovy.controller.enums;

public enum Token17 {
	
	// Nombre del campo, tipo, longitud, posición inicial, posicion final, campo sas
	// Mapeo de campos evolutivo COF y MIT
	TRAN_ID_MMDD("AN", 4, 2, 5, "rur_4byte_string_004"), // TRAN_ID: MMDD
	TRAN_ID_HHMMSS("AN", 6, 6, 11, "dua_8byte_string_004"), // TRAN_ID: HHMMSS
	TRAN_ID_C37("AN", 5, 12, 16, "dua_8byte_string_007"), // TRAN_ID: C37
	TIPO_TX("AN", 2, 17, 18, "rua_2byte_string_006"),
	CATEGORIA_TX_MIT("AN", 2, 19, 20, "dmx_3byte_string_01_tag"),
		 		
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private Token17(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
