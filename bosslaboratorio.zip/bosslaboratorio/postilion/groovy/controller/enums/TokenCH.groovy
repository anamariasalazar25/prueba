package postilion.groovy.controller.enums;

public enum TokenCH {
	
	// Nombre del campo, tipo, longitud, posición inicial, posicion final, campo sas
	// Mapeo de campos evolutivo COF y MIT
	RESP_SRC_RSN_CDE("AN", 1, 1, 1, "rua_ind_032"),
	ONLINE_LMT("AN", 12, 3, 14, "dua_20byte_string_003"),
	PMNT_IND("AN", 1, 20, 20, "rur_ind_003"), // Token CH MIT
	RVSL_RSN_IND("AN", 1, 34, 34, "dmx_ind_03"),
	AUTH_MSG_IND("AN", 1, 37, 37, "dmx_ind_04"), // Token CH MIT
	TERM_TYP("AN", 1, 38, 38, "dmx_ind_05"),
	PMNT_INFO("AN", 1, 39, 39, "rur_ind_004"),
	
	// Mapeo de los campos MoneySend
	FUNDING_PAYMENT_TRANSACTION_TYPE_INDICATOR("AN", 3, 25, 27, "dmx_3byte_string_03"),
	
	// Estructura de la informacion contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Metodo invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenCH(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
