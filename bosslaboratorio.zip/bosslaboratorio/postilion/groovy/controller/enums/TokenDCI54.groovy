package postilion.groovy.controller.enums;

public enum TokenDCI54 {
	
	 // Mapeo de los campos relacionados en el Excel MoneySend
	 // Nombre del campo, tipo, longitud, posición inicial, posición final, campo sas 
	 AMOUNTTYPE("AN", 2, 3, 4, "dmx_n3_03_tag"),
	 CURRENCYCODE("AN", 3, 5, 7, "dmx_n3_03"),
	 AMOUNT("AN", 12, 9, 20, "dmx_n22_01");
	 		
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenDCI54(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
