package postilion.groovy.controller.enums;

public enum TokenB0 {
	
	// Mapeo de los campos relacionados en el Excel MoneySend
	// Nombre del campo, tipo, longitud, posición inicial, posición final, campo sas 
	MIS_CAS_CDE("AN", 4, 145, 148, "rur_4byte_string_001"),
	PRTL_AUTH_IND("AN", 1, 149, 149, "rur_4byte_string_003"),
		 		
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenB0(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
