package postilion.groovy.controller.enums;

public enum TokenDCI122 {
	
	 // Mapeo de los campos relacionados en el Excel Diners 3ds
	 // Nombre del campo("tipo", longitud, posición inicial, posición final, "campo sas") 
	 ECI("AN", 1, 2, 2, "dmx_ind_01"),
	 AUTHRESCODE("AN", 2, 3, 4, "dmx_n8_02_tag"),
	 SFAUTHRESCODE("AN", 2, 5, 6, "dmx_n22_01_tag"),
	 CAVVKEYIND("AN", 2, 7, 8, "dmx_n22_02_tag"),
	 CAVV("AN", 4, 9, 12, "rur_4byte_string_006"),
	 AUTHTRACK("AN", 16, 17, 32, "dua_20byte_string_004"),
	 VERSIONACTION("AN", 2, 33, 34, "dmx_3byte_string_02_tag"),
	 IPHEX("AN", 8, 35, 42, "dua_8byte_string_009");
	 		
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenDCI122(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
