package postilion.groovy.controller.enums;

public enum TokenTK {
	
	// Mapeo de los campos relacionados ya existentes en Tokenizacion - Control de cambios
	// Nombre del campo, tipo, longitud, posición inicial, posición final, campo sas
	TOKEN_ASSURANCE_LEVEL("AN", 2, 21, 22, "dmx_2byte_string_01"),
	TOKEN_REQUESTOR_ID("N", 11, 23, 33, "rua_numeric_057"), // Visa
	TIPO_DE_TOKEN("AN", 2, 38, 39, "dmx_2byte_string_02_tag"),
	AAM_VELOCITY_CHECKING_RESULT("N", 2, 40, 41, "dmx_2byte_string_02"),
	TOKEN_REQUESTOR_TOKEN_SERVICE_PROVIDER_ID("N", 11, 42, 52, "rua_numeric_058"),
	TOKEN_USER_IDENTIFIER("N", 11, 55, 65, "rua_numeric_059"),
	TOKEN_USER_APPLICATION_TYPE("AN", 2, 66, 67, "dmx_2byte_string_03_tag"),
	TOKEN_AUTHENTICATION_FACTOR_A("N", 2, 68, 69, "dmx_2byte_string_03"),
	TOKEN_AUTHENTICATION_FACTOR_B("N", 2, 70, 71, "dmx_ind_01_tag")	
	
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenTK(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
