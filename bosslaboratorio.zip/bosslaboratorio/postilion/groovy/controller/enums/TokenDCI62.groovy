package postilion.groovy.controller.enums;

public enum TokenDCI62 {
	
	 // Mapeo de los campos relacionados en el Excel MoneySend
	 // Nombre del campo, tipo, longitud, posición inicial, posición final, campo sas 
	 ADDAUTHDATA("AN", 1, 1, 1, "rua_ind_027");
	 		
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenDCI62(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
