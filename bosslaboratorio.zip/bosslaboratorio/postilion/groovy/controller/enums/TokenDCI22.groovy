package postilion.groovy.controller.enums;

public enum TokenDCI22 {
	
	 // Mapeo de los campos relacionados en el Excel Diners DCI
	 // Nombre del campo, tipo, longitud, posición inicial, posición final, campo sas 
	 POSENTRYMODE1("AN", 1, 5, 5, "rua_ind_029"), //Cambio de campo SAS por uno nuevo, inicialmente rua_ind_020
	 POSENTRYMODE2("AN", 1, 7, 7, "rua_ind_030"); //Cambio de campo SAS por uno nuevo, inicialmente rua_ind_005
	 		
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenDCI22(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
