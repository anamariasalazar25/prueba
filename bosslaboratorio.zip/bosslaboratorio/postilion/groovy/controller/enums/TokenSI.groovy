package postilion.groovy.controller.enums;

public enum TokenSI {
	
	 // Mapeo de los campos relacionados en el Excel MoneySend
	 // Nombre del campo, tipo, longitud, posición inicial, posición final, campo sas 
	 FRMT_CODE("AN", 2, 1, 2, "dmx_n3_01_tag"),
	 ACC_NUM("AN", 20, 6, 25, "tpp_acct_num"),
	 TOTAL_NAME("AN", 71, 26, 96, "tpp_name"),
	 STREET_ADDR("AN", 50, 97, 146, "tpp_address"),
	 CITY("AN", 25, 147, 171, "tpp_city"),
	 STATE_ADDR("AN", 3, 172, 174, "tpp_state"),
	 //POSTAL_CDE("AN", 10, 178, 187, "tpp_post_code"),
	 CNTRY("AN", 3, 175, 177, "tpp_cntry_code");
	 		
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenSI(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
