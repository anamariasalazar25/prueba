package postilion.groovy.controller.enums;

public enum TokenSJ {
	
	 // Mapeo de los campos relacionados en el Excel MoneySend
	 // Nombre del campo, tipo, longitud, posición inicial, posición final, campo sas 
	FRMT_CODE("AN", 2, 1, 2, "dmx_n3_02_tag"),
	ACC_NUM("AN", 20, 6, 25, "dua_20byte_string_002"),
	TOTAL_NAME("AN", 71, 26, 96, "xqo_cust_name"),
	STREET_ADDR("AN", 50, 97, 146, "xqo_address"),
	CITY("AN", 25, 147, 171, "dee_entity_id_2"),
	ST("AN", 3, 172, 174, "dmx_3byte_string_01"),
	CNTRY("AN", 3, 175, 177, "rua_3byte_string_008"),
	//POSTAL_CDE("AN", 10, 178, 187, "dee_entity_id_1_tag"),
	PHN_NUM("AN", 20, 188, 207, "dee_entity_id_1"),
	DOB("AN", 8, 208, 215, "dee_entity_id_2_tag"),
	ID_TYP("AN", 2, 216, 217, "dmx_ind_03_tag"),
	ID_NUM("AN", 25, 218, 242, "dee_entity_id_3");
	 		
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenSJ(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
