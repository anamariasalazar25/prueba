package postilion.groovy.controller.enums;

public enum TokenDCI37 {
	
	 // Mapeo de los campos relacionados en el Excel Diners DCI
	 // Nombre del campo, tipo, longitud, posición inicial, posición final, campo sas 
	 DE37("AN", 8, 5, 12, "dua_8byte_string_006");
	 		
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenDCI37(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
