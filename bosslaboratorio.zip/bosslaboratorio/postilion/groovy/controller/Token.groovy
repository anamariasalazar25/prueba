package postilion.groovy.controller;

import java.util.List;

import postilion.groovy.controller.Common;

public class Token {
	
	public Token(String code, String info) {
		
		this.code = code;
		this.info = info;
	}
	
	private String code;
	private String info;

	
	public String getCode() {
		return this.code;
	}
	
	public String getInfo() {
		return this.info;
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", Token.class.getSimpleName() + "{", "}")
			.add("code='" + this.code + "'")
			.add("info='" + this.info + "'")
			.toString();
	}
	
	
}
