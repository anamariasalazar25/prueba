package postilion.groovy.tools;

import java.util.Arrays;
import java.util.List;
import java.util.StringJoiner;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.enums.SASCitiesCodes;
import com.sas.davivienda.efm.commons.enums.SASCitiesNames;
import com.sas.davivienda.efm.commons.enums.SASCountryCodesAlpha2;
import com.sas.davivienda.efm.commons.enums.SASCountryCodesAlpha3;
import com.sas.davivienda.efm.commons.enums.SASUSCitiesNames;
import com.sas.davivienda.efm.commons.util.FMUtils;

public class CardAcceptorLocationParser {

	private static final Logger logger = LoggerFactory.getLogger("CardAcceptorLocationParser");
	private static List<String> colStatesNom = Arrays.asList("ARC","BOG","ANT","VAL","CUN","ATL","SAN","BOL","COR","NAR","NOR","CAU","MAG","TOL","CES","BOY","HUI","MET","CAL","LAG","RIS","SUC","QUI","CHO","CAS","CAQ","PUT","ARA","VIC","GUA","AMA","SAN","GUA","VAU","COL");
	private static final String NAT_NODE = "NAL";
	private static final String INT_NODE = "INT";
	
	private ProcessDataPostilion() {
		throw new IllegalStateException("Utility class");
	}
		
	public static String[] processCardAcceptorNameLocation(String cardAcceptorNameLocation, String nodoSource, String nationalInternalIndicator) {
		
		String termOwnerName = cardAcceptorNameLocation.substring(0, 22);
		String termCity = cardAcceptorNameLocation.substring(22, 36).toUpperCase().trim();
		String termState = cardAcceptorNameLocation.substring(36, 38).toUpperCase();
		String termCntryCode = cardAcceptorNameLocation.substring(38, 40).toUpperCase();
		String stateCntry = (termState+termCntryCode).trim();
		
		if(termState.trim().isEmpty()){termState="";}
		if(termCntryCode.trim().isEmpty()){termCntryCode="";}
		
		if("CtmMsgSplSr".equals(nodoSource) || "PsvOn2Src".equals(nodoSource) || "N".equals(nationalInternalIndicator) || "CO".equals(termCntryCode)) {
			String nomencState = cardAcceptorNameLocation.substring(35, 38).toUpperCase();
			return ubicacionComercioColombia(termOwnerName, termCity, termState, nomencState);
		}else {
			return ubicacionComercioInternacional(termOwnerName, termCity, termState, stateCntry, termCntryCode);
		}
	}
	
	private static String[] ubicacionComercioColombia(String termOwnerName, String termCity, String termState, String nomencState) {
		
		String colTermPostCode = "";
		String colTermCntryCode = "170";
		String colTermCntryName = "COLOMBIA";
		
		if(termCity.trim().length() >= 3) {
			
			//Casos en que el departamento tiene 3 caracteres y se encuentra entre ciudad y departamento, 
			//se debe eliminar la ultima posicion del campo ciudad para poder realizar la busqueda por ciudad alfabetica
			if(colStatesNom.contains(nomencState)){
				termCity = termCity.substring(0,13);
			}
			
			String[] resultado = obtenerNumerosCadena(termCity);
			//logger.info("resultado: [{},{}]",resultado[0],resultado[1]);
			
			String ciudadNumerico = resultado[0];
			String ciudadAlfabetico = resultado[1];
			
			if(FMUtils.hasValue(ciudadNumerico)){
				SASCitiesCodes cityCodes = SASCitiesCodes.getIfPresent("C_"+ciudadNumerico);
				if(cityCodes != null) {
					termCity = cityCodes.getOfficialName();
					colTermPostCode = cityCodes.getNumericCode();
					termState = colTermPostCode.substring(0,2);
				}
			}
			
			if(FMUtils.isNullOrEmpty(colTermPostCode) && FMUtils.hasValue(ciudadAlfabetico)) {
				ciudadAlfabetico = ciudadAlfabetico.trim().replace("-", "").replace(",", "").replace(".", "");
				SASCitiesNames cityNames = SASCitiesNames.getIfPresent(ciudadAlfabetico.toUpperCase());
				if(cityNames != null){
					termCity = cityNames.getOfficialName();
					colTermPostCode = cityNames.getNumericCode();
					termState = cityNames.getNumericState();
				}
			}
			
		}
		return [termOwnerName, termCity, termState, colTermCntryCode, colTermPostCode, colTermCntryName, NAT_NODE] as String[];
		//return new String [] {termOwnerName, termCity, termState, colTermCntryCode, colTermPostCode, colTermCntryName, NAT_NODE};
	}
	
	private static String[] ubicacionComercioInternacional(String termOwnerName, String termCity, String termState, String stateCntry, String termCntryCode) {
		String intTermPostCode = "";
		String intTermCntryName = "";
		int stateCntryLen = stateCntry.length(); 

		switch(stateCntryLen) {
			case 2: 
			case 4:
				if(termCntryCode.trim().length() == 2) {
					SASCountryCodesAlpha2 alpha2Eq = SASCountryCodesAlpha2.getIfPresent(termCntryCode);
					termCntryCode = alpha2Eq == null ? termCntryCode :alpha2Eq.getNumericCode();
					intTermCntryName = alpha2Eq == null ? "" :alpha2Eq.getOfficialName();
				}else {
					String alfabetico = termCity.replaceAll("[^A-Za-z]", "");
					SASUSCitiesNames sasUSCities = SASUSCitiesNames.getIfPresent(stateCntry+"_"+alfabetico);
					
					if(sasUSCities != null) {
						termCity = sasUSCities.getOfficialName();
						termState = sasUSCities.getState();
						termCntryCode = "840";
						intTermCntryName = "ESTADOS UNIDOS DE AMERICA";
					}
				}
			break;
			case 3:
				SASCountryCodesAlpha3 alpha3Eq = SASCountryCodesAlpha3.getIfPresent(stateCntry);
				termCntryCode = alpha3Eq == null ? termCntryCode :alpha3Eq.getNumericCode();
				termState = "";
				intTermCntryName = alpha3Eq == null ? "" :alpha3Eq.getOfficialName();
			break;
			default:
			break;
		}
        return [termOwnerName, termCity, termState, termCntryCode, intTermPostCode, intTermCntryName, INT_NODE] as String[];
		//return new String [] {termOwnerName, termCity, termState, termCntryCode, intTermPostCode, intTermCntryName, INT_NODE};
	}

	private static String[] obtenerNumerosCadena(String cadena) {
		try {
			
			String alfabetico = cadena.replaceAll("[^A-Za-z]", "");
			String numerico = cadena.replaceAll("[^0-9]", "");

			if(numerico !=null && numerico.length() >= 7) {
				if(numerico.startsWith("00")) {
					numerico = numerico.substring(2, 7);
				}else {
					numerico = numerico.substring(0, 5);
				}
			}
			
			if(numerico !=null && numerico.length() > 5) {
				numerico = numerico.substring(0, 5);
			}
            return [numerico,alfabetico] as String[];
            //return new String[] {numerico,alfabetico};
		}catch (Exception e) {
			return ["",""] as String[];
		}
	}
	
	public static void printInfoByPosition(String msgType, String termOwnerName,String termCity,String termState,String termCntryCode) {
		
		String message = new StringJoiner(" ", "CardAcceptorByPosition: [", "]")
				.add("[termOwnerName:").add(termOwnerName.concat("]"))
				.add("[termCity:").add(termCity.concat("]"))
				.add("[termState:").add(termState.concat("]"))
				.add("[termCntryCode:").add(termCntryCode.concat("]"))
				.toString();
		logger.info("{}: {}",msgType,message);
	}
	
}
