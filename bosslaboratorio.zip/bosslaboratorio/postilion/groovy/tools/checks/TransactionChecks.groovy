package postilion.groovy.tools.checks;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.FMTrackDataParser
import com.sas.davivienda.efm.commons.util.FMUtils
import com.sas.davivienda.efm.commons.util.PostilionTransactionDate
import postilion.groovy.model.enums.ActivityType;
import java.text.SimpleDateFormat;
import org.apache.camel.Exchange;

import java.time.LocalDate;
import javax.annotation.Resource;

public class TransactionChecks {

	private static final Logger logger = LoggerFactory.getLogger("InputProcessor");
	
	public static void mapRequiredInfoForUpdate(Exchange exchange) {
		Map<String,Object> initialMap = exchange.getProperty("8583MsgMap",Map.class);
		Map<String,Object> updateParams = new HashMap();
		
		String pan = initialMap.get("2");
		String processingCode = initialMap.get("3");
		String trxAmt = initialMap.get("4");
		String settlementAmt = initialMap.get("5");
		String trxTime = initialMap.get("12");
		String trxDate = initialMap.get("13");
		String trackii = initialMap.get("35");
		String trxRefNum = initialMap.get("37");
		String authNumber = initialMap.get("38");
		
		String tranAmount = getTranAmount(trxAmt,settlementAmt);
		String productId = getProductId(pan, trackii);
		LocalDate dateNow = LocalDate.now();
		
		updateParams.put("productId", productId);
		//updateParams.put("dateNow", dateNow);
		updateParams.put("referenceNumber", trxRefNum);
		updateParams.put("tranDateLocal", PostilionTransactionDate.getDBTransactionDate(trxDate, dateNow));
		String tranTimeLocal = PostilionTransactionDate.getSASTransactionTime(trxTime);
		updateParams.put("tranTimeLocal", "01/01/1970 ".concat(tranTimeLocal));
		updateParams.put("authorizationIdResponse", authNumber);
		
		Date dateNowRef = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDateNow = formatter.format(dateNowRef);
		updateParams.put("dateNow", strDateNow);
		//exchange.setProperty("dateNow",strDateNow);
		
		String procCode = initialMap.get("3");
		String postActivityType = procCode.substring(0, 2);
		String sasActivityType = getSASActivityType(postActivityType);
		
		exchange.setProperty("sasActivityType", sasActivityType);
		exchange.setProperty("updateParams", updateParams);
	}
	
	static String getSASActivityType(String postActivityType) {
		return ActivityType.("AT_".concat(postActivityType)).sasActivityType;
	}
		
	public static String getTranAmount(String trxAmt, String settlementAmt) {
		String tranAmount = trxAmt;
		if(FMUtils.hasValue(settlementAmt)){
			tranAmount = settlementAmt;
		}
		tranAmount = FMUtils.stripLeadingZeros(tranAmount);
		
		return FMUtils.addDecimalSeparator(tranAmount);
	}
	
	/**
	 * Si el DE5 viene poblado, el monto en moneda de comercio es el DE4 y el monto en pesos es el DE5,
	 * caso contrario, DE4 es la moneda del comercio y del cliente
	 * @param trxAmt
	 * @param trxCurrCode
	 * @param settlementAmt
	 * @param settlementCurrCode
	 * @return [clientAmt,clientCurrCode,merchAmt,merchCurrCode]
	 */
	public static String[] getTranAmtInformation(String trxAmt, String trxCurrCode, String settlementAmt, String settlementCurrCode) {
		
		String clientAmount = "";
		String clientCurrCode = "";
		String merchAmount = FMUtils.stripLeadingZeros(trxAmt);
		merchAmount = FMUtils.addDecimalSeparator(merchAmount);
		String merchCurrCode = trxCurrCode;
		
		if(FMUtils.hasValue(settlementAmt)){
			clientAmount = settlementAmt;
			clientCurrCode = settlementCurrCode;
			
			clientAmount = FMUtils.stripLeadingZeros(clientAmount);
			clientAmount = FMUtils.addDecimalSeparator(clientAmount);
		}else {
			clientAmount = merchAmount;
			clientCurrCode = merchCurrCode;
		}
		
		return [clientAmount,clientCurrCode,merchAmount,merchCurrCode] as String[];
	}

        public static String getDci54Amount(String dciAmt) {
                String dci54Amount = FMUtils.stripLeadingZeros(dciAmt);
                dci54Amount = FMUtils.addDecimalSeparator(dci54Amount);
                //println "dci54Amount="+dci54Amount;
                return dci54Amount;
        }

	public static String getProductId(String pan, String trackii) {
		String productId = pan;
		
		if(FMUtils.isNullOrEmpty(pan) && FMUtils.isNullOrEmpty(trackii)){
			throw new Exception("No fue posible obtener informacion del producto");
		}
		
		if(FMUtils.isNullOrEmpty(pan) && FMUtils.hasValue(trackii)) {
			int separatorPosition =  FMTrackDataParser.getTrackSeparatorPosition(trackii);
			productId = trackii.substring(0, separatorPosition);
		}
		return productId;
	}
}

