package clientsApis.groovy.model.enums;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

public enum ActivityType {

        BILL_PAYMENT("BILL_PAYMENT", "B"),
        REQUEST_PRODUCT("REQUEST_PRODUCT", null),
        PERSON_PAYMENT("PERSON_PAYMENT", "P"),          //multibanco
        BALANCE_TRANSFER("BALANCE_TRANSFER", "T"),      //multibanco
	
/**
*       ACCOUNT_ACTIVATION("ACCOUNT_ACTIVATION", null),
*       ADD_PAYEE_PAY_A_PERSON("ADD_PAYEE_PAY_A_PERSON", null),
*       AUTHORISES_SMARTCARD("AUTHORISES_SMARTCARD", null),
*       CHANGE_DETAILS("CHANGE_DETAILS", null),
*       CHANGE_PASSWORD("CHANGE_PASSWORD", null),
*       ENROLLMENT("ENROLLMENT", null),
*       LOGIN("LOGIN", null),
*       OB_CONSENT_SUBMISSION("OB_CONSENT_SUBMISSION", null),
*       RESET_PASSWORD("RESET_PASSWORD", null),
*       SECOND_LOGIN("SECOND_LOGIN", null),
*       UPDATE_TEXT_ALERTS("UPDATE_TEXT_ALERTS", null),
*       VIEW_CARD_INFO("VIEW_CARD_INFO", null),
*       CHANGE_ADDRESS("CHANGE_ADDRESS", null),
*		BULK_AUTHORIZE_PAYMENT("BULK_AUTHORIZE_PAYMENT", null), //evolutivo Multitransferencias
*/
		
        private final String activityType;
        private final String tranTypeTBT;

        private ActivityType(final String activityType, final String tranTypeTBT) {
                this.activityType = activityType;
                this.tranTypeTBT = tranTypeTBT;
        }

        @Override
        public String toString() {
                return this.activityType;
        }
}
