package clientsApis.groovy.model.enums;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonCreator;

public enum AccountTypePayee {
	
	BILLER("",""),
	CD("SV","03"),
	CHECKING("CK","01"),
	CREDIT_CARD("CC",""),
	DAVIPLATA("SV","03"),
	DEBIT_CARD("SV","03"),
	MONEDERO_OTRO_BANCO("SV","03"),
	MONEDERO_OTROS_BANCOS("SV","03"),
	PERSONAL_ACCOUNT("SV","03"),
	SAVINGS("SV","03"),
	LINE_OF_CARD("LC",""), 
	BROKERAGE("IV",""),
	//CC059
	CUENTA_AHORROS("SV","03"),
	CUENTA_CORRIENTE("CK","01"),
	TARJETA_CREDITO("CC",null),
	CUENTA_OTRO_BANCO_AHO("",null),		//antes de multibanco estaba este valor CUENTA_OTRO_BANCO_AHO("SV",null), -> para multibanco se deja vacío el primer valor
	CUENTA_OTRO_BANCO_CTE("",null),		//antes de multibanco estaba este valor CUENTA_OTRO_BANCO_CTE("CK",null), -> para multibanco se deja vacío el primer valor
	OTRO_MONEDERO("SV",null),
	NUMERO_CELULAR("SV",null),
	BOLSILLO("SV",null),
	ADELANTO_NOMINA("LC",null),
	CREDIEXPRESS("LC",null),
	LIBRANZA("LC",null),
	CREDITO_MOVIL("LC",null),
	CREDITO_HIPOTECARIO("LC",null),
	CREDITO_LIBRANZA("LC",null),
	//TODO: ask about subtype
	FICS("IV",null),
	DAFUTURO("IV",null),
	DEFAULT("",""),
	CREDIT_CARD_DAVIPUNTOS("CC",null),
	DAVIPUNTOS("CC",null),
	//SuperApp
	LINE_OF_CREDIT("LC",null),
	
	private final String accountType;
	private final String enrAccountType;
 
	private AccountTypePayee(final String accountType, final String enrAccountType) {
		this.accountType = accountType;
		this.enrAccountType = enrAccountType;
	}
		
	@Override
	public String toString() {
		return this.accountType;
	}
	
}
