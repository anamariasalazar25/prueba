package clientsApis.groovy.model.enums;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.google.gson.annotations.JsonAdapter;

public enum AccountType {
	
	CHECKING("CS","01","C","ACCOUNT_NUM"),
	SAVINGS("CS","03","S","ACCOUNT_NUM"),
	CREDIT_CARD("CC",null,null,"CREDIT_CARD"),
	DEBIT_CARD("CS","03","S","DEBIT_CARD"),
	LINE_OF_CARD("LC",null,null,"ACCOUNT_NUM"),
	CD("CS",null,null,"ACCOUNT_NUM"),
	BROKERAGE("CS",null,null,"ACCOUNT_NUM"),
	DEFAULT("CS",null,null,"ACCOUNT_NUM"),
	//CC059
	CUENTA_AHORROS("CS","03","S","ACCOUNT_NUM"),
	CUENTA_CORRIENTE("CS","01","C","ACCOUNT_NUM"),
	TARJETA_CREDITO("CC",null,null,"CREDIT_CARD"),
	CUENTA_OTRO_BANCO_AHO("NA","","",null),
	CUENTA_OTRO_BANCO_CTE("NA","","",null),
	DAVIPLATA("CS","03","S","ACCOUNT_NUM"),
	OTRO_MONEDERO("NA",null,null,null),
	NUMERO_CELULAR("NA",null,null,null),
	BOLSILLO("CS","03","S","ACCOUNT_NUM"),
	ADELANTO_NOMINA("LC",null,null,"ACCOUNT_NUM"),
	CREDIEXPRESS("LC",null,null,"ACCOUNT_NUM"),
	LIBRANZA("LC",null,null,"ACCOUNT_NUM"),
	CREDITO_MOVIL("LC",null,null,"ACCOUNT_NUM"),
	CREDITO_HIPOTECARIO("LC",null,null,"ACCOUNT_NUM"),
	CREDITO_LIBRANZA("LC",null,null,"ACCOUNT_NUM"),
	CREDIT_CARD_DAVIPUNTOS("CC",null,null,"CREDIT_CARD"),
	DAVIPUNTOS("CC",null,null,"CREDIT_CARD"),
	TRANSPORTADORA("CS",null,null,"ACCOUNT_NUM"),
	//SuperApp 
	MONEDERO_OTRO_BANCO("CS",null,null,"ACCOUNT_NUM"),
        //Dafuturo
        CUENTA_OTRO_BANCO("CS",null,null,null),
        //Dafuturo Sprint2
	FICS("CS","03","S","ACCOUNT_NUM"),
	DAFUTURO("CS","03","S","ACCOUNT_NUM"),


	private final String accountType;
	private final String enrAccountType; // 03=CUENTA AHORROS, 01=CUENTA CORRIENTE
	private final String accountRelationship; // S: CUENTA AHORROS, C: CUENTA CORRIENTE.

	private final String trxMean;
 
	private AccountType(final String accountType, final String enrAccountType, final String accountRelationship, final String trxMean) {
		this.accountType = accountType;
		this.enrAccountType = enrAccountType;
		this.accountRelationship = accountRelationship;
		this.trxMean = trxMean;
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", AccountType.class.getSimpleName() + "[", "]")
		.add("accountType=" + this.accountType)
		.add("enrAccountType=" + this.enrAccountType)
		.add("accountRelationship=" + this.accountRelationship)
		.add("trxMean=" + this.trxMean)
		.toString();
	}
}
