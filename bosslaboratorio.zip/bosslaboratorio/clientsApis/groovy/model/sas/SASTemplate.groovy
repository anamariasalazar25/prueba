package clientsApis.groovy.model.sas;

import org.slf4j.Logger
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;

import clientsApis.groovy.tools.Common;
import clientsApis.groovy.tools.values.Segments;
import clientsApis.groovy.tools.deserializers.DatesFormats;

public abstract class SASTemplate {
	 
	private static final Logger logger = LoggerFactory.getLogger("clientsApislog");

	private static ArrayList validSegments = null;
	
	/**
	 * Map SASTemplate java object attributes to SAS fields
	 * @return HashMap with SAS fields
	 */
	public abstract Map<String,Object> obtainSASFormat();

	/**
	 * Map SASTemplate java object attributes to SAS fields
	 * @param object SASTemplate object
	 * @param enumer SAS enumeration mapper
	 * @return HashMap with object SAS fields
	 */
	protected <T,S> Map<String,Object> sasValidation(T object, S enumer) {
		
		
		def attrsMap = Common.getObjectAttList(object);
		if(attrsMap.containsKey("validSegments")) this.validSegments = attrsMap.get("validSegments");
		
		if(this.validSegments != null) {
			
			Map<String,Object> sasMap = new HashMap<String, Object>();
			
			for(att in attrsMap) {
	
				if(att.value instanceof SASTemplate == false) {
							
					if(att.value != null) {
						try {
							def attKey = att.key;
							def attVal = att.value;
							
							if (attVal instanceof List) {
	
								for(Object e: attVal) {
									if(e instanceof SASTemplate == true) sasMap.putAll(e.obtainSASFormat());
								}
							}
	
							if(attVal instanceof java.util.Date) {
								attVal = DatesFormats.changeDateFormat(DatesFormats.DATE_FORMAT_A, attVal);
							}
							
							def sasValue = enumer.valueOfElement(attKey);
							
							if (sasValue != null && this.validSegments.contains(sasValue.getSegment())) sasMap.put(sasValue.getAtt(), attVal.toString());
						}
						
						catch(Exception e) {
							logger.error(e.getMessage() + ": " + att.key);
						}
					}		
				}
				
				else {
					
					if(att.value instanceof SASTemplate == true) {
						sasMap.putAll(att.value.obtainSASFormat());
					}
				}
				
			}
			
			return sasMap;
		}
		return null;
    }
}
