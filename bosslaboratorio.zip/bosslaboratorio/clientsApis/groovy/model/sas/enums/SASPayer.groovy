package clientsApis.groovy.model.sas.enums;

import java.util.Map;
import java.util.HashMap;

import clientsApis.groovy.model.sas.interfaces.SASInterface;

public enum SASPayer implements SASInterface {
	
	idType("rua_2byte_string_002", 2, 2, "RUA", false),
	idNumber("rua_20byte_string_002", 20, 20, "RUA", false),
	accountNumber("aqo_acct_num", 34, 34, "AQO", true),
	accountType("dua_40byte_string_002", 30, 30, "DUA", false),
	accountTypeSMH("smh_acct_type", 2, 2, "SMH", false),
	brand("dee_entity_id_2", 30, 30, "DEE", false), //tipo cliente
	
	//BOSS
	tipoBrandSMH("smh_cust_type", 1, 1, "SMH", false),
	tipoBrandMulti("smh_multi_org_name", 1, 1, "SMH", false)
		
	
	private final String payerAtt;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;

	private SASPayer(final String payerAtt, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.payerAtt = payerAtt;
		this.minLength = minLength;
		this.maxLength = maxLength;		
		this.segment = segment;
		this.req = req;
	}
	
	
	public static SASInterface valueOfElement(String name) {

		try {
			def val = SASPayer.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.payerAtt;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}

	@Override
	public Boolean getReq() {
		return this.req;
	}
}


