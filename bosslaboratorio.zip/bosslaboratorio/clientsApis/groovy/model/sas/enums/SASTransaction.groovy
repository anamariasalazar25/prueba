package clientsApis.groovy.model.sas.enums;

import java.util.Map;
import java.util.HashMap;

import clientsApis.groovy.model.sas.interfaces.SASInterface;

public enum SASTransaction implements SASInterface {
	
	enterpriseCustomerId("hqo_ob_userid", 50, 50, "HQO", false),
	sessionId("hob_session_id", 100, 100, "HOB", false),
	platformType("dua_40byte_string_001", 40, 40, "DUA", true),
	activityName("rua_30byte_string_001", 30, 30, "RUA", false),
	activityType("rua_30byte_string_002",30, 30, "RUA", true),
	activityAmount("tsh_client_amt", 22, 22, "TSH", true),
	transactionId("tbt_ref_num", 40, 40, "TBT", true),
	cusPSE("rua_20byte_string_001", 20, 20, "RUA", false),
	referenceNumber1("tbt_billing_ref_num", 80, 80, "TBT", false),
	referenceNumber2("tpp_description", 100, 100, "TPP", false),
	selfCustomerTransferIndicator("tbt_self_acct_ind", 1, 1, "TBT", true),
	amountBeforeTrnx("aqd_avail_bal", 22, 22, "AQD", false),
	agreementId("rua_10byte_string_002", 10, 10, "RUA", false),
	uniqueCommercialCode("dua_20byte_string_005", 20, 20, "DUA", false),  // new
	transactionDate("rqo_tran_date_alt", 8, 8, "RQO", true),
	transactionTime("rqo_tran_time_alt", 11, 11, "RQO", true),
	transactionDateGMT("rqo_tran_date", 8, 8, "RQO", true),
	transactionTimeGMT("rqo_tran_time", 11, 11, "RQO", true),
	ipAddress("hob_ip_address", 23, 23, "HOB", false),
	userType("dee_entity_id_3", 40, 40, "DEE", false),
	userAgent("hdf_http_user_agent", 300, 300, "HDF", false),
	// hasBiocatchResponse("rua_numeric_056", 8, 8, "RUA", false),  // removed
	// BOSS
	activityTypeSMH("smh_activity_type", 2, 2, "SMH", false),
	activityTypeTBT("tbt_tran_type", 1, 1, "TBT", false),
	bankTypeTPP("tpp_bank_type", 1, 1, "TPP", false),
	utcIndicator("rqo_tran_utc_flag", 1, 1, "RQO", true),
	tranAmountTBT("tbt_tran_amt", 22, 22, "TBT", false),
	tranAmountModTBT("tbt_mod_amt", 22, 22, "TBT", false),
	tranAmountTDP("tdp_client_amt", 22, 22, "TDP", false),
	tranAmountModTDP("tdp_mod_amt", 22, 22, "TDP", false),
	creditLimitAQO("aqo_limit_amt", 22, 22, "AQO", false),
	limitTypeAQO("aqo_limit_type", 3, 3, "AQO", false),
	subTranTypeTNG("tng_sub_tran_type", 8, 8, "TNG", false),
	authMethod("smh_authenticate_mtd", 2, 2, "SMH", false),
	channelType("smh_channel_type", 1, 1, "SMH", false),
	channelId("rua_2byte_string_007", 2, 2, "RUA", false),
	billCat("tbt_bill_cat", 2, 2, "TBT", false),
	activityDetail1SMH("smh_activity_detail1", 3, 3, "SMH", false),
	tppPayeePayerInd("tpp_payee_payer_ind", 1, 1, "TPP", false)
	
	
	private final String transAtt;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;	
	private final Boolean req;

	private SASTransaction(final String transAtt, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.transAtt = transAtt;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	
	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASTransaction.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.transAtt;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
	
}


