package clientsApis.groovy.model.sas.enums;

import java.util.Map;
import java.util.HashMap;

import clientsApis.groovy.model.sas.interfaces.SASInterface;

public enum SASPayee implements SASInterface {
	
	accountNumber("tpp_acct_num", 34, 34, "TPP", false),
	accountType("tpp_name", 30, 30, "TPP", false),
	accountTypeTPP("tpp_acct_type", 2, 2, "TPP", false),
	//accountTypeRUA("rua_4byte_string_01", 2, 2, "RUA", false),
	bankId("tpp_bank_num", 15, 15, "TPP",  false)
	
	
	private final String payeeAtt;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	

	private SASPayee(final String payeeAtt, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.payeeAtt = payeeAtt;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}
	
	
	public static SASInterface valueOfElement(String name) {
		try {
			def val = SASPayee.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.payeeAtt;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}


