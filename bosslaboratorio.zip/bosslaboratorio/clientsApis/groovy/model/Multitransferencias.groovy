package clientsApis.groovy.model;

import java.util.StringJoiner;

import com.google.gson.annotations.SerializedName;

import java.util.Map;

import clientsApis.groovy.model.sas.SASTemplate;
import clientsApis.groovy.model.enums.TpoPersona;
import clientsApis.groovy.model.enums.AccountType;
import clientsApis.groovy.model.sas.enums.SASMultitransferencias; //adicion multitransferencias
import clientsApis.groovy.tools.Common;

public class Multitransferencias extends SASTemplate {
		
	public Multitransferencias() {}
	
	def String activityAmountTotal  = "";
	def String batchFilePayeesNumber = "";
	def String batchFileCreationDate  = "";
	def String batchFileEditionDate = "";

	public String getActivityAmountTotal() { 
		
		if(this.activityAmountTotal != null) {

			try {
				String amountTotal = this.activityAmountTotal;
				return amountTotal;
			}
			
			catch(Exception e) {
				// No se recibieron los puntos usados
				return null;
				
			}
		}
		return null;
	}

	public String getBatchFilePayeesNumber() { 
		
		if(this.batchFilePayeesNumber != null) {

			try {
				String payeesNumber = this.batchFilePayeesNumber;
				return payeesNumber;
			}
			
			catch(Exception e) {
				// No se recibieron los puntos disponibles
				return null;
				
			}
		}
		return null;
	}

	public String getBatchFileCreationDate() { 
		
		if(this.batchFileCreationDate != null) {

			try {
				String creationDate = this.batchFileCreationDate;
				return creationDate;
			}
			
			catch(Exception e) {
				// No se recibieron los puntos disponibles
				return null;
				
			}
		}
		return null;
	}
	
	public String getBatchFileEditionDate() { 
		
		if(this.batchFileEditionDate != null) {

			try {
				String editionDate = this.batchFileEditionDate;
				return editionDate;
			}
			
			catch(Exception e) {
				// No se recibieron los puntos disponibles
				return null;
				
			}
		}
		return null;
	}
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASMultitransferencias);	
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", Multitransferencias.class.getSimpleName() + "[", "]")
			.add("activityAmountTotal='" + this.activityAmountTotal + "'")
			.add("batchFilePayeesNumber='" + this.batchFilePayeesNumber + "'")
			.add("batchFileCreationDate='" + this.batchFileCreationDate + "'")
			.add("batchFileEditionDate='" + this.batchFileEditionDate + "'")
			.toString();
	}

}