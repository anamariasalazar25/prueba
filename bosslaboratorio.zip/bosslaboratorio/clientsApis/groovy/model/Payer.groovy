package clientsApis.groovy.model;

import java.util.StringJoiner;

import com.google.gson.annotations.SerializedName

import java.util.Map;

import clientsApis.groovy.model.sas.SASTemplate;
import clientsApis.groovy.model.enums.TpoPersona;
import clientsApis.groovy.model.enums.AccountType;
import clientsApis.groovy.model.sas.enums.SASPayer;
import clientsApis.groovy.tools.Common;

public class Payer extends SASTemplate {
		
	public Payer() {}
	
	def String idType;
	def String idNumber;
	def String accountNumber;
	def String accountType;
	def TpoPersona brand;

	public String getAccountTypeSMH() { 
		
		if(this.accountType != null) {

			try {
				AccountType at = AccountType.valueOf(this.accountType);
				return at.accountType;
			}
			
			catch(Exception e) {
				// No existe el valor
				return AccountType.DEFAULT.accountType;
				
			}
		}
		return AccountType.DEFAULT.accountType;
	}

	public String getCustNum(){
		String custNum = "";
		if(this.idType != null && this.idNumber != null){
			custNum = this.idType.concat(String.valueOf(idNumber));
		}
		return custNum;
	}
	
	public String getTipoBrandSMH() {
		
		if(this.brand != null) {
			return this.brand.tpoPersonaSMH;
		}
		
		return TpoPersona.I.tpoPersonaSMH;
	}

	public String getTipoBrandMulti() {
		
		if(this.brand != null) {
			return this.brand.tpoPersonaMulti;
		}
		
		return TpoPersona.I.tpoPersonaMulti;
	}
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASPayer);	
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", Payer.class.getSimpleName() + "[", "]")
			.add("idType='" + this.idType + "'")
			.add("idNumber='" + this.idNumber + "'")
			.add("accountNumber='" + this.accountNumber + "'")
			.add("accountType='" + this.accountType + "'")
			.add("brand='" + this.brand + "'")
			.toString();
	}

}
