package clientsApis.groovy.model;

import java.util.StringJoiner;

public class TransactionResponse {

	public TransactionResponse(String transactionId, String transactionType, String queueId, String type, String alertReason) {
		
		 this.transactionId = transactionId;
		 this.transactionType = transactionType;
		 this.queueId = queueId;
		 this.type = type;
		 this.alertReason = alertReason;
	}
	
	def String transactionId;
	def String transactionType;
	def String queueId; 
	def String type;
	def String alertReason;	
		
	
	@Override
	public String toString() {
		return new StringJoiner(", ", TransactionResponse.class.getSimpleName() + "[", "]")
			.add("transactionId=" + this.transactionId)
			.add("transactionType=" + this.transactionType)
			.add("queueId='" + this.queueId + "'")
			.add("type=" + this.type + "'")
			.add("alertReason='" + this.alertReason + "'")
			.toString();
	}

}


