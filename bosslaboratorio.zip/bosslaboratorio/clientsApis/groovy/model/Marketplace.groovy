package clientsApis.groovy.model;

import java.util.StringJoiner;

import com.google.gson.annotations.SerializedName

import java.util.Map;

import clientsApis.groovy.model.sas.SASTemplate;
import clientsApis.groovy.model.enums.TpoPersona;
import clientsApis.groovy.model.enums.AccountType;
import clientsApis.groovy.model.sas.enums.SASMarketplace;
import clientsApis.groovy.tools.Common;

public class Marketplace extends SASTemplate {
		
	public Marketplace() {}
	
	def String numPointsUsed  = "";
	def String numAvailPoints = "";

	public String getNumPointsUsed() { 
		
		if(this.numPointsUsed != null) {

			try {
				String pointsUsed = this.numPointsUsed;
				return pointsUsed;
			}
			
			catch(Exception e) {
				// No se recibieron los puntos usados
				return null;
				
			}
		}
		return null;
	}

	public String getNumAvailPoints() { 
		
		if(this.numAvailPoints != null) {

			try {
				String availPoints = this.numAvailPoints;
				return availPoints;
			}
			
			catch(Exception e) {
				// No se recibieron los puntos disponibles
				return null;
				
			}
		}
		return null;
	}

	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASMarketplace);	
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", Marketplace.class.getSimpleName() + "[", "]")
			.add("numPointsUsed='" + this.numPointsUsed + "'")
			.add("numAvailPoints='" + this.numAvailPoints + "'")
			.toString();
	}

}
