package clientsApis.groovy.model;

import java.util.StringJoiner;

public class AuthorizationResult {
	
//	public AuthorizationResult(String cmxTranId, String responseCode, String scoreSAS, String scoreBiocatch) {
	public AuthorizationResult(String cmxTranId, String responseCode, String scoreSAS) {
		
		this.cmxTranId = cmxTranId;
		this.responseCode = responseCode;
		this.scoreSAS = scoreSAS;
//		this.scoreBiocatch = scoreBiocatch;
	}
	
	public AuthorizationResult() {}

	def String cmxTranId;
	def String responseCode;
	def String scoreSAS;
//  def String scoreBiocatch;
	
	@Override
	public String toString() {
		return new StringJoiner(", ", AuthorizationResult.class.getSimpleName() + "{", "}")
			.add("cmxTranId='" + this.cmxTranId + "'")
			.add("responseCode='" + this.responseCode + "'")
			.add("scoreSAS='" + this.scoreSAS + "'")
//			.add("scoreBiocatch='" + this.scoreBiocatch + "'")
			.toString();
	}
}
