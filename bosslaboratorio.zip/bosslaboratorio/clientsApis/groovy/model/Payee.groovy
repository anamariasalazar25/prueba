package clientsApis.groovy.model;

import java.util.StringJoiner;

import com.google.gson.annotations.SerializedName;

import java.util.Map;
import java.util.HashMap;

import com.google.gson.annotations.SerializedName;

import clientsApis.groovy.model.sas.SASTemplate;
import clientsApis.groovy.model.sas.enums.SASPayee;
import clientsApis.groovy.model.enums.AccountTypePayee;
import clientsApis.groovy.tools.Common;

public class Payee extends SASTemplate  {
		
	public Payee() {}

	def String accountNumber;
	def String accountType;
	def String bankId;

	public String getAccountTypeValue() {
		if(this.accountType != null) {
			
			try {
				AccountTypePayee at = AccountTypePayee.valueOf(this.accountType);
				return at.accountType;
			}
			
			catch(Exception e) {
				// No existe el valor
				return AccountTypePayee.DEFAULT.accountType;
				
			}
		}
		return AccountTypePayee.DEFAULT.accountType;
	}
	
	public String getAccountTypeTPP() {
		getAccountTypeValue();
	}
	
	public String getAccountTypeRUA() {
		getAccountTypeValue();
	}
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASPayee);		
	}

	@Override
	public String toString() {
		return new StringJoiner(", ", Payee.class.getSimpleName() + "[", "]")
			.add("accountNumber='" + this.accountNumber + "'")
			.add("accountType='" + this.accountType + "'")
			.add("accountTypeTPP='" + getAccountTypeTPP() + "'")
			.add("accountTypeRUA='" + getAccountTypeRUA() + "'")
			.add("bankId='" + this.bankId + "'")
			.toString();
	}

}