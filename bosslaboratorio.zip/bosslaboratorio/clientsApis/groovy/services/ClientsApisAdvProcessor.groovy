package clientsApis.groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.reflect.TypeToken;
import com.sas.davivienda.efm.commons.util.FMUtils
import com.google.gson.Gson
import org.json.JSONObject;

import clientsApis.groovy.model.TransactionResponse;
import clientsApis.groovy.model.AuthenticationResult;
import clientsApis.groovy.model.ApiResponse;
import clientsApis.groovy.tools.checks.Checks;
import clientsApis.groovy.tools.GsonBuilderFormat;
import clientsApis.groovy.tools.values.Segments;
import java.text.SimpleDateFormat;
import clientsApis.groovy.exceptions.ClientsApisException;

public class ClientsApisAdvProcessor implements Processor {

	private static final Logger logger = LoggerFactory.getLogger("clientsApislog");

	public void process(Exchange exchange) {

		Gson gson = GsonBuilderFormat.getGson();
		try {
			String body = exchange.getIn().getBody(String.class);
			
			AuthenticationResult authenticationResult = gson.fromJson(body, new TypeToken<AuthenticationResult>() {}.getType());
			//Checks.checkNull(authenticationResult);

			String authCmxTranId = exchange.getIn().getHeader("cmxTranId");

			StringBuilder trxInfoLog = new StringBuilder();
			trxInfoLog.append("tran-id:").append(authCmxTranId)
					.append(", authenticationResult:").append(authenticationResult.authenticationResult)
					.append(", authMethod:").append(authenticationResult.authMethodUsed)

			logger.info("Orq-adv-request: {}",trxInfoLog.toString());
			exchange.setProperty("trxInfoLog", trxInfoLog.toString());

			if(FMUtils.isNullOrEmpty(authCmxTranId) || "null".equals(authCmxTranId)) {
				throw new ClientsApisException("cmxTranId null");
			}

			String cmxTranId = authCmxTranId.substring(4, authCmxTranId.length());
			String transactionType = authCmxTranId.substring(0, 4);

			exchange.setProperty("transactionType",transactionType);

			String alertQueueId = exchange.getProperty("alertQueueId");
			String alertType = exchange.getProperty("alertType");
			String alertReason = exchange.getProperty("alertReason");

			//inputMap alertApiRequest
			TransactionResponse transactionResponse = new TransactionResponse(cmxTranId,transactionType, alertQueueId, alertType, alertReason);

			//set values on exchange: transactionId (in header) and alertApiRequest (in body)
			exchange.getIn().setHeader("transactionId", cmxTranId);
			exchange.setProperty("alertApiRequest", gson.toJson(transactionResponse).toString());

			// SAS mapped transaction
			Segments.getTransSegmsAlt(transactionType, authenticationResult); // fingerprint
			def sasAuthenticationResultMap = authenticationResult.obtainSASFormat();

			Date dateNow = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String strDateNow = formatter.format(dateNow);

			Map<String, Object> updateParams = new HashMap<String, Object>();
			updateParams.put("dua_8byte_string_008", sasAuthenticationResultMap.get("dua_8byte_string_008"));
			updateParams.put("dee_entity_id_6", sasAuthenticationResultMap.get("dee_entity_id_6"));
			updateParams.put("rua_numeric_003", sasAuthenticationResultMap.get("rua_numeric_003"));
			updateParams.put("rua_numeric_060", sasAuthenticationResultMap.get("rua_numeric_060"));
			updateParams.put("dateNow", strDateNow);
			updateParams.put("cmxTranId", cmxTranId);

			exchange.setProperty("sasAuthenticationResultMap",updateParams);

			// successful operation
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			exchange.getIn().setBody(gson.toJson(new ApiResponse(0, "00", "Advice processed")));
		}catch(Exception e) {
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			exchange.getIn().setBody(gson.toJson(new ApiResponse(0, "96", e.getMessage())));
			exchange.setProperty("isError", "true");
		}finally {
			exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
		}
	}
}
