package clientsApis.groovy.tools;

import com.google.gson.Gson
import com.google.gson.GsonBuilder;

import clientsApis.groovy.tools.deserializers.DateDeserializer;
import clientsApis.groovy.tools.deserializers.DoubleDefaultAdapter;

public class GsonBuilderFormat {
	
	public static Gson getGson() {
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.registerTypeAdapter(Date.class, new DateDeserializer())
		.registerTypeAdapter(Double.class, new DoubleDefaultAdapter())
		
		return gsonBuilder.setPrettyPrinting().serializeNulls().create();
	}
}
