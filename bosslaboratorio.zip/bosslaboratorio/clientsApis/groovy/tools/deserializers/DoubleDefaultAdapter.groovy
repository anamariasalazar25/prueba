package clientsApis.groovy.tools.deserializers;

import java.lang.reflect.Type;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.JsonSyntaxException;

public class DoubleDefaultAdapter implements JsonSerializer<Double>, JsonDeserializer<Double> {
	
	@Override
	public Double deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
		try {
			if (json.getAsString().equals("") || json.getAsString().equals("null")) {//Defined as double type, if the background returns "" or null, it returns 0.00
				return 0.00;
		}
			} catch (Exception ignore) {
		}
		try {
			return json.getAsDouble();
		} catch (NumberFormatException e) {
			throw new JsonSyntaxException(e);
		}
	}

	@Override
	public JsonElement serialize(Double src, Type typeOfSrc, JsonSerializationContext context) {
		return new JsonPrimitive(src);
	}
}
