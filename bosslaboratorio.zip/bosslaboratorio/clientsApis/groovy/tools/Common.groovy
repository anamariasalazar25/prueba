package clientsApis.groovy.tools;

import java.util.List;
import java.util.Base64;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.HashMap;


public class Common {
	
	/**
	 * Deserialize string with json format
	 * @param data String with json format
	 * @param columnNames Json attributes (keys) to deserialize
	 * @return Deserialized string
	 */
	public static String getDeserializeJsonString(String data, List<String> columnNames) {
		
		JSONObject json = new JSONObject(data);
		
		for(c in columnNames) {
			byte[] decoded = Base64.getDecoder().decode(json[c].getBytes("UTF-8"));
			String decodedString = new String(decoded, StandardCharsets.UTF_8);
			
			if(decodedString.indexOf("[") == 0) {
				decodedString = decodedString.substring(1, decodedString.length() - 2);
			}
			
			json.put(c, new JSONObject(decodedString));
		}
		
		return json.toString();	
	}
	
	/**
	 * Get map of object attributes
	 * @param object Object to evaluate
	 * @return HashMap with object content
	 */
	public static getObjectAttList(Object object) {
		return object.metaClass.properties.findAll { it.name != 'class' && it.name != 'metaClass' }.inject([:]) { acc, e -> acc[e.name] = e.getProperty(object); acc };
	}
	
	/**
	 * Cast boolean value to integer
	 * @param b Boolean value
	 * @return 1 if b = true; false otherwise
	 */
	public static int boolToInt (Boolean b) {
		return b ? 1 : 0;	
	}
	
	/**
	 * 
	 * @param value
	 * @param maxValue
	 * @return
	 */
	public static String truncateString(String value, int maxValue) {
		
		int valueLength = value.length();
		
		if(valueLength > maxValue) {
			return value.substring(0, maxValue);		
		}
		return value;
	}

	/**
	 * Fill string with spaces
	 * @param val Value to fill
	 * @param valLength Final size of string value
	 */
	public static String fillStringWithSpace(String val, int valLength) {
		
		int diff = valLength - val.length();
		
		if(diff <= 0) {
			return val;
		}
		
		return String.format("%-"+valLength+ "s", val);
		
	}
	
}


