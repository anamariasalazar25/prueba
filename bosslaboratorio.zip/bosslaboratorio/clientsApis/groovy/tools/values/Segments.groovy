package clientsApis.groovy.tools.values;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;

import clientsApis.groovy.model.AuthenticationResult;
import clientsApis.groovy.model.Transaction;
import clientsApis.groovy.tools.checks.TransactionChecks;

public class Segments {
	
	private static final Logger logger = LoggerFactory.getLogger("clientsApislog");
		
	/**
	 * Valid segments depending on transaction account type and activity type combination
	 */
	private static segmentsGroups = [
		
		FP01: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HOB", "HDF", "TBT", "TPP", "DMX", "DEE", "DUA"],
		FP02: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQC", "UNM", "HQO", "HOB", "HDF", "TBT", "TPP", "DMX", "DEE", "DUA"],
		FP03: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQC", "UNM", "HQO", "HOB", "HDF", "TDP", "TPP", "DMX", "DEE", "DUA"],
		FP04: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HOB", "HDF", "TDP", "TPP", "DMX", "DEE", "DUA"],
		FP05: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQS", "UNM", "HQO", "HOB", "HDF", "TBT", "TPP", "DMX", "DEE", "DUA"],
		FP06: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQC", "UNM", "HQO", "HOB", "HDF", "TNG", "DMX", "DEE", "DUA"],
		FP07: ["SMH", "RQO", "RUA", "RUR", "XQO", "UNM", "HQO", "HOB", "HDF", "TNG", "DMX", "DEE", "DUA"],
		FP08: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HOB", "HDF", "TNG", "DMX", "DEE", "DUA"],
		FP09: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQL", "UNM", "HQO", "HOB", "HDF", "TBT", "TPP", "DMX", "DEE", "DUA"],
		FP10: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQL", "UNM", "HQO", "HOB", "HDF", "TBT", "TPP", "DMX", "DEE", "DUA"]
	];
	

	/**
	 * FingerPrints combinations
	 *
	 * v1 -> Account type
	 * v2 -> Auth method
	 * v3 -> Channel type
	 * v4 -> Activity type
	 *
	 */
	private static segmentsGroupsDef = [
		FP01: ["CS", "NC", "W","BF"],
		FP02: ["CC", "NC", "W","BF"],
		FP03: ["CC", "NC", "W","DP"],
		FP04: ["CS", "NC", "W","DP"],
		FP05: ["SL", "NC", "W","BF"],
		FP06: ["CC", "NC", "W","NM"],
		FP07: ["NA", "NC", "W","NM"],
		FP08: ["CS", "NC", "W","NM"],
		FP09: ["LC", "NC", "W","BF"],
		FP10: ["LC", "NC", "W","DP"]
	];
	
	/**
	 * FingerPrints combinations
	 *
	 * v1 -> Account type
	 * v2 -> Activity type
	 *
	 */
	private static segmentsGroupsDefAlt = [
		FP01: "CSBF",
		FP02: "CCBF",
		FP03: "CCDP",
		FP04: "CSDP",
		FP05: "SLBF",
		FP06: "CCNM",
		FP07: "NANM",
		FP08: "CSNM"
	];
	
	/**
	 * Obtain transaction fingerprint valid values
	 * 
	 * @param transaction Transaccion
	 * @return
	 */
	public static getTransSegms(Transaction transaction) {
		
		ArrayList<String> accType_actType = TransactionChecks.getTransactionAccAct(transaction);
		
		if(accType_actType.size > 0) {
			
			String accType = accType_actType.get(0);
			String actType = accType_actType.get(1);
			String authMethod = transaction.getAuthMethod();
			String channelType = transaction.getChannelType();
			
			def vals = [accType, authMethod, channelType, actType];
			//logger.info(vals.toString())
					
			String segKey = segmentsGroupsDef.find{ it.value == vals }?.key;
					
			if(segKey != null) {
				transaction.setValidSegments(segmentsGroups.find{ it.key == segKey }?.value);
				
				return transaction.getValidSegments();
			}
		}
	}
	
	
	/**
	 * Obtain fingerprint valid values
	 *
	 * @param authenticationResult AuthenticationResult
	 * @param accType_actType AccountType + ActivityType (Ej: CSBF)
	 * @return
	 */
	public static getTransSegmsAlt(String accType_actType, AuthenticationResult authenticationResult) {
		
		if(accType_actType != null) {
			
			String segKey = segmentsGroupsDefAlt.find{ it.value == accType_actType }?.key;
					
			if(segKey != null) {
				authenticationResult.setValidSegments(segmentsGroups.find{ it.key == segKey }?.value);
				
				return authenticationResult.getValidSegments();
			}
		}
	}

}
