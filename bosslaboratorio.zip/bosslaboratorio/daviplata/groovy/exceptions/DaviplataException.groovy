package daviplata.groovy.exceptions;

class DaviplataException extends Exception {
	
	private static final long serialVersionUID = 1L;

	private int codError;
	private String message;

	public DaviplataException(int codError){
		super();
		this.codError = codError;
	}
	
	public DaviplataException(String message){
		super();
		this.message = message;
	}
	
	public DaviplataException(int codError, String message){
		super();
		this.codError = codError;
		this.message = message;
	}


	@Override
	public String getMessage(){
		
		switch(this.codError){
			
			case 111:
				this.message = "Not null values are accepted on mandatory fields: " + this.message;
				break;
			case 222:
				this.message = "Invalid input: " + this.message;
				break;
		}

		return this.message;
	}
}
