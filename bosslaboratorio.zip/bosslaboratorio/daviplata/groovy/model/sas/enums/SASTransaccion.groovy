package daviplata.groovy.model.sas.enums

import daviplata.groovy.model.sas.interfaces.SASInterface;

public enum SASTransaccion implements SASInterface {
	
	//BOSS
	selfAccIndTBT("tbt_self_acct_ind", 1, 1, "TBT", false),
	custcntryCode("xqo_cust_cntry_code", 3, 3, "XQO", false),
	hobDevice("hob_device", 1, 1, "HOB", false)
	

	private final String transaccionVal;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	
	private SASTransaccion(final String transaccionVal, final Integer minLength, final Integer maxLength, final String segment, 
		final Boolean req) {
		
		this.transaccionVal = transaccionVal;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASTransaccion.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.transaccionVal;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
	
}
