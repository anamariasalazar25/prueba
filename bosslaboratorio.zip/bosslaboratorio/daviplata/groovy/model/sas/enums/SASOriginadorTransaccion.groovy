package daviplata.groovy.model.sas.enums

import daviplata.groovy.model.sas.interfaces.SASInterface;
import daviplata.groovy.model.Transaccion;

public enum SASOriginadorTransaccion implements SASInterface {
	
	codTrnx("rua_10byte_string_001", 10, 10, "RUA", true),
	tpoCliente("smh_cust_type", 1, 1, "SMH", true),
	tpoCuenta("smh_acct_type", 2, 2, "SMH", true),
	codCanalAmp("rua_2byte_string_007", 2, 2, "RUA", true),
	modoOperacionDP("tca_reversal_ind", 1, 1, "TCA", false),
	modoOperacionOC("tdp_reversal_ind", 1, 1, "TDP", false),
	codAlianzaOriginal("dmx_5byte_string_01", 5, 5, "DMX", false),
	codAlianza("smh_multi_org_name", 16, 16, "SMH", false),
	nroTerminal("hct_term_id", 8, 8, "HCT", true),
	
	//BOSS
	custNum("xqo_cust_num", 50, 50, "XQO", false),
	tpoClienteRUA("rua_ind_012", 1, 1, "RUA", false),
	tpoCuentaRUA("rua_2byte_string_006", 2, 2, "RUA", false),
	tpoCuentaDUA("dua_8byte_string_004", 2, 2, "DUA", false),
	authMethod("smh_authenticate_mtd", 2, 2, "SMH", true),
	channelType("smh_channel_type", 1, 1, "SMH", true),
	
	tbtTransType("tbt_tran_type", 1, 1, "TBT", false),
	smhActivity("smh_activity_type", 2, 2, "SMH", true),
	subActivity("rua_30byte_string_002", 30, 30, "RUA", false),
	tdpTransType("tdp_type", 1, 1, "TDP", false),
	tppPayeePayer("tpp_payee_payer_ind", 1, 1, "TPP", false),
	tppEntityType("tpp_entity_type", 1, 1, "TPP", false),
	tbtBillCat("tbt_bill_cat", 2, 2, "TBT", false),
	
	transCompType("smh_tran_type", 3, 3, "SMH", false),
	actDetail1("smh_activity_detail1", 3, 3, "SMH", false),
	actDetail2("smh_activity_detail2", 3, 3, "SMH", false),
	actDetail3("smh_activity_detail3", 3, 3, "SMH", false),
	tpoClienteXQO("xqo_cust_type", 1, 1, "XQO", false),
	tpoCuentaRShip("aqd_acct_relationship", 1, 1, "AQD", false),
	transStatus("tbt_tran_status", 1, 1, "TBT", false),
	
	tngTransType("tng_tran_type", 2, 2, "TNG", false),
	tngCategory("tng_category", 1, 1, "TNG", false),
	aqoAcctCntryCode("aqo_acct_cntry_code", 3, 3, "AQO", false),
	smhMsgType("smh_msg_type", 1, 1, "SMH", false),
	smhRespReq("smh_resp_req", 1, 1, "SMH", false),
	smhSddInd("smh_sdd_ind", 1, 1, "SMH", false),
	smhSource("smh_source", 8, 8, "SMH", false),
	
	
	private final String origTrans;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	
	private SASOriginadorTransaccion(final String origTrans, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.origTrans = origTrans;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASOriginadorTransaccion.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.origTrans;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
	
	public String getSmh_source() {
		return this.source;
	}
	
}
