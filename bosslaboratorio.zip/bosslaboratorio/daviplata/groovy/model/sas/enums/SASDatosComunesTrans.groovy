package daviplata.groovy.model.sas.enums

import daviplata.groovy.model.sas.interfaces.SASInterface;

public enum SASDatosComunesTrans implements SASInterface {
	
	idTrnx("tbt_ref_num", 40, 40, "TBT", false),
	idTrnxTDP("tdp_ref_num", 30, 30, "TDP", false),
	fchCreaProd("rua_10byte_string_007", 10, 10, "RUA", true),
	horaCreaProd("rua_10byte_string_008", 10, 10, "RUA", true),
	saldoAntTrnxAbs("aqd_avail_bal", 22, 22, "AQD", true),
	valorTrnx("tbt_tran_amt", 22, 22, "TBT", false),
	valorTrnxMod("tbt_mod_amt", 22, 22, "TBT", false),	
	valorTrnxDP("tdp_client_amt", 22, 22, "TDP", false),
	clientCurr("tdp_client_curr_code", 3, 3, "TDP", false),
	valorTrnxModDP("tdp_mod_amt", 22, 22, "TDP", false),
	fchTrnxAlt("rqo_tran_date_alt", 8, 8, "RQO", true),
	horaTrnxAlt("rqo_tran_time_alt", 11, 11, "RQO", true),
	
	//BOSS
	saldoAntTrnxSigno("rua_ind_014", 1, 1, "RUA", true),
	fchTrnx("rqo_tran_date", 8, 8, "RQO", true),
	horaTrnx("rqo_tran_time", 11, 11, "RQO", true),
	tranUTCFlag("rqo_tran_utc_flag", 1, 1, "RQO", false),
	signoSaldo("rua_ind_014", 1, 1, "RUA", false)
	
	private final String datComunes;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	
	private SASDatosComunesTrans(final String datComunes, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.datComunes = datComunes;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASDatosComunesTrans.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.datComunes;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
	
}
