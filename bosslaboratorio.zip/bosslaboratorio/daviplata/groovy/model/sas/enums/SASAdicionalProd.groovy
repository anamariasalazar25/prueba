package daviplata.groovy.model.sas.enums

import daviplata.groovy.model.sas.interfaces.SASInterface;

public enum SASAdicionalProd implements SASInterface {
	
	subProd("rur_30byte_string_002", 30, 30, "RUR", false),
	estadoProd("rua_3byte_string_001", 3, 3, "RUA", true),
	tpoBloqueo("rua_3byte_string_004", 3, 3, "RUA", false),
	motivoBloqueo("rua_3byte_string_005", 3, 3, "RUA", false),
	fchUltBloqueo("rua_10byte_string_003",10, 10, "RUA", false),
	horaUltBloqueo("rua_10byte_string_004",10, 10, "RUA", false),
	codUltMvmnto("rua_8byte_string_001", 8, 8, "RUA", false),
	rptaUltMvmnto("rua_ind_015", 1, 1, "RUA", false),
	fchUltMvmnto("dua_10byte_string_005", 10, 10, "DUA", false),
	horaUltMvmnto("dua_10byte_string_006", 10, 10, "DUA", false),
	tpoUltNovedad("rua_8byte_string_002", 8, 8, "RUA", false),
	rptaUltNovedadFlag("rua_ind_016", 1, 1, "RUA", false),
	fchUltNovedad("dua_10byte_string_007", 10, 10, "DUA", false),
	horaUltNovedad("dua_10byte_string_008", 10, 10, "DUA", false)
	
	
	private final String adProd;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	
	private SASAdicionalProd(final String adProd, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.adProd = adProd;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASAdicionalProd.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.adProd;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}