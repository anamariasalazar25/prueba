package daviplata.groovy.model.sas.enums

import daviplata.groovy.model.sas.interfaces.SASInterface;

public enum SASDatosBeneficiario implements SASInterface {

        tpoIdentDestinoBen("rua_2byte_string_001", 2, 2, "RUA", false),   
        nroIdentDestinoBen("rua_20byte_string_005", 20, 20, "RUA", false),
/*      nroProdDestinoTPP("tpp_acct_num", 16, 16, "TPP", false),             */
/*      nroProdDestinoXQO("xqo_phone", 16, 16, "XQO", false),                */
/*      nroProdDestinoRUA("rua_20byte_string_005", 16, 16, "RUA", false),    */
        nroProdDestinoBen("tpp_acct_num", 16, 16, "TPP", false),
        codProdDestinoBen("rua_4byte_string_002", 4, 4, "RUA", false),  
        codSubprodDestinoBen("rua_4byte_string_004", 4, 4, "RUA", false),
        codBancoDestino("tpp_bank_num", 15, 15, "TPP", false),
        codBancoDestinoTPP("tpp_bank_type", 1, 1, "TPP", false)

        private final String datosBen;
        private final Integer minLength;
        private final Integer maxLength;
        private final String segment;
        private final Boolean req;

        private SASDatosBeneficiario(final String datosBen, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
                this.datosBen = datosBen;
                this.minLength = minLength;
                this.maxLength = maxLength;
                this.segment = segment;
                this.req = req;
        }

        public static SASInterface valueOfElement(String name) {

                try {
                        def val = SASDatosBeneficiario.valueOf(name);
                        return val;
                }
                catch(Exception e) {
                        return null;
                }
        }

        @Override
        public String getAtt() {
                return this.datosBen;
        }

        @Override
        public Integer getMinLength() {
                return this.minLength;
        }

        @Override
        public Integer getMaxLength() {
                return this.maxLength;
        }

        @Override
        public String getSegment() {
                return this.segment;
        }

        @Override
        public Boolean getReq() {
                return this.req;
        }
}

