package daviplata.groovy.model.sas.enums

import daviplata.groovy.model.sas.interfaces.SASInterface;

public enum SASRecConvenio implements SASInterface {
	
	codComercio("dua_20byte_string_005", 20, 20, "DUA", false),
	//tpoConvenio("tpoConvenio", 4, 4, "*", false),//
	//tpoRecaudo("tpoRecaudo", 1, 1, "*", false),//
	codConvenioIAC("rua_20byte_string_004", 20, 20, "RUA", false),
	codConvenio("rua_20byte_string_003", 20, 20, "RUA", false),
	numProcesoEmp("dua_40byte_string_002", 40, 40, "DUA", false),
	traceNumber("dua_40byte_string_001", 40, 40, "DUA", false),
	
	private final String recConv;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	
	private SASRecConvenio(final String recConv, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.recConv = recConv;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASRecConvenio.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.recConv;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
	
}
