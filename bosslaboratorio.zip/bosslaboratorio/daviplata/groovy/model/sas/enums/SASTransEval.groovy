package daviplata.groovy.model.sas.enums

import daviplata.groovy.model.sas.interfaces.SASInterface;

public enum SASTransEval implements SASInterface {
	
	talon("talon", 8, 8, "RUA", false),
	codAutoriz("codAutoriz", 20, 20, "DUA", false),
	fchAutoriz("fchAutoriz", 10, 10, "RUA", false),
	horaAutoriz("horaAutoriz", 10, 10, "RUA", false),
	codError("codError", 4, 4, "RUA", false),
	codRechazo("codRechazo", 3, 3, "RUA", false),
	
	private final String transEval;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	
	private SASTransEval(final String transEval, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.transEval = transEval;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASTransEval.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.transEval;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
	
}
