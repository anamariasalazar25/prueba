package daviplata.groovy.model.sas.enums

import daviplata.groovy.model.sas.interfaces.SASInterface;

public enum SASReferencias implements SASInterface {
	
	celularFactServicios("dua_10byte_string_002", 10, 10, "DUA", false),
	ref1("tbt_billing_ref_num", 80, 80, "TBT", false),
	ref2("tpp_description", 100, 100, "TPP", false),
	ref3("rua_30byte_string_001", 30, 30, "RUA", false),
	refTotal("tpp_num", 25, 25, "TPP", false),
	ref6("tpp_name", 80, 80, "TPP", false),
	ref7("rua_20byte_string_001", 20, 20, "RUA", false),
	
	private final String referencias;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	
	private SASReferencias(final String referencias, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.referencias = referencias;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASReferencias.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.referencias;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
	
}
