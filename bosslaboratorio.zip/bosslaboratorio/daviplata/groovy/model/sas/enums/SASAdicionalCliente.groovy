package daviplata.groovy.model.sas.enums

import daviplata.groovy.model.sas.interfaces.SASInterface;

public enum SASAdicionalCliente implements SASInterface {
	
	eMail("dua_80byte_string_001", 80, 80, "DUA", false),
	origenCreacionCliente("rua_3byte_string_003", 3, 3, "RUA", true),
	tpoVinculacion("rua_2byte_string_004", 2, 2, "RUA", true),
	fchCreaCliente("dua_10byte_string_003", 10, 10, "DUA", true),	
	horaCreaCliente("dua_10byte_string_004", 10, 10, "DUA", true),
	
	private final String adCliente;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	
	private SASAdicionalCliente(final String adCliente, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.adCliente = adCliente;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASAdicionalCliente.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.adCliente;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
	
}
