package daviplata.groovy.model.sas.enums

import daviplata.groovy.model.sas.interfaces.SASInterface;

public enum SASDatosPagador implements SASInterface {

        tpoIdentOrigenPag("rua_2byte_string_002", 2, 2, "RUA", false),
        nroIdentOrigenPag("rua_20byte_string_002", 20, 20, "RUA", false),
/*      nroProdOrigenTPP("tpp_acct_num", 34, 34, "TPP", false),          */
/*      nroProdOrigenXQO("xqo_phone", 15, 15, "XQO", true),              */
/*      nroProdOrigenRUA("rua_20byte_string_005", 15, 15, "RUA", false), */
        nroProdOrigenPag("xqo_phone", 15, 15, "XQO", true),
        nroCuentaInterno("aqo_acct_num", 34, 34, "AQO", false),
        codProdOrigenPag("rua_4byte_string_001", 4, 4, "RUA", false), 
        codSubprodOrigenPag("rua_4byte_string_003", 4, 4, "RUA", false),

        private final String datosPag;
        private final Integer minLength;
        private final Integer maxLength;
        private final String segment;
        private final Boolean req;

        private SASDatosPagador(final String datosPag, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
                this.datosPag = datosPag;
                this.minLength = minLength;
                this.maxLength = maxLength;
                this.segment = segment;
                this.req = req;
        }

        public static SASInterface valueOfElement(String name) {

                try {
                        def val = SASDatosPagador.valueOf(name);
                        return val;
                }
                catch(Exception e) {
                        return null;
                }
        }

        @Override
        public String getAtt() {
                return this.datosPag;
        }

        @Override
        public Integer getMinLength() {
                return this.minLength;
        }

        @Override
        public Integer getMaxLength() {
                return this.maxLength;
        }


        @Override
        public String getSegment() {
                return this.segment;
        }

        @Override
        public Boolean getReq() {
                return this.req;
        }
}
