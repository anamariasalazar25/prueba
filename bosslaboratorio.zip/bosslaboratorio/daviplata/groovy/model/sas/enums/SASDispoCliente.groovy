package daviplata.groovy.model.sas.enums

import daviplata.groovy.model.sas.interfaces.SASInterface;

enum SASDispoCliente implements SASInterface {
	
	direccionIP("hob_ip_address", 23, 23, "HOB", false),
	direccionIPAjax("hdf_dev_ip_address", 23, 23, "HDF", false),
	tpoDispositivo("dua_20byte_string_004", 20, 20, "DUA", false),
	idDispositivo("hdf_mac_addr", 17, 17, "HDF", false),
	deviceAppVersion("dua_20byte_string_002", 20, 20, "DUA", false),
	gpsLat("hob_ip_latitude", 22, 22, "HOB", false),
	gpsLong("hob_ip_longitude", 22, 22, "HOB", false),
	codUsuario("dua_20byte_string_001", 20, 20, "DUA", false),
	
	private final String dispoClien;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	
	private SASDispoCliente(final String dispoClien, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.dispoClien = dispoClien;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASDispoCliente.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.dispoClien;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}
