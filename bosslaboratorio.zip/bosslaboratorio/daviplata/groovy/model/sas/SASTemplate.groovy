package daviplata.groovy.model.sas;

import java.util.Map;

import org.slf4j.Logger

import java.util.HashMap;

import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import daviplata.groovy.model.TransaccionEvaluada;
import daviplata.groovy.tools.Common;
import daviplata.groovy.tools.values.Segments;
import daviplata.groovy.tools.deserializers.DatesFormats;
import daviplata.groovy.exceptions.DaviplataException;
import daviplata.groovy.tools.checks.Checks;
import daviplata.groovy.tools.deserializers.DatesFormats;

public abstract class SASTemplate {
	
	private static final Logger logger = LoggerFactory.getLogger("daviplatalog");
	
	private static ArrayList validSegments = null;
	
	/**
	 * Map SASTemplate java object attributes to SAS fields
	 * @return HashMap with SAS fields
	 */
	public abstract Map<String,Object> obtainSASFormat();

	/**
	 * Map SASTemplate java object attributes to SAS fields
	 * @param object SASTemplate object
	 * @param enumer SAS enumeration mapper
	 * @return HashMap with object SAS fields
	 */
	protected <T,S> Map<String,Object> sasValidation(T object, S enumer) {
		
		def attrsMap = Common.getObjectAttList(object);
		if(attrsMap.containsKey("validSegments")) this.validSegments = attrsMap.get("validSegments");
		
		if(this.validSegments != null || object instanceof TransaccionEvaluada) {
		
			Map<String,Object> sasMap = new HashMap<String, Object>();
			for(att in attrsMap) {
				def attKey = att.key;
				def attVal = att.value;
				def sasValue = enumer.valueOfElement(attKey);
				
				if(attVal instanceof SASTemplate == false) {
							
					if(attVal != null) {
						try {
							if (sasValue != null) {
								
								if(validSegments != null && validSegments.contains(sasValue.getSegment())) {

/******								if(validSegments != null && validSegments.contains(sasValue.getSegment()) 
*									|| (validSegments == null && enumsExceptions.contains(enumer)) ) {
**/
									sasMap.put(sasValue.getAtt(), attVal.toString());
								}
							}
						}
						catch(Exception e) {
							logger.error(e.getMessage() + ": " + att.key);
						}
					}
					
					else {
						if (sasValue != null) {
							def value = sasValue.getAtt();
							//avoid overwirting tpp var if it is null
							if (!"tpp_acct_num".equals(value) && !sasMap.containsKey(sasValue.getAtt())){
								sasMap.put(sasValue.getAtt(), null);
							}
						}
					}
				}else {
					sasMap.putAll(att.value.obtainSASFormat());
				}
			}
			return sasMap;
		}
		return null;
	}
}

