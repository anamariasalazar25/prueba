package daviplata.groovy.model.enums;

import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;

@JsonAdapter(MotivoBloqueo.Serializer.class)
public enum MotivoBloqueo {

    // Se eliminan valores asociados a la Tabla de homologación motivoBloqueo para que este campo quede libre (solicitado para TDD)

    private final String motivoBloqueo;
		
	private MotivoBloqueo(final String motivoBloqueo) {
		this.motivoBloqueo = motivoBloqueo;
	}
	
	static MotivoBloqueo getTypeByVal(String motivoBloqueo) {

		for (MotivoBloqueo motivoBloqueoObj : values()) {
			if (motivoBloqueoObj.motivoBloqueo.equals(motivoBloqueo)) return motivoBloqueoObj;
		}

		return null;
	}

	static class Serializer implements JsonSerializer<MotivoBloqueo>, JsonDeserializer<MotivoBloqueo> {
		
		@Override
		public JsonElement serialize(MotivoBloqueo src, Type typeOfSrc, JsonSerializationContext context) {
			return context.serialize(src.motivoBloqueo);
		}
		
		@Override
		public MotivoBloqueo deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
			try {
				return getTypeByVal(json.getAsString());
			} catch (JsonParseException e) {
				return null;
			}
		}
	}
	
	@Override
	public String toString() {
		return this.motivoBloqueo;
	}
}
