package daviplata.groovy.model.enums

import java.util.List;

import daviplata.groovy.model.enums.DeviceType;
import daviplata.groovy.model.enums.TpoDispo;
import com.google.gson.annotations.SerializedName;

public enum TpoDispoHOB {
	
	tipo1([TpoDispo.space, TpoDispo.blank], DeviceType.blank),
	tipo2([TpoDispo.Mobile, TpoDispo.space, TpoDispo.blank], DeviceType.A),
	tipo3([TpoDispo.Computer, TpoDispo.space, TpoDispo.blank], DeviceType.C),
	tipo4([TpoDispo.space, TpoDispo.blank], DeviceType.C),
	tipo5([TpoDispo.space, TpoDispo.blank], DeviceType.M),
	tipo6([TpoDispo.space, TpoDispo.blank], DeviceType.A)
	
	
	private final List<TpoDispo> tpoDispos;
	private final String hobDevice;
	
	private TpoDispoHOB(final List<TpoDispo> tpoDispos, final DeviceType deviceType) {
		this.tpoDispos = tpoDispos;
		this.hobDevice = deviceType.hobDevice;
	}
	
	@Override
	public String toString() {
		return this.hobDevice;
	}
	
}

