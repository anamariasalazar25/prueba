package daviplata.groovy.model.enums

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.annotations.JsonAdapter;
import java.lang.reflect.Type;

@JsonAdapter(CodBanco.Serializer.class)
public enum CodBanco {

        @SerializedName("0") BCO_REPUBLICA("0", "L"),
        @SerializedName("1") BCO_BOGOTA("1", "L"),
        @SerializedName("2") BCO_POPULAR("2", "L"),
        @SerializedName("6") ITAU("6", "L"),
        @SerializedName("7") BANCOLOMBIA("7", "L"),
        @SerializedName("9") CITIBANK("9", "L"),
        @SerializedName("12") GNB_SUDAMERIS("12", "L"),
        @SerializedName("13") BBVA("13", "L"),
        @SerializedName("19") COLPATRIA("19", "L"),
        @SerializedName("23") BCO_OCCIDENTE("23", "L"),
        @SerializedName("31") BANCOLDEX("31", "L"),
        @SerializedName("32") BCO_BCSC("32", "L"),
        @SerializedName("40") BCO_AGRARIO_COL("40", "L"),
        @SerializedName("42") PARIBAS("42", "L"),
        @SerializedName("47") BCO_MUNDO_MUJER("47", "L"),
        @SerializedName("51") BCO_DAVIVIENDA("51", "S"),
        @SerializedName("52") BCO_AV_VILLAS("52", "L"),
        @SerializedName("53") BANCO_W("53", "L"),
        @SerializedName("58") BCO_CREDIFINANCIERA("58", "L"),
        @SerializedName("59") BANCAMIA("59", "L"),
        @SerializedName("60") BCO_PICHINCHA("60", "L"),
        @SerializedName("61") BANCOOMEVA("61", "L"),
        @SerializedName("62") BCO_FALABELLA("62", "L"),
        @SerializedName("63") BCO_FINANDINA("63", "L"),
        @SerializedName("64") MULTIBANK("64", "L"),
        @SerializedName("65") BCO_SANTANDER("65", "L"),
        @SerializedName("66") BCO_COOPCENTRAL("66", "L"),
        @SerializedName("67") MIBANCO("67", "L"),
        @SerializedName("69") BCO_SERFINANZA("69", "L"),
        @SerializedName("70") LULO_BANK("70", "L"),
        @SerializedName("71") BCO_JPMORGAN("71", "L"),
        @SerializedName("121") JURISCOOP("121", "L"),
        @SerializedName("151") RAPPIPAY("151", "L"),
        @SerializedName("283") CFA("283", "L"),
        @SerializedName("289") COOTRAFA("289", "L"),
        @SerializedName("291") COOFINEP("291", "L"),
        @SerializedName("292") CONFIAR("292", "L"),
        @SerializedName("303") GIROS_FINANZAS("303", "L"),
        @SerializedName("370") COLTEFINANCIERA("370", "L"),
        @SerializedName("499") TECHBANK("499", "L"),
        @SerializedName("507") NEQUI("507", "L"),
        @SerializedName("551") DAVIPLATA("551", "L"),
        @SerializedName("637") IRIS("637", "L"),
        @SerializedName("801") MOVII("801", "L"),
        @SerializedName("805") BCO_PACTUAL("805", "L"),
        @SerializedName("000") BCO_REPUBLICA_("000", "L"),
        @SerializedName("001") BCO_BOGOTA_("001", "L"),
        @SerializedName("002") BCO_POPULAR_("002", "L"),
        @SerializedName("006") ITAU_("006", "L"),
        @SerializedName("007") BANCOLOMBIA_("007", "L"),
        @SerializedName("009") CITIBANK_("009", "L"),
        @SerializedName("012") GNB_SUDAMERIS_("012", "L"),
        @SerializedName("013") BBVA_("013", "L"),
        @SerializedName("019") COLPATRIA_("019", "L"),
        @SerializedName("023") BCO_OCCIDENTE_("023", "L"),
        @SerializedName("031") BANCOLDEX_("031", "L"),
        @SerializedName("032") BCO_BCSC_("032", "L"),
        @SerializedName("040") BCO_AGRARIO_COL_("040", "L"),
        @SerializedName("042") PARIBAS_("042", "L"),
        @SerializedName("047") BCO_MUNDO_MUJER_("047", "L"),
        @SerializedName("051") BCO_DAVIVIENDA_("051", "S"),
        @SerializedName("052") BCO_AV_VILLAS_("052", "L"),
        @SerializedName("053") BANCO_W_("053", "L"),
        @SerializedName("058") BCO_CREDIFINANCIERA_("058", "L"),
        @SerializedName("059") BANCAMIA_("059", "L"),
        @SerializedName("060") BCO_PICHINCHA_("060", "L"),
        @SerializedName("061") BANCOOMEVA_("061", "L"),
        @SerializedName("062") BCO_FALABELLA_("062", "L"),
        @SerializedName("063") BCO_FINANDINA_("063", "L"),
        @SerializedName("064") MULTIBANK_("064", "L"),
        @SerializedName("065") BCO_SANTANDER_("065", "L"),
        @SerializedName("066") BCO_COOPCENTRAL_("066", "L"),
        @SerializedName("067") MIBANCO_("067", "L"),
        @SerializedName("069") BCO_SERFINANZA_("069", "L"),
        @SerializedName("070") LULO_BANK_("070", "L"),
        @SerializedName("071") BCO_JPMORGAN_("071", "L"),

        private final String codBanco;
        private final String codBancoTPP;

        private CodBanco(final String codBanco, final String codBancoTPP) {
                this.codBanco = codBanco;
                this.codBancoTPP = codBancoTPP;
        }

        static CodBanco getTypeByVal(String codBanco) {

                for (CodBanco codBancoObj : values()) {
                        if (codBancoObj.codBanco.equals(codBanco)) return codBancoObj;
                }

                return null;
        }

        static class Serializer implements JsonSerializer<CodBanco>, JsonDeserializer<CodBanco> {

                @Override
                public JsonElement serialize(CodBanco src, Type typeOfSrc, JsonSerializationContext context) {
                        return context.serialize(src.codBanco);
                }

                @Override
                public CodBanco deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
                        try {
                                return getTypeByVal(json.getAsString());
                        } catch (JsonParseException e) {
                                return null;
                        }
                }
        }

        @Override
        public String toString() {
                return this.codBanco;
        }

}


