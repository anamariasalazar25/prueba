package daviplata.groovy.model.enums

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonValue;

public enum EstadoProd {
	
	@SerializedName("ACT") ACT("ACT"),
	@SerializedName("CAN") CAN("CAN"),

	
	private final String estadoProd;
	
	private EstadoProd(final String estadoProd) {
		this.estadoProd = estadoProd;
	}
	
	@Override
	public String toString() {
		return this.estadoProd;
	}

}
