package daviplata.groovy.model.enums

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.annotations.JsonAdapter;
import java.lang.reflect.Type;

@JsonAdapter(CodTrnx.Serializer.class)
public enum CodTrnx {
	
	@SerializedName("10001501") DESEMB_CART("10001501", "I", "DP", "Abono crédito","X"),
	@SerializedName("82002019") TRANS_DEB("82002019", null, "BF", "Trnsf a Cta","X"),
	@SerializedName("82052020") TRANS_ABONO("82052020", "I", "DP", "Trnsf a Cta","X"),
	@SerializedName("82002021") DEBITO_OTROS_ACH("82002021", null, "BF", "Trnsf a Cta","X"),
	@SerializedName("82002023") DEBITO_OTROS_CENIT("82002023", null, "BF", "Trnsf a Cta","X"),
	@SerializedName("82052025") TRANS_DAVI_DAVI("82052025", "I", "DP", "Trnsf a Cta","X"),
	@SerializedName("82002028") MON_CUENTA("82002028", null, "BF", "Trnsf a Cta","X"),
	@SerializedName("82052029") DIS_CENIT("82052029", "B", "DP", "Abono",""),
	@SerializedName("82052030") DIS_ACH("82052030", "B", "DP", "Abono",""),
	@SerializedName("82002031") ENVIA_ACH("82002031", "B", "BF", "Trnsf a Cta","X"),
	@SerializedName("82052032") ACEPTA_ACH("82052032", "B", "DP", "Trnsf a Cta",""),
	@SerializedName("82002034") ACEP_SOL_ACH("82002034", "B", "BF", "Trnsf a Cta",""),
	@SerializedName("82002035") RECARGA_ECARD("82002035", null, "BF", "Pago compra","X"),
	@SerializedName("82052036") TRANS_SOCIAL_SELLER("82052036", "B", "DP", "Abono",""),
	@SerializedName("82052037") TRANS_PSE_SOCIAL_SELLER("82052037", "B", "DP", "Abono",""),
	@SerializedName("82102038") RET_ATM_PROPIO("82102038", null, "BF", "Retiro",""),
	@SerializedName("82102039") RET_CORRESP("82102039", null, "BF", "Retiro",""),
	@SerializedName("82102040") RET_ATM_OTRAS_REDES("82102040", null, "BF", "Retiro",""),
	@SerializedName("82052041") TRANS_DAVI_DAVI_HOLD("82052041", "I", "DP", "Trnsf a Cta",""),
	@SerializedName("82202043") DEB_PAG_SERV_PUB("82202043", null, "BF", "Pago servicios",""),
	@SerializedName("82202044") DEB_PAG_SERV_PUB_EXT("82202044", null, "BF", "Pago servicios","X"),
	@SerializedName("82202045") REC_CON_MON("82202045", null, "BF", "Trnsf a Cta (Cnvnio)",""),
	@SerializedName("82202046") DEB_PAGO_CONV_REC("82202046", null, "BF", "Pago compra","X"),
	@SerializedName("82202047") DEB_PAGO_SOAT("82202047", null, "BF", "Pago compra",""),
	@SerializedName("82302048") REC_A_CEL("82302048", null, "BF", "Pago compra","X"),
	@SerializedName("82302049") REC_MIN_DB("82302049", null, "BF", "Pago compra","X"),
 	@SerializedName("82302050") REC_PAQ_DB("82302050", null, "BF", "Pago compra","X"),
	@SerializedName("82502055") COMPRAS_QR("82502055", null, "BF", "Pago compra","X"),
	@SerializedName("82502056") CELUCOMPRA("82502056", null, "BF", "Pago compra",""),
	@SerializedName("82502057") COMPRAS_PSE("82502057", null, "BF", "Pago compra PSE","X"),
	@SerializedName("82052101") ABONO_MON_PSE_RAPPI("82052101", "B", "DP", "Abono de PSE","X"),
	@SerializedName("82002102") TRANS_ACH_RAPPI("82002102", null, "BF", "Trnsf a Cta",""),
	@SerializedName("82052103") TRANS_NOTA_CRED_RAPPI("82052103", "W", "DP", "Abono",""),
	@SerializedName("82102104") RET_ATM_PROP_RAPPI("82102104", null,  "BF", "Retiro",""),
 	@SerializedName("82102105") RET_RAPPI_CASH("82102105", null,  "BF", "Retiro","X"),
	@SerializedName("82502107") COMPRAS_PSE_RAPPI("82502107", null, "BF", "Pago compra PSE","X"),
	@SerializedName("82502108") COMPRAS_RAPPI_APP("82502108", null, "BF", "Pago compra","X"),
	@SerializedName("82502109") COMPRAS_DEB_RAPPI_1("82502109", null, "BF", "Pago compra",""),
	@SerializedName("82202112") PAG_TAR_CRED("82202112", null, "BF", "Pago crédito","X"),
	@SerializedName("82502113") COMPRAS_DEB_RAPPI_2("82502113", null, "BF", "Pago compra","X"),
	@SerializedName("82202130") DEB_TRANS_MASIVO_METRO("82202130", null, "BF", "Pago compra",""),
/*	@SerializedName("82502134") COMPRA_TD_CIVICAPAY_PIN("82502134", null, "BF", "Pago compra",""),          */
/*	@SerializedName("82502135") COMPRA_TD_CIVICAPAY_CONTACTLESS("82502135", null, "BF", "Pago compra",""),  */
/*	@SerializedName("82502136") COMPRA_VIRTUAL_TD_CIVICAPAY("82502136", null, "BF", "Pago compra",""),      */
	@SerializedName("CRE") REGISTRO_COMPLETO("CRE", null, "NM", "Registro","X"),
	@SerializedName("CRES") REGISTRO_SIMPLE("CRES", null, "NM", "Registro",""),
	// Tarjeta Debito Digital TDD
	@SerializedName("CG") COMPRA_NACIONAL_TD("CG", null, "BF", "Pago compra","X"),
	@SerializedName("CI") COMPRA_INTERNACIONAL_TD("CI", null, "BF", "Pago compra","X"),
	@SerializedName("ACT") ACTIVACION("ACT", null, "NM", "Registro","X"),
	@SerializedName("CAN") CANCELACION_TARJETA("CAN", null, "NM", "Registro","X"),
	@SerializedName("REX") CANCELACION_REEXPEDICION("REX", null, "NM", "Registro","X"),
	
	private final String codTrnx;
	private final String transTypeTDP;
	private final String actTypeSMH;
	private final String actSubType;
	private final String logicaHobDev;
	/* logicaHobDev permite definir cual logica aplicar en la determinacion de hob_device
	** (segun el codTrnx):
	** Si es "X", debe calcularse a partir del canal de donde viene la trnx (codCanalAmp)
	** Si es "" , el campo hob_device debe asignarsele valor null */
	
	private CodTrnx(final String codTrnx, final String transTypeTDP, final String actTypeSMH, final String actSubType, final String logicaHobDev) {
		
		this.codTrnx = codTrnx;
		this.transTypeTDP = transTypeTDP;
		this.actTypeSMH = actTypeSMH;
		this.actSubType = actSubType;
		this.logicaHobDev = logicaHobDev;
	}
	
	static CodTrnx getTypeByVal(String codTrnx) {

		for (CodTrnx codTrnxObj : values()) {
			if (codTrnxObj.codTrnx.equals(codTrnx)) return codTrnxObj;
		}

		return null;
	}

	static class Serializer implements JsonSerializer<CodTrnx>, JsonDeserializer<CodTrnx> {
		
		@Override
		public JsonElement serialize(CodTrnx src, Type typeOfSrc, JsonSerializationContext context) {
			return context.serialize(src.codTrnx);
		}
		
		@Override
		public CodTrnx deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
			try {
				return getTypeByVal(json.getAsString());
			} catch (JsonParseException e) {
				return null;
			}
		}
	}
	
	@Override
	public String toString() {
		return this.codTrnx;
	}

}

