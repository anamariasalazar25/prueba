package daviplata.groovy.model.enums

import java.util.List;

import daviplata.groovy.model.enums.TpoDispo;
import com.google.gson.annotations.SerializedName;

public enum DeviceType {
	
	M("M"),
	C("C"),
	A("A"),
	blank(null)

	
	private final String hobDevice;
	
	private DeviceType(final String hobDevice) {
		this.hobDevice = hobDevice;
	}
	
	@Override
	public String toString() {
		return this.hobDevice;
	}
}
