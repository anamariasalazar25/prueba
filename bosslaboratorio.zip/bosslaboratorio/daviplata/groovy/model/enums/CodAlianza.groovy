package daviplata.groovy.model.enums;

import com.google.gson.annotations.SerializedName;



import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.annotations.JsonAdapter;
import java.lang.reflect.Type;

@JsonAdapter(CodAlianza.Serializer.class)
public enum CodAlianza {

	@SerializedName("CD_DAVIPLATA") CD_DAVIPLATA("8500"),
	@SerializedName("ALIANZA_2") ALIANZA_2("8600"),
	@SerializedName("ALI_CIVICAPAY") ALI_CIVICAPAY("8700"),
	@SerializedName("ALIANZA_3") ALIANZA_3("8800"),


	private final String codAlianza;
	
	private CodAlianza(final String codAlianza) {
		this.codAlianza = codAlianza;
	}
	
	static CodAlianza getTypeByVal(String codAlianza) {

		for (CodAlianza codAlianzaObj : CodAlianza.values()) {
			if (codAlianzaObj.codAlianza.equals(codAlianza)) return codAlianzaObj;
		}

		return CD_DAVIPLATA;
	}

	static class Serializer implements JsonSerializer<CodAlianza>, JsonDeserializer<CodAlianza> {

		@Override
		public JsonElement serialize(CodAlianza src, Type typeOfSrc, JsonSerializationContext context) {
			return context.serialize(src.codAlianza);
		}

		@Override
		public CodAlianza deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
			try {
				return getTypeByVal(json.getAsString());
			} catch (JsonParseException e) {
				return null;
			}
		}
	}

}
