package daviplata.groovy.model.enums

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonValue;

public enum CodSubprod {
	
	// Se eliminan valores asociados a la Tabla de homologación codSubprodOrigen para que este campo quede libre (solicitado para TDD)
	
	private final String codSubprod;
	
	private static Map<String, CodSubprod> map = new HashMap<>();

	private CodSubprod(final String codSubprod) {
		this.codSubprod = codSubprod;
	}

	static {
		for (CodSubprod cod : CodSubprod.values()) {
			map.put(cod.codSubprod, cod);
		}
	}

	public static String valueOfType(String cod) {
		if(map.get(cod) != null) {
			return cod;
		}
		return null;
	}
	
	@Override
	public String toString() {
		return this.codSubprod;
	}
	
}
