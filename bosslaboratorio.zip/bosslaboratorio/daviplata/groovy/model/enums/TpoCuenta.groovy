package daviplata.groovy.model.enums;

public enum TpoCuenta{
	
	DV("CS", "S", "DV"),
	BC("CS", null, "BC"),
	DN("CS", null, "DN"),
	BS("CS", null, "BS"),
	
	
	private final String tpoCuenta;
	private final String relationship;
	private final String name;
	
	private TpoCuenta(final String tpoCuenta, final String relationship, final String name) {
		this.tpoCuenta = tpoCuenta;
		this.relationship = relationship;
		this.name = name;
	}
	
	@Override
	public String toString() {
		return this.tpoCuenta;
	}
	
};
 
