package daviplata.groovy.model.enums;

public enum BillCat {

	Blank(null),
	UT("UT"),
	IS("IS"),
	TE("TE"),
	OT("OT"),
	CA("CA"),
	SV("SV"),
	
	
	private final String billCat;
	
	private BillCat(final String billCat) {
		this.billCat = billCat;
	}
	
	@Override
	public String toString() {
		return this.billCat;
	}

}
