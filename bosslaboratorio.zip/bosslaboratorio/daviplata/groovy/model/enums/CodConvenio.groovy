package daviplata.groovy.model.enums

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.annotations.JsonAdapter;
import java.lang.reflect.Type;

@JsonAdapter(CodConvenio.Serializer.class)
public enum CodConvenio {
	
	@SerializedName("0001") REC_APPDAVI_TIGO("0001"),
	@SerializedName("0002") REC_MOVISTAR("0002"),
	@SerializedName("0004") REC_APPDAVI_CLARO("0004"),
	@SerializedName("0005") REC_APPDAVI_VIRGIN("0005"),
	@SerializedName("0006") REC_APPDAVI_AVANTEL("0006"),
	@SerializedName("0008") REC_APPDAVI_ETB("0008"),
	@SerializedName("0009") REC_APPDAVI_CELLVOZ("0009"),
	@SerializedName("0010") FLASH_MOBILE("0010"),
	
	private final String codConvenio;
	
	private CodConvenio(final String codConvenio) {
		this.codConvenio = codConvenio;
	}
	
	static CodConvenio getTypeByVal(String codConvenio) {

		for (CodConvenio codConvenioObj : values()) {
			if (codConvenioObj.codConvenio.equals(codConvenio)) return codConvenioObj;
		}

		return null;
	}

	static class Serializer implements JsonSerializer<CodConvenio>, JsonDeserializer<CodConvenio> {
		
		@Override
		public JsonElement serialize(CodConvenio src, Type typeOfSrc, JsonSerializationContext context) {
			return context.serialize(src.codConvenio);
		}
		
		@Override
		public CodConvenio deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
			try {
				return getTypeByVal(json.getAsString());
			} catch (JsonParseException e) {
				return null;
			}
		}
	}
	
	@Override
	public String toString() {
		return this.codConvenio;
	}
	
}
