package daviplata.groovy.model.enums;

import com.google.gson.annotations.SerializedName;

public enum CodTrnxTDD {

    @SerializedName("CG") CG("CG"),
    @SerializedName("CI") CI("CI"),
    @SerializedName("ACT") ACT("ACT"),
    @SerializedName("CAN") CAN("CAN"),
    @SerializedName("REX") REX("REX");

    private final String codTrnxTDD;

    private CodTrnxTDD(final String codTrnxTDD) {
        this.codTrnxTDD = codTrnxTDD;
    }

    @Override
    public String toString() {
        return this.codTrnxTDD;
    }

    static CodTrnxTDD getTypeByVal(String codTrnxTDD) {
        for (CodTrnxTDD codTrnxTDDObj : CodTrnxTDD.values()) {
            if (codTrnxTDDObj.codTrnxTDD.equals(codTrnxTDD)) return codTrnxTDDObj;
        }
        return null;
    }

}
