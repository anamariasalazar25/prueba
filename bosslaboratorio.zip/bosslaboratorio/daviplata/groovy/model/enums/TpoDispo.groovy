package daviplata.groovy.model.enums

import com.google.gson.annotations.SerializedName;

public enum TpoDispo {
	
	Mobile("Mobile"),
	Computer("Computer"),
	space(""),
	blank(null),
	INVALID("invalid")
	
	
	private final String tpoDispo;
	
	private TpoDispo(final String tpoDispo) {
		this.tpoDispo = tpoDispo;
	}
	
	static TpoDispo getTypeByVal(String tpoDispo) {

		for (TpoDispo tpoDispoObj : TpoDispo.values()) {
			if (tpoDispoObj.tpoDispo.equals(tpoDispo)) return tpoDispoObj;
		}

		return INVALID;
	}
	
	@Override
	public String toString() {
		return this.tpoDispo;
	}
}

