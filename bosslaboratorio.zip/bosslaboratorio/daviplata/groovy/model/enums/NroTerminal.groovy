package daviplata.groovy.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.annotations.JsonAdapter;
import java.lang.reflect.Type;

@JsonAdapter(NroTerminal.Serializer.class)
public enum NroTerminal {

	@SerializedName("001") OFF_DALI("001"),
	
	private final String nroTerminal;
	
	private NroTerminal(final String nroTerminal) {
		this.nroTerminal = nroTerminal;
	}
	
	static NroTerminal getTypeByVal(String nroTerminal) {

		for (NroTerminal nroTerminalObj : values()) {
			if (nroTerminalObj.nroTerminal.equals(nroTerminal)) return nroTerminalObj;
		}

		return null;
	}

	static class Serializer implements JsonSerializer<NroTerminal>, JsonDeserializer<NroTerminal> {
		
		@Override
		public JsonElement serialize(NroTerminal src, Type typeOfSrc, JsonSerializationContext context) {
			return context.serialize(src.nroTerminal);
		}
		
		@Override
		public NroTerminal deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
			try {
				return getTypeByVal(json.getAsString());
			} catch (JsonParseException e) {
				return null;
			}
		}
	}
	
	@Override
	public String toString() {
		return this.nroTerminal;
	}


}
