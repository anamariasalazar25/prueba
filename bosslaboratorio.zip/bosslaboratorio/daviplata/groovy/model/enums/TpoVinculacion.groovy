package daviplata.groovy.model.enums

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.annotations.JsonAdapter;
import java.lang.reflect.Type;

@JsonAdapter(TpoVinculacion.Serializer.class)
public enum TpoVinculacion {

	@SerializedName("01") VINC_SIMP("01"),
	@SerializedName("02") VINC_SIMP_COM("02"),
	@SerializedName("03") VINC_FULL("03"),
	@SerializedName("04") VINC_FULL_COM("04"),
	
	private final String tpoVinc;
	
	private TpoVinculacion(final String tpoVinc) {
		this.tpoVinc = tpoVinc;
	}

	static TpoVinculacion getTypeByVal(String tpoVinc) {

		for (TpoVinculacion tpoVincObj : values()) {
			if (tpoVincObj.tpoVinc.equals(tpoVinc)) return tpoVincObj;
		}

		return null;
	}

	static class Serializer implements JsonSerializer<TpoVinculacion>, JsonDeserializer<TpoVinculacion> {
		
		@Override
		public JsonElement serialize(TpoVinculacion src, Type typeOfSrc, JsonSerializationContext context) {
			return context.serialize(src.tpoVinc);
		}
		
		@Override
		public TpoVinculacion deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
			try {
				return getTypeByVal(json.getAsString());
			} catch (JsonParseException e) {
				return null;
			}
		}
	}
	
	@Override
	public String toString() {
		return this.tpoVinc;
	}
}
