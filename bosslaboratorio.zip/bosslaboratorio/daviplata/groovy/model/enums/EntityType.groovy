package daviplata.groovy.model.enums;

public enum EntityType {

	Blank(null),
	T("T"),
	M("M"),
		
	
	private final String entityTypeTPP;
	
	private EntityType(final String entityTypeTPP) {
		this.entityTypeTPP = entityTypeTPP;
	}
	
	@Override
	public String toString() {
		return this.entityTypeTPP;
	}

}
