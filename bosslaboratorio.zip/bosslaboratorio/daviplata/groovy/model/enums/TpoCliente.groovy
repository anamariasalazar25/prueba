package daviplata.groovy.model.enums;

public enum TpoCliente {
	
	Natural("I"),
	Jurídico("B"),
	Regular_individual("R")
	
	private final String tpoCliente;
	
	private TpoCliente(final String tpoCliente) {
		this.tpoCliente = tpoCliente;
	}
	
    @Override
	public String toString() {
		return this.tpoCliente;
	}
	

}
