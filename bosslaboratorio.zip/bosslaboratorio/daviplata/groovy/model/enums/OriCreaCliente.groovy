package daviplata.groovy.model.enums

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.annotations.JsonAdapter;
import java.lang.reflect.Type;

@JsonAdapter(OriCreaCliente.Serializer.class)
public enum OriCreaCliente {
	
	@SerializedName("001") LISTA_ACEP("001"),
	@SerializedName("002") BASICO("002"),
	@SerializedName("005") CLIENTE_RBM("005"),
	
	private final String oriCreaCliente;
	
	private OriCreaCliente(final String oriCreaCliente) {
		this.oriCreaCliente = oriCreaCliente;
	}

	static OriCreaCliente getTypeByVal(String oriCreaCliente) {

		for (OriCreaCliente oriCreaClienteObj : values()) {
			if (oriCreaClienteObj.oriCreaCliente.equals(oriCreaCliente)) return oriCreaClienteObj;
		}

		return null;
	}

	static class Serializer implements JsonSerializer<OriCreaCliente>, JsonDeserializer<OriCreaCliente> {
		
		@Override
		public JsonElement serialize(OriCreaCliente src, Type typeOfSrc, JsonSerializationContext context) {
			return context.serialize(src.oriCreaCliente);
		}
		
		@Override
		public OriCreaCliente deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
			try {
				return getTypeByVal(json.getAsString());
			} catch (JsonParseException e) {
				return null;
			}
		}
	}
	
	@Override
	public String toString() {
		return this.oriCreaCliente;
	}

	
}
