package daviplata.groovy.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.annotations.JsonAdapter;
import java.lang.reflect.Type;

@JsonAdapter(ModoOperacion.Serializer.class)
public enum ModoOperacion {

	@SerializedName("N") N("0", "A"),
	@SerializedName("R") R("1", "R")

	private final String modoOperacion;
	private final String status;
	
	private ModoOperacion(final String modoOperacion, final String status) {
		this.modoOperacion = modoOperacion;
		this.status = status;
	}
	
	static ModoOperacion getTypeByVal(String modoOperacion) {

		for (ModoOperacion modoOperacionObj : values()) {
			if (modoOperacionObj.modoOperacion.equals(modoOperacion)) return modoOperacionObj;
		}

		return null;
	}

	static class Serializer implements JsonSerializer<ModoOperacion>, JsonDeserializer<ModoOperacion> {
		
		@Override
		public JsonElement serialize(ModoOperacion src, Type typeOfSrc, JsonSerializationContext context) {
			return context.serialize(src.modoOperacion);
		}
		
		@Override
		public ModoOperacion deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
			try {
				return getTypeByVal(json.getAsString());
			} catch (JsonParseException e) {
				return null;
			}
		}
	}

}
