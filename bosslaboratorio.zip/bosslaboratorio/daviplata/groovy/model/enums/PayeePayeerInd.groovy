package daviplata.groovy.model.enums;

public enum PayeePayeerInd {

	Blank(null),
	E("E"),
	R("R"),
		
	
	private final String payeePayeerInd;
	
	private PayeePayeerInd(final String payeePayeerInd) {
		this.payeePayeerInd = payeePayeerInd;
	}
	
	@Override
	public String toString() {
		return this.payeePayeerInd;
	}

}
