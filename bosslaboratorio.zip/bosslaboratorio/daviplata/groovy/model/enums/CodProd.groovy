package daviplata.groovy.model.enums

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.annotations.JsonAdapter;
import java.lang.reflect.Type;

@JsonAdapter(CodProd.Serializer.class)
public enum CodProd {

	@SerializedName("0900") DAVI_REDEBAN("0900"),
	@SerializedName("0902") DAVI_BANCO("0902"),
	@SerializedName("0950") NANOCREDITOS("0950")
	
	private final String codProd;
	
	private CodProd(final String codProd) {
		this.codProd = codProd;
	}
	
	static CodProd getTypeByVal(String codProd) {

		for (CodProd codProdObj : values()) {
			if (codProdObj.codProd.equals(codProd)) return codProdObj;
		}

		return null;
	}

	static class Serializer implements JsonSerializer<CodProd>, JsonDeserializer<CodProd> {
		
		@Override
		public JsonElement serialize(CodProd src, Type typeOfSrc, JsonSerializationContext context) {
			return context.serialize(src.codProd);
		}
		
		@Override
		public CodProd deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
			try {
				return getTypeByVal(json.getAsString());
			} catch (JsonParseException e) {
				return null;
			}
		}
	}
	
	@Override
	public String toString() {
		return this.codProd;
	}
	
}
