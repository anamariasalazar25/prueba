package daviplata.groovy.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.annotations.JsonAdapter;
import java.lang.reflect.Type;

import daviplata.groovy.model.enums.TpoDispoHOB;

@JsonAdapter(CodCanalAmp.Serializer.class)
public enum CodCanalAmp {

	@SerializedName("00") OFF_CIM("00", null, null, TpoDispoHOB.tipo1),
	@SerializedName("02") WEBAPP("02", "W", "NC", TpoDispoHOB.tipo2),
	@SerializedName("03") ATM_DAVI("03", "D", "NC", TpoDispoHOB.tipo1),
	@SerializedName("05") TEL_ROJO("05", null, null, TpoDispoHOB.tipo1),
	@SerializedName("06") INTERBANC("06", "B", "NA", TpoDispoHOB.tipo1),
	@SerializedName("10") REDES_ATMS("10", "D", "NC", TpoDispoHOB.tipo1),
	@SerializedName("11") PROC_AUTO("11", null, null, TpoDispoHOB.tipo1),
	@SerializedName("16") DAVI("16", "W", "NC", TpoDispoHOB.tipo3),
	@SerializedName("21") PORT_EMP("21", null, null, TpoDispoHOB.tipo3),
	@SerializedName("24") CORR_BANC("24", "D", "NC", TpoDispoHOB.tipo1),
	@SerializedName("26") ATMS_DAVI_MULT("26", "D", "NC", TpoDispoHOB.tipo1),
	@SerializedName("32") HOST_HOST("32", null, null, TpoDispoHOB.tipo1),
	@SerializedName("37") DAVIAPP("37", "D", "NC", TpoDispoHOB.tipo2),
	@SerializedName("47") PSE_DAVI("47", "D", "NC", TpoDispoHOB.tipo3),
	@SerializedName("81") PORT_EMP_REG("81", null, null, TpoDispoHOB.tipo3),
	@SerializedName("83") APPS_DAVI("83", "D", "NC", TpoDispoHOB.tipo2),
	@SerializedName("89") CORE_DIGITAL("89", "D", "NA", TpoDispoHOB.tipo1)

	
	private final String codCanalAmp;
	private final String channelType;
	private final String authMethod;
	private final tpoDispoHOB;
	
	private CodCanalAmp(final String codCanalAmp, final String channelType, final String authMethod, final TpoDispoHOB tpoDispoHOB) {
		this.codCanalAmp = codCanalAmp;
		this.channelType = channelType;
		this.authMethod = authMethod;
		this.tpoDispoHOB = tpoDispoHOB
	}
	
	static CodCanalAmp getTypeByVal(String codCanalAmp) {

		for (CodCanalAmp codCanalAmpObj : values()) {
			if (codCanalAmpObj.codCanalAmp.equals(codCanalAmp)) return codCanalAmpObj;
		}

		return null;
	}

	static class Serializer implements JsonSerializer<CodCanalAmp>, JsonDeserializer<CodCanalAmp> {
		
		@Override
		public JsonElement serialize(CodCanalAmp src, Type typeOfSrc, JsonSerializationContext context) {
			return context.serialize(src.codCanalAmp);
		}
		
		@Override
		public CodCanalAmp deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
			try {
				return getTypeByVal(json.getAsString());
			} catch (JsonParseException e) {
				return null;
			}
		}
	}
	
	@Override
	public String toString() {
		return this.codCanalAmp;
	}

}

