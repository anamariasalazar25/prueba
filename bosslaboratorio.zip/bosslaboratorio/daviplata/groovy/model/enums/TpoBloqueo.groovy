package daviplata.groovy.model.enums

import com.google.gson.annotations.SerializedName;

public enum TpoBloqueo {
	
	// Se eliminan valores asociados a la Tabla de homologación tpoBloqueo para que este campo quede libre (solicitado para TDD)

}
