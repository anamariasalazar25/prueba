package daviplata.groovy.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.annotations.JsonAdapter;
import java.lang.reflect.Type;

@JsonAdapter(TpoIdent.Serializer.class)
public enum TpoIdent {
	
	CC("01"),
	CE("02"),
	NIT_PJ("03"),
	TI("04"),
	PASAPORTE("05"),
	NIT_EXTRAN("11"),
	REG_CIVIL("13"),
	CARNET_DIP("15"),
	COD_FISCAL_TRIB("16"),
	PMSO_PERMANENCIA("17"),
	
	private final String tpoIdent;
	
	private TpoIdent(final String tpoIdent) {
		this.tpoIdent = tpoIdent;
	}

	static TpoIdent getTypeByVal(String tpoIdent) {

		for (TpoIdent tpoIdentObj : values()) {
			if (tpoIdentObj.tpoIdent.equals(tpoIdent)) return tpoIdentObj;
		}

		return null;
	}

	static class Serializer implements JsonSerializer<TpoIdent>, JsonDeserializer<TpoIdent> {
		
		@Override
		public JsonElement serialize(TpoIdent src, Type typeOfSrc, JsonSerializationContext context) {
			return context.serialize(src.tpoIdent);
		}
		
		@Override
		public TpoIdent deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) {
			try {
				return getTypeByVal(json.getAsString());
			} catch (JsonParseException e) {
				return null;
			}
		}
	}
	
	@Override
	public String toString() {
		return this.tpoIdent;
	}
}

