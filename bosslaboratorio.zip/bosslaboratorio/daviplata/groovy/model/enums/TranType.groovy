package daviplata.groovy.model.enums;

public enum TranType {

	Blank(null),
	T("T"),
	P("P"),
	B("B")
	
	
	private final String tranTypeTBT;
	
	private TranType(final String tranTypeTBT) {
		this.tranTypeTBT = tranTypeTBT;
	}
	
	@Override
	public String toString() {
		return this.tranTypeTBT;
	}

}
