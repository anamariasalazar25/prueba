package daviplata.groovy.model;

import java.util.StringJoiner;
import java.util.Map;

/* import daviplata.groovy.model.enums.CodConvenio;  */
import daviplata.groovy.model.sas.SASTemplate;
import daviplata.groovy.model.sas.enums.SASRecConvenio;

public class RecaudoConvenio extends SASTemplate {

	/**
	 * 
	 * @param codComercio
	 * @param tpoConvenio
	 * @param tpoRecaudo
	 * @param codConvenioIAC
	 * @param codConvenio
	 * @param numProcesoEmp
	 * @param traceNumber
	 */

	public RecaudoConvenio() {}
	
	def String codComercio;
	def String tpoConvenio;
	def String tpoRecaudo;
	def String codConvenioIAC;
/*	def CodConvenio codConvenio;  */
	def String codConvenio;
	def String numProcesoEmp;
	def String traceNumber;
    
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASRecConvenio);
	}
	
    @Override
	public String toString() {
		return new StringJoiner(", ", RecaudoConvenio.class.getSimpleName() + "[", "]")
			.add("codComercio=" + this.codComercio + "'")
			.add("tpoConvenio='" + this.tpoConvenio + "'")
			.add("tpoRecaudo='" + this.tpoRecaudo + "'")
			.add("codConvenioIAC=" + this.codConvenioIAC + "'")
			.add("codConvenio='" + this.codConvenio + "'")
			.add("numProcesoEmp='" + this.numProcesoEmp + "'")
			.add("traceNumber='" + this.traceNumber + "'")
			.toString();
	}
   
}

