package daviplata.groovy.model;

import java.util.Map;
import java.util.Date;
import java.util.StringJoiner;

import com.google.gson.annotations.SerializedName;

import daviplata.groovy.model.sas.SASTemplate;
import daviplata.groovy.model.enums.EstadoProd;
import daviplata.groovy.model.sas.enums.SASAdicionalProd;
import daviplata.groovy.tools.deserializers.DatesFormats;

public class AdicionalProd extends SASTemplate {
	
	@SerializedName(value = "fchUltBloqueo")
	private Date fchHoraUltBloqueo;
	
	@SerializedName(value = "fchUltMvmnto")
	private Date fchHoraUltMvmnto;
	
	@SerializedName(value = "fchUltNovedad")
	private Date fchHoraUltNovedad;
	
	public AdicionalProd() {}
	
	def String subProd;
	def EstadoProd estadoProd;
	def String tpoBloqueo;
	def String motivoBloqueo;
	def String codUltMvmnto;
	def String rptaUltMvmnto;
	def String tpoUltNovedad;
	def String rptaUltNovedad;
	
	public String getFchUltBloqueo() {
		if(this.fchHoraUltBloqueo != null) {
			return DatesFormats.changeDateFormat(DatesFormats.DATE_FORMAT_A, this.fchHoraUltBloqueo);
		}
		return null;
	}
	
	public String getHoraUltBloqueo() {
		if(this.fchHoraUltBloqueo != null) {
			return DatesFormats.changeDateFormat(DatesFormats.TIME_FORMAT_A, this.fchHoraUltBloqueo);
		}
		return null;
	}
	
	public void setFchHoraUltBloqueo(Date fchHoraUltBloqueo) {
		this.fchHoraUltBloqueo = fchHoraUltBloqueo;
	}
	
	public String getFchUltMvmnto() {
		if(this.fchHoraUltMvmnto != null) {
			return DatesFormats.changeDateFormat(DatesFormats.DATE_FORMAT_A, this.fchHoraUltMvmnto);
		}
		return null;
	}
	
	public String getHoraUltMvmnto() {
		if(this.fchHoraUltMvmnto != null) {
			return DatesFormats.changeDateFormat(DatesFormats.TIME_FORMAT_A, this.fchHoraUltMvmnto);
		}
		return null;
	}
	
	public void setFchHoraUltMvmnto(Date fchHoraUltMvmnto) {
		this.fchHoraUltMvmnto = fchHoraUltMvmnto;
	}
	
	public String getFchUltNovedad() {
		if(this.fchHoraUltNovedad != null) {
			return DatesFormats.changeDateFormat(DatesFormats.DATE_FORMAT_A, this.fchHoraUltNovedad);
		}
		return null;
	}
	
	public String getHoraUltNovedad() {
		if(this.fchHoraUltNovedad != null) {
			return DatesFormats.changeDateFormat(DatesFormats.TIME_FORMAT_A, this.fchHoraUltNovedad);
		}
		return null;
	}
	
	public void setFchHoraUltNovedad(Date fchHoraUltNovedad) {
		this.fchHoraUltNovedad = fchHoraUltNovedad;
	}
	
	public String getRptaUltNovedadFlag() {
		if (this.rptaUltNovedad.equals('0')) {
			return '0';
		}
		return '1';
	}
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASAdicionalProd);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", AdicionalProd.class.getSimpleName() + "[", "]")
			.add("subProd=" + this.subProd + "'")
			.add("estadoProd='" + this.estadoProd + "'")
			.add("tpoBloqueo='" + this.tpoBloqueo + "'")
			.add("motivoBloqueo=" + this.motivoBloqueo + "'")
			.add("fchUltBloqueo=" + this.fchUltBloqueo + "'")
			.add("codUltMvmnto='" + this.codUltMvmnto + "'")
			.add("rptaUltMvmnto='" + this.rptaUltMvmnto + "'")
			.add("fchUltMvmnto=" + this.fchUltMvmnto + "'")
			.add("tpoUltNovedad='" + this.tpoUltNovedad + "'")
			.add("rptaUltNovedad='" + this.rptaUltNovedad + "'")
			.add("fchUltNovedad=" + this.fchUltNovedad + "'")
			.toString();
	}	
}
