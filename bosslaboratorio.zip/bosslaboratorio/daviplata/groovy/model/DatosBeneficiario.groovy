package daviplata.groovy.model;

import java.util.Map;
import java.util.StringJoiner;

import daviplata.groovy.model.sas.SASTemplate;
import daviplata.groovy.model.enums.TpoIdent;
import daviplata.groovy.model.enums.CodProd;
import daviplata.groovy.model.enums.CodBanco;
import daviplata.groovy.model.sas.enums.SASDatosBeneficiario;

public class DatosBeneficiario extends SASTemplate {

        /**
         *
         * @param tpoIdentDestino Tipo de identificación del titular del producto Destino (01, 02, 04, 05, 11, 13, 15)
         * @param nroIdentDestino Número de indentificación del titular del producto Destino
         * @param nroProdDestino Número del producto Destino (Ej. número del Daviplata destino)
         * @param codProdDestino Código de producto destino; indica si es monedero o bolsillo
         * @param codSubprodDestino Código de subproducto destino; indica el tipo de bolsillo
         * @param codBancoDestino Identificador del Banco destino
         */

        public DatosBeneficiario() {}

        def TpoIdent tpoIdentDestino;
        def String nroIdentDestino;
        def String nroProdDestino;
        def CodProd codProdDestino;
        def String codSubprodDestino;
        def CodBanco codBancoDestino;

        def TpoIdent tpoIdentDestinoBen;
        def String nroIdentDestinoBen;
        def String nroProdDestinoBen;  
        def String codProdDestinoBen; 
        def String codSubprodDestinoBen;
/*      def String nroProdDestinoTPP;
        def String nroProdDestinoXQO; 
*/

/*        public String getTpoIdentDestinoBen() {
                return this.tpoIdentDestinoBen.toString();
        }

        public void setTpoIdentDestinoBen(TpoIdent tpoIdentBen) {
                this.tpoIdentDestinoBen = tpoIdentBen;
        }

        public String getNroProdDestinoRUA() {
                return this.nroProdDestinoBen;
        }

        public String getNroProdTPP() {
                return this.nroProdDestinoTPP;
        }

        public void setNroProdTPP(String nroProdTPP) {
                this.nroProdDestinoTPP = nroProdTPP;
        }

        public String getNroProdXQO() {
                return this.nroProdDestinoXQO;
        }

        public void setNroProdXQO(String nroProdXQO) {
                this.nroProdDestinoXQO = nroProdXQO;
        }

        public String getCodBancoDestinoTPP() {
                if(this.codBancoDestino != null) return this.codBancoDestino.codBancoTPP;
                return 'S';
        }
*/
    @Override
        public Map<String,Object> obtainSASFormat() {
                return super.sasValidation(this, SASDatosBeneficiario);
        }

    @Override
        public String toString() {
                return new StringJoiner(", ", DatosBeneficiario.class.getSimpleName() + "[", "]")
                        .add("tpoIdentDestino='" + this.tpoIdentDestino.toString() + "'")
                        .add("nroIdentDestino='" + this.nroIdentDestino + "'")
                        .add("nroProdDestino='"  + this.nroProdDestino + "'")
                        .add("codProdDestino='"  + this.codProdDestino + "'")
                        .add("codSubprodDestino='" + this.codSubprodDestino + "'")
                        .add("codBancoDestino='" + this.codBancoDestino + "'")

/*                        .add("tpoIdentDestinoBen='" + this.tpoIdentDestinoBen.toString() + "'")
                        .add("nroProdDestinoTPP='" + this.nroProdDestinoTPP.toString() + "'")
                        .add("nroProdDestinoXQO='" + this.nroProdDestinoXQO.toString() + "'")
*/
                        .toString();
        }
}
