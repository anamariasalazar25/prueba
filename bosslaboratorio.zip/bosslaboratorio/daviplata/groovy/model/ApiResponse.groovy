package daviplata.groovy.model;

import java.util.StringJoiner;

public class ApiResponse {
	
	/**
	 * 
	 * @param codResponse
	 * @param cmxTranId
	 */
	public ApiResponse(String codResponse, String cmxTranId) {
		
		this.codResponse = codResponse;
		this.cmxTranId = cmxTranId;
	}
	
	
	/**
	 *
	 * @param codResponse
	 */
	public ApiResponse(String codResponse) {
		
		this.codResponse = codResponse;
	}
	
	
	public ApiResponse() {}

	def String codResponse;
	def String cmxTranId;
	
	@Override
	public String toString() {
		
		if(this.cmxTranId != null) {
			return new StringJoiner(", ", ApiResponse.class.getSimpleName() + "[", "]")
				.add("codResponse=" + this.codResponse + "'")
				.add("cmxTranId='" + this.cmxTranId + "'")
				.toString();
		}
		
		return new StringJoiner(", ", ApiResponse.class.getSimpleName() + "[", "]")
		.add("codResponse=" + this.codResponse + "'")
		.toString();
	}	
	
}
