package daviplata.groovy.model;

import java.util.Date;
import java.util.StringJoiner;
import java.util.Map;

import daviplata.groovy.model.sas.SASTemplate;
import daviplata.groovy.model.sas.enums.SASTransEval;
import daviplata.groovy.tools.deserializers.DatesFormats;

public class TransaccionEvaluada extends SASTemplate {
	
	private Date fchHoraAutoriz;
	
	public TransaccionEvaluada() {}

	def String talon;
	def String codAutoriz;
	def String codError;
	def String codRechazo;
	
	public void setFchHoraAutoriz(Date fchHoraAutoriz) {
		this.fchHoraAutoriz = fchHoraAutoriz;
	}
	
	public String getFchAutoriz() {
		return DatesFormats.changeDateFormat(DatesFormats.DATE_FORMAT_A, this.fchHoraAutoriz);
	}
	
	public String getHoraAutoriz() {
		return DatesFormats.changeDateFormat(DatesFormats.TIME_FORMAT_A, this.fchHoraAutoriz);
	}
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASTransEval);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", TransaccionEvaluada.class.getSimpleName() + "[", "]")
			.add("talon=" + this.talon + "'")
			.add("codAutoriz='" + this.codAutoriz + "'")
			.add("fchHoraAutoriz='" + this.fchHoraAutoriz + "'")
			.add("codError=" + this.codError + "'")
			.add("codRechazo='" + this.codRechazo + "'")
			.toString();
	}
	
}
