package daviplata.groovy.model;

import com.google.gson.annotations.SerializedName;

import java.util.StringJoiner;
import java.util.Map;

import javax.annotation.Nonnull;

import daviplata.groovy.model.enums.CodTrnx;
import daviplata.groovy.model.enums.CodTrnxTDD;
import daviplata.groovy.model.enums.CodCanalAmp;
import daviplata.groovy.model.enums.ModoOperacion;
import daviplata.groovy.model.enums.TpoCliente;
import daviplata.groovy.model.enums.TpoCuenta;
import daviplata.groovy.model.enums.CodAlianza;
import daviplata.groovy.model.enums.NroTerminal;
import daviplata.groovy.model.sas.SASTemplate;
import daviplata.groovy.model.sas.enums.SASOriginadorTransaccion;
import daviplata.groovy.tools.values.Segments;;
import daviplata.groovy.model.enums.BillCat;
import daviplata.groovy.model.enums.TranType;
import daviplata.groovy.model.enums.EntityType;
import daviplata.groovy.model.enums.PayeePayeerInd;

public class OriginadorTransaccion extends SASTemplate {
	
	public OriginadorTransaccion() {}

	def CodTrnx codTrnx;
	def CodTrnxTDD codTrnxTDD;
	def String codTrnxTDDOriginal;
	def TpoCliente tpoCliente;
	def TpoCuenta tpoCuenta;
	def CodCanalAmp codCanalAmp;
	def ModoOperacion modoOperacion;
	@SerializedName("codAlianza")
	def String codAlianzaOriginal;
	def String nroTerminal;
	def String custNum;
	def String transCompType;
	def String actDetail1;
	def String actDetail2;
	def String actDetail3;
		
	public CodAlianza getCodAlianza() {
		
		if(this.codAlianzaOriginal == null) return CodAlianza.CD_DAVIPLATA;
			
		return CodAlianza.getTypeByVal(codAlianzaOriginal);
	}
	/**
	 * Get client type for RUA
	 * @return
	 */
	public String getTpoClienteRUA() {
		return this.tpoCliente.toString();
	}
	
	/**
	 * Get account type for RUA
	 * @return
	 */
	public String getTpoCuentaRUA() {
		return this.tpoCuenta.name;
	}
	
	/**
	 * Get account type for DUA
	 * @return
	 */
	public String getTpoCuentaDUA() {
		return this.tpoCuenta.name;
	}
	
	/**
	 * Get account type for DUA
	 * @return
	 */
	public String getAuthMethod() {
		return this.codCanalAmp.authMethod;
	}
	
	/**
	 * Get account type for RUA
	 * @return
	 */
	public String getChannelType() {
		return this.codCanalAmp.channelType;
	}
	
	/**
	 * Get transaction Transaction Type
	 * @return
	 */
	public String getTbtTransType() {
		
		String codTrans = this.codTrnx.codTrnx;
		
		if(codTrans.length() >= 8 || codTrans.equals("CRE") || codTrans.equals("CRES")) {
			
			String motivoTrnx = null;
			
			if(codTrans.equals("CRE") || codTrans.equals("CRES")) {
				motivoTrnx = codTrans;
			}			
			else {
				motivoTrnx = this.codTrnx.codTrnx.substring(4, 8);
			}
			
			def group1 = ["1501", "2038", "2039", "2040", "2104", "CRE" , "CRES"];
			def group2 = ["2019", "2020", "2021", "2023", "2025", "2028", "2029", "2030", "2031", "2032", "2034", "2036", "2037",
						  "2041", "2101", "2102", "2103"];
			def group3 = [];
			def group4 = ["2035", "2043", "2044", "2045", "2046", "2047", "2048", "2049", "2050", "2055", "2056", "2057", "2107", "2108", 
			              "2109", "2112", "2113", "2130"];
			
			if(group1.contains(motivoTrnx)) {
				return TranType.Blank;
			}
			
			else if(group2.contains(motivoTrnx)) {
				return TranType.T;
			}
			
			else if(group3.contains(motivoTrnx)) {
				return TranType.P;
			}
			
			else if(group4.contains(motivoTrnx)) {
				return TranType.B;
			}
			
			return null;
		}
		
		return null;
	}
	
	/**
	 * Get transaction activity type
	 * @return
	 */
	public String getSmhActivity() {
		return this.codTrnx.actTypeSMH;
	}
	
	
	/**
	 * Get created sub activity type
	 * @return
	 */
	public String getSubActivity() {
		return this.codTrnx.actSubType;
	}
	
	/**
	 *  Get transaction Type of Deposit
	 * @return
	 */
	public String getTdpTransType() {
		return this.codTrnx.transTypeTDP;
	}
	
	/**
	 *  Get logic to be used for finding out HobDevice
	 * @return
	 */
	public String getLogicHobDevice() {
		return this.codTrnx.logicaHobDev;
	}

	/**
	 * Get Payee/Payer Indicator
	 * @return
	 */
	public String getTppPayeePayer() {
		
		String codTrans = this.codTrnx.codTrnx;
		
		if(codTrans.length() >= 8 || codTrans.equals("CRE") || codTrans.equals("CRES")) {
			
			String motivoTrnx = null;
			
			if(codTrans.equals("CRE") || codTrans.equals("CRES")) {
				motivoTrnx = codTrans;
			}			
			else {
				motivoTrnx = this.codTrnx.codTrnx.substring(4, 8);
			}
			
			def group1 = ["2019", "2021", "2023", "2028", "2031", "2034", "2035", "2045", "2102"];
			def group2 = ["1501", "2020", "2025", "2029", "2030", "2032", "2036", "2037", "2041", "2101", "2103"];
         /*
			def group3 = ["2036", "2037", "2103"];
			def group4 = ["2043", "2044"];
			def group5 = ["2045", "2046"];
			def group6 = ["2047", "2048", "2049", "2050", "2055", "2056", "2057", "2108", "2109", "2113", "2130", "2134", "2135", "2136"];
			def group7 = ["2057", "2107"];
			def group8 = ["2112"];
			def group9 = [];  */
			
			if(group1.contains(motivoTrnx)) {
				return PayeePayeerInd.E;
			}
			
			else if(group2.contains(motivoTrnx)) {
				return PayeePayeerInd.R;
			}
          /*			
			else if(group3.contains(motivoTrnx)) {
				return PayeePayeerInd.R;
			}
			
			else if(group4.contains(motivoTrnx)) {
				return PayeePayeerInd.E;
			}
			
			else if(group5.contains(motivoTrnx)) {
				return PayeePayeerInd.E;
			}
			
			else if(group6.contains(motivoTrnx)) {
				return PayeePayeerInd.E;
			}
			
			else if(group7.contains(motivoTrnx)) {
				return PayeePayeerInd.E;
			}
			
			else if(group8.contains(motivoTrnx)) {
				return PayeePayeerInd.E;
			}
			
			else if(group9.contains(motivoTrnx)) {
				return PayeePayeerInd.R;
			}    */
			
			return null;
		}
		
		return null;
	}
	
	/**
	 * Get tpp_entity_type
	 * @return
	 */
	public String getTppEntityType() {
		
		String codTrans = this.codTrnx.codTrnx;
		
		if(codTrans.length() >= 8 || codTrans.equals("CRE") || codTrans.equals("CRES")) {
			
			String motivoTrnx = null;
			
			if(codTrans.equals("CRE") || codTrans.equals("CRES")) {
				motivoTrnx = codTrans;
			}			
			else {
				motivoTrnx = this.codTrnx.codTrnx.substring(4, 8);
			}
			
			def group1 = ["1501", "2019", "2020", "2021", "2023", "2025", "2028", "2029", "2030", "2031", "2032",
			              "2034", "2035", "2036", "2037", "2041", "2045", "2046", "2101", "2102", "2103", "2112"];
			def group2 = [];
			def group3 = [];
			def group4 = [];
			def group5 = [];
			def group6 = ["2047", "2048", "2049", "2050", "2055", "2056", "2057", "2107", "2108", "2109", "2113", "2130"];
			def group7 = [];
			def group8 = [];
			def group9 = [];
			
			if(group1.contains(motivoTrnx)) {
				return EntityType.T;
			}
		 /*	
			else if(group2.contains(motivoTrnx)) {
				return EntityType.T;
			}
			
			else if(group3.contains(motivoTrnx)) {
				return EntityType.T;
			}
			
			else if(group4.contains(motivoTrnx)) {
				return EntityType.T;
			}
			
			else if(group5.contains(motivoTrnx)) {
				return EntityType.T;
			}  */
			
			else if(group6.contains(motivoTrnx)) {
				return EntityType.M;
			}
         /*			
			else if(group7.contains(motivoTrnx)) {
				return EntityType.M;
			}
			
			else if(group8.contains(motivoTrnx)) {
				return EntityType.Blank;
			}
			
			else if(group9.contains(motivoTrnx)) {
				return EntityType.Blank;
			}   */
 			
			return null;
		}
		
		return null;
	}
	
	/**
	 * Get tbt_bill_cat
	 * @return
	 */
	public String getTbtBillCat() {
		
		String codTrans = this.codTrnx.codTrnx;
		
		if(codTrans.length() >= 8 || codTrans.equals("CRE") || codTrans.equals("CRES")) {
			
			String motivoTrnx = null;
			
			if(codTrans.equals("CRE") || codTrans.equals("CRES")) {
				motivoTrnx = codTrans;
			}			
			else {
				motivoTrnx = this.codTrnx.codTrnx.substring(4, 8);
			}
			
			def group1 = ["1501", "2019", "2020", "2021", "2023", "2025", "2028", "2029", "2030", "2031", "2032", "2034", "2036", "2037",
						  "2038", "2039", "2040", "2041", "2101", "2102", "2103", "2104", "CRE" , "CRES" ];
			def group2 = ["2043", "2044", "2045", "2046"];
			def group3 = ["2047"];
			def group4 = ["2048", "2049", "2050"];
			def group5 = ["2035", "2055", "2056", "2057", "2107", "2108", "2109", "2113"];
			def group6 = ["2112"];
			def group7 = ["2130"];
			
			if(group1.contains(motivoTrnx)) {
				return BillCat.Blank;
			}
			
			else if(group2.contains(motivoTrnx)) {
				return BillCat.UT;
			}
			
			else if(group3.contains(motivoTrnx)) {
				return BillCat.IS;
			}
			
			else if(group4.contains(motivoTrnx)) {
				return BillCat.TE;
			}
			
			else if(group5.contains(motivoTrnx)) {
				return BillCat.OT;
			}
			
			else if(group6.contains(motivoTrnx)) {
				return BillCat.CA;
			}
			
			else if(group7.contains(motivoTrnx)) {
				return BillCat.SV;
			}
			
			return null;
		}
		
		return null;
	}
	
	/**
	 * Get transaction Transaction Component Type
	 * @return
	 */
	public String getTransCompType() {
		
		if(this.transCompType != null) return this.transCompType;
		
		return 'TRX';
	}
	
	/**
	 * Get activity details 1
	 * @return
	 */
	public String getActDetail1() {
		
		if(getSmhActivity().equals("N")) return 'DNU';
		return 'DMX';
	}
	
	/**
	 * Get activity details 2
	 * @return
	 */
	public String getActDetail2() {
		if(this.actDetail2 != null) return actDetail2;
		return 'DEE';
	}
	
	/**
	 * Get activity details 3
	 * @return
	 */
	public String getActDetail3() {
		if(this.actDetail3 != null) return actDetail3;
		return 'DUA';
	}

	/**
	 * Get client type for XQO
	 * @return
	 */
	public String getTpoClienteXQO() {
		return TpoCliente.Regular_individual;
	}
	
	public String getTpoCuentaRShip() {
		return this.tpoCuenta.relationship;
	}
	
	public String getTransStatus() {
		return this.modoOperacion.status;
	}
	
	// Manejo de campos ModoOperación:
	// getModoOperacionDP -> si activityType = DP, si no es nulo.
	// getModoOperacionOC -> Para cualquier otro caso en que activityType = DP, si no es nulo.
	/**
	 * 
	 * @return
	 */
	public String getModoOperacionDP() {
		String activityType = this.getSmhActivity();
		
		if(activityType.equals("DP")){
			return this.modoOperacion;
		}
		return null;
	}
	
	public String getModoOperacionOC() {
		String activityType = this.getSmhActivity();
		
		if(!activityType.equals("DP")){
			return this.modoOperacion;
		}
		return null;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getTngTransType() {
		if(this.codTrnx.codTrnx.equals("CRE")) {
			return 'OR';
		}
		return null;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getTngCategory() {//
		if(this.getSmhActivity().equals("NM")) {
			return 'R';
		}
		return null;
	}
	
	/**
	 * 
	 * @return
	 */
	public Integer getAqoAcctCntryCode() {
		return 170;
	}
	
	/**
	 * 
	 * @return
	 */
	public Integer getSmhMsgType() {
		return 1;
	}

	/**
	 * 
	 * @return
	 */
	/*public Integer getSmhRespReq() {
		String activityType = this.getSmhActivity();
		
		if(activityType.equals("CA") || activityType.equals("BF") || activityType.equals("DP")) {
			return 1;
		}
		return 0;
	}*/
	
	/**
	 * 
	 * @return
	 */
	public Integer getSmhSddInd() {
		return 2;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getSmhSource() {
		if (this.codTrnx != null && CodTrnxTDD.getTypeByVal(this.codTrnx.toString()) != null) {
			return "MllEvent";
		} else {
        return "CoreDgt";
		}
	}
	
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASOriginadorTransaccion);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", OriginadorTransaccion.class.getSimpleName() + "[", "]")
			.add("codTrnx=" + this.codTrnx + "'")
			.add("tpoCliente='" + this.tpoCliente + "'")
			.add("tpoCuenta='" + this.tpoCuenta + "'")
			.add("codCanalAmp=" + this.codCanalAmp + "'")
			.add("modoOperacion='" + this.modoOperacion + "'")
			.add("codAlianzaOriginal='" + this.codAlianzaOriginal + "'")
			.add("nroTerminal='" + this.nroTerminal + "'")
			.toString();
	}
}
