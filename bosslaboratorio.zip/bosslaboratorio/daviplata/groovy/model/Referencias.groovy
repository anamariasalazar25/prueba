package daviplata.groovy.model;

import java.util.StringJoiner;
import java.util.Map;

import daviplata.groovy.model.sas.SASTemplate;
import daviplata.groovy.model.sas.enums.SASReferencias;

public class Referencias extends SASTemplate {
	
	/**
	 * 
	 * @param celularFactServicios
	 * @param ref1
	 * @param ref2
	 * @param ref3
	 * @param ref4
	 * @param ref5
	 * @param ref6
	 * @param ref7
	 */
	
	public Referencias() {}
	
	def String celularFactServicios;
	def String ref1;
	def String ref2;
	def String ref3;
	def String ref4;
	def String ref5;
	def String ref6;
	def String ref7;
	// Ref4 o Ref5
	def String refTotal;
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASReferencias);
	}
	
	
	@Override
	public String toString() {
		return new StringJoiner(", ", Referencias.class.getSimpleName() + "[", "]")
			.add("celularFactServicios=" + this.celularFactServicios + "'")
			.add("ref1='" + this.ref1 + "'")
			.add("ref2='" + this.ref2 + "'")
			.add("ref3='" + this.ref3 + "'")
			.add("ref4='" + this.ref4 + "'")
			.add("ref5='" + this.ref5 + "'")
			.add("ref6='" + this.ref6 + "'")
			.add("ref7='" + this.ref7 + "'")
			.toString();
	}
	 
}

