package daviplata.groovy.model;

import java.util.Map;
import java.util.Date;
import java.util.StringJoiner;

import com.google.gson.annotations.SerializedName;
import com.fasterxml.jackson.annotation.JsonIgnore;

import daviplata.groovy.model.sas.SASTemplate;
import daviplata.groovy.model.enums.OriCreaCliente;
import daviplata.groovy.model.enums.TpoVinculacion;
import daviplata.groovy.model.sas.enums.SASAdicionalCliente;
import daviplata.groovy.tools.deserializers.DatesFormats;

public class AdicionalCliente extends SASTemplate {
	
	/**
	 * 
	 * @param eMail Correo electrónico registrado por el cliente al momento de vincularse al producto
	 * @param origenCreacionCliente Código que señala si el cliente creado se hallaba en una lista de aceptación o su origen es básico
	 * @param tpoVinculacion Tipo de vinculación del cliente, ya sea simplificada, simple con comercio, full, full comercio
	 * @param fchCreaCliente Fecha y hora de creación del Cliente
	 */
	
	@SerializedName(value = "fchCreaCliente")
	private Date fchHoraCreaCliente;
	
	public AdicionalCliente() {}

	def String eMail;
	def OriCreaCliente origenCreacionCliente;
	def TpoVinculacion tpoVinculacion;
	
	/**
	 * Se obtiene el valor de fchHoraCreaCliente (mapeo inicial)
	 * @return Valor de fchHoraCreaCliente
	 */
	public Date getFchHoraCreaCliente() {
		return this.fchHoraCreaCliente;
	}
	
	/**
	 * Se establece el valor de fchHoraCreaCliente (mapeo inicial)
	 * @param fchHoraCreaCliente Valor de fchHoraCreaCliente 
	 */
	public void setFchHoraCreaCliente(Date fchHoraCreaCliente) {
		this.fchHoraCreaCliente = fchHoraCreaCliente;
	}
	
	/**
	 * Se formatea el valor el valor para el campo fchCreaCliente (dua_10byte_string_003)
	 * @return Valor del campo dua_10byte_string_003
	 */
	public String getFchCreaCliente() {
		return DatesFormats.changeDateFormat(DatesFormats.DATE_FORMAT_A, this.fchHoraCreaCliente);
	}
	
	/**
	 * Se formatea el valor el valor para el campo horaCreaCliente (dua_10byte_string_004)
	 * @return Valor del campo dua_10byte_string_004
	 */
	public String getHoraCreaCliente() {
		return DatesFormats.changeDateFormat(DatesFormats.TIME_FORMAT_A, this.fchHoraCreaCliente);
	}
	
	/**
	 * Se mapea el objeto, con los valores de SAS
	 * @return Mapa: llave_campo_sas : valor_mapeado
	 */
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASAdicionalCliente);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", AdicionalCliente.class.getSimpleName() + "[", "]")
			.add("eMail=" + this.eMail + "'")
			.add("origenCreacionCliente='" + this.origenCreacionCliente + "'")
			.add("tpoVinculacion='" + this.tpoVinculacion + "'")
			.add("fchCreaCliente=" + this.fchCreaCliente + "'")
			.toString();
	}

}
