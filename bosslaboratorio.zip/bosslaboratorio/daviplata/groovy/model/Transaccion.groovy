package daviplata.groovy.model;

import java.util.StringJoiner;
import java.util.Arrays;

import daviplata.groovy.model.enums.CodCanalAmp;
import daviplata.groovy.model.enums.CodTrnx;
import daviplata.groovy.model.enums.CodTrnxTDD;
import daviplata.groovy.model.enums.TpoDispo;
import daviplata.groovy.model.enums.TpoDispoHOB;
import daviplata.groovy.model.sas.SASTemplate;
import daviplata.groovy.model.sas.enums.SASTransaccion;

public class Transaccion extends SASTemplate {

	/**
	 * 
	 * @param originadorTransaccion
	 * @param datosPagador
	 * @param datosComunesTransaccion
	 * @param datosBeneficiario
	 * @param recaudoConvenio
	 * @param dispositivoCliente
	 * @param referencias
	 * @param adicionalCliente
	 * @param adicionalProd
	 * @param codTrnx
	 * @param codTrnxTDD
	 */
	public Transaccion() {}
	
	def OriginadorTransaccion originadorTransaccion;
	def DatosPagador datosPagador;
	def DatosComunesTransaccion datosComunesTransaccion;
	def DatosBeneficiario datosBeneficiario;
	def RecaudoConvenio recaudoConvenio;
	def DispositivoCliente dispositivoCliente;
	def Referencias referencias;
	def AdicionalCliente adicionalCliente;
	def AdicionalProd adicionalProd;
	def CodTrnx codTrnx;
	def CodTrnxTDD codTrnxTDD;
	
	// 	Valores válidos en el fingerprint
	def ArrayList validSegments;

	/**
	 * Se obtiene el valor para el campo tbt_self_acct_ind
	 * @return Valor de tbt_self_acct_ind
	 */
	public String getSelfAccIndTBT() {
		if(this.datosPagador.nroIdentOrigen.equals(this.datosBeneficiario.nroIdentDestino) &&
			this.datosPagador.tpoIdentOrigen.equals(this.datosBeneficiario.tpoIdentDestino)) {
			
			return 'Y';
		}
		return 'N';
	}	

	/**
	 * Se obtiene el valor para el campo custcntryCode
	 * @return Valor de custcntryCode
	 */
	public String getCustcntryCode() {
		return '170';
	}
	
	/**
	 * Se obtiene el valor para el campo hob_device
	 * @return Valor de hob_device
	 */
	public String getHobDevice() {
		
		try {
			
			CodCanalAmp codCanalAmpValue = this.getOriginadorTransaccion().getCodCanalAmp();
			String logicaHobDevValue = this.getOriginadorTransaccion().getLogicHobDevice();
			
			if(codCanalAmpValue != null){
				
				if (logicaHobDevValue != "") {
					TpoDispoHOB tpoDispoHOB = codCanalAmpValue.tpoDispoHOB;	
					return tpoDispoHOB.toString();
				}
				else {
					return "";
				}

				/*// Valor de entrada tpoDispositivo
				String tpoDispositivo = this.getDispositivoCliente().tpoDispositivo;
				TpoDispo tpoDispo = TpoDispo.getTypeByVal(tpoDispositivo);
				
				if(tpoDispo != TpoDispo.INVALID) {
					
					// Contiene los valores válidos para tpoDispositivo según el tipo de canal, y su respectivo valor para hob_device
					TpoDispoHOB tpoDispoHOB = codCanalAmpValue.tpoDispoHOB;
					// Valores válidos para tpoDispositivo según el tipo de canal
					List<TpoDispo> tpoDispos = tpoDispoHOB.tpoDispos;
					
					if(tpoDispos.contains(tpoDispo)) {
						// Respectivo valor para hob_device
						return tpoDispoHOB.hobDevice;
					}
				}*/
			}
			return null;
		}
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	// Validación de códigos de transacción TDD, el valor por default del campo smh_source="Coredgtl" es reemplazado por smh_source="MllEvent"
	public String getSmh_source() {
		String smh_source = "";
		CodTrnx codTrnx = this.getOriginadorTransaccion().getCodTrnx();
		System.out.println("Valor de getCodTrnx(): " + codTrnx);

		if (CodTrnxTDD.getTypeByVal(codTrnx.toString()) != null) {
			smh_source = "MllEvent";
		} else {
			smh_source = "CoreDgt";
		}

		return smh_source;
	}

	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASTransaccion);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", Transaccion.class.getSimpleName() + "[", "]")
			.add("originadorTransaccion=" + this.originadorTransaccion)
			.add("datosPagador='" + this.datosPagador)
			.add("datosComunesTransaccion='" + this.datosComunesTransaccion)
			.add("datosBeneficiario=" + this.datosBeneficiario)
			.add("recaudoConvenio='" + this.recaudoConvenio)
			.add("dispositivoCliente='" + this.dispositivoCliente)
			.add("referencias='" + this.referencias)
			.add("adicionalCliente='" + this.adicionalCliente)
			.add("adicionalProd='" + this.adicionalProd)
			.toString();
	}

}
