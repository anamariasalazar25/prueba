package daviplata.groovy.model;

import java.util.StringJoiner;
import java.util.Map;

import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.Expose

import daviplata.groovy.model.enums.TpoIdent;
import daviplata.groovy.model.enums.CodProd;
/*import daviplata.groovy.model.enums.CodSubprod; */
import daviplata.groovy.model.sas.SASTemplate;
import daviplata.groovy.model.sas.enums.SASDatosPagador;

public class DatosPagador extends SASTemplate {

        /**
         *
         * @param tpoIdentOrigen Tipo de identificación del titular del producto Origen (01, 02, 04, 05, 11, 13, 15)
         * @param nroIdentOrigen Número de identificación del titular del producto Origen
         * @param nroProdOrigen Número del producto Origen/Número del Daviplata origen
         * @param nroCuentaInterno Número de cuenta, asignado por el Core en Compras
         * @param codProdOrigen Número de cuenta, asignado por el Core en Activaciones o Reexpediciones
         * @param codProdOrigen Código de producto origen; indica si es monedero o bolsillo
         * @param codSubprodOrigen Código de subproducto origen; indica el tipo de bolsillo
         */
        public DatosPagador() {}

        def TpoIdent tpoIdentOrigen;
        def String nroIdentOrigen;
        def String nroProdOrigen;
        def String nroCuentaInterno;
        def String nroProdInterno;
        def CodProd codProdOrigen;
        def String codSubprodOrigen;

        def TpoIdent tpoIdentOrigenPag;
        def String nroIdentOrigenPag;
        def String nroProdOrigenPag;
        def CodProd codProdOrigenPag;
        def String codSubprodOrigenPag;
/*        def String nroProdOrigenXQO;
        def String nroProdOrigenTPP;
*/
/*
        public String getTpoIdentOrigenPag() {
                return this.tpoIdentOrigenPag.toString();
        }

        public void setTpoIdentOrigenPag(TpoIdent tpoIdentPag) {
                this.tpoIdentOrigenPag = tpoIdentPag;
        }

        public String getNroProdXQO() {
                return this.nroProdOrigenXQO;
        }

        public void setNroProdXQO(String nroProdXQO) {
                this.nroProdOrigenXQO = nroProdXQO;
        }

        public String getNroProdTPP() {
                return this.nroProdOrigenTPP;
        }

        public void setNroProdTPP(String nroProdTPP) {
                this.nroProdOrigenTPP = nroProdTPP;
        }

        public String getNroProdOrigenRUA() {
                return this.nroProdOrigenPag;
        }
*/
    @Override
        public Map<String,Object> obtainSASFormat() {
                return super.sasValidation(this, SASDatosPagador);
        }

    @Override
        public String toString() {
                return new StringJoiner(", ", DatosPagador.class.getSimpleName() + "[", "]")
                        .add("tpoIdentOrigen='" + this.tpoIdentOrigen.toString() + "'")
                        .add("nroIdentOrigen='" + this.nroIdentOrigen + "'")
                        .add("nroProdOrigen='" + this.nroProdOrigen + "'")
                        .add("nroCuentaInterno='" + this.nroCuentaInterno + "'")
                        .add("codProdOrigen='" + this.codProdOrigen + "'")
                        .add("codSubprodOrigen='" + this.codSubprodOrigen + "'")
/*                      .add("tpoIdentOrigenPag='" + this.tpoIdentOrigenPag.toString() + "'")
                        .add("nroProdOrigenXQO='"  + this.nroProdOrigenXQO.toString() + "'")
                        .add("nroProdOrigenTPP='"  + this.nroProdOrigenTPP.toString() + "'")
*/
                        .toString();
        }

}
