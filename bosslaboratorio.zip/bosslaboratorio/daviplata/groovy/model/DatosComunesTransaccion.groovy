package daviplata.groovy.model;

import java.util.Date;
import java.util.StringJoiner;
import java.util.Map;

import java.lang.Math;

import com.google.gson.annotations.SerializedName;

import daviplata.groovy.model.sas.SASTemplate;
import daviplata.groovy.model.sas.enums.SASDatosComunesTrans;
import daviplata.groovy.tools.deserializers.DatesFormats;

public class DatosComunesTransaccion extends SASTemplate {
	
	/**
	 * 
	 * @param idTrnx Código único que identifica la transacción en el Core digital
	 * @param fchCreaProd Fecha de creación del Producto
	 * @param saldoAntTrnx Saldo disponible antes de la transacción
	 * @param valorTrnx Valor de la transacción (valor de la operación a debitar); serán siempre positivos
	 * @param fchHoraTrnx Fecha y hora en que se realizó la transacción
	 */
	
	private String fchHoraTrnx;
	private String tranUTCFlag;
	
	@SerializedName(value = "fchCreaProd")
	def Date fchHoraCreaProd;
	
	public DatosComunesTransaccion() {}

	def String idTrnx;
	def Double saldoAntTrnx;
	def Double valorTrnx;
	
	def String valorTrnxDP = "";
	def String clientCurr = "";
	def String valorTrnxModDP = "";
	
	def String idTrnxTDP = "";
	
	public String getSaldoAntTrnxSigno() {
		
		if(this.saldoAntTrnx >= 0) return '+';
		return '-';
	}
	
	public Double getSaldoAntTrnxAbs() {
		return Math.abs(this.saldoAntTrnx);
	}
	
	public Date getFchHoraCreaProd() {
		return this.fchHoraCreaProd;
	}
	
	public void setFchHoraCreaProd(Date fchHoraCreaProd) {
		this.fchHoraCreaProd = fchHoraCreaProd;
	}
	
	public String getFchHoraTrnx() {
		return this.fchHoraTrnx;
	}
	
	public void setFchHoraTrnx(String fchHoraTrnx) {
		this.fchHoraTrnx = fchHoraTrnx;
	}
	
	public String getFchCreaProd() {
		
		return DatesFormats.changeDateFormat(DatesFormats.DATE_FORMAT_A, this.fchHoraCreaProd);
	}
	
	public String getHoraCreaProd() {
		
		return DatesFormats.changeDateFormat(DatesFormats.TIME_FORMAT_A, this.fchHoraCreaProd);
	}
	
	public String getFchTrnxAlt() {
		
		this.fchHoraTrnx = fchHoraTrnx.substring(0, 14);
		
		return DatesFormats.changeDateFormat(DatesFormats.DATE_FORMAT_A, this.fchHoraTrnx);
	}
	
	public String getHoraTrnxAlt() {
		
		this.fchHoraTrnx = fchHoraTrnx.substring(0, 14);
		
		String time = DatesFormats.changeDateFormat(DatesFormats.TIME_FORMAT_A, this.fchHoraTrnx);
		if(time.equals("00:00:00")) {
			return time + ".00";
		}
		return time;
	}
	
	public String getFchTrnx() {
		return this.getFchTrnxAlt();
	}
	
	public String getHoraTrnx() {
		return this.getHoraTrnxAlt();
	}
	
	public String getTranUTCFlag() {
		return this.tranUTCFlag;
	}
	
	public void setTranUTCFlag(String tranUTCFlag) {
		this.tranUTCFlag = tranUTCFlag;
	}
	
	public Long getValorTrnxMod() {
		return this.valorTrnx;
	}
	
	public String getSignoSaldo() {//
		return "+";
	}
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASDatosComunesTrans);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", DatosComunesTransaccion.class.getSimpleName() + "[", "]")
			.add("idTrnx=" + this.idTrnx + "'")
			.add("fchCreaProd=" + this.fchCreaProd + "'")
			.add("saldoAntTrnx='" + this.saldoAntTrnx + "'")
			.add("valorTrnx='" + this.valorTrnx + "'")
			.add("fchHoraTrnx=" + this.fchTrnx + "'")
			.toString();
	}
}
