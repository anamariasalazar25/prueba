package daviplata.groovy.model;

import java.util.StringJoiner;
import java.util.Map;

import com.google.gson.annotations.SerializedName;

import daviplata.groovy.model.sas.SASTemplate;
import daviplata.groovy.model.enums.TpoDispo;
import daviplata.groovy.model.sas.enums.SASDispoCliente;

public class DispositivoCliente extends SASTemplate {
	
	/**
	 * 
	 * @param direccionIP
	 * @param tpoDispositivo
	 * @param idDispositivo
	 * @param deviceAppVersion
	 * @param gps
	 * @param codUsuario
	 */
	
	public DispositivoCliente() {}

	def String direccionIP;
	def String tpoDispositivo;
	def String idDispositivo;
	def String deviceAppVersion;
	def String gps;
	def String codUsuario;
	
	private def getLatLong() {

		if(this.gps != null) {

			def sep = this.gps.split(",");

			if(sep.length != 2) {
				sep = this.gps.split(";");
			}

			if(sep.length == 2) {
				String latitude = sep[0];
				String longitude =  sep[1];

				Double latDouble = Double.valueOf(latitude);
				Double lonDouble = Double.valueOf(longitude);

				if(!(latDouble >= -90) || !(latDouble <= 90)) {
					latitude = null;
				}

				if(!(lonDouble >= -180) || !(lonDouble <= 180)) {
					longitude = null;
				}

				return [latitude, longitude];
			}
			
			return [null, null];
		}

		return [null, null];
	}
	
	public String getGpsLat() {
		return getLatLong()[0]; 
	}
	
	public String getGpsLong() {
		return getLatLong()[1]; 
	}
	
	public String getDireccionIPAjax() {
		return this.direccionIP;
	}
    
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASDispoCliente);
	}
	
    @Override
  	public String toString() {
  		return new StringJoiner(", ", DispositivoCliente.class.getSimpleName() + "[", "]")
  			.add("direccionIP=" + this.direccionIP + "'")
  			.add("tpoDispositivo='" + this.tpoDispositivo + "'")
  			.add("idDispositivo='" + this.idDispositivo + "'")
  			.add("deviceAppVersion=" + this.deviceAppVersion + "'")
  			.add("gps='" + this.gps + "'")
  			.add("codUsuario='" + this.codUsuario + "'")
  			.toString();
  	}
    
}
