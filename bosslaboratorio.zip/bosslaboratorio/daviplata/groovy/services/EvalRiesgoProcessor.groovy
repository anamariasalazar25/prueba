package daviplata.groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson
import org.json.JSONObject;

import daviplata.groovy.tools.GsonBuilderFormat;
import daviplata.groovy.model.Transaccion;
import daviplata.groovy.model.ApiResponse;
import daviplata.groovy.tools.checks.TransactionChecks;
import daviplata.groovy.tools.Common;
import daviplata.groovy.exceptions.DaviplataException;

public class EvalRiesgoProcessor implements Processor {	
	
	private static final Logger logger = LoggerFactory.getLogger("daviplatalog");
		
	public void process(Exchange exchange) {
		
		String defaultTranCode = TransactionChecks.getDefaultTransactionCode(null);
		Gson gson = GsonBuilderFormat.getGson();

		try {
			String body = exchange.getIn().getBody(String.class);

			Transaccion transaccion = gson.fromJson(body, new TypeToken<Transaccion>() {}.getType());
			defaultTranCode = TransactionChecks.getDefaultTransactionCode(transaccion);
			
			StringBuilder trxInfoLog = new StringBuilder();
			trxInfoLog.append("mti:0200")
						.append(", canal-amp:").append(transaccion.originadorTransaccion.codCanalAmp)
						.append(", cod-tran:").append(transaccion.originadorTransaccion.codTrnx)
						.append(", cod-alianza:").append(transaccion.originadorTransaccion.codAlianza)
						.append(", date:").append(transaccion.datosComunesTransaccion.fchHoraTrnx)
						.append(", ref-num:").append(transaccion.datosComunesTransaccion.idTrnx)
						.append(", amt:").append(transaccion.datosComunesTransaccion.valorTrnx);
			
			logger.info("CoreDigital-auth-request: {}",trxInfoLog.toString());
			exchange.setProperty("trxInfoLog", trxInfoLog);
						
			//Obtener fecha original
			JSONObject json = new JSONObject(body);
			String fechaRQO = json.getJSONObject("datosComunesTransaccion").getString("fchHoraTrnx");

			transaccion = TransactionChecks.checkTransAttributes(transaccion, fechaRQO);

			if(transaccion == null) {
				throw new DaviplataException(222, "Invalid FingerPrint");
			}
			
			Map<String,Object> transSASMap = transaccion.obtainSASFormat();

			transSASMap.put("hqo_msg_type", "0200");
			transSASMap.put("mti", "0200");
			logger.info("EvalRiesgoProcessor - transSASMap: {}",transSASMap);

			//lineas adicionales en groovyold : para validar
			exchange.setProperty("mti", "0200");
			exchange.setProperty("isResponseRequired", true);

			// successful operation
			exchange.getIn().setBody(transSASMap);
		}


		catch(Exception e) {
			e.printStackTrace();
			logger.error("Error on Request data: " + e.getMessage());
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			ApiResponse resError = new ApiResponse('96', defaultTranCode);
			exchange.setProperty("processingError",true);
			exchange.setProperty("errorType", "PROCESSING_ERROR");
			exchange.getIn().setBody(Common.objectToMap(resError));
		}

		finally {
			exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
		}
	}
}
