package daviplata.groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

import java.util.Map;
import org.json.JSONObject;

import daviplata.groovy.tools.GsonBuilderFormat;
import com.sas.davivienda.efm.commons.util.FMResponseHelper
import daviplata.groovy.model.ApiResponse;
import daviplata.groovy.model.enums.CodTrnx;
import daviplata.groovy.tools.Common;

public class ResponseProcessor implements Processor {
	
	private static final Logger logger = LoggerFactory.getLogger("daviplatalog");
		
	public void process(Exchange exchange) {

		//JM -start
		Gson gson = GsonBuilderFormat.getGson();
		
		Map<String,String> output = exchange.getIn().getBody();
		logger.info("resp-from-ode: {}",output);
		// -end
		
		try {
			// String body = exchange.getIn().getBody(String.class);
			// JSONObject jsonObject = new JSONObject(body);
			// Gson gson = GsonBuilderFormat.getGson();

			String codResponse = FMResponseHelper.getResponseCode(exchange);
			logger.info("codResponse: {}",codResponse);
			// String cmxTranId = jsonObject.getString("cmxTranId");
			//JM -start
			String cmxTranId = output.get("cmx_tran_id");
			logger.info("cmxTranId: {}", cmxTranId);
			// -end
			//CodTrnx codTrnx = CodTrnx.getTypeByVal("20318200");
			String acctType = output.get("smh_activity_type");
			logger.info("acctType: {}",acctType);
			
			// successful operation
			
			ApiResponse response;
			
			if(cmxTranId == null) {
				response = new ApiResponse(codResponse);
			}
			
			else {
				response = new ApiResponse(codResponse, acctType + Common.fillStringWithSpace(cmxTranId, 30));
			}

			logger.info("response: {}",response);
			exchange.getIn().setBody(gson.toJson(response));
		}

		catch(Exception e) {
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			ApiResponse resError = new ApiResponse('96', output.get("cmx_tran_id"));
			exchange.getIn().setBody(gson.toJson(resError));
		}

		finally {
			exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
		}
	}
}


