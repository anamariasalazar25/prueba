package daviplata.groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson

import daviplata.groovy.model.TransaccionEvaluada;
import daviplata.groovy.tools.GsonBuilderFormat;
import daviplata.groovy.tools.Common;
import java.text.SimpleDateFormat;
import daviplata.groovy.tools.deserializers.DatesFormats;

public class ActualizarTransProcessor implements Processor {

	private static final Logger logger = LoggerFactory.getLogger("daviplatalog");

	public void process(Exchange exchange) {

		try {
			String cmxTranId = exchange.getIn().getHeader("cmxTranId").toString();
			logger.info("cmxTranId: " + cmxTranId);
			if(cmxTranId == null || "null".equals(cmxTranId)) {
				throw new Exception("cmx_tran_id is null");
			}

			String body = exchange.getIn().getBody(String.class);
			Gson gson = GsonBuilderFormat.getGson();

			//TransaccionEvaluada transaccionEvaluada = gson.fromJson(body, new TypeToken<TransaccionEvaluada>() {}.getType());
			//logger.info("transaccionEvaluada: {}",transaccionEvaluada);

			Map<String,Object> actTransSASMap = gson.fromJson(body, Map.class);
			logger.info("actTransSASMap:{}",actTransSASMap.toString());
			String cmxTranIdValue = cmxTranId.substring(2, cmxTranId.length());
			// actTransSASMap.put("cmxTranId",  Common.fillStringWithSpace(cmxTranIdValue, 30));
			actTransSASMap.put("cmxTranId", cmxTranIdValue);
			actTransSASMap.put("sasActivityType", cmxTranId.substring(0,2));
			
			String fchHoraAutoriz = actTransSASMap.get("fchHoraAutoriz");
			actTransSASMap.put("fchAutoriz", DatesFormats.changeDateFormat(DatesFormats.DATE_FORMAT_A, fchHoraAutoriz));
			actTransSASMap.put("horaAutoriz", DatesFormats.changeDateFormat(DatesFormats.TIME_FORMAT_A, fchHoraAutoriz));
			
			exchange.setProperty("sasActivityType",cmxTranId.substring(0,2));

			Date dateNow = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String strDateNow = formatter.format(dateNow);

			actTransSASMap.put("dateNow", strDateNow);

			exchange.setProperty("actTransSASMap",actTransSASMap);
			logger.info("################### actTransSASMap: {}",actTransSASMap);

			// successful operation
			exchange.getIn().setBody(gson.toJson(actTransSASMap));
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 202);
		}

		catch(Exception e) {
			e.printStackTrace();
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 400);
			exchange.getIn().setBody(null);
		}

		finally {
			exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
		}
	}
}
