package daviplata.groovy.tools.values;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import daviplata.groovy.model.Transaccion;
import daviplata.groovy.model.enums.BillCat;

public class Segments {

	private static final Logger logger = LoggerFactory.getLogger("daviplatalog");

	// Lista de valores subactivitytype(rua_30byte_string_002) de tipo BF, para los que no se necesita información en el campo de destino.
	public static final actTypeSMH_BFExceptions = [
		"Trnsf a Cta (Cnvnio)",
		"Pago compra",
		"Pago compra PSE",
		"Pago crédito",
		"Pago servicios",
		"Retiro"
	];
	
	// Lista de valores subactivitytype(rua_30byte_string_002) de tipo DP, para los que no se necesita información en el campo de origen.
	public static final actTypeSMH_DPExceptions = [
		"Trnsf a Cta",
		"Abono"
	];
	
	/**
	 * Valid segments depending on transaction account type and activity type combination
	 */
	public static segmentsGroups = [
		FP01: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HCT", "HOB", "HDF", "TBT", "TPP", "DMX", "DEE", "DUA"],
		FP02: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HOB", "HDF", "TBT", "TPP", "DMX", "DEE", "DUA"],
		FP03: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HCT", "HOB", "HDF", "TDP", "TPP", "DMX", "DEE", "DUA"],
		FP04: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HOB", "HDF", "TDP", "TPP", "DMX", "DEE", "DUA"],
		FP05: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "HQO", "TDP", "TPP", "DMX", "DEE", "DUA"],	
		FP06: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HCT", "HOB", "HDF", "TSH", "TPP", "DMX", "DEE", "DUA"],
		FP07: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HOB", "HDF","TSH", "TPP", "DMX", "DEE", "DUA"],
		FP08: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "HQO", "TBT", "TPP", "DMX", "DEE", "DUA"],
		FP09: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HCT","HOB", "HDF", "TNG", "DMX", "DEE", "DUA"]
	];

	/**
	 * FingerPrints combinations
	 * 
	 * v1 -> Account type
	 * v2 -> Auth method
	 * v3 -> Channel type
	 * v4 -> Activity type
	 * 
	 */
	public static segmentsGroupsDef = [
		FP01: ["TRX", "I", "CS", "NC", "D","BF"],
		FP02: ["TRX", "I", "CS", "NC", "W","BF"],
		FP03: ["TRX", "I", "CS", "NC", "D","DP"],
		FP04: ["TRX", "I", "CS", "NC", "W","DP"],
		FP05: ["TRX", "I", "CS", "NA", "B","DP"],
		FP06: ["TRX", "I", "CS", "NC", "D","SH"],
		FP07: ["TRX", "I", "CS", "NC", "W","SH"],
		FP08: ["TRX", "I", "CS", "NA", "B","BF"],
		FP09: ["TRX", "I", "CS", "NC", "D","NM"],
	];
	
	/**
	 * 
	 * @param transaccion
	 * @return
	 */
	public static getTransSegms(Transaccion transaccion) {
		
		String transType = transaccion.originadorTransaccion.getTransCompType();
		String custType = transaccion.originadorTransaccion.tpoCliente.toString();
		String cuenta = transaccion.originadorTransaccion.tpoCuenta.toString();
		String auth = transaccion.originadorTransaccion.codCanalAmp.authMethod;
		String channel = transaccion.originadorTransaccion.codCanalAmp.channelType;
		String activity = transaccion.originadorTransaccion.getSmhActivity();
		
		def vals = [transType, custType, cuenta, auth, channel, activity];

		logger.info("Segments vals: " + vals);
		
		String segKey = segmentsGroupsDef.find{ it.value == vals }?.key;
		
		if(segKey != null) {
			
			transaccion.setValidSegments(segmentsGroups.find{ it.key == segKey }?.value);
			
			return transaccion.getValidSegments();
		}
				
		return null;
	}
}


