package daviplata.groovy.tools.checks;

import java.lang.reflect.Field
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonParseException;

import java.util.HashMap;
import java.util.ArrayList;

import java.lang.IllegalArgumentException;

import daviplata.groovy.model.Transaccion;
import daviplata.groovy.model.sas.SASTemplate;
import daviplata.groovy.model.sas.interfaces.SASInterface;
import daviplata.groovy.model.sas.enums.SASAdicionalCliente;
import daviplata.groovy.model.sas.enums.SASAdicionalProd;
import daviplata.groovy.model.sas.enums.SASDatosBeneficiario;
import daviplata.groovy.model.sas.enums.SASDatosComunesTrans;
import daviplata.groovy.model.sas.enums.SASDatosPagador;
import daviplata.groovy.model.sas.enums.SASDispoCliente;
import daviplata.groovy.model.sas.enums.SASOriginadorTransaccion;
import daviplata.groovy.model.sas.enums.SASRecConvenio;
import daviplata.groovy.model.sas.enums.SASReferencias;
import daviplata.groovy.model.sas.enums.SASTransEval;
import daviplata.groovy.model.sas.enums.SASTransaccion;
import daviplata.groovy.tools.values.Segments;
import daviplata.groovy.tools.Common;
import daviplata.groovy.exceptions.DaviplataException;

public class Checks {
	
	private static final Logger logger = LoggerFactory.getLogger("daviplatalog");
	
	/**
	 * List with SAS enumerations values
	 * key -> Name of enumaration representation (SAS mappers) (daviplata.groovy.model.sas.enums)
	 * value -> Enumeration class 
	 */
	private static enumsList = [
		
		"adicionalCliente": SASAdicionalCliente,
		"adicionalProd": SASAdicionalProd,
		"datosBeneficiario": SASDatosBeneficiario,
		"datosComunesTransaccion": SASDatosComunesTrans,
		"datosPagador": SASDatosPagador,
		"dispositivoCliente": SASDispoCliente,
		"originadorTransaccion": SASOriginadorTransaccion,
		"recaudoConvenio": SASRecConvenio,
		"referencias": SASReferencias,
		"evauluarTransaccion": SASTransEval,
		"transaccion": SASTransaccion
	];
	
	/**
	 * List with class enums that does not need segments validation
	 */
	private static List enumsListExceptions = [
		SASTransEval
	];
	
	public static List getEnumsListExceptions() {
		return this.enumsListExceptions;
	}
	
	/**
	 * The content of an object is deconstructed (excepting date type)
	 * @param object Object that wants to be deconstruyed
	 * @return HashMap with object attributes
	 */
	private static HashMap getObjectAttList(Object object) {
		if(object instanceof java.util.Date) return null;
		return Common.getObjectAttList(object);
	}

	/**
	 * Get if an object has attributes with null values
	 * @param object Object to analyze
	 * @return true or false depending if at least one of object attribute value is null
	 */
	private static boolean getObjectNullAtt(Object object) {
		try {			
			
			def atts = getObjectAttList(object);
			
			if(atts!= null && atts.size() > 0) {
				for (attribute in atts) {					
					if(attribute.value.equals(null)) {
						return true;
					}	
					
					if(getObjectNullAtt(attribute.value) ) {
						return true;
					}
				}
			}
			return false;
			
		}

		catch(Exception e) {
			e.printStackTrace();			
			return true;
		}
	}
	

	
	/**
	 * Verify if attributes of an SASTemplate object are valid: Length and segments
	 * @param object SASTemplate object to evaluate 
	 * @param validSegments List of object valid segments eg. CSBF: ["SMH", "RQO", "RUA", ... ]
	 * @param enumValue Key of enumsList, representing enumeration mapper
	 * @return HashMap Map of object representation
	 * @throws VirtualChannelsException If an attribute value min size is not valid
	 */
	public static HashMap checkFields(SASTemplate object, ArrayList validSegments, String enumValue) throws DaviplataException {

		def attrsMap = Common.getObjectAttList(object);
		def finalAttrsMap = attrsMap.clone();
		
		for(att in attrsMap) {
			
			def key = att.key;
			def value = att.value;

			if(value instanceof SASTemplate == false) {
				
				try {

					def enumAtt = enumsList[enumValue].valueOfElement(key.toString());
					
					if(value instanceof Double) {
						finalAttrsMap[key] = Common.setMaxTwoDec(value);
					}
					
					if(enumAtt != null) {
					
						String attSegement = enumAtt.getSegment();
		
						if(validSegments.contains(attSegement)) {
							evalValue(key, value, enumAtt, finalAttrsMap)
						}
					}
				}
				catch(IllegalArgumentException e) {
					logger.error("Attribute not found in given enumeration: " + key);
				}
			}
			
			else {
				finalAttrsMap[key] = checkFields(value, validSegments, key);
			}
		}

		return finalAttrsMap;
	}
	
	/**
	 * Verify fields values
	 * @param key Field key (object attribute name)
	 * @param value Field value (object attribute value)
	 * @param enumAtt SASTemplate enum of object
	 * @param finalAttrsMap Final hashmap with object values
	 */
	private static void evalValue(key, value, enumAtt, finalAttrsMap) throws DaviplataException {
		
		if(enumAtt.getReq() && value == null) {
			throw new DaviplataException(111, key);
		}
		
		else {
			if(value instanceof String) {
				
				int valueLength = value.length();
	
				if(valueLength < 1) {
					
					if(enumAtt.getReq()) {
						throw new DaviplataException(222, key);
					}
				}
	
				else {
					finalAttrsMap[key] = Common.truncateString(value, enumAtt.getMaxLength());
				}
			}
			
			else if(value instanceof Boolean) {
				finalAttrsMap[key] = Common.boolToInt(value);
			}
			
			else if(value instanceof Integer) {
				String val = Common.truncateString(value.toString(), enumAtt.getMaxLength());
				finalAttrsMap[key] = Integer.valueOf(val);
			}
			
			else if(value instanceof Float) {
				String val = Common.truncateString(value.toString(), enumAtt.getMaxLength());
				finalAttrsMap[key] = Float.valueOf(val);
			}
		}
	}
	
}


