package daviplata.groovy.tools.checks

import java.util.Map;

import daviplata.groovy.model.enums.CodTrnx;
import daviplata.groovy.model.Transaccion;
import daviplata.groovy.tools.checks.Checks;
import daviplata.groovy.tools.values.Segments;
import daviplata.groovy.tools.Common;
import daviplata.groovy.exceptions.DaviplataException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TransactionChecks {

        private static final Logger logger = LoggerFactory.getLogger("daviplatalog");
        /**
         * Verify if transactions attributes
         * @param transaction Transaction object
         */
        public static Transaccion checkTransAttributes(Transaccion transaccion, String fechaRQO) {

                // Set Customer number xqo_cust_num
                transaccion.originadorTransaccion.setCustNum(getCustNum(transaccion));

                // Manage tpoIdentOrigen/tpoIdentDestino
                manageIdentType(transaccion);

                // Manage nroIdentOrigen/nroIdentDestino
                manageIdentNum(transaccion);

                // Manage product number nroProdOrigen/nroProdDestino
                manageProdNum(transaccion);

                // Manage product code codProdOrigen/codProdDestino
                manageProdCod(transaccion);

                // Manage subproduct code codSubprodOrigen/codSubprodDestino
                manageSubProdCod(transaccion);

                // Manage datosComunesTransaccion: valorTrnxDP, clientCurr, valorTrnxModDP
                manageValorTrnx(transaccion);

                // Manage datosComunesTransaccion idTrnx --> DP
                manageIdTrnx(transaccion);

                // Manage References ref4-ref5
                manageRefs(transaccion);

                //Método para validar que valor se ingresa en el nroCuentanroCuentaInterno
                manageProdInterno(transaccion);

                // Flag date UTC
                String flag = Common.getIfDateIsUTC(fechaRQO);
                transaccion.datosComunesTransaccion.setTranUTCFlag(flag);


                def validSegments = Segments.getTransSegms(transaccion);

                if(validSegments != null) {
                        HashMap transHash = Checks.checkFields(transaccion, validSegments, "transaccion");
                        Transaccion newTransaction = Common.hashMapToObject(transHash, Transaccion.class);
                        return newTransaction;
                }
                return null;
        }

        /**
         * Retorna si el tipo de subactividad entra en las excepciones de validación para
         * DP (origen) y BF (destino)
         * @param actSMH Tipo de actividad (BF, DP, ...)
         * @param actSubType Sub actividad (Retiro, Trnsf a Cta, ...)
         * @return
         */
        private static boolean getIfValidExceptionTranActType(String actSMH, String actSubType) {

                if(actSMH.equals("DP") && Arrays.asList(Segments.actTypeSMH_DPExceptions).contains(actSubType)) {
                        return true;
                }

                else if(actSMH.equals("BF") && Arrays.asList(Segments.actTypeSMH_BFExceptions).contains(actSubType)) {
                        return true;
                }

                return false;
        }

        /**
         * Get customer number value xqo_cust_num
         * @param transaccion
         */
        private static String getCustNum(Transaccion transaccion) {

                String actSMH = transaccion.originadorTransaccion.getSmhActivity();

                String custNum = null;

                if("BF".equals(actSMH) || "NM".equals(actSMH)) {

                        def tpoIdentOrigen = transaccion.datosPagador.tpoIdentOrigen.toString();
                        def nroIdentOrigen = transaccion.datosPagador.nroIdentOrigen;

                        custNum = tpoIdentOrigen + nroIdentOrigen;

                        if(tpoIdentOrigen == null || nroIdentOrigen == null) {
                                //throw new DaviplataException(222, "Null values: " + custNum);
                        }
                }

                else if("DP".equals(actSMH)) {

                        def tpoIdentDestino = transaccion.datosBeneficiario.tpoIdentDestino.toString();
                        def nroIdentDestino = transaccion.datosBeneficiario.nroIdentDestino;

                        custNum = tpoIdentDestino + nroIdentDestino;

                        if(tpoIdentDestino == null || tpoIdentDestino == null) {
                                //throw new DaviplataException(222, "Null values: " + custNum);
                        }

                }

                return custNum;
        }

        /**
         * Atts tpoIdentOrigen/tpoIdentDestino
         * @param transaccion
         */

        private static void manageIdentType(Transaccion transaccion) {

                String actSMH = transaccion.originadorTransaccion.getSmhActivity();

                def tpoIdentOrigen  = transaccion.datosPagador.tpoIdentOrigen;
                def tpoIdentDestino = transaccion.datosBeneficiario.tpoIdentDestino;

                if(actSMH.equals("BF") || actSMH.equals("NM")) {

                        transaccion.datosPagador.setTpoIdentOrigenPag(tpoIdentOrigen);          //Protagonista
                        transaccion.datosBeneficiario.setTpoIdentDestinoBen(tpoIdentDestino);

                        if(tpoIdentOrigen == null) {
                                //throw new DaviplataException(222, "Null values: tpoIdentOrigen");
                        }
                }

                else if(actSMH.equals("DP")) {

                        transaccion.datosPagador.setTpoIdentOrigenPag(tpoIdentDestino);         //Protagonista
                        transaccion.datosBeneficiario.setTpoIdentDestinoBen(tpoIdentOrigen);

                        if(tpoIdentDestino == null) {
                                //throw new DaviplataException(222, "Null values: tpoIdentDestino");
                        }
                }
                
        }

        /**
         * Atts nroIdentOrigen/nroIdentDestino
         * @param transaccion
         */
        private static void manageIdentNum(Transaccion transaccion) {

                String actSMH = transaccion.originadorTransaccion.getSmhActivity();

        		def nroIdentOrigen  = transaccion.datosPagador.nroIdentOrigen;
        		def nroIdentDestino = transaccion.datosBeneficiario.nroIdentDestino;

                if(actSMH.equals("BF") || actSMH.equals("NM")) {

                        transaccion.datosPagador.setNroIdentOrigenPag(nroIdentOrigen);
                        transaccion.datosBeneficiario.setNroIdentDestinoBen(nroIdentDestino);

                        if(nroIdentOrigen == null) {
                                //throw new DaviplataException(222, "Null values: tpoIdentOrigen");
                        }
                }

                else if(actSMH.equals("DP")) {

                        transaccion.datosPagador.setNroIdentOrigenPag(nroIdentDestino);
                        transaccion.datosBeneficiario.setNroIdentDestinoBen(nroIdentOrigen);

                        if(nroIdentDestino == null) {
                                //throw new DaviplataException(222, "Null values: tpoIdentDestino");
                        }
                }

        }

        /**
         * Atts nroProdDestino/nroProdOrigen
         * @param transaccion
         */
        private static void manageProdNum(Transaccion transaccion) {

                String actSMH = transaccion.originadorTransaccion.getSmhActivity();

                def nroProdOrigen  = transaccion.datosPagador.nroProdOrigen;
                def nroProdDestino = transaccion.datosBeneficiario.nroProdDestino;

                if(actSMH.equals("BF") || actSMH.equals("NM")) {

/*                        transaccion.datosPagador.setNroProdXQO(nroProdOrigen);
                        transaccion.datosBeneficiario.setNroProdTPP(nroProdDestino);  */
                        transaccion.datosPagador.setNroProdOrigenPag(nroProdOrigen);
                        transaccion.datosBeneficiario.setNroProdDestinoBen(nroProdDestino);

                        if(nroProdOrigen == null) {
                                //throw new DaviplataException(222, "Null values: nroProdOrigen");
                        }
                }

                else if(actSMH.equals("DP")) {

/*                        transaccion.datosPagador.setNroProdTPP(nroProdOrigen);
                        transaccion.datosBeneficiario.setNroProdXQO(nroProdDestino);       */
                        transaccion.datosPagador.setNroProdOrigenPag(nroProdDestino);
                        transaccion.datosBeneficiario.setNroProdDestinoBen(nroProdOrigen);

                        if(nroProdDestino == null) {
                                //throw new DaviplataException(222, "Null values: nroProdDestino");
                        }
                }
        }

        /**
         * Atts codProdOrigen/codProdDestino
         * @param transaccion
         */
        private static void manageProdCod(Transaccion transaccion) {

                String actSMH = transaccion.originadorTransaccion.getSmhActivity();

                def codProdOrigen  = transaccion.datosPagador.codProdOrigen;
                def codProdDestino = transaccion.datosBeneficiario.codProdDestino;

                if(actSMH.equals("BF") || actSMH.equals("NM")) {

                        transaccion.datosPagador.setCodProdOrigenPag(codProdOrigen);
                        transaccion.datosBeneficiario.setCodProdDestinoBen(codProdDestino);
/*
*                       if(codSubprodOrigen == null) {
*                               //throw new DaviplataException(222, "Null values: codSubprodOrigen");
*                       }
*/
                }

                else if(actSMH.equals("DP")) {

                        transaccion.datosBeneficiario.setCodProdDestinoBen(codProdOrigen);
                        transaccion.datosPagador.setCodProdOrigenPag(codProdDestino);
/*
*                       if(codSubprodDestino == null) {
*                               //throw new DaviplataException(222, "Null values: codSubprodDestino");
*                       }
*/
                }
        }

        /**
         * Atts codSubprodOrigen/codSubprodDestino
         * @param transaccion
         */
        private static void manageSubProdCod(Transaccion transaccion) {

                String actSMH = transaccion.originadorTransaccion.getSmhActivity();

                def codSubprodOrigen = transaccion.datosPagador.codSubprodOrigen;
                def codSubprodDestino = transaccion.datosBeneficiario.codSubprodDestino;

                if(actSMH.equals("BF") || actSMH.equals("NM")) {

                        transaccion.datosPagador.setCodSubprodOrigenPag(codSubprodOrigen);
                        transaccion.datosBeneficiario.setCodSubprodDestinoBen(codSubprodDestino);

                        if(codSubprodOrigen == null) {
                                //throw new DaviplataException(222, "Null values: codSubprodOrigen");
                        }
                }

                else if(actSMH.equals("DP")) {

                        transaccion.datosBeneficiario.setCodSubprodDestinoBen(codSubprodOrigen);
                        transaccion.datosPagador.setCodSubprodOrigenPag(codSubprodDestino);

                        if(codSubprodDestino == null) {
                                //throw new DaviplataException(222, "Null values: codSubprodDestino");
                        }
                }
        }

        private static void manageValorTrnx(Transaccion transaccion) {
                String actSMH = transaccion.originadorTransaccion.getSmhActivity();

                if(actSMH.equals("DP")) {
                        String valorTrnx = Common.setMaxTwoDec(transaccion.datosComunesTransaccion.valorTrnx).toString();

                        transaccion.datosComunesTransaccion.setValorTrnxDP(valorTrnx);
                        transaccion.datosComunesTransaccion.setClientCurr('170');
                        transaccion.datosComunesTransaccion.setValorTrnxModDP(valorTrnx);
                }
        }

        private static void manageIdTrnx(Transaccion transaccion) {
                String actSMH = transaccion.originadorTransaccion.getSmhActivity();

                if(actSMH.equals("DP")) {
                        transaccion.datosComunesTransaccion.setIdTrnxTDP(transaccion.datosComunesTransaccion.idTrnx);
                }
        }

        private static void manageRefs(Transaccion transaccion) {
                String activityType = transaccion.originadorTransaccion.getSmhActivity();

                if(activityType.equals("BF")) {
                        transaccion.referencias.setRefTotal(transaccion.referencias.getRef4());
                }
                else if(activityType.equals("DP")) {
                        transaccion.referencias.setRefTotal(transaccion.referencias.getRef5());
                }
        }

        public static String getDefaultTransactionCode(Transaccion transaccion) {

                // 82052029
                String codeDP = CodTrnx.DIS_CENIT.codTrnx;

                // 82102039
                String codeBF = CodTrnx.RET_CORRESP.codTrnx;

                try {
                        String activityType = transaccion.originadorTransaccion.codTrnx.actTypeSMH;

                        if(activityType.equals("DP")) {
                                return codeDP;
                        }

                        else if(activityType.equals("BF") || activityType.equals("NM")) {
                                return codeBF;
                        }

                        return codeDP;
                }
                catch(Exception e) {
                        return codeDP;
                }
        }

        /**
         * Atts nroCuentaInterno/nroProdInterno
         * @param transaccion
         */
        private static void manageProdInterno(Transaccion transaccion) {
                // Cargar el archivo properties
                Properties properties = new Properties()
                FileInputStream input = null
                try {
                        input = new FileInputStream("/opt/sas/viya/config/etc/boss/daviplata/config.properties")
                        properties.load(input)
                } catch (IOException e) {
                        logger.error("Error loading properties file daviplata - config.properties", e)
                } finally {
                        if (input != null) {
                                try {
                                        input.close()
                                } catch (IOException e) {
                                        logger.error("Error closing properties file daviplata - config.properties", e)
                                }
                        }
                }

                // Recuperar el valor del properties y dividirlo por pipe
                String codTrnValues = properties.getProperty("codTrnValues")
                List<String> codTrnList = codTrnValues?.split("\\|")?.toList() ?: []
                logger.info("Método manageProdInterno - Lista de códigos de transacción: " + codTrnList)

                // Obtener el código de transacción
                String codTrn = transaccion.originadorTransaccion.codTrnx.codTrnx
                logger.info("Método manageProdInterno - Codigo de transacción: " + codTrn)

                // Comparar con los valores cargados desde el properties
                if (codTrnList.contains(codTrn)) {
                        logger.info("codTrn matches one of the values from properties")
                        // Realizar alguna acción si codTrn coincide con uno de los valores del properties
                        transaccion.datosPagador.setNroCuentaInterno(transaccion.datosPagador.nroProdInterno)
                        logger.info("Se actualiza el valor de nroCuentaInterno con el valor de producto interno: " + transaccion.datosPagador.nroProdInterno)
                } else {
                        logger.info("codTrn does not match any of the values from properties")
                        // Realizar alguna acción si codTrn no coincide con ninguno de los valores del properties
                        transaccion.datosPagador.setNroCuentaInterno(transaccion.datosPagador.nroCuentaInterno)
                        logger.info("Se actualiza el valor de nroCuentaInterno con el valor de número de cuenta: " + transaccion.datosPagador.nroCuentaInterno)                        
                }
        }

}
