package daviplata.groovy.tools;

import com.google.gson.Gson
import com.google.gson.GsonBuilder;

import daviplata.groovy.tools.deserializers.DateDeserializer;

public class GsonBuilderFormat {
	
	public static Gson getGson() {
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.registerTypeAdapter(Date.class, new DateDeserializer());
		
		return gsonBuilder.setPrettyPrinting().serializeNulls().create();
	}
}
