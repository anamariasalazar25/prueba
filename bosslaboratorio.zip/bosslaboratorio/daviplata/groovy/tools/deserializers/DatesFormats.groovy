package daviplata.groovy.tools.deserializers;

import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.validator.GenericValidator;

import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.text.ParseException;

public class DatesFormats {
	
	//general format: yyyyMMddHHmmss
	private static final ALL_FORMATS = [
		"yyyyMMddHHmmss",
		"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
		"yyyy-MM-dd'T'HH:mm:ss'Z'",   
		"yyyy-MM-dd'T'HH:mm:ssZ",
		"yyyy-MM-dd'T'HH:mm:ss",      
		"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
		"yyyy-MM-dd'T'HH:mm:ss.SSSZ", 
		"yyyy-MM-dd HH:mm:ss",
		"MM/dd/yyyy HH:mm:ss",        
		"MM/dd/yyyy'T'HH:mm:ss.SSS'Z'",
		"MM/dd/yyyy'T'HH:mm:ss.SSSZ", 
		"MM/dd/yyyy'T'HH:mm:ss.SSS",
		"MM/dd/yyyy'T'HH:mm:ssZ",     
		"MM/dd/yyyy'T'HH:mm:ss",
		"yyyy:MM:dd HH:mm:ss",        
		"yyyyMMdd"
	];
	
	// UTC
	public static String BASIC_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	
	public static String DATE_TIME_FORMAT_A = "yyyyMMddHH:mm:ss";
	
	public static String DATE_FORMAT_A = "yyyyMMdd";
	
	public static String TIME_FORMAT_A = "HH:mm:ss";
	
	/**
	 * Se cambia el formato de una fecha
	 * @param newFormat Nuevo formato
	 * @param date Fecha (tipo Date)
	 * @return Fecha con el nuevo formato
	 */
	public static String changeDateFormat(String newFormat, Date date) {
		if(date != null) {
			DateFormat sdf = new SimpleDateFormat(newFormat);
			return sdf.format(date);
		}
		
		return null;
	}
	
	/**
	 * Se cambia el formato de una fecha
	 * @param newFormat Nuevo formato
	 * @param dateString Fecha (tipo String)
	 * @return Fecha con el nuevo formato
	 */
	public static String changeDateFormat(String newFormat, String dateString) {
		
		String generalFormat = ALL_FORMATS.get(0);
		
		if(dateString != null && getIfDateIsValid(generalFormat, dateString)) {
			
			DateFormat sdf = new SimpleDateFormat(generalFormat, Locale.ENGLISH);
			Date parsedDate = sdf.parse(dateString);
						
			return changeDateFormat(newFormat, parsedDate);
		}
		
		return null;
	}
	
	/**
	 * Se obtiene el formato de una fecha
	 * @param date Fecha
	 * @return Formato de la fecha
	 */
	public static String getDateFormat(String date) {
		if (date != null) {
			for (String format : ALL_FORMATS) {
				SimpleDateFormat sdf = new SimpleDateFormat(format);
				try {
					sdf.parse(date);
					return format;
				}
				catch (ParseException e) {
					// Do nothing
				}
			}
		}
		return null;
	}
	
	/**
	 * Verifica que una fecha sea válida
	 * @param format Formato de la fecha
	 * @param dateString Fecha
	 * @return true si es válida, false en caso contrario
	 */
	public static boolean getIfDateIsValid(String format, String dateString) {
		return GenericValidator.isDate(dateString, format, true);
	}
}





