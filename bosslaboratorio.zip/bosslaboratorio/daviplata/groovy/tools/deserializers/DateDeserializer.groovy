package daviplata.groovy.tools.deserializers;

import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

import daviplata.groovy.tools.deserializers.DatesFormats;

public class DateDeserializer implements JsonDeserializer<Date> {
	
	public DateDeserializer() {}
	
	@Override
	public Date deserialize(JsonElement element, Type arg1, JsonDeserializationContext arg2) throws JsonParseException {

     String date = element.getAsString();

      SimpleDateFormat format = new SimpleDateFormat(DatesFormats.getDateFormat(date));

		try {
			return format.parse(date);
		} 
		catch (ParseException exp) {

			return null;
		}
	}
}
