package xams.groovy.model

import com.fasterxml.jackson.annotation.JsonInclude;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@JsonInclude(JsonInclude.Include.NON_NULL)
@XmlRootElement(name = "rule")
@XmlAccessorType(XmlAccessType.FIELD)
class Rule {
    String id;
    String version;
    String name;
    String reason;

    @Override
    public String toString() {
        return "Rule{" +
                "id='" + id + '\'' +
                ", version='" + version + '\'' +
                ", name='" + name + '\'' +
                ", reason='" + reason + '\'' +
                '}';
    }
}
