package xams.groovy.model

import javax.xml.bind.annotation.XmlAccessType
import javax.xml.bind.annotation.XmlAccessorType
import javax.xml.bind.annotation.XmlElement
import javax.xml.bind.annotation.XmlRootElement

@XmlRootElement(name = "dataItem")
@XmlAccessorType(XmlAccessType.FIELD)
class DataItem {
	@XmlElement
	String name
	
	@XmlElement
	String value

	DataItem() {}

	DataItem(String name, String value) {
		this.name = name
		this.value = value
	}

	@Override
	public String toString() {
		return "DataItem{" +
				"name='" + name + '\'' +
				", value='" + value + '\'' +
				'}'
	}
}
