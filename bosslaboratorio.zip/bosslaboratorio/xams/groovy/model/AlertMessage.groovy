package xams.groovy.model

import com.fasterxml.jackson.annotation.JsonInclude
import javax.xml.bind.annotation.XmlAccessType
import javax.xml.bind.annotation.XmlAccessorType
import javax.xml.bind.annotation.XmlElementWrapper
import javax.xml.bind.annotation.XmlElement
import javax.xml.bind.annotation.XmlRootElement

@JsonInclude(JsonInclude.Include.NON_NULL)
@XmlRootElement(name = "alert")
@XmlAccessorType(XmlAccessType.FIELD)
class AlertMessage {

	String type
	String entityID
	String acctNumber
	String custNumber
	String createTimestamp
	String multiOrg
	String transactionID
	String accountType
	String activityType
	String timestamp
	String amount
	String fraudScore
	String tableName

	@XmlElementWrapper(name = "firedRules")
	@XmlElement(name = "rule")
	List<Rule> firedRules = []

	@XmlElementWrapper(name = "customData")
	@XmlElement(name = "dataItem")
	List<DataItem> customData = []

	AlertMessage() {}

	String getType() {
		return type
	}

	void setType(String type) {
		this.type = type
	}

	String getEntityID() {
		return entityID
	}

	void setEntityID(String entityID) {
		this.entityID = entityID
	}

	String getCustNumber() {
		return custNumber
	}

	void setCustNumber(String custNumber) {
		this.custNumber = custNumber
	}

	String getCreateTimestamp() {
		return createTimestamp
	}

	void setCreateTimestamp(String createTimestamp) {
		this.createTimestamp = createTimestamp
	}

	String getMultiOrg() {
		return multiOrg
	}

	void setMultiOrg(String multiOrg) {
		this.multiOrg = multiOrg
	}

	String getTransactionID() {
		return transactionID
	}

	void setTransactionID(String transactionID) {
		this.transactionID = transactionID
	}

	String getAccountType() {
		return accountType
	}

	void setAccountType(String accountType) {
		this.accountType = accountType
	}

	String getActivityType() {
		return activityType
	}

	void setActivityType(String activityType) {
		this.activityType = activityType
	}

	String getTimestamp() {
		return timestamp
	}

	void setTimestamp(String timestamp) {
		this.timestamp = timestamp
	}

	String getAmount() {
		return amount
	}

	void setAmount(String amount) {
		this.amount = amount
	}

	String getFraudScore() {
		return fraudScore
	}

	void setFraudScore(String fraudScore) {
		this.fraudScore = fraudScore
	}

	List<DataItem> getCustomData() {
		return customData
	}

	void setCustomData(List<DataItem> customData) {
		this.customData = customData
	}

	String getAcctNumber() {
		return acctNumber
	}

	void setAcctNumber(String acctNumber) {
		this.acctNumber = acctNumber
	}

	List<Rule> getFiredRules() {
		return firedRules
	}

	void setFiredRules(List<Rule> firedRules) {
		this.firedRules = firedRules
	}

	String getTableName() {
		return tableName
	}

	void setTableName(String tableName) {
		this.tableName = tableName
	}


	@Override
	public String toString() {
		return "AlertMessage{" +
				"type='" + type + '\'' +
				", entityID='" + entityID + '\'' +
				", acctNumber='" + acctNumber + '\'' +
				", custNumber='" + custNumber + '\'' +
				", createTimestamp='" + createTimestamp + '\'' +
				", multiOrg='" + multiOrg + '\'' +
				", transactionID='" + transactionID + '\'' +
				", accountType='" + accountType + '\'' +
				", activityType='" + activityType + '\'' +
				", timestamp='" + timestamp + '\'' +
				", amount='" + amount + '\'' +
				", fraudScore='" + fraudScore + '\'' +
				", tableName='" + tableName + '\'' +
				", firedRules=" + firedRules +
				", customData=" + customData +
				'}';
	}
}
