package xams.groovy.processor

import com.fasterxml.jackson.dataformat.xml.XmlMapper
import org.apache.camel.Exchange
import org.apache.camel.Processor
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import xams.groovy.model.AlertMessage
import xams.groovy.model.DataItem

import java.util.function.Predicate
import java.util.stream.Collectors
import java.util.*;

import com.sas.davivienda.efm.commons.util.FMUtils;

class XMLToAlertProcessor implements Processor{

    private static final Logger logger = LoggerFactory.getLogger("XMLToAlertProcessor");
    @Override
    void process(Exchange exchange) throws Exception {
        try{
            def xmlBody = exchange.getIn().getBody(String.class);
            def xmlMapper = new XmlMapper()
            def alertMessage = xmlMapper.readValue(xmlBody, AlertMessage);
            List<DataItem> customData = alertMessage.getCustomData();

            StringBuilder sbAlertInfo = new StringBuilder();

            def customDataMap = customData.collectEntries { item -> [item.name, item.value] }

            def rrfRuleId = customDataMap.get("rrfRuleId");
            int rrfRuleIdInt = FMUtils.hasValue(rrfRuleId) ? Integer.valueOf(rrfRuleId) : 0;

            def cqfAlertXId = customDataMap.get("cqfAlertXId");

            sbAlertInfo.append("cmx-tran-id: ").append(alertMessage.getTransactionID())
                    .append(" tran-type: ").append(alertMessage.getAccountType()).append(alertMessage.getActivityType())
                    .append(" alert-id: ").append(cqfAlertXId)
                    .append(" createTimestamp: ").append(alertMessage.getCreateTimestamp())

            logger.info("xams-req: {}",sbAlertInfo);

            def cqfRuleXId = customDataMap.get("cqfRuleXId");
            int cqfRuleXIdInt = FMUtils.hasValue(cqfRuleXId) ? Integer.valueOf(cqfRuleXId) : 0;

            def rrfRuleVersion = customDataMap.get("rrfRuleVersion");
            int rrfRuleVersionInt = FMUtils.hasValue(rrfRuleVersion) ? Integer.valueOf(rrfRuleVersion) : 0;

            def cqfRuleVersionXNbr = customDataMap.get("cqfRuleVersionXNbr");
            int cqfRuleVersionXNbrInt = FMUtils.hasValue(cqfRuleVersionXNbr) ? Integer.valueOf(cqfRuleVersionXNbr) : 0;

            exchange.getIn().setHeader("mostRestrictiveRuleId",rrfRuleIdInt);
            exchange.getIn().setHeader("highestPriorityRuleId",cqfRuleXIdInt);
            exchange.getIn().setHeader("mostRestrictiveRuleVNbr",rrfRuleVersionInt);
            exchange.getIn().setHeader("highestPriorityRuleVNbr",cqfRuleVersionXNbrInt);

            customDataMap.remove("rrfRuleId");
            customDataMap.remove("cqfRuleXId");

            exchange.setProperty("alertMessage",alertMessage);
            exchange.setProperty("customDataMap",customDataMap);
        }catch (Exception e){
            e.printStackTrace();
            throw new com.sas.davivienda.efm.commons.exceptions.EFMException(e.getMessage());
        }
    }
}