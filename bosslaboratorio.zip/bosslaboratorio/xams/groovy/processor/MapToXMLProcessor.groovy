package xams.groovy.processor

import groovy.xml.MarkupBuilder
import org.apache.camel.Exchange
import org.apache.camel.Processor

class MapToXMLProcessor implements Processor{
    @Override
    void process(Exchange exchange) throws Exception {
        def alertResultSet = exchange.getIn().getBody();
        exchange.getIn().setBody(mapToXMLString(alertResultSet));
    }

    public String mapToXMLString(Map alertMap){
        def xmlString = new StringWriter().with { stringWriter ->
            new MarkupBuilder(stringWriter).with {
                alert {
                    alertMap.collect { key, value ->
                        "$key" {
                            if (value instanceof Map) {
                                value.collect(owner)
                            } else {
                                mkp.yield(value)
                            }
                        }
                    }
                }
            }
            stringWriter.toString()
        }
        return xmlString;
    }
}
