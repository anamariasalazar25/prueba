package xams.groovy.processor

import com.google.gson.Gson
import java.util.Calendar
import java.util.TimeZone
import java.text.SimpleDateFormat
import java.text.ParseException
import org.apache.camel.Exchange
import org.apache.camel.Processor
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import xams.groovy.model.AlertMessage
import xams.groovy.model.DataItem

class JSONProcessor implements Processor{

    private static final Logger logger = LoggerFactory.getLogger("xamslog");
    @Override
    void process(Exchange exchange) throws Exception {
        try{
            def alertMessage = exchange.getProperty("alertMessage");
            def customDataMap = exchange.getProperty("customDataMap", Map.class);
            def mostRestrictiveRuleResultset = exchange.getProperty("mostRestrictiveRuleResultset");
            def highestPriorityRuleResultset = exchange.getProperty("highestPriorityRuleResultset");
            def mostRestrictiveRuleId = exchange.getIn().getHeader("mostRestrictiveRuleId");
            def highestPriorityRuleId = exchange.getIn().getHeader("highestPriorityRuleId");

            customDataMap.put("mostRestrictiveRuleId",mostRestrictiveRuleId.toString());
            customDataMap.put("highestPriorityRuleId",highestPriorityRuleId.toString());
			customDataMap.put("acctNumber",alertMessage.getAcctNumber());

            if(mostRestrictiveRuleResultset != null){
                customDataMap.put("mostRestrictiveRuleName",mostRestrictiveRuleResultset);
            }

            if(highestPriorityRuleResultset != null){
                customDataMap.put("highestPriorityRuleName",((Map) highestPriorityRuleResultset).get("RULE_NAME"));
                customDataMap.put("highestPriorityQueueId",((Map) highestPriorityRuleResultset).get("QUEUE_ID").toString());
                customDataMap.put("highestPriorityQueueName",((Map) highestPriorityRuleResultset).get("QUEUE_NAME"));
                customDataMap.put("highestPriorityStrategyId",((Map) highestPriorityRuleResultset).get("STRATEGY_ID").toString());
                customDataMap.put("highestPriorityStrategyName",((Map) highestPriorityRuleResultset).get("STRATEGY_NAME"));
            }
			
			try {
                String rqoProcUtc= customDataMap.get("rqoProcUtcDatetime");
	            if (rqoProcUtc.length() > 15) {
	                // Caso reto fallido "yyyy-MM-dd HH:mm:ss.SS"
	                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
	                inputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
	                Calendar calendar = Calendar.getInstance();
	                calendar.setTime(inputFormat.parse(rqoProcUtc));
	                SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	                outputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
	                customDataMap.put("rqoProcUtcDatetime", outputFormat.format(calendar.getTime()));
	            } else {
	                // Caso Fecha en segundos
	                double fechaD = Double.parseDouble(rqoProcUtc);
	                Calendar calendar = Calendar.getInstance();
	                calendar.setTimeInMillis((long) (fechaD * 1000));
	                calendar.add(Calendar.YEAR, -10);
	                SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	                outputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
                    customDataMap.put("rqoProcUtcDatetime", outputFormat.format(calendar.getTime()));
	            }
	        } catch (ParseException e) {
	            e.printStackTrace();
	        }

            List<DataItem> customDataN = customDataMap.collect { k, v -> new DataItem (k,v) };

            alertMessage.setCustomData(customDataN);

            Gson gson = new Gson();
			
			 // alertMessage to Map, remove tableName
            Map<String, Object> alertMessageMap = gson.fromJson(gson.toJson(alertMessage), Map.class);
            alertMessageMap.remove("tableName");
			alertMessageMap.remove("acctNumber");

            //Estructura Json a F5
			Map<String,Object> request = new HashMap<>();
			Map<String,Object> value = new HashMap<>();
			value.put("type", "JSON");
			value.put("data", alertMessageMap);			
			request.put("value", value);
			String alertMessageJson = gson.toJson(request);			
			
            //String alertMessageJson = gson.toJson(alertMessage);
            exchange.getIn().setBody(alertMessageJson);
        }catch (Exception e){
            e.printStackTrace();
            throw new com.sas.davivienda.efm.commons.exceptions.EFMException(e.getMessage());
        }

    }
}
