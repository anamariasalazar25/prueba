package virtualChannels.groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.fasterxml.jackson.dataformat.xml.XmlMapper
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;

import virtualChannels.groovy.tools.GsonBuilderFormat;

import java.util.Map;
import org.json.JSONObject;
import xams.groovy.model.AlertMessage;
import xams.groovy.model.DataItem;

import javax.xml.bind.JAXBContext
import javax.xml.bind.JAXBException
import javax.xml.bind.Marshaller
import java.io.StringWriter

public class JsonToMapProcessor implements Processor{

	private static final Logger logger = LoggerFactory.getLogger("xamslog");
	
	public void process(Exchange exchange) throws Exception {
		try{
			Gson gson = GsonBuilderFormat.getGson();
			AlertMessage message = new AlertMessage();
			List<DataItem> dataItem = new ArrayList<>();

			//Extracción de información 'almacenada' previo al Processor
			String alertBodyResponse = exchange.getProperty("alertMessageResponse",String.class);
			String transactionType = exchange.getProperty("transactionType",String.class);
			String transactionId = exchange.getIn().getHeader("transactionId", String.class);

			//Body y Property a MAP
			Map<String, String> queryMap = exchange.getIn().getBody(Map.class);
			Map<String, String> jsonAlertMap = gson.fromJson(alertBodyResponse, Map.class);

			def alertId = jsonAlertMap.get("id");
			exchange.setProperty("alertId", alertId);

			message.setType("X");
			message.setTransactionID(transactionId);
			message.setAccountType(transactionType.substring(0, 2));
			message.setActivityType(transactionType.substring(2, 4));
			message.setMultiOrg(jsonAlertMap.get("multiOrgName"));
			message.setCreateTimestamp(jsonAlertMap.get("createTimestamp"));
			message.setTimestamp(jsonAlertMap.get("createTimestamp"));

			for (Map.Entry<String, String> entry : queryMap.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				if (key.equals("XQO_CUST_NUM")){
					String entityId = value;
					message.setCustNumber(entityId);
					message.setEntityID(entityId);
				} else if (key.equals("RRR_SCORE_1")) {
					message.setFraudScore(value);
				} else if (key.equals("CMX_CLIENT_AMT")) {
					message.setAmount(value);
				}else {
					dataItem.add(new DataItem(key, value));
				}
				
			}
			message.setCustomData(dataItem);
			
			// Convertir el objeto AlertMessage a XML
			def xmlString = convertirAXml(message);

			exchange.getIn().setBody(xmlString);
		}catch (Exception e){
			e.printStackTrace();
			throw new com.sas.davivienda.efm.commons.exceptions.EFMException(e.getMessage());
		}
	}
	
	String convertirAXml(AlertMessage alertMessage) {
		try {
			// Crear el contexto JAXB
			def contexto = JAXBContext.newInstance(AlertMessage.class)

			// Crear el marshaller
			def marshaller = contexto.createMarshaller()
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true)

			// Escribir los datos en un StringWriter
			def stringWriter = new StringWriter()
			marshaller.marshal(alertMessage, stringWriter)

			// Obtener el XML como String
			return stringWriter.toString()
		} catch (JAXBException e) {
			e.printStackTrace()
			return null
		}
	}
	
}