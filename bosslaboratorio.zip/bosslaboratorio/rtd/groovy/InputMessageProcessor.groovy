package com.fadosol.integration.groovy
import javax.xml.soap.MessageFactory
import javax.xml.soap.SOAPConstants
import javax.xml.soap.SOAPMessage
import javax.xml.ws.Holder

import org.apache.camel.Exchange
import org.apache.camel.Processor
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.sas.davivienda.homologaciones.HomologacionesUtil

class IndividualCustomerProcessor implements Processor {
	
	private static final Logger logger = LoggerFactory.getLogger("rtdlog");
	HomologacionesUtil homologaciones = new HomologacionesUtil();
	
	@Override
	public void process(Exchange exchange) throws Exception {
		
		Map<String,String> inputMap = exchange.getIn().getBody();
		
		String idNumber = "";
		String idType = "";
		
		try {
			logger.info("response: {}",inputMap);

			String entityType = inputMap.get("/entityRequest/@entityType");
			String customerId = "X".equals(entityType) ? inputMap.get("/entityRequest/entityID") : inputMap.get("/entityRequest/contactID");
			String custId = customerId;

			if(customerId != null && customerId.length() >= 3){
				custId = customerId.substring(0,2).concat("*****").concat(customerId.substring(customerId.length()-4));

				idType = customerId.substring(0, 2);
				idNumber = customerId.substring(2);

				exchange.setProperty("idType", idType);
				exchange.setProperty("idNumber", idNumber);
				exchange.getIn().setBody(inputMap);
			}else{
				logger.info("ERR datos de cliente indeterminados: {}", customerId);
				exchange.getIn().setBody(null);
			}

			String txMsg = " entityType:".concat(entityType).concat(", customerId:").concat(custId);
			
			exchange.setProperty("msgInfoLog",txMsg);
			
		}catch(Exception ex) {
			logger.error(ex.getMessage());
		}
	}
	
}
