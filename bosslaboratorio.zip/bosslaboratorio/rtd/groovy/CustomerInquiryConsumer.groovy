package com.fadosol.integration.groovy
import javax.xml.soap.MessageFactory
import javax.xml.soap.SOAPConstants
import javax.xml.soap.SOAPMessage

import org.apache.camel.Exchange
import org.apache.camel.Processor
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class CustomerInquiryConsumer implements Processor {

	private static final Logger logger = LoggerFactory.getLogger("rtdlog");
	
	@Override
	public void process(Exchange exchange) throws Exception {
		
		String request = exchange.getIn().getBody();
		String endpoint = exchange.getIn().getHeader("endpoint");

		//logger.info("endpoint: {}, request:{}", endpoint, request);
		
		try {
			MessageFactory messageFactory = MessageFactory.newInstance(SOAPConstants.SOAP_1_1_PROTOCOL);
			InputStream inputStream = new ByteArrayInputStream(request.bytes)
			SOAPMessage message = messageFactory.createMessage(null, inputStream);
			Object response = executorConnection(message, endpoint);
			exchange.getIn().setBody(response);
		}catch(Exception ex) {
			logger.error(ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	public String executorConnection(SOAPMessage request, String endpoint) {
		
		def URLConnection connection = null;
		def server = new URL(endpoint);
				
		connection = (HttpURLConnection) server.openConnection();
		
		connection.setRequestProperty(Exchange.CONTENT_TYPE, "text/xml; charset=utf-8");
		connection.setRequestProperty(Exchange.SOAP_ACTION,"");
		connection.setDoOutput(true);
		
		OutputStream reqStream = connection.getOutputStream();

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		request.writeTo(out);
		reqStream.write(out.toByteArray());
		reqStream.flush();
		
		String responseCode = connection.responseCode; 
		
		if (responseCode.startsWith("2")) {
			
			java.io.BufferedReader rd = new java.io.BufferedReader(new java.io.InputStreamReader(connection.getInputStream()));
			String line;
			String response="";
			
			while ((line = rd.readLine()) != null) {
				response = response + line + "\r\n";
			}
			
			return response;
		} else {
			 throw new Exception("Error - "  + responseCode  + " - " + connection.responseMessage);
		}
	}
}