package com.fadosol.integration.groovy
import javax.xml.soap.MessageFactory
import javax.xml.soap.SOAPConstants
import javax.xml.soap.SOAPMessage
import javax.xml.ws.Holder

import org.apache.camel.Exchange
import org.apache.camel.Processor
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import com.sas.davivienda.homologaciones.HomologacionesUtil

class IndividualCustomerProcessor implements Processor {
	
	private static final Logger logger = LoggerFactory.getLogger("rtdlog");
	HomologacionesUtil homologaciones = new HomologacionesUtil();
	
	@Override
	public void process(Exchange exchange) throws Exception {
		
		try {
			String idType = exchange.getProperty("idType");
			String idNumber = exchange.getProperty("idNumber");
			
			//logger.info("BusinessProcessor - idType:{},idNumber:{}",idType,idNumber,idNumber);
			
			exchange.getIn().setBody(getRequest(idType,idNumber));
		}catch(Exception ex) {
			logger.error(ex.getMessage());
			ex.printStackTrace();
		}
	}

	public String getRequest(String idType, String idNumber) {
		
		StringBuilder request = new StringBuilder();
		request.append("<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">\n")
				.append("   <env:Header>\n")
				.append("   </env:Header>\n")
				.append("   <S:Body>\n")
				.append("      <con:consultarClientePNV3 xmlns:con=\"http://www.davivienda.com/xml/ConsultaClientePNV3\">\n")
				.append("         <Request>\n")
				.append("            <DataHeader>\n")
				.append("               <nombreOperacion>")	.append(HEADER_NOMBRE_OPERACION)	.append("</nombreOperacion>\n")
				.append("               <total>")			.append(HEADER_TOTAL)				.append("</total>\n")
				.append("               <jornada>")			.append(HEADER_JORNADA)				.append("</jornada>\n")
				.append("               <canal>")			.append(HEADER_CANAL)				.append("</canal>\n")
				.append("               <modoDeOperacion>") .append(HEADER_MODO_OPERACION)		.append("</modoDeOperacion>\n")
				.append("               <usuario>") 		.append(HEADER_USUARIO) 			.append("</usuario>\n")
				.append("               <perfil>")			.append(HEADER_PERFIL)				.append("</perfil>\n")
				.append("               <versionServicio>") .append(HEADER_VERSION_SERVICIO) 	.append("</versionServicio>\n")
				.append("               <idTransaccion>")	.append(HEADER_ID_TRANSACCION) 		.append("</idTransaccion>\n")
				.append("            </DataHeader>\n")
				.append("            <Data>\n")
				.append("               <numeroId>"+idNumber+"</numeroId>\n")
				.append("               <tipoId>"+idType+"</tipoId>\n")
				.append("            </Data>\n")
				.append("         </Request>\n")
				.append("      </con:consultarClientePNV3>\n")
				.append("   </S:Body>\n")
				.append("</S:Envelope>\n");
		
		return request;
	}
	
	public void procesWebServiceResponse(Exchange exchange) {
		
		String response = exchange.getIn().getHeader("wsResponse");
		Map<String,String> demographicMap = exchange.getProperty("mapBody");
		initVariables();
        boolean notFoundInIndividual = false;
        try{		
			def completeXml = new XmlSlurper().parseText(response);
		
			if (completeXml instanceof groovy.util.slurpersupport.GPathResult) {
				
				header_nombreOperacion		= completeXml.Body.consultarClientePNV3Response.Response.DataHeader.nombreOperacion.text();
				header_caracterAceptacion	= completeXml.Body.consultarClientePNV3Response.Response.DataHeader.caracterAceptacion.text();
				header_codMsgRespuesta		= completeXml.Body.consultarClientePNV3Response.Response.DataHeader.codMsgRespuesta.text();
				
				String msgInfoLog = exchange.getProperty("msgInfoLog");
				logger.info("operacion:{}, caracterAceptacion:{}, codMsgRespuesta:{}, input:{}",header_nombreOperacion, header_caracterAceptacion,header_codMsgRespuesta, msgInfoLog);

				if("B".equals(header_caracterAceptacion) && completeXml.Body.consultarClientePNV3Response.Response.Data.datos_PN.cliente.nroIdentificacionCLI != null) {
					getValuesFromXML(completeXml);
				}else {
					notFoundInIndividual = true;
					exchange.getIn().setBody(null);
				}
			}else {
				logger.error("ERR- Error al procesar respuesta consultaPN");	
			}
		}catch(Exception e) {
			logger.error("ERR - INDDemographicsPN - {}", e.getMessage());
			exchange.getIn().setBody(null);
		}finally {
			exchange.getIn().setHeader("notFoundInIndividual", notFoundInIndividual);
			setMapValues(demographicMap);
			exchange.getIn().setBody(demographicMap);
		}
	}
	
	public void getValuesFromXML(Object completeXml) {
		
		def datos_pn = completeXml.Body.consultarClientePNV3Response.Response.Data.datos_PN;
		def datos_cliente = datos_pn.cliente;
		
		obtenerValoresDeDirecciones(datos_pn.direcciones.direccion.toList());
		obtenerValoresDeTelefonos(datos_pn.telefonos.telefono.toList());
		obtenerValoresDeCelulares(datos_pn.celulares.celular.toList());
		obtenerValoresDeEmails(datos_pn.emails.email.toList());
		obtenerValoresDeRelaciones(datos_pn.relaciones.relacion.toList());
		obtenerValoresDeActLaborales(datos_pn.actLaborales.actLaboral.toList());
		obtenerValoresDeEmpleos(datos_pn.empleos.empleo.toList());
		obtenerValoresDeIngresos(datos_pn.ingresos.ingreso.toList());
		
		//CLIENTE
		CON_FULLNAME = formatearValor(datos_cliente.nombresCLI.toString() +" "+ datos_cliente.primerApellidoCLI.toString() +" "+ datos_cliente.segundoApellidoCLI.toString());
		//regla 228
		//DEM_ACTIVIDAD_ECONOMICA = datosPN.getData().getDatosPN().getCliente().getActividadLaboralCLI();
		// regla 241
		DEM_CLIENTE_DAVIVALORES = formatearValor(datos_cliente.clienteDavivaloresCLI.toString());
		//regla 245
		DEM_FECHA_VINCULACION = formatearValor(datos_cliente.fechaVinculacionCLI.toString());
		//regla 246
		DEM_IND_PERSONA_NATURAL_NEGOCIO = formatearValor(datos_cliente.indicadorPNCNCLI.toString());
		//regla 248
		DEM_MANEJA_RECURSOS_PUBLICOS = formatearValor(datos_cliente.manejaRecursosPublCLI.toString());
		//regla 254
		DEM_SEGMENTO_COLOR = formatearValor(datos_cliente.segmentoColorCLI.toString());
		//regla 290
		DEM_GOZA_DE_RECONOCIMIENTO_PUBLICO = formatearValor(datos_cliente.reconocimientoPublicoCLI.toString());
		//regla 292
		DEM_INDIC_EXISTENCIA = formatearValor(datos_cliente.indicadorExistenciaCLI.toString());
		//regla 301
		DEM_NACIONALIDAD = homologaciones.obtenerPaises(datos_cliente.nacionalidadCLI.toString());
		//regla 310
		DEM_PAIS_DE_NACIMIENTO = homologaciones.obtenerPaises(datos_cliente.paisNacimientoCLI.toString());
		//regla 315
		DEM_SALUDO = formatearValor(datos_cliente.saludoCLI.toString());
		//regla 316
		DEM_SEXO = homologaciones.obtenerSexo(datos_cliente.sexoCLI.toString());
		//regla 589
		DEM_ACCIONISTA_DAVIVIENDA = formatearValor(datos_cliente.accionistaDaviviendaCLI.toString());
		//regla 600
		DEM_CLIENTE_PEPS = formatearValor(datos_cliente.clientePEPSCLI.toString());
		//regla 639
		DEM_INDICADOR_CLIENTE_ESTABLECIMI = formatearValor(datos_cliente.indClienteEstablecimCLI.toString());
		//regla 579
		DEM_SEGMENTO_COMERCIAL = formatearValor(homologaciones.obtenerSegmentosPN(datos_cliente.segmentoComercialCLI.toString()));
		//regla 255
		DEM_SUBSEGMENTO_COMERCIAL = formatearValor(homologaciones.obtenerSubsegmentoPN(datos_cliente.subsegmentoComercialCLI.toString()));
		
		//VERIFICACION
		//regla 244
		VER_FECHA_EXPEDICION = formatearValor(datos_cliente.fechaExpedicionCLI.toString());
		//regla 282
		VER_ESTADO_CIVIL = formatearValor(homologaciones.obtenerEstadoCivil(datos_cliente.estadoCivilCLI.toString()));
		//regla 285
		VER_FECHA_NACIMIENTO = formatearValor(datos_cliente.fechaNacimientoCLI.toString());
		//regla 296
		VER_LUGAR_EXPEDICION = formatearValor(homologaciones.obtenerCiudad(datos_cliente.lugarExpedicionCLI.toString()));
		//regla 297
		VER_LUGAR_NACIMIENTO =  formatearValor(homologaciones.obtenerCiudad(datos_cliente.lugarNacimientoCLI.toString()));
		//regla 563
		VER_OFICINA_RADICACION = formatearValor(datos_cliente.oficinaRadicacionCLI.toString());
		//regla 563
		VER_FECHA_VINCULACION = formatearValor(datos_cliente.fechaVinculacionCLI.toString());
		//regla 621
		VER_FECHA_ACTUALIZACION_DATOS = formatearValor(datos_cliente.fechaActInformacionClienteCLI.toString());
		//regla 632
		VER_HORA_ACTUALIZACION_DATOS = formatearValor(datos_cliente.fechaActInformacionClienteCLI.toString());
		//regla 261
		VER_TIPO_IDENTIFICACION = formatearValor(datos_cliente.tipoIdentificacionCLI.toString());

	}
	
	public void obtenerValoresDeDirecciones(Object direcciones) {
		
		//logger.info("data_direcciones:{}",direcciones);
		for(Object direccion: direcciones) {
			String direccionPrincipal = direccion.direccionPrincipalDI.toString();
			String codTipoDireccion = direccion.codTipoDireccionDI.toString();
			String claseDireccion = direccion.claseDireccionDI.toString();
			String valDireccion = direccion.direccionDI.toString();
			
			if(direccionPrincipal != null && "Y".equals(direccionPrincipal)) {
				CON_ADDRESSLINE1 = formatearValor(valDireccion);
				if(codTipoDireccion != null && ("01".equals(codTipoDireccion) || "02".equals(codTipoDireccion) || "04".equals(codTipoDireccion))) {
					CON_CITY = formatearValor(homologaciones.obtenerCiudad(direccion.ciudadDI.toString()));
					CON_COUNTRY = formatearValor(homologaciones.obtenerPaises(direccion.paisDI.toString()));
				}
				CON_POSTALCODE = formatearValor(direccion.codigoPostalDI.toString());
				//regla 346
				VER_PROVINCIA = formatearValor(homologaciones.obtenerDepartamentos(direccion.departamentoDI.toString()));
			}
			//regla 384
			if(codTipoDireccion != null && "01".equals(codTipoDireccion) && claseDireccion != null && "01".equals(claseDireccion)) {
				CON_ADDRESSLINE2 = formatearValor(valDireccion);
			}
			if(codTipoDireccion != null && "02".equals(codTipoDireccion) && claseDireccion != null && "02".equals(claseDireccion)) {
				CON_ADDRESSLINE3 = formatearValor(valDireccion);
			}
			if(codTipoDireccion != null && "04".equals(codTipoDireccion) && claseDireccion != null && "04".equals(claseDireccion)) {
				CON_ADDRESSLINE4 = formatearValor(valDireccion);
			}
			//REGLA 240
			DEM_CLASE_DIRECCION = formatearValor(claseDireccion);
		}
		//logger.info("CON_CITY:{}, CON_COUNTRY:{}, CON_POSTALCODE:{}, CON_ADDRESSLINE1:{}, VER_PROVINCIA:{}, CON_ADDRESSLINE2:{}, CON_ADDRESSLINE3:{}, CON_ADDRESSLINE4:{}, DEM_CLASE_DIRECCION:{}",CON_CITY,CON_COUNTRY,CON_POSTALCODE,CON_ADDRESSLINE1,VER_PROVINCIA,CON_ADDRESSLINE2,CON_ADDRESSLINE3,CON_ADDRESSLINE4,DEM_CLASE_DIRECCION);
	}
	
	public void obtenerValoresDeTelefonos(Object telefonos) {
		
		//logger.info("data_telefonos: {}",telefonos);
		for(Object telefono: telefonos) {
			String tipoTelefono = telefono.tipoTL.toString();
			String numeroTelefono = telefono.numeroTL.toString();
			String extensionTelefono = telefono.extensionTL.toString();
			String telefonoPrincipal = telefono.telefonoPpalTL.toString();
			
			if(tipoTelefono != null && "01".equals(tipoTelefono)) {
				CON_HOMEPHONE2 = formatearValor(numeroTelefono);
			}
			
			if(tipoTelefono != null && "02".equals(tipoTelefono)) {
				CON_HOMEPHONE1 = formatearValor(numeroTelefono);
				//regla 209
				DEM_EXTENSION = formatearValor(telefono.extensionTL.toString());
			}
			
			if(telefonoPrincipal != null && "Y".equals(telefonoPrincipal)) {
				CON_HOMEPHONE1 = formatearValor(numeroTelefono);
				//regla 203
				DEM_CIUDAD = formatearValor(homologaciones.obtenerCiudad(telefono.ciudadTL.toString()));
				//regla 215
				DEM_ACTIVO = formatearValor(telefono.activoTL.toString());
				//regla 215
				DEM_INDICATIVO = formatearValor(telefono.indicativoTL.toString());
				//regla 211
				DEM_CLASE = formatearValor(homologaciones.obtenerTelefonoPN(telefono.tipoTelefonoTL.toString()));
			}
		}
		//logger.info("CON_HOMEPHONE1:{}, CON_HOMEPHONE2:{}, DEM_EXTENSION:{}, DEM_CIUDAD:{}, DEM_ACTIVO:{}, DEM_INDICATIVO:{}, DEM_CLASE:{}",CON_HOMEPHONE1,CON_HOMEPHONE2,DEM_EXTENSION,DEM_CIUDAD,DEM_ACTIVO,DEM_INDICATIVO,DEM_CLASE);
	}
	
	public void obtenerValoresDeCelulares(Object celulares) {
		
		//logger.info("data_celulares: {}",celulares);
		for(Object celular:celulares) {
			String celularPrincipal = celular.celularPrincipalCL.toString();
			String tipoTelefono = celular.tipoTelefonoCL.toString();
			String numeroCelular = celular.numeroCL.toString();
			
			if(celularPrincipal != null && "Y".equals(celularPrincipal)) {
				CON_MOBILEPHONE1 = formatearValor(numeroCelular);
			}
			//regla 207
			if(tipoTelefono != null && "03".equals(tipoTelefono)) {
				CON_MOBILEPHONE2 = formatearValor(numeroCelular);
			}
		}
		//logger.info("CON_MOBILEPHONE1:{}, CON_MOBILEPHONE2:{}",CON_MOBILEPHONE1, CON_MOBILEPHONE2);
	}
	
	public void obtenerValoresDeEmails(Object emails) {
		
		//logger.info("data_emails:{}",emails);
		for(Object email: emails) {
			String correoPrincipal = email.correoPrincipalEM.toString();
			String valEmail = email.emailEM.toString();
			
			if(correoPrincipal != null && "Y".equals(correoPrincipal)) {
				CON_EMAIL = formatearValor(valEmail);
			}else if(correoPrincipal != null && "N".equals(correoPrincipal)) {
				//regla 208
				DEM_EMAIL = formatearValor(valEmail);
			}
		}
		//logger.info("CON_EMAIL:{}, DEM_EMAIL:{}",CON_EMAIL,DEM_EMAIL);
	}
	
	public void obtenerValoresDeRelaciones(Object relaciones) {
		
		//logger.info("data_relaciones:{}",relaciones);
		for(Object relacion: relaciones) {
			// regla 801
			DEM_CARGO_SOCIO = formatearValor(relacion.codTipoRelacionRL.toString());
		}
		//logger.info("DEM_CARGO_SOCIO:{}",DEM_CARGO_SOCIO);
	}
	
	public void obtenerValoresDeActLaborales(Object actLaborales) {
		
		//logger.info("data_activ_laboral:{}",actLaborales);
		for(Object actividadLaboral: actLaborales) {
			//regla 236
			DEM_ACTIVIDAD_LABORAL = formatearValor(actividadLaboral.tipoAL.toString());
			//regla 273
			//DEM_COD_ACTIVIDAD_LABORAL = objLoop.getTipoAL();
		}
		//logger.info("DEM_ACTIVIDAD_LABORAL:{}",DEM_ACTIVIDAD_LABORAL);
	}
	
	public void obtenerValoresDeEmpleos(Object empleos) {
		
		//logger.info("data_empleos:{}",empleos);
		for(Object empleo: empleos) {
			//regla 237
			DEM_CARGO = formatearValor(empleo.cargoEM.toString());
		}
		//logger.info("DEM_CARGO:{}",DEM_CARGO);
	}
	
	public void obtenerValoresDeIngresos(Object ingresos) {
		
		//logger.info("data_ingresos:{}",ingresos);
		for(Object ingreso: ingresos) {
			//regla 253
			DEM_PROFESION = formatearValor(ingreso.profesionIN.toString());
			//regla 228
			DEM_ACTIVIDAD_ECONOMICA = formatearValor(homologaciones.obtenerActividadPN(ingreso.actEconomicaIN.toString()));
			//regla 273
			DEM_COD_ACTIVIDAD_LABORAL = formatearValor(ingreso.codActLaboralIN.toString());
		}
		//logger.info("FINAL -- DEM_PROFESION:{}, DEM_ACTIVIDAD_ECONOMICA:{}, DEM_COD_ACTIVIDAD_LABORAL:{}",DEM_PROFESION,DEM_ACTIVIDAD_ECONOMICA,DEM_COD_ACTIVIDAD_LABORAL);
	}
	
	public static String formatearValor(String valor) {
		return valor==null ? "": valor.length()<=50 ? valor :valor.substring(0,50)+"...";
	}
	
	public void setMapValues(Map<String,String> demographicMap) {
		
		demographicMap.put("CON_ADDRESSLINE1", CON_ADDRESSLINE1);
		demographicMap.put("CON_ADDRESSLINE2", CON_ADDRESSLINE2);
		demographicMap.put("CON_ADDRESSLINE3", CON_ADDRESSLINE3);
		demographicMap.put("CON_ADDRESSLINE4", CON_ADDRESSLINE4);
		demographicMap.put("CON_CITY", CON_CITY);
		demographicMap.put("CON_COUNTRY", CON_COUNTRY);
		demographicMap.put("CON_EMAIL", CON_EMAIL);
		demographicMap.put("CON_FULLNAME", CON_FULLNAME);
		demographicMap.put("CON_HOMEPHONE1", CON_HOMEPHONE1);
		demographicMap.put("CON_HOMEPHONE2", CON_HOMEPHONE2);
		demographicMap.put("CON_MOBILEPHONE1", CON_MOBILEPHONE1);
		demographicMap.put("CON_MOBILEPHONE2", CON_MOBILEPHONE2);
		demographicMap.put("CON_POSTALCODE", CON_POSTALCODE);
		demographicMap.put("CON_STATEPROVINCENAME", CON_STATEPROVINCENAME);
		demographicMap.put("CON_WORKPHONE1", CON_WORKPHONE1);
		
		demographicMap.put("DEM_CIUDAD", DEM_CIUDAD);
		demographicMap.put("DEM_ACTIVO", DEM_ACTIVO);
		demographicMap.put("DEM_EMAIL", DEM_EMAIL);
		demographicMap.put("DEM_EXTENSION", DEM_EXTENSION);
		demographicMap.put("DEM_CLASE", DEM_CLASE);
		demographicMap.put("DEM_INDICATIVO", DEM_INDICATIVO);
		demographicMap.put("DEM_ACTIVIDAD_ECONOMICA", DEM_ACTIVIDAD_ECONOMICA);
		demographicMap.put("DEM_ACTIVIDAD_LABORAL", DEM_ACTIVIDAD_LABORAL);
		demographicMap.put("DEM_CARGO", DEM_CARGO);
		demographicMap.put("DEM_CLASE_DIRECCION", DEM_CLASE_DIRECCION);
		demographicMap.put("DEM_CLIENTE_DAVIVALORES", DEM_CLIENTE_DAVIVALORES);
		demographicMap.put("DEM_ESTADO_DIRECCION", DEM_ESTADO_DIRECCION);
		demographicMap.put("DEM_FECHA_VINCULACION", DEM_FECHA_VINCULACION);
		demographicMap.put("DEM_IND_PERSONA_NATURAL_NEGOCIO",DEM_IND_PERSONA_NATURAL_NEGOCIO);
		demographicMap.put("DEM_MANEJA_RECURSOS_PUBLICOS",DEM_MANEJA_RECURSOS_PUBLICOS);
		demographicMap.put("DEM_PROFESION", DEM_PROFESION);
		demographicMap.put("DEM_SEGMENTO_COLOR",DEM_SEGMENTO_COLOR);
		demographicMap.put("DEM_COD_ACTIVIDAD_LABORAL", DEM_COD_ACTIVIDAD_LABORAL);
		demographicMap.put("DEM_GOZA_DE_RECONOCIMIENTO_PUBLICO",DEM_GOZA_DE_RECONOCIMIENTO_PUBLICO);
		demographicMap.put("DEM_INDIC_EXISTENCIA",DEM_INDIC_EXISTENCIA);
		demographicMap.put("DEM_NACIONALIDAD",DEM_NACIONALIDAD);
		demographicMap.put("DEM_NOMBRE_PNCN",DEM_NOMBRE_PNCN);
		demographicMap.put("DEM_OCUPACION",DEM_OCUPACION);
		demographicMap.put("DEM_PAIS_DE_NACIMIENTO",DEM_PAIS_DE_NACIMIENTO);
		demographicMap.put("DEM_SALUDO",DEM_SALUDO);
		demographicMap.put("DEM_SEXO",DEM_SEXO);
		demographicMap.put("DEM_OPERACIONES_INTERNACIONALES",DEM_OPERACIONES_INTERNACIONALES);
		demographicMap.put("DEM_ACCIONISTA_DAVIVIENDA",DEM_ACCIONISTA_DAVIVIENDA);
		demographicMap.put("DEM_ACTIVIDAD_DE_INDUSTRIA_Y_COME", DEM_ACTIVIDAD_DE_INDUSTRIA_Y_COME);
		demographicMap.put("DEM_CLASE_EMPRESA", DEM_CLASE_EMPRESA);
		demographicMap.put("DEM_CLIENTE_PEPS",DEM_CLIENTE_PEPS);
		demographicMap.put("DEM_COD_GRUPO_ECONOMICO",DEM_COD_GRUPO_ECONOMICO);
		demographicMap.put("DEM_EMPRESA_CONTRATISTA_DEL_ESTADO", DEM_EMPRESA_CONTRATISTA_DEL_ESTADO);
		demographicMap.put("DEM_FECHA_CONFIRMACION_DATO", DEM_FECHA_CONFIRMACION_DATO);
		demographicMap.put("DEM_FECHA_MARCACION", DEM_FECHA_MARCACION);
		demographicMap.put("DEM_INDICADOR_CLIENTE_ESTABLECIMI",DEM_INDICADOR_CLIENTE_ESTABLECIMI);
		demographicMap.put("DEM_NIT_CASA_MATRIZ", DEM_NIT_CASA_MATRIZ);
		demographicMap.put("DEM_NRO_DE_EMPLEADOS", DEM_NRO_DE_EMPLEADOS);
		demographicMap.put("DEM_NRO_DE_SOCIOS", DEM_NRO_DE_SOCIOS);
		demographicMap.put("DEM_PAGINA_WEB", DEM_PAGINA_WEB);
		demographicMap.put("DEM_PAIS_FILIALES", DEM_PAIS_FILIALES);
		demographicMap.put("DEM_PAIS_PRINCIPAL", DEM_PAIS_PRINCIPAL);
		demographicMap.put("DEM_RELACION_GRUPO_BOLIVAR", DEM_RELACION_GRUPO_BOLIVAR);
		demographicMap.put("DEM_SECTOR_ECONOMICO", DEM_SECTOR_ECONOMICO);
		demographicMap.put("DEM_SEGMENTO_EMPRESARIAL",DEM_SEGMENTO_EMPRESARIAL);
		demographicMap.put("DEM_SUBSECTOR_ECONOMICO", DEM_SUBSECTOR_ECONOMICO);
		demographicMap.put("DEM_SUCURSAL_FILIAL_O_SUBSIDIARI", DEM_SUCURSAL_FILIAL_O_SUBSIDIARI);
		demographicMap.put("DEM_TIPO_EMPRESA", DEM_TIPO_EMPRESA);
		demographicMap.put("DEM_TIPO_SEDE", DEM_TIPO_SEDE);
		demographicMap.put("DEM_CARGO_SOCIO", DEM_CARGO_SOCIO);
		demographicMap.put("DEM_CLASE_RELACION", DEM_CLASE_RELACION);
		demographicMap.put("DEM_GRUPO_FAMILIAR_SUM_MAY_10_PORC", DEM_GRUPO_FAMILIAR_SUM_MAY_10_PORC);
		demographicMap.put("DEM_PORC_PARTICIPACION_SOCIO", DEM_PORC_PARTICIPACION_SOCIO);
		demographicMap.put("DEM_RELACION", DEM_RELACION);
		demographicMap.put("DEM_TIPO_RELACIONADO", DEM_TIPO_RELACIONADO);
		demographicMap.put("DEM_SEGMENTO_COMERCIAL",DEM_SEGMENTO_COMERCIAL);
		demographicMap.put("DEM_SUBSEGMENTO_COMERCIAL",DEM_SUBSEGMENTO_COMERCIAL);
		
		demographicMap.put("VER_OFICINA_RADICACION", VER_OFICINA_RADICACION);
		demographicMap.put("VER_FECHA_EXPEDICION", VER_FECHA_EXPEDICION);
		demographicMap.put("VER_ESTADO_CIVIL", VER_ESTADO_CIVIL);
		demographicMap.put("VER_PROVINCIA", VER_PROVINCIA);
		demographicMap.put("VER_FECHA_NACIMIENTO", VER_FECHA_NACIMIENTO);
		demographicMap.put("VER_LUGAR_EXPEDICION", VER_LUGAR_EXPEDICION);
		demographicMap.put("VER_LUGAR_NACIMIENTO", VER_LUGAR_NACIMIENTO);
		demographicMap.put("VER_FECHA_VINCULACION", VER_FECHA_VINCULACION);
		demographicMap.put("VER_CIUDAD_DE_CONSTITUCION", VER_CIUDAD_DE_CONSTITUCION);
		demographicMap.put("VER_EDAD_DE_LA_EMPRESA", VER_EDAD_DE_LA_EMPRESA);
		demographicMap.put("VER_FECHA_ACTUALIZACION_DATOS", VER_FECHA_ACTUALIZACION_DATOS);
		demographicMap.put("VER_FECHA_CONSTITUCION", VER_FECHA_CONSTITUCION);
		demographicMap.put("VER_NOMBRE_CASA_MATRIZ_O_FILIAL", VER_NOMBRE_CASA_MATRIZ_O_FILIAL);
		demographicMap.put("VER_PAIS_CONSTITUCION", VER_PAIS_CONSTITUCION);
		demographicMap.put("VER_RAZON_COMERCIAL", VER_RAZON_COMERCIAL);
		demographicMap.put("VER_TIPO_IDENTIFICACION", VER_TIPO_IDENTIFICACION);
		demographicMap.put("VER_CIUDAD_FILIALES", VER_CIUDAD_FILIALES);
		demographicMap.put("VER_CIUDAD_PRINCIPAL", VER_CIUDAD_PRINCIPAL);
		demographicMap.put("VER_HORA_ACTUALIZACION_DATOS", VER_HORA_ACTUALIZACION_DATOS);
	}
	
	public void initVariables() {
		
		header_nombreOperacion = "";
		header_caracterAceptacion = "";
		header_codMsgRespuesta = "";
		
		CON_ADDRESSLINE1 = "";
		CON_ADDRESSLINE2 = "";
		CON_ADDRESSLINE3 = "";
		CON_ADDRESSLINE4 = "";
		CON_CITY = "";
		CON_COUNTRY = "";
		CON_EMAIL = "";
		CON_FULLNAME = "";
		CON_HOMEPHONE1 = "";
		CON_HOMEPHONE2 = "";
		CON_MOBILEPHONE1 = "";
		CON_MOBILEPHONE2 = "";
		CON_POSTALCODE = "";
		CON_STATEPROVINCENAME = "";
		CON_WORKPHONE1 = "";
		
		DEM_CIUDAD = "";
		DEM_ACTIVO = "";
		DEM_EMAIL = "";
		DEM_EXTENSION = "";
		DEM_CLASE = "";
		DEM_INDICATIVO = ""
		DEM_ACTIVIDAD_ECONOMICA = "";
		DEM_ACTIVIDAD_LABORAL = "";
		DEM_CARGO = "";
		DEM_CLASE_DIRECCION = "";
		DEM_CLIENTE_DAVIVALORES = "";
		DEM_ESTADO_DIRECCION ="";
		DEM_FECHA_VINCULACION = "";
		DEM_IND_PERSONA_NATURAL_NEGOCIO = "";
		DEM_MANEJA_RECURSOS_PUBLICOS = "";
		DEM_PROFESION = "";
		DEM_SEGMENTO_COLOR = "";
		DEM_COD_ACTIVIDAD_LABORAL = "";
		DEM_GOZA_DE_RECONOCIMIENTO_PUBLICO = "";
		DEM_INDIC_EXISTENCIA = "";
		DEM_NACIONALIDAD = "";
		DEM_NOMBRE_PNCN = "";
		DEM_OCUPACION = "";
		DEM_PAIS_DE_NACIMIENTO = "";
		DEM_SALUDO = "";
		DEM_SEXO = "";
		DEM_OPERACIONES_INTERNACIONALES = "";
		DEM_ACCIONISTA_DAVIVIENDA = "";
		DEM_ACTIVIDAD_DE_INDUSTRIA_Y_COME = "";
		DEM_CLASE_EMPRESA = "";
		DEM_CLIENTE_PEPS = "";
		DEM_COD_GRUPO_ECONOMICO = "";
		DEM_EMPRESA_CONTRATISTA_DEL_ESTADO = "";
		DEM_FECHA_CONFIRMACION_DATO = "";
		DEM_FECHA_MARCACION = "";
		DEM_INDICADOR_CLIENTE_ESTABLECIMI = "";
		DEM_NIT_CASA_MATRIZ = "";
		DEM_NRO_DE_EMPLEADOS = "";
		DEM_NRO_DE_SOCIOS = "";
		DEM_PAGINA_WEB = "";
		DEM_PAIS_FILIALES = "";
		DEM_PAIS_PRINCIPAL = "";
		DEM_RELACION_GRUPO_BOLIVAR = "";
		DEM_SECTOR_ECONOMICO = "";
		DEM_SEGMENTO_EMPRESARIAL = "";
		DEM_SUBSECTOR_ECONOMICO = "";
		DEM_SUCURSAL_FILIAL_O_SUBSIDIARI = "";
		DEM_TIPO_EMPRESA = "";
		DEM_TIPO_SEDE = "";
		DEM_CARGO_SOCIO = "";
		DEM_CLASE_RELACION = "";
		DEM_GRUPO_FAMILIAR_SUM_MAY_10_PORC = "";
		DEM_PORC_PARTICIPACION_SOCIO = "";
		DEM_RELACION = "";
		DEM_TIPO_RELACIONADO = "";
		DEM_SEGMENTO_COMERCIAL = "";
		DEM_SUBSEGMENTO_COMERCIAL = "";
		
		VER_OFICINA_RADICACION = "";
		VER_FECHA_EXPEDICION = "";
		VER_ESTADO_CIVIL = "";
		VER_PROVINCIA = "";
		VER_FECHA_NACIMIENTO = "";
		VER_LUGAR_EXPEDICION = "";
		VER_LUGAR_NACIMIENTO = "";
		VER_FECHA_VINCULACION = "";
		VER_CIUDAD_DE_CONSTITUCION = "";
		VER_EDAD_DE_LA_EMPRESA = "";
		VER_FECHA_ACTUALIZACION_DATOS = "";
		VER_FECHA_CONSTITUCION = "";
		VER_NOMBRE_CASA_MATRIZ_O_FILIAL = "";
		VER_PAIS_CONSTITUCION = "";
		VER_RAZON_COMERCIAL = "";
		VER_TIPO_IDENTIFICACION = "";
		VER_CIUDAD_FILIALES = "";
		VER_CIUDAD_PRINCIPAL = "";
		VER_HORA_ACTUALIZACION_DATOS = "";
	}
	
	//HEADER
	def HEADER_NOMBRE_OPERACION = "consultarClientePNV3";
	def HEADER_TOTAL = 6001;
	def HEADER_JORNADA = 0;
	def HEADER_CANAL = 98;
	def HEADER_MODO_OPERACION = 0;
	def HEADER_USUARIO = "WEL";
	def HEADER_PERFIL = 0;
	def HEADER_VERSION_SERVICIO = "1.0.0";
	def HEADER_ID_TRANSACCION = "IT";
	
	//RESPONSE
	def header_nombreOperacion;
	def header_total;
	def header_caracterAceptacion;
	def header_ultimoMensaje;
	def header_idTransaccion;
	def header_codMsgRespuesta;

	//DEMOGRAPHIC_MAP
	def CON_ADDRESSLINE1 = "";
	def CON_ADDRESSLINE2 = "";
	def CON_ADDRESSLINE3 = "";
	def CON_ADDRESSLINE4 = "";
	def CON_CITY = "";
	def CON_COUNTRY = "";
	def CON_EMAIL = "";
	def CON_FULLNAME = "";
	def CON_HOMEPHONE1 = "";
	def CON_HOMEPHONE2 = "";
	def CON_MOBILEPHONE1 = "";
	def CON_MOBILEPHONE2 = "";
	def CON_POSTALCODE = "";
	def CON_STATEPROVINCENAME = "";
	def CON_WORKPHONE1 = "";
	//
	def DEM_CIUDAD = "";
	def DEM_ACTIVO = "";
	def DEM_EMAIL = "";
	def DEM_EXTENSION = "";
	def DEM_CLASE = "";
	def DEM_INDICATIVO = ""
	def	DEM_ACTIVIDAD_ECONOMICA = "";
	def DEM_ACTIVIDAD_LABORAL = "";
	def DEM_CARGO = "";
	def DEM_CLASE_DIRECCION = "";
	def DEM_CLIENTE_DAVIVALORES = "";
	def DEM_ESTADO_DIRECCION ="";
	def DEM_FECHA_VINCULACION = "";
	def DEM_IND_PERSONA_NATURAL_NEGOCIO = "";
	def DEM_MANEJA_RECURSOS_PUBLICOS = "";
	def DEM_PROFESION = "";
	def DEM_SEGMENTO_COLOR = "";
	def	DEM_COD_ACTIVIDAD_LABORAL = "";
	def DEM_GOZA_DE_RECONOCIMIENTO_PUBLICO = "";
	def DEM_INDIC_EXISTENCIA = "";
	def DEM_NACIONALIDAD = "";
	def DEM_NOMBRE_PNCN = "";
	def DEM_OCUPACION = "";
	def DEM_PAIS_DE_NACIMIENTO = "";
	def DEM_SALUDO = "";
	def DEM_SEXO = "";
	def DEM_OPERACIONES_INTERNACIONALES = "";
	def DEM_ACCIONISTA_DAVIVIENDA = "";
	def DEM_ACTIVIDAD_DE_INDUSTRIA_Y_COME = "";
	def DEM_CLASE_EMPRESA = "";
	def DEM_CLIENTE_PEPS = "";
	def DEM_COD_GRUPO_ECONOMICO = "";
	def DEM_EMPRESA_CONTRATISTA_DEL_ESTADO = "";
	def DEM_FECHA_CONFIRMACION_DATO = "";
	def DEM_FECHA_MARCACION = "";
	def DEM_INDICADOR_CLIENTE_ESTABLECIMI = "";
	def DEM_NIT_CASA_MATRIZ = "";
	def DEM_NRO_DE_EMPLEADOS = "";
	def DEM_NRO_DE_SOCIOS = "";
	def DEM_PAGINA_WEB = "";
	def	DEM_PAIS_FILIALES = "";
	def	DEM_PAIS_PRINCIPAL = "";
	def	DEM_RELACION_GRUPO_BOLIVAR = "";
	def DEM_SECTOR_ECONOMICO = "";
	def DEM_SEGMENTO_EMPRESARIAL = "";
	def	DEM_SUBSECTOR_ECONOMICO = "";
	def	DEM_SUCURSAL_FILIAL_O_SUBSIDIARI = "";
	def DEM_TIPO_EMPRESA = "";
	def	DEM_TIPO_SEDE = "";
	def DEM_CARGO_SOCIO = "";
	def DEM_CLASE_RELACION = "";
	def DEM_GRUPO_FAMILIAR_SUM_MAY_10_PORC = "";
	def DEM_PORC_PARTICIPACION_SOCIO = "";
	def DEM_RELACION = "";
	def DEM_TIPO_RELACIONADO = "";
	def DEM_SEGMENTO_COMERCIAL = "";
	def DEM_SUBSEGMENTO_COMERCIAL = "";
	//
	def VER_OFICINA_RADICACION = "";
	def VER_FECHA_EXPEDICION = "";
	def VER_ESTADO_CIVIL = "";
	def VER_PROVINCIA = "";
	def VER_FECHA_NACIMIENTO = "";
	def VER_LUGAR_EXPEDICION = "";
	def VER_LUGAR_NACIMIENTO = "";
	def VER_FECHA_VINCULACION = "";
	def VER_CIUDAD_DE_CONSTITUCION = "";
	def VER_EDAD_DE_LA_EMPRESA = "";
	def VER_FECHA_ACTUALIZACION_DATOS = "";
	def VER_FECHA_CONSTITUCION = "";
	def VER_NOMBRE_CASA_MATRIZ_O_FILIAL = "";
	def VER_PAIS_CONSTITUCION = "";
	def VER_RAZON_COMERCIAL = "";
	def VER_TIPO_IDENTIFICACION = "";
	def VER_CIUDAD_FILIALES = "";
	def VER_CIUDAD_PRINCIPAL = "";
	def VER_HORA_ACTUALIZACION_DATOS = "";
}