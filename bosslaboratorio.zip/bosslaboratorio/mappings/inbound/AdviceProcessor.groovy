import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Map;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Qualifier;
import com.sas.davivienda.efm.commons.util.FMUtils;
import com.sas.davivienda.efm.commons.exceptions.EFMException;
import stratus.groovy.model.enums.PCActivityTypeFromTranCode;
import stratus.groovy.model.enums.PCActivityTypeFromMotive;
import stratus.groovy.model.enums.VCActivityTypeFromTranCode;
import stratus.groovy.model.enums.ChannelType;
import stratus.groovy.model.enums.AccountType;

public class AdviceProcessor implements Processor {

	private static final Logger logger = LoggerFactory.getLogger("strlog");

	public void process(Exchange exchange) throws EFMException {
		
		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");

		try {
			String channelId = inputMsg.get("channel");
			String transactionalMean = inputMsg.get("transactional_mean");
			String motive = inputMsg.get("motive");
			String tranCode = inputMsg.get("transaction_code");
			String strAcctType = inputMsg.get("acct_type_payeer");
			String integrationSource = "APPROVED_TX";
			boolean adviceForUpdate = true;
			String sasActivityType = "";
			
			AccountType accountType = AccountType.getIfPresent("ACC_"+strAcctType);
			if(accountType == null){
				throw new EFMException("Account type could not be calculated - strAcctType: "+strAcctType);
			}
			
			String sasAccountType = accountType.sasAccountType;
									
			if("02".equals(channelId) || "33".equals(channelId) || ("03".equals(channelId) && "18".equals(transactionalMean))){
				adviceForUpdate = false;

				sasActivityType = getActivityTypeForPChannel(tranCode,channelId);

				if(FMUtils.isNullOrEmpty(sasActivityType)){
					PCActivityTypeFromMotive pcActivityTypeMotive = PCActivityTypeFromMotive.getIfPresent("PC_"+motive);

					if(pcActivityTypeMotive == null){
						throw new EFMException("Activity type could not be calculated for trancode: "+tranCode);
					}
					sasActivityType = pcActivityTypeCode.getSASActivityType();
				}
			}else{
				ChannelType channelType = ChannelType.getIfPresent("CH_"+channelId);
				
				if(channelType == null) {
					throw new EFMException("Channel not in list: " + channelId);
				}
				
				integrationSource = channelType.getIntegration();
				
				switch(integrationSource) {
					case "PHYSICAL-CHANNEL":
						sasActivityType = getActivityTypeForPChannel(tranCode,channelId);
					break;
					case "VIRTUAL-CHANNEL":
						VCActivityTypeFromTranCode vcActivityType = VCActivityTypeFromTranCode.getIfPresent("VC_"+tranCode);
						
						if(vcActivityType == null) {throw new EFMException("Activity type could not be calculated - tranCode: " + tranCode);}
						sasActivityType = vcActivityType.getSASActivityType();
					break;
				}
					
				if(FMUtils.isNullOrEmpty(sasActivityType)){
					String message = "Activity type could not be calculated - tranCode: " + tranCode;
					throw new EFMException(message);
				}
				if(logger.isDebugEnabled()){logger.info("channelId: {}, integSource: {}",channelId, integrationSource);}
			}

			inputMsg.put("sas_acct_type", sasAccountType);
			inputMsg.put("sas_activity_type", sasActivityType);
			
			String transactionType = sasAccountType.concat(sasActivityType);
			exchange.setProperty("transactionType",transactionType);
			exchange.setProperty("integSource",integrationSource);
			
		}catch(Exception e) {
			String errorMsg = "ERROR - AdviceProcessor: " + e.toString();
			throw new EFMException(errorMsg);
		}
	}

	public String getActivityTypeForPChannel(String tranCode,String channelId){
		String sasActivityType = "";

		PCActivityTypeFromTranCode pcActivityType = PCActivityTypeFromTranCode.getIfPresent("PC_"+tranCode);
						
		if(pcActivityType == null) {throw new EFMException("Activity type could not be calculated - tranCode: " + tranCode);}
		
		sasActivityType = pcActivityType.getSASActivityType();
		logger.info("sasActivityType: {},channelId: {}", sasActivityType,channelId);
		if("CW".equals(sasActivityType) && "03".equals(channelId)){
			sasActivityType = "CA";
		}
		return sasActivityType;
	}

}
