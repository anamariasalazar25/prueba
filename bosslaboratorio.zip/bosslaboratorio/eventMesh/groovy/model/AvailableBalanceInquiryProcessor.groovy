package com.fadosol.integration.groovy;

import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import javax.annotation.Resource;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sas.davivienda.efm.commons.dto.ISOCountry
import com.sas.davivienda.efm.commons.exceptions.EFMException;
import com.sas.davivienda.efm.commons.mapper.DIANComplementaryCodeMapper;
import com.sas.davivienda.efm.commons.dto.DIANComplementaryCode;
import com.sas.davivienda.efm.commons.mapper.ISOCountryMapper;
import com.sas.davivienda.efm.commons.util.FMAPIFieldMapper
import com.sas.davivienda.efm.commons.util.FMDateFormatter;
import com.sas.davivienda.efm.commons.util.FMUtils;
import org.apache.commons.lang.StringUtils;

/**
 * 
 *
 */
public class AvailableBalanceInquiryProcessor {

	private static final Logger logger = LoggerFactory.getLogger("mshlog");
	
	private static final String TASK = "EF02";
	private static final String FILLER_1 = "00";
	private static final String TRANSACTION_CODE = "6592";
	private static final String TOTAL = "002222";
	private static final String JOURNEY = "0";
	private static final String CHANNEL = "49";
	private static final String OP_MODE = "00";
	private static final String USER = "EFM";
	private static final String PROFILE = "EF";
	private static final String VERSION = "00";
	private static final String FILLER_2 = "000000";

	/**
	 * 
	 */
	public AvailableBalanceInquiryProcessor() {
		logger.info("Init AvailableBalanceInquiryProcessor");
	}

	/**
	 * 
	 * @param exchange
	 * @throws EFMException
	 */
	public void processRequest(Exchange exchange) {
		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");

		try {

			String acctRelationShip = inputMsg.get("aqd_acct_relationship");
			String mshAcctType = "C".equals(acctRelationShip) ? "01" : "03";
			String acctNum = inputMsg.get("aqo_acct_num");
			acctNum = StringUtils.leftPad(acctNum, 16, '0');

			String eopInstance = exchange.getProperty("eopInstance");
			int rndMinValue = 1;
			int rndMaxValue = 499999;

			if("dsdgvfmrteop2".equals(eopInstance)){
				rndMinValue = 500000;
				rndMaxValue = 999999;
			}

			int unboundedRandomValue = ThreadLocalRandom.current().nextInt(rndMinValue, rndMaxValue);
			String msgNumber = StringUtils.leftPad(String.valueOf(unboundedRandomValue), 6, '0');

			StringBuilder requestData = new StringBuilder();
			requestData.append(TASK)
					.append(FILLER_1)
					.append(TRANSACTION_CODE)
					.append(TOTAL)
					.append(JOURNEY)
					.append(CHANNEL)
					.append(OP_MODE)
					.append(USER)
					.append(PROFILE)
					.append(msgNumber)
					.append(VERSION)
					.append(FILLER_2)
					.append(mshAcctType)
					.append(acctNum);

			exchange.setProperty("msgNumber", msgNumber);
			exchange.getIn().setBody(requestData.toString());

			if(logger.isDebugEnabled()){logger.info("request sent to Event Mesh: {}",requestData.toString());}
		}catch (Exception e) {
			logger.error("Error enviando solicitud a Event Mesh: {}",e.getMessage());
			exchange.getIn().setHeader("mshEnrError",true);
		}
	}

	/**
	 * 
	 * @param exchange
	 */
	public void processResponse(Exchange exchange) {

		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");
		Map<String, String> inputMsgBalanceInqResp = (Map<String, String>) exchange.getProperty("inputMsgBalanceInqResp");

		if(logger.isDebugEnabled()){logger.info("BalanceInquiry event mesh response: {}",inputMsgBalanceInqResp);}
		
		try {
			
			if(inputMsgBalanceInqResp != null) {
				String acceptanceChar = inputMsgBalanceInqResp.get("dh_acceptance_char");
				String response = inputMsgBalanceInqResp.get("db_message");
				
				if("B".equals(acceptanceChar)) {
					String sign = response.substring(0, 1);
					String amount = "0000";

					//when balance is zero there is no sign, the message come with an space at first position and the bfs makes trim,
					//so the sign should be blank and the amount position change
					if("0".equals(sign)){
						sign = " ";
					}else{
						amount = response.substring(1,19);
					}
					
					inputMsg.put("msh_balance_sign", sign);
					inputMsg.put("msh_balance", FMUtils.addDecimalSeparator(amount));
				}else {
					String prodId = inputMsg.get("productId");
					StringBuilder msgError = new StringBuilder().append("Error consultando en Event Mesh: ")
																.append(response.substring(0, response.length()-3))
																.append(" prod: ")
																.append(prodId.substring(prodId.length()-4))
																.append(" tipo: ")
																.append(inputMsg.get("productType"));
					exchange.getIn().setHeader("mshEnrError",msgError.toString());
				}
			}
			
		}catch (Exception e) {
			StringBuilder msgError = new StringBuilder().append("Error consultando en Event Mesh: ")
																.append(e.getMessage())
																.append(" prod: ")
																.append(prodId.substring(prodId.length()-4))
																.append(" tipo: ")
																.append(inputMsg.get("productType"));
			exchange.getIn().setHeader("mshEnrError",msgError.toString());
		}
	}

}
