
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.sas.davivienda.efm.commons.dto.TableCardMedia;
import com.sas.davivienda.efm.commons.exceptions.EFMException;
import com.sas.davivienda.efm.commons.util.FMUtils;

/**
 * 
 *
 */
public class MshActivityTypeDataProcessor {
	
	private static final Logger logger = LoggerFactory.getLogger("mshlog");
	
	@Resource
	@Qualifier("mshActivityTypeFromTranType")
	private Map<String, String> mshActivityTypeFromTranType;

	@Resource
	@Qualifier("mshActRelationshipFromRPR")
	private Map<String, String> mshActRelationshipFromRPR;
	
	@Resource
	@Qualifier("mshTcaTranTypeFromPosConditionCode")
	private Map<String, String> mshTcaTranTypeFromPosConditionCode;
	
/**
 * 	@Resource
 * 	@Qualifier("mshTbtTranTypeFromProcCode")
 *	private Map<String, String> mshTbtTranTypeFromProcCode;
 *	
 *	@Resource
 *	@Qualifier("mshTbtBillCatFromProcCode")
 *	private Map<String, String> mshTbtBillCatFromProcCode;
 */
	
	/**
	 * 
	 */
	public MshActivityTypeDataProcessor() {
		logger.info("Init mshActivityTypeDataProcessor");
	}
	
	/**
	 * 
	 * @param exchange
	 * @throws EFMException 
	 */
	public void mapActivityTypeData(Exchange exchange) throws EFMException {
		
		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");
		
		/* String activityType = exchange.getProperty("sasActivityType", String.class); */
		String trxAmount = inputMsg.get("transaction_amount");
		String trxRefNumber = inputMsg.get("transaction_number");
		String prodCode = inputMsg.get("ed_prod_code");	//RPR
		String mti = inputMsg.get("message_type");
		String posConditionCode = inputMsg.get("pos_condition_code");
		String trxCode = inputMsg.get("transaction_code");
		/* Next line added for TDD's activity type definition */
		String trxType = trxCode.substring(0,2);
		String responseCode = inputMsg.get("response_code");
		String sysDec = responseCode == null || "0000".equals(responseCode) ? "1" : "4";
		String multiOrgName = "TARJ_DAVIPLATA";
    	String nationalInternational = inputMsg.get("national_international");

		if(FMUtils.hasValue(prodCode)) {
			String actRelationship = mshActRelationshipFromRPR.get(prodCode);
			inputMsg.put("acct_relationship", actRelationship);
		}

		/* Added to define TDD activityType from TranType as it doesn't result from usual enrichment process */
		String activityType = mshActivityTypeFromTranType.get(trxType);
		inputMsg.put("activityType", activityType);

		inputMsg.put("smh_multi_org_name", multiOrgName);
		if(FMUtils.hasValue(nationalInternational)) {
			inputMsg.put("nal_internal", nationalInternational.substring(0, 1));
		}

		try {
			switch(activityType) {
				case "CA":
					mapTCAActivityType(inputMsg, trxAmount, trxRefNumber, mti, posConditionCode, sysDec);
				break;
				/*
				case "DP":
					mapTDPActivityType(inputMsg, trxAmount, trxRefNumber, mti)
				case "NM":
					inputMsg.put("ref_num_nm", trxRefNumber);
					inputMsg.put("tng_tran_type", "BE");
				break;
				*/
			}
			
		}catch(Exception e) {
			logger.error("ERR-ActivityTypeDataProcessor: {} ", e.toString());
		}
	}

	/**
	 * 
	 * @param inputMsg
	 * @param trxAmount
	 * @param trxRefNumber
	 * @param mti
	 * @param posConditionCode
	 * @param sysDec
	 */
	public void mapTCAActivityType(Map<String, String> inputMsg, String trxAmount, String trxRefNumber, String mti, String posConditionCode, String sysDec) {
		
		inputMsg.put("tca_merch_amt", trxAmount);
		inputMsg.put("tca_merch_curr_code", inputMsg.get("currency_code"));
		inputMsg.put("tca_client_amt", trxAmount);
		inputMsg.put("tca_client_curr_code", "170");
		inputMsg.put("tca_mod_amt", trxAmount);
		inputMsg.put("tca_ref_num", trxRefNumber);
		String reversalIndicator = FMUtils.hasValue(mti) && "0420".equals(mti) ? "R" : "N";
		inputMsg.put("tca_reversal_ind", reversalIndicator);
		
		if(FMUtils.hasValue(posConditionCode)) {
			String tranType = mshTcaTranTypeFromPosConditionCode.get(posConditionCode);
			inputMsg.put("tca_tran_type", tranType);
		}
		inputMsg.put("tca_auth_sys_dec", sysDec);
	}
	
/** Se elimina lo relacionado con activityType DP que no existe en TDD EventMesh
 *	public void mapTDPActivityType(Map<String, String> inputMsg, String trxAmount, String trxRefNumber, String mti) {
 *		inputMsg.put("tdp_client_amt", trxAmount);
 *		inputMsg.put("tdp_client_curr_code", "170");
 *		inputMsg.put("tdp_mod_amt", trxAmount);
 *		inputMsg.put("tdp_ref_num", trxRefNumber);
 *		String reversalIndicator = FMUtils.hasValue(mti) && "0420".equals(mti) ? "R" : "N";
 *		inputMsg.put("tdp_reversal_ind", reversalIndicator);
 *	}
 */
}
