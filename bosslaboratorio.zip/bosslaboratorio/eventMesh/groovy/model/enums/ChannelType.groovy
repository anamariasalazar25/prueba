package eventMesh.groovy.model.enums;

import com.google.common.base.Enums;

public enum ChannelType {
	
	CH_00("H","Oficina","PHYSICAL-CHANNEL"),
	CH_01("H","CLIENTE360","PHYSICAL-CHANNEL"),
	CH_02("H","PCBank","PHYSICAL-CHANNEL"),
	CH_03("C","ATM-DISP","PHYSICAL-CHANNEL"),
	CH_05("P","TelRojo","PHYSICAL-CHANNEL"),
	CH_11("H","PROC-AUT","PHYSICAL-CHANNEL"),
	CH_16("W","DAVCOM","VIRTUAL-CHANNEL"),
	CH_21("W","CORP-EMP-PYME","VIRTUAL-CHANNEL"),
	CH_22("H","KIOSKO","PHYSICAL-CHANNEL"),
	CH_24("H","CORRESPONSALES","PHYSICAL-CHANNEL"), //Adicion de canal 24 rdb stratus
	CH_26("C","ATM-MULTI","PHYSICAL-CHANNEL"),
	CH_32("B","H2H","PHYSICAL-CHANNEL"),
	CH_33("H","PROC-ESP","PHYSICAL-CHANNEL"),
	CH_37("W","APP-PERSONAS","VIRTUAL-CHANNEL"),
	CH_41("W","PSE","VIRTUAL-CHANNEL"),
	CH_97("W","API-PERSONAS","CLIENTS-APIS"),
	CH_99("W","MOD-TRANSV","VIRTUAL-CHANNEL"),
	DEFAULT("W","DEFAULT","VIRTUAL-CHANNEL"),

	private final String sasChannelType;
	private final String description;
	private final String integration;
	 
	private ChannelType(final String sasChannelType, final String description, final String integration) {
		this.sasChannelType = sasChannelType;
		this.description = description;
		this.integration = integration;
	}
	
	public static ChannelType getIfPresent(String name) {
		return Enums.getIfPresent(ChannelType.class, name).orNull();
	}
	
	public String getIntegration(){
		return this.integration;
	}
	
	public String getSASChannelType(){
		return this.sasChannelType;
	}
}
