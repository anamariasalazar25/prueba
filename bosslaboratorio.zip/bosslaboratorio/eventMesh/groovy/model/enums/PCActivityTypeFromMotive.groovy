package eventMesh.groovy.model.enums;

import com.google.common.base.Enums;

public enum PCActivityTypeFromMotive {
	
	PC_0000("CA"),
	PC_0001("CW"),
	PC_0087("DP"),
	PC_0118("DP"),
	PC_0561("DP"),
	PC_0585("DP"),
	PC_0640("DP"),
			
	private final String sasActivityType;
	 
	private PCActivityTypeFromMotive(final String sasActivityType) {
		this.sasActivityType = sasActivityType;
	}
	
	public static PCActivityTypeFromMotive getIfPresent(String name) {
		return Enums.getIfPresent(PCActivityTypeFromMotive.class, name).orNull();
	}
	
	public String getSASActivityType(){
		return sasActivityType;
	}
	
}
