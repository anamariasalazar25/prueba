package eventMesh.groovy.model.enums;

import com.google.common.base.Enums;

public enum CAActivityTypeFromTranCode {
	
/**
* 
*	CA_000124("NM","Consulta de Cuenta con Tarjeta"),
*	CA_000132("NM","Consulta productos"),
*	CA_000133("NM","Consulta de productos"),
*	CA_000350("NM","Bloqueo y Desbloqueo de cuenta"),
*	CA_000352("NM","Novedad Marcación Empresarial"),
*	CA_000372("NM","Asignación - Activación Tarjeta"),
*	CA_000374("NM","Inscripción de cuentas ACH"),
*	CA_000382("BF","Recargas a Celular (Comcel, movistar, tigo)"),
*	CA_000394("NM","Cambios de clave"),
*	CA_000396("NM","Cambio de Clave"),
*	CA_000400("NM","Asignación clave web"),
*	CA_001151("NM","Asignación - Activación Tarjeta Crédito"),
*	CA_001706("NM","Asociación Débito Automático"),
*	CA_001726("BF","Pago producto Crédito FM"),
*	CA_003100("NM","Consulta Persona Natural"),
*	CA_003189("NM","Consulta Titulares Cuentas"),
*	CA_004373("BF","Pago de Servicios Públicos"),
*	CA_004812("BF","Pago Tarjeta de Crédito"),
*	CA_004822("NM","Consulta Tarjeta de Crédito"),
*	CA_005050("NM","Consulta de Saldo"),
*	CA_005060("NM","Consulta cobros"),
*	CA_005074("NM","Cambiar numero destinatario Giro"),
*	CA_005100("NM","Consulta de saldos para Cuenta Corriente sin tarjeta"),
*	CA_005102("NM","Consulta Titular Cuentas"),
*	CA_005104("NM","Consulta saldo de cuenta con tarjeta"),
*	CA_005111("NM","Consulta de Saldo Cta Ahorros"),
*	CA_005113("NM","Consulta saldo Bolsillo "),
*	CA_005126("NM","Consulta Saldo Cancelación con Tarjeta"),
*	CA_005128("NM","Consulta Saldo Cancelación con Tarjeta"),
*	CA_005138("NM","Consulta Cuentas"),
*	CA_005150("NM","Consulta Estado de un Cheque"),
*	CA_005151("NM","Consulta Cheque-Chequera"),
*	CA_005160("NM","Consulta Chequeras"),
*	CA_005163("NM","Consulta Chequeras"),
*	CA_005190("NM","Consulta de Divisas "),
*	CA_005194("NM","Consulta Liquidación Transferencia"),
*	CA_005220("BF","Transferencia a Monedero"),
*	CA_005260("BF","Transferencias"),
*	CA_005355("NM","Consulta de Saldo Crédito"),
*	CA_005360("NM","Cancelación de Producto"),
*	CA_005382("NM","Activacion chequera"),
*	CA_005660("BF","Nota Débito"),
*	CA_005680("BF","Nota Débito Supervisada"),
*	CA_005682("BF","Transferencias"),
*	CA_005683("BF","Pagos Planilla Asistida"),
*	CA_005686("BF","Transferencias"),
*	CA_005700("NM","Consignación Efectivo. Cta. Ahorro/Cta Cte"),
*	CA_005702("NM","Consignación Efectivo. Cta. Ahorro AFC"),
*	CA_005704("NM","Consignación Efectivo Tarjeta. Cta. Ahorro/Cta Cte"),
*	CA_005710("NM","Consignación En Cheques Locales Sin tarjeta Cta. Ahorro/Cte"),
*	CA_005714("NM","Consignación En Cheques Locales Con Tarjeta Cta. Ahorro/Cte"),
*	CA_005780("BF","Nota Crédito Tarjeta de Crédito"),
*	CA_006262("BF","Transferencia"),
*	CA_006464("BF","Transferencia a Cuentas de Otros Bancos"),
*	CA_006502("BF","Adelanto o transferencia a daviplata"),
*	CA_007500("BF","Recaudo"),
*	CA_007501("BF","Reversión Recaudo"),
*	CA_007502("BF","Recaudo de Convenios"),
*	CA_007504("BF","Recaudo"),
*	CA_007508("BF","Pago de Servicios"),
*	CA_007510("BF","Pago Servicios con Tarjeta Debito"),
*	CA_009090("NM","Cambio de Clave"),
*/
	CA_005682("BF","Pago con cuenta en Aliados"),
	CA_001128("NM","Originacion TDC Aliados"),
		
	private final String sasActivityType;
	private final String description;
	 
	private CAActivityTypeFromTranCode(final String sasActivityType, final String description) {
		this.sasActivityType = sasActivityType;
		this.description = description;
	}
	
	public static CAActivityTypeFromTranCode getIfPresent(String name) {
		return Enums.getIfPresent(CAActivityTypeFromTranCode.class, name).orNull();
	}
	
	public String getSASActivityType(){
		return sasActivityType;
	}
}
