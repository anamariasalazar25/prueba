package eventMesh.groovy.model.enums;

import com.google.common.base.Enums;

public enum AccountType {
	
	ACC_0120("CC",""),
	ACC_0550("CS","S"),
	ACC_0560("CS","C"),
	ACC_0570("CS","S"),
	DEFAULT("CS","S"),
			
	private final String sasAccountType;
	private final String sasAccountRelationship;
		 
	private AccountType(final String sasAccountType, final String sasAccountRelationship) {
		this.sasAccountType = sasAccountType
		this.sasAccountRelationship = sasAccountRelationship;
	}
	
	public static AccountType getIfPresent(String name) {
		return Enums.getIfPresent(AccountType.class, name).orNull();
	}
	
}
