
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.sas.davivienda.efm.commons.dto.TableCardMedia;
import com.sas.davivienda.efm.commons.exceptions.EFMException;
import com.sas.davivienda.efm.commons.util.FMUtils;

/**
 * 
 *
 */
public class MshAccountDataProcessor {
	
	private static final Logger logger = LoggerFactory.getLogger("mshlog");
	
	@Resource
	@Qualifier("mshAcctTypeFromRPR")
	private Map<String, String> mshAccountTypeFromSubProduct;
	
	/**
	 * 
	 */
	public MshAccountDataProcessor() {
		logger.info("Init mshAccountDataProcessor");
	}
	
	/**
	 * 
	 * @param exchange
	 * @throws EFMException 
	 */
	public void mapAccountData(Exchange exchange) throws EFMException {
		
		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");
		
		try {
			
			String balance = inputMsg.get("balance");
			if(FMUtils.hasValue(balance)) {
				inputMsg.put("balance",FMUtils.addDecimalSeparator(balance));
			}
			
			//Payee
			String payeeProdType = inputMsg.get("payee_product_type");
			if(FMUtils.hasValue(payeeProdType)) {
				String sasPayeeAcctType = mshAccountTypeFromSubProduct.get(payeeProdType);
				inputMsg.put("sas_payee_product_type",sasPayeeAcctType);
				String payeeProdNumber = inputMsg.get("payee_product_number");
				inputMsg.put("payee_product_number", getValidatedProductNumber(payeeProdNumber));
			}
			
		}catch(Exception e) {
			logger.error("ERR-AccountDataProcessor: {}", e.toString());
		}
	}

	/**
	 * 	
	 * @param cardNumber
	 * @return
	 * @throws EFMException
	 */
	public String getValidatedProductNumber(String cardNumber) throws EFMException {
		if(FMUtils.isNullOrEmpty(cardNumber)) {
			throw new EFMException("It was not possible to get payee product information");
		}
		return cardNumber.trim(); 
	}
}
