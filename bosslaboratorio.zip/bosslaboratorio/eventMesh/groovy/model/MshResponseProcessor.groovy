import javax.annotation.Resource

import org.apache.camel.Exchange
import org.apache.commons.lang.StringUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Qualifier

import com.sas.davivienda.efm.commons.util.FMResponseHelper
import com.sas.davivienda.efm.commons.util.FMUtils

public class MshResponseProcessor {
	
	private static final Logger logger = LoggerFactory.getLogger("mshlog");
	
	private static final String FILLER1 = StringUtils.leftPad("", 8);
	private static final String SUCCESS_ACCEPTANCE_CHAR = "B";
	private static final String DELINE_ACCEPTANCE_CHAR = "M";
	private static final String LAST_MESSAGE = "1";
	private static final String NUMBER_OF_LINES = "00";
	private static final String FILLER2 = "000000";
	
	public MshResponseProcessor() {
		logger.info("init Response Processor");
	}
	
	/**
	 * Build a event mesh response message
	 * 
	 *  total (len 6): same value as total field on request
	 *  sequential (len 6): same value as sequential field on request
	 *  filler 1 (len 8): future use, default: space
	 *  acceptance character (len 6): B: success transaction, M: unsuccess transaction, default: B
	 *  lastMessage (len 1): recurrent transaction indicator, 1: last message, 0: not last message, default: 1
	 *  number of lines (len 2): total records for recurrent rtansaction, default: 00
	 *  messageCode (len 4): sas response code, 0000: success, 0076: declined, 0091: timeout, 0096: not proccessed
	 *  filler 2 (len 6): future use
	 *  message (len 40): blank if acceptance char is B, message error when acceptance char is M
	 * @param exchange
	 */
	public void processResponse(Exchange exchange) {
		
		try {
			String total = "";
			String sequential = "";
			
			Map<String, String> inputMsg = exchange.getProperty("inputMsgHeader");
			String trxInfoLog = exchange.getProperty("trxInfoLog",String.class);

			StringBuilder infoLogBuilder = new StringBuilder();
			
			if(inputMsg != null) {
				total = inputMsg.get("dh_total");
				sequential = inputMsg.get("dh_sequential");
			}
			
			StringBuilder responseData = new StringBuilder();
			String responseCode = "00";

			if(exchange.getIn().getBody() instanceof Map){
				Map<String, Object> outputMap = (Map<String, Object>) exchange.getIn().getBody();

				if(outputMap != null){
					responseCode = FMResponseHelper.getResponseCode(exchange);
				}
			}else{
				String errorType = exchange.getProperty("errorType");
				if(errorType != null && "PROCESSING_ERROR".equals(errorType)){
					responseCode = "96";
				}
			}
			
			String message = StringUtils.leftPad("", 40);
			String acceptance = "00".equals(responseCode) ? SUCCESS_ACCEPTANCE_CHAR : DELINE_ACCEPTANCE_CHAR;
			
			responseData.append(total)
						.append(sequential)
						.append(FILLER1)
						.append(acceptance)
						.append(LAST_MESSAGE)
						.append(NUMBER_OF_LINES)
						.append("00".concat(responseCode))
						.append(FILLER2)
						.append(message)
						
			infoLogBuilder.append(trxInfoLog).append(" resp-code:").append(responseCode);
			exchange.setProperty("trxInfoLog",infoLogBuilder.toString());
			exchange.getIn().setBody(responseData.toString());
			
		}catch(Exception e) {
			logger.error("ERR-ResponseProcessor: {}",e.toString());
		}
	}
	
}
