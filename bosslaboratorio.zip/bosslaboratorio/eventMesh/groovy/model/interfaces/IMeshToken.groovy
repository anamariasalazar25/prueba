package eventMesh.groovy.model.interfaces;

import java.util.Map;

public interface IMeshToken {

	public void mapTokenData(Map<String,String> inputMsg, String additionalData);
}
