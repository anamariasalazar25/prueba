package eventMesh.groovy.controller;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import eventMesh.groovy.controller.TokenTypes;
import eventMesh.groovy.controller.Token;
import eventMesh.groovy.controller.enums.TokenCZ;
import eventMesh.groovy.controller.enums.TokenSC;
import eventMesh.groovy.controller.enums.TokenC4;
import eventMesh.groovy.controller.enums.TokenB0;
import eventMesh.groovy.controller.enums.TokenC0;


public class TokenChecks {
	
	private static final Logger logger = LoggerFactory.getLogger("mshlog");
	
	private static final tokensValue = [
		
		"C0": TokenC0,
		"CZ": TokenCZ,
		"SC": TokenSC,
		"B0": TokenB0,
		"C4": TokenC4,
	];
		
	public static Map <String, String> createTokensValues(String tokenInfo, String tokenType) {
		
		Map <String, String> sasMap = new HashMap <String, String>();
		try {
			def tokensEnum = tokensValue[tokenType].values();
			
			for(def tokenValue: tokensEnum) {
				sasMap.put(tokenValue.sasValue, tokenInfo.substring(tokenValue.startPos - 1, tokenValue.finalPos))
			}
		}catch(Exception e) {
			logger.info("Length of {} token received is less than expected - {}",tokenType,e.getMessage());
		}
		return sasMap;
	}
	
	public static Map <String, String> checkTokenValues(Token token) {

		// Check token type
		TokenTypes tokenType = TokenTypes.tokenValueOf(token.getCode());
				
		if(tokenType == null) {
			return null;
		}
		
		// Check token info size
		int tokenInfoSize = token.getInfo().length();
		
		if(tokenInfoSize != tokenInfoSize) {
			return null;
		}
		
		return createTokensValues(token.getInfo(), tokenType.code);
	}
	
}
