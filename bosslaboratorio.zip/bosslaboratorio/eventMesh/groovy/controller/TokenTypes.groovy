package eventMesh.groovy.controller;

public enum TokenTypes {
	
	C0("C0"),
	CZ("CZ"),
	SC("SC"),
	C4("C4"),
	B0("B0"),

	private final String code;
	
	private TokenTypes(final String code) {
		this.code = code;
	}
	
	public static TokenTypes tokenValueOf(String code){

		for(TokenTypes value : values()) {
						
			if(value.code.equals(code)) {
				return value;
			}
		}
		return null;
	}
	
	@Override
	public String toString() {
		return this.code;
	}
	
	
}
