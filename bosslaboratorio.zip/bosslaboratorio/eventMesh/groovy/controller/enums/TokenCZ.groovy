package eventMesh.groovy.controller.enums;

public enum TokenCZ {

	FORM_FACTR_IND("AN", 8, 1, 8, "dua_8byte_string_010"),
	CRD_AUTHN_IND("AN", 1, 9, 9, "rua_ind_026");
	
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	private TokenCZ(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
