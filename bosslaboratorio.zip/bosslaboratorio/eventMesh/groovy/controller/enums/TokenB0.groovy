package eventMesh.groovy.controller.enums;

public enum TokenB0 {
	
	SEC_LVL_IND("AN", 3, 1, 3, "dmx_3byte_string_03"),
	F_DATA_SCORE("AN", 3, 4, 6, "rua_3byte_string_002");
	
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	private TokenB0(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
