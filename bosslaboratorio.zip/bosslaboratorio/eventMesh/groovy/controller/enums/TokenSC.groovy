package eventMesh.groovy.controller.enums;

public enum TokenSC {
	
	TOKEN_ASSRC_LEVEL("AN", 2, 1, 2, "dmx_2byte_string_01_tag"),
	TOKEN_RQ_ID("AN", 11, 3, 13, "rua_20byte_string_003");
	
	// Estructura de la información contenida en el Token
	private final String type; 	
	private final Integer length; 
	private final Integer startPos; 
	private final Integer finalPos;	
	private final String sasValue; 
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenSC(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
