package eventMesh.groovy.controller.enums;

public enum TokenC0 {
	
	INTRNATNL_FLAG("AN", 1, 1, 1, "rua_ind_025"); //POSITION 19 TOKEN C0
	
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	private TokenC0(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
