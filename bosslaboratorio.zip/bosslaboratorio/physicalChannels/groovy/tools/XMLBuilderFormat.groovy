package physicalChannels.groovy.tools;

import com.google.gson.Gson
import com.google.gson.GsonBuilder;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import javax.xml.soap.SOAPMessage;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.MimeHeaders;
import java.nio.charset.Charset;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBIntrospector;
import javax.xml.bind.Unmarshaller;

import org.w3c.dom.Document;

import physicalChannels.groovy.model.AuthorizeTransaction;
import physicalChannels.groovy.tools.deserializers.DateDeserializer;

public class XMLBuilderFormat {
	
	public static Gson getGson() {
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.registerTypeAdapter(Date.class, new DateDeserializer());
		
		return gsonBuilder.setPrettyPrinting().create();
	}
	
	private static classesList = [
		"authorizeTransaction": AuthorizeTransaction.class
	];
	
	public static Object getXMLMappingObject(String body, String objectClassName) {
		
		MessageFactory factory = MessageFactory.newInstance();
		SOAPMessage message = factory.createMessage(
				new MimeHeaders(),
				new ByteArrayInputStream(body.getBytes(Charset
						.forName("UTF-8"))));

		SOAPBody soapBody = message.getSOAPBody();
		
		Document document = soapBody.extractContentAsDocument();
		JAXBContext content = JAXBContext.newInstance(classesList[objectClassName]);
		Unmarshaller unmarshaller = content.createUnmarshaller();
		JAXBIntrospector jaxbIntrospector = content.createJAXBIntrospector();
		Object transactionObject = unmarshaller.unmarshal(document);

		return jaxbIntrospector.getValue(transactionObject);
		
	}
}



