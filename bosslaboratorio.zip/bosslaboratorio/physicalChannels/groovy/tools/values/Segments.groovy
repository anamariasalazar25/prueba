package physicalChannels.groovy.tools.values;

import org.slf4j.Logger
import org.slf4j.LoggerFactory

import physicalChannels.groovy.model.AuthorizeTransaction;

public class Segments {
	
	private static final Logger logger = LoggerFactory.getLogger("physicalChannelslog");
	
	/**
	 * Valid segments depending on transaction account type and activity type combination
	 */
	public static segmentsGroups = [
		FP01: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HPB", "TNG", "DMX", "DEE", "DUA"],
		FP02: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HPB", "TBT", "TPP", "DMX", "DEE", "DUA"],
		FP03: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HPB", "TNG", "DMX", "DEE", "DUA"],
		FP04: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HPB", "TDP", "TPP", "DMX", "DEE", "DUA"],
		FP05: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HPB", "TPP", "DMX", "DEE", "DUA"],	
		FP06: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HPB", "TCA", "DMX", "DEE", "DUA"],
		FP07: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HPB", "TBT", "TPP", "DMX", "DEE", "DUA"],
		FP08: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UNM", "HQO", "HBP", "TAB", "DMX", "DEE", "DUA"],
		FP09: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UCM", "HQO", "HCT", "TNG", "DMX", "DEE", "DUA"],
		FP10: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UCM", "HQO", "HCT", "TCA", "DMX", "DEE", "DUA"],
		FP11: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UCM", "HQO", "HCT", "TBT", "TPP", "DMX", "DEE", "DUA"],
		FP12: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UCM", "HQO", "HCT", "TNG", "DMX", "DEE", "DUA"],
		FP13: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UCM", "HQO", "HCT", "TCA", "DMX", "DEE", "DUA"],
		FP14: ["SMH", "RQO", "RUA", "RUR", "XQO", "AQO", "AQD", "UCM", "HQO", "HCT", "TBT", "TPP", "DMX", "DEE", "DUA"]
	];

	/**
	 * FingerPrints combinations
	 * 
	 * v1 -> Account type
	 * v2 -> Auth method
	 * v3 -> Channel type
	 * v4 -> Activity type
	 * 
	 */
	public static segmentsGroupsDef = [
		FP01: ["TRX", "CS", "NC", "P","NM"],
		FP02: ["TRX", "CS", "NC", "P","BF"],
		FP03: ["TRX", "CS", "NC", "H","NM"],
		FP04: ["TRX", "CS", "NC", "H","DP"],
		FP05: ["TRX", "CS", "NC", "H","CW"],
		FP06: ["TRX", "CS", "NC", "C","CA"],
		FP07: ["TRX", "CS", "NC", "H","BF"],
		FP08: ["TRX", "CS", "NC", "B","AB"],
		FP09: ["TRX", "CS", "CD", "C","NM"],
		FP10: ["TRX", "CS", "CD", "C","CA"],
		FP11: ["TRX", "CS", "CD", "C","BF"],
		FP12: ["TRX", "CS", "CP", "C","NM"],
		FP13: ["TRX", "CS", "CP", "C","CA"],
		FP14: ["TRX", "CS", "CP", "C","BF"]
	];
	
	/**
	 * 
	 * @param transaccion
	 * @return
	 */
	public static getAuthTransSegms(AuthorizeTransaction authTransaccion) {
		
		String transType = "TRX";
		String custType = authTransaccion.tipoPersona.toString();
		String accType = authTransaccion.getTipoProdCtaSMH();
		String authMethod = authTransaccion.getPosEntryModeSMH();
		String channelType = authTransaccion.getChannelTypeSMH();
		String actType = authTransaccion.getActivityTypeSMH();
	
		if(custType != null) {
			def vals = [transType, accType, authMethod, channelType, actType];
			String segKey = segmentsGroupsDef.find{ it.value == vals }?.key;
			
			if(segKey != null) {
				authTransaccion.setValidSegments(segmentsGroups.find{ it.key == segKey }?.value);
				return authTransaccion.getValidSegments();
			}
		}
		
		return null;
	}
}