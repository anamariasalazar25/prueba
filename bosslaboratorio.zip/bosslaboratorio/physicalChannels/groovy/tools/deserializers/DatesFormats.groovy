package physicalChannels.groovy.tools.deserializers;

import java.util.Date;
import java.util.TimeZone;

import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.text.ParseException;

public class DatesFormats {
	
	private static final ALL_FORMATS = [
		"yyyyMMddHHmmss",
		"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
		"yyyy-MM-dd'T'HH:mm:ss'Z'",   
		"yyyy-MM-dd'T'HH:mm:ssZ",
		"yyyy-MM-dd'T'HH:mm:ss",      
		"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
		"yyyy-MM-dd'T'HH:mm:ss.SSSZ", 
		"yyyy-MM-dd HH:mm:ss",
		"MM/dd/yyyy HH:mm:ss",        
		"MM/dd/yyyy'T'HH:mm:ss.SSS'Z'",
		"MM/dd/yyyy'T'HH:mm:ss.SSSZ", 
		"MM/dd/yyyy'T'HH:mm:ss.SSS",
		"MM/dd/yyyy'T'HH:mm:ssZ",     
		"MM/dd/yyyy'T'HH:mm:ss",
		"yyyy:MM:dd HH:mm:ss",        
		"yyyyMMdd",
		"HH:mm:ss"
	];
	
	// UTC
	public static String BASIC_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	
	public static String DATE_TIME_FORMAT_A = "yyyyMMddHH:mm:ss";
	
	public static String DATE_FORMAT_A = "yyyyMMdd";
	
	public static String TIME_FORMAT_A = "HH:mm:ss";
	
	
	public static String changeDateFormat(String newFormat, Date date) {
		if(date != null) {
			DateFormat sdf = new SimpleDateFormat(newFormat);
			return sdf.format(date);
		}
		
		return null;
	}
	
	public static String getDateFormat(String date) {
		if (date != null) {
			for (String format : ALL_FORMATS) {
				SimpleDateFormat sdf = new SimpleDateFormat(format);
				try {
					sdf.parse(date);
					return format;
				}
				catch (ParseException e) {
					// Do nothing
				}
			}
		}
		return null;
	}

}





