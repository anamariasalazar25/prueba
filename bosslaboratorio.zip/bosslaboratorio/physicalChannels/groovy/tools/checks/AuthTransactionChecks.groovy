package physicalChannels.groovy.tools.checks

import org.apache.camel.Exchange;

import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang.time.DateUtils;

import physicalChannels.groovy.model.enums.TpoPersona;
import physicalChannels.groovy.model.enums.TpoProducto;
import physicalChannels.groovy.model.enums.CodTrnx;
import physicalChannels.groovy.model.AuthorizeTransaction;
import physicalChannels.groovy.tools.checks.Checks;
import physicalChannels.groovy.tools.values.Segments;
import physicalChannels.groovy.tools.Common;
import physicalChannels.groovy.model.enums.UtcInd;
import physicalChannels.groovy.tools.deserializers.DatesFormats;
import com.sas.davivienda.efm.commons.util.FMUtils;

public class AuthTransactionChecks {
	
	private static final Logger logger = LoggerFactory.getLogger("physicalChannelslog");

	/**
	 * Verify if transactions attributes
	 * @param transaction Transaction object
	 */
	public static AuthorizeTransaction checkAuthTransAttributes(AuthorizeTransaction authTrans) {
		
		ArrayList validSegments = Segments.getAuthTransSegms(authTrans);
		
		if(validSegments != null) {
			
			// Check transaction date and time
			validDateTime(authTrans);
			
			HashMap authTransHash = Checks.checkFields(authTrans, validSegments, "authorizeTransaction");
			AuthorizeTransaction newTransaction = Common.hashMapToObject(authTransHash, AuthorizeTransaction.class);

			String trxDate = newTransaction.getTransactionDate();
			String trxTime = newTransaction.getTransactionTime();

			Date date = new SimpleDateFormat("yyyyMMdd HH:mm:ss").parse(trxDate + " " + trxTime);

			// GMT date-time
			Date gmtDate = getCompleteTransactionDateGMT(trxDate, trxTime);
			
			newTransaction.setTransactionDate(formatTransactionDateGMT(date));
			newTransaction.setTransactionTime(formatTransactionTimeGMT(date));

			newTransaction.setTransactionDateGMT(formatTransactionDateGMT(gmtDate));
			newTransaction.setTransactionTimeGMT(formatTransactionTimeGMT(gmtDate));

			return newTransaction;
		}
		
		return null;
	}
	
	/**
	 *  Verify if auth transaction date and time format are correct. If they are not, these fields are going to be null
	 * @param authTrans Auth transaction
	 */
	private static void validDateTime(AuthorizeTransaction authTrans) {
		
		String transDate = authTrans.transactionDate;
		String transTime = authTrans.transactionTime;
		
		if(!Checks.dateVerification(transDate, DatesFormats.DATE_FORMAT_A)) {
			authTrans.setTransactionDate(null);
		}
		
		if(!Checks.dateVerification(transTime, DatesFormats.TIME_FORMAT_A)) {
			authTrans.setTransactionTime(null);
		}
	}

	/**
	 * Authorize Transaction DB Enrichment
	 * @param authTrans Authorize Transaction object to enrich
	 */
	public static void authTransEnrichment(AuthorizeTransaction authTrans, Exchange exchange) {
		
		Map<String,Object> inputMsg = exchange.getProperty("inputMsg",Map.class);

		if(authTrans != null && inputMsg != null) {
			
			// Get DB-Enrich data

			// TIPO_PERSONA
			String tipoPersona = inputMsg.get("dbenr_prod_type");

			// TIPO_PRODUCTO_CTA
			String tipoProdCTA = inputMsg.get("dbenr_prod_code");

			String idType = inputMsg.get("dbenr_id_type");
			String idNumber = inputMsg.get("dbenr_id_number");
			String custNumber = inputMsg.get("dbenr_cust_num");
			String payeerAcctType = inputMsg.get("payeerAccountType");
			String payeeAcctType = inputMsg.get("payeeAccountType");
			String payeeAcctNumber = inputMsg.get("payeeAccountNumber");
			
			String tppAcctNum = inputMsg.get("tpp_acct_num");
			if(FMUtils.hasValue(tppAcctNum)) {
				payeeAcctNumber = tppAcctNum; 
			}
			
			if(FMUtils.hasValue(idType) && FMUtils.hasValue(idNumber)){
				inputMsg.put("rua_2byte_string_002",idType);
				inputMsg.put("rua_20byte_string_002",idNumber);
				inputMsg.put("xqo_cust_num",custNumber);
			}

			if(FMUtils.hasValue(payeeAcctNumber) && payeeAcctNumber.length() >= 16) {
				payeeAcctType = FMUtils.hasValue(payeeAcctType) && ("01".equals(payeeAcctType)|| "03".equals(payeeAcctType))? payeeAcctNumber.substring(0,4):payeeAcctType;
				inputMsg.put("rua_4byte_string_001",payeeAcctType);
			}

			// user Balance
			String balance = exchange.getIn().getHeader("balance");

			//H2H hallazgo 12
			//Multi-org ATM
			String channelId = exchange.getProperty("channelId");
			if(channelId != null){
				switch(channelId){
					case "03":
						String activityType = authTrans.getActivityTypeSMH();
						if(FMUtils.isNullOrEmpty(tipoPersona)){
							tipoPersona = "P";
						}
						tipoPersona = tipoPersona + channelId + activityType;
					break;
					case "32":
						if(FMUtils.isNullOrEmpty(tipoPersona)){
							tipoPersona = "E";
						}
					break;
					default:
					break;
				}
			}

			if(FMUtils.hasValue(tipoPersona)){
				authTrans.setTipoPersona(TpoPersona.valueOf(tipoPersona));
			}else {
				authTrans.setTipoPersona(TpoPersona.valueOf('P'));
			}

			if(FMUtils.hasValue(tipoProdCTA)){
				authTrans.setTipoProdCta(TpoProducto.textValueOf(tipoProdCTA));
			}else {
				authTrans.setTipoProdCta(TpoProducto.textValueOf(payeerAcctType));
			}

			String prodNum = inputMsg.get("aqo_acct_num");

			if(FMUtils.hasValue(prodNum)){
				authTrans.setPayeerAccountNumber(prodNum);
			}

			authTrans.setBalance(balance);
		}
	}

	private static String completeATMTransaction(AuthorizeTransaction authTrans, Exchange exchange){
		
		Map<String,Object> inputMsg = exchange.getProperty("inputMsg",Map.class);
		String cardMedia = "C";

		String ucmPos = authTrans.posEntryMode.toString();

		if("90".equals(ucmPos)){
			cardMedia = "M";
		}

		inputMsg.put("ucm_pos",ucmPos);
		inputMsg.put("hct_media",cardMedia);

		return null;
	}

	private static void getMessageTypeTran(Map<String,Object> sasAuthTransactionMap, String channelId, Exchange exchange){

		String respRequired = "1";
		Boolean isResponseRequired = true;
		String messageType = "0200";
		String entryCount = sasAuthTransactionMap.get("entryCount");

		if(channelId != null && ("32".equals(channelId) || ("00".equals(channelId) && "220".equals(entryCount)))){
			respRequired = "0";
			isResponseRequired = false;
			messageType = "0220";
		}
		sasAuthTransactionMap.put("hqo_msg_type",messageType);
		sasAuthTransactionMap.put("smh_resp_req",respRequired);
		exchange.setProperty("isResponseRequired", isResponseRequired);

		exchange.setProperty("mti", "0200");

	}
	
	private static Date getCompleteTransactionDateGMT(String transactionDate, String transactionTime) {
		
		if(transactionDate != null && transactionTime != null) {
			Date date = new SimpleDateFormat("yyyyMMdd HH:mm:ss").parse(transactionDate + " " + transactionTime);
			Date gmtDate = DateUtils.addHours(date, 5);
			
			return gmtDate;
		}
		
		return null;
	}
	
	private static String formatTransactionDateGMT(Date date) {
		
		String patternDate = "yyyyMMdd";
		DateFormat df = new SimpleDateFormat(patternDate);
		
		if(date != null) {
			return df.format(date);
		}
		
		return null;
	}
	
	private static String formatTransactionTimeGMT(Date date) {

		String patternTime = "HH:mm:ss";
		DateFormat df = new SimpleDateFormat(patternTime);

		if(date != null) {
			return df.format(date);
		}

		return null;
	}

	private static String checkAccounts(AuthorizeTransaction authTrans, Map<String,Object> authTransactionMap){
		String payerAccountType = authTrans.getPayeerAccountType();
		String payerAccountNumber = authTrans.getPayeerAccountNumber();
		String payerCardNumber = authTrans.getPayeerCardNumber();
		String payeeProductNumber = authTrans.getPayeeAccountNumber();
		String trxMean = authTrans.getProductoOriginador();
		String activityType = authTrans.getActivityTypeSMH();

		String productId = "ACCOUNT_NUM".equals(trxMean) ? payerAccountNumber : payerCardNumber;
		authTransactionMap.put("tbt_self_acct_ind",authTrans.selfCustomerIndicator);
		authTransactionMap.put("productId",productId);
		authTransactionMap.put("productType",payerAccountType);

		String accountRelationship = payerAccountType == '01' ? 'C' : 'S';

		authTransactionMap.put("aqo_acct_num",payerAccountNumber);
		authTransactionMap.put("aqd_acct_relationship",accountRelationship);
		
		boolean isTransfer = ("BF".equals(activityType) && payeeProductNumber != null);
		authTransactionMap.put("transfer",isTransfer);

		if(FMUtils.hasValue(payerCardNumber) && payerCardNumber.length() > 6){
			authTransactionMap.put("rua_8byte_string_001",payerCardNumber.substring(0,6));
		}
	}
	
	private static boolean isEnrichedByProductNumber(AuthorizeTransaction authTrans, Map<String,Object> authTransactionMap){
		
		String payerAcctNum = authTransactionMap.get("productId");
		String channelId = authTransactionMap.get("channelId");
		String activityType = authTransactionMap.get("activityTypeSMH");

		if("TEL_ROJO".equals(channelId) && "NM".equals(activityType) && (FMUtils.isNullOrEmpty(payerAcctNum))) {
			String refNum1 = authTransactionMap.get("referenceNumber1");
			String refNum2 = authTransactionMap.get("referenceNumber2");
			authTransactionMap.put("rua_2byte_string_002",refNum1);
			authTransactionMap.put("rua_20byte_string_002",refNum2);
			if(refNum1 != null && refNum2 != null) {
				authTransactionMap.put("xqo_cust_num",refNum1.concat(refNum2));
			}
			return false;
		}
		return true;
	}

}
