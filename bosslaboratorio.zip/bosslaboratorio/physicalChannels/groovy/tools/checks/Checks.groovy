package physicalChannels.groovy.tools.checks;

import java.lang.reflect.Field
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonParseException;

import java.util.HashMap;
import java.util.ArrayList;

import java.lang.IllegalArgumentException;

import physicalChannels.groovy.model.sas.SASTemplate;
import physicalChannels.groovy.model.sas.interfaces.SASInterface;
import physicalChannels.groovy.model.sas.enums.SASAuthorizeTransaction;
import physicalChannels.groovy.tools.values.Segments;
import physicalChannels.groovy.tools.Common;
import physicalChannels.groovy.tools.deserializers.DatesFormats;
import physicalChannels.groovy.exceptions.PhysicalChannelException;

public class Checks {
	
	private static final Logger logger = LoggerFactory.getLogger("physicalChannelslog");
	
	/**
	 * List with SAS enumerations values
	 * key -> Name of enumaration representation (SAS mappers) (physicalChannels.groovy.model.sas.enums)
	 * value -> Enumeration class 
	 */
	private static enumsList = [
		"authorizeTransaction": SASAuthorizeTransaction
	];
	
	/**
	 * The content of an object is deconstructed (excepting date type)
	 * @param object Object that wants to be deconstruyed
	 * @return HashMap with object attributes
	 */
	private static HashMap getObjectAttList(Object object) {
		if(object instanceof java.util.Date) return null;
		return Common.getObjectAttList(object);
	}

	/**
	 * Get if an object has attributes with null values
	 * @param object Object to analyze
	 * @return true or false depending if at least one of object attribute value is null
	 */
	private static boolean getObjectNullAtt(Object object) {
		try {			
			
			def atts = getObjectAttList(object);
			
			if(atts!= null && atts.size() > 0) {
				for (attribute in atts) {					
					if(attribute.value.equals(null)) {
						return true;
					}	
					
					if(getObjectNullAtt(attribute.value) ) {
						return true;
					}
				}
			}
			return false;
			
		}

		catch(Exception e) {
			e.printStackTrace();			
			return true;
		}
	}
	
	/**
	 * 
	 * Validate if an object is null
	 * @param object Object to evaluate
	 * @param errorMess Error Message to show if an object is null
	 * @throws VirtualChannelsException If an object is null
	 */
	public static void checkNull(Object object, String errorMess) throws PhysicalChannelException {
		
		if(object == null) {
			throw new PhysicalChannelException(errorMess);
		}
			
	}
	
	/**
	 * Validate if an object has attributes with null values
	 * @param object Object to evaluate
	 * @throws VirtualChannelsException If the object has attributes with null values
	 */
	public static void checkNull(Object object) throws PhysicalChannelException {

		if(getObjectNullAtt(object)) {
			throw new PhysicalChannelException(111) ;
		}
		
	}
	
	/**
	 * Verify if attributes of an SASTemplate object are valid: Length and segments
	 * @param object SASTemplate object to evaluate 
	 * @param validSegments List of object valid segments eg. CSBF: ["SMH", "RQO", "RUA", ... ]
	 * @param enumValue Key of enumsList, representing enumeration mapper
	 * @return HashMap Map of object representation
	 * @throws VirtualChannelsException If an attribute value min size is not valid
	 */
	public static HashMap checkFields(SASTemplate object, ArrayList validSegments, String enumValue) throws PhysicalChannelException {

		def attrsMap = Common.getObjectAttList(object);
		def finalAttrsMap = attrsMap.clone();
		
		for(att in attrsMap) {
			
			def key = att.key;
			def value = att.value;

			if(value instanceof SASTemplate == false) {
				
				try {

					def enumAtt = enumsList[enumValue].valueOfElement(key.toString());
					
					if(enumAtt != null) {
					
						String attSegement = enumAtt.getSegment();
		
						if(validSegments.contains(attSegement)) {
							evalValue(key, value, enumAtt, finalAttrsMap)
						}
					}
				}
				catch(IllegalArgumentException e) {
					logger.error("Attribute not found in given enumeration: " + key);
				}
			}
			
			else {
				finalAttrsMap[key] = checkFields(value, validSegments, key);
			}
		}

		return finalAttrsMap;
	}
	
	/**
	 * Verify fields values
	 * @param key Field key (object attribute name)
	 * @param value Field value (object attribute value)
	 * @param enumAtt SASTemplate enum of object
	 * @param finalAttrsMap Final hashmap with object values
	 */
	private static void evalValue(key, value, enumAtt, finalAttrsMap) throws PhysicalChannelException {
		
		if(value == null) {
			finalAttrsMap[key] = "";
		}
		
		else {
			if(value instanceof String) {
				
				int valueLength = value.length();
	
				if(valueLength >= 1) {
					finalAttrsMap[key] = Common.truncateString(value, enumAtt.getMaxLength());
				}
			}
			
			else if(value instanceof Boolean) {
				finalAttrsMap[key] = Common.boolToInt(value);
			}
			
			else if(value instanceof Integer) {
				String val = Common.truncateString(value.toString(), enumAtt.getMaxLength());
				finalAttrsMap[key] = Integer.valueOf(val);
			}
		}
	}
	
	/**
	 * Verify Date format
	 * @param date String date
	 * @param format Correct format
	 * @return
	 */
	public static boolean dateVerification(String date, String format) {
		
		if(DatesFormats.getDateFormat(date).equals(format)){
			return true;
		}
		
		return false;
	}
	
}


