package physicalChannels.groovy.tools;

import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.TimeZone;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;

import java.text.SimpleDateFormat;

import physicalChannels.groovy.model.sas.SASTemplate;
import physicalChannels.groovy.tools.deserializers.DatesFormats;

public class Common {
		
	public static String intToStringWithFront(String front, int value, int length) {
		
		String valueString = Integer.toString(value);
		if(valueString.length() == length)  valueString = front + valueString;
		
		return valueString;
		
	}
	
	/**
	 * Get map of object attributes
	 * @param object Object to evaluate
	 * @return HashMap with object content
	 */
	public static getObjectAttList(Object object) {
		return object.metaClass.properties.findAll { it.name != 'class' && it.name != 'metaClass' }.inject([:]) { acc, e -> acc[e.name] = e.getProperty(object); acc };
	}
	
	/**
	 * Cast boolean value to integer
	 * @param b Boolean value
	 * @return 1 if b = true; false otherwise
	 */
	public static int boolToInt (Boolean b) {
		return b ? 1 : 0;
	}
	
	/**
	 * Transform HashMap into SASTemplate object
	 * @param map HashMap to transform
	 * @param sasClass SASTemplate instance class eg: Transaction.class
	 * @return SASTemplate object
	 */
	public static SASTemplate hashMapToObject(HashMap map, sasClass) {
		
		final ObjectMapper mapper = new ObjectMapper();
		mapper.enable(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE);
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		
		return mapper.convertValue(map, sasClass);
		
	}
	
	public static String getIfDateIsUTC(String date) {
		try {
			String dateFormat = DatesFormats.getDateFormat(date);
			SimpleDateFormat format = new SimpleDateFormat(dateFormat);
			Date dateVal = format.parse(date);
			String time = DatesFormats.changeDateFormat(DatesFormats.TIME_FORMAT_A, dateVal);
			
			if(time.equals("00:00:00")) {
				return 'N';
			}
			
			if(!dateFormat.equals(DatesFormats.BASIC_FORMAT)) {
				return 'M';
			}
			
			return 'Y';
		}
		catch(Exception e) {
			return 'N';
		}
		
	}
	
	/**
	 * Truncate string value
	 * 
	 * @param value Value to truncate
	 * @param maxValue Limit number to get inside string
	 * @return 
	 */
	public static String truncateString(String value, int maxValue) {
		
		int valueLength = value.length();
		
		if(valueLength > maxValue) {
			return value.substring(0, maxValue);
		}
		return value;
	}
	
	public static Map objectToMap(Object obj) {
		
		ObjectMapper oMapper = new ObjectMapper();
		Map<String, Object> map = oMapper.convertValue(obj, Map.class);
		
		return map;
	}
	
	/**
	 * Fill string with spaces
	 * @param val Value to fill
	 * @param valLength Final size of string value
	 */
	public static String fillStringWithSpace(String val, int valLength) {
		
		int diff = valLength - val.length();
		
		if(diff <= 0) {
			return val;
		}
		
		return String.format("%-"+valLength+ "s", val);
	}

}


