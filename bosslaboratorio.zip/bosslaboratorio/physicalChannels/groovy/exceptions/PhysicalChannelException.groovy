package physicalChannels.groovy.exceptions;

public class PhysicalChannelException extends Exception {
	
	private static final long serialVersionUID = 1L;

	private int codError;
	private String message;

	public PhysicalChannelException(int codError){
		super();
		this.codError = codError;
	}
	
	public PhysicalChannelException(String message){
		super();
		this.message = message;
	}
	
	public PhysicalChannelException(int codError, String message){
		super();
		this.codError = codError;
		this.message = message;
	}


	@Override
	public String getMessage(){
		
		switch(this.codError){
			
			case 111:
				this.message = "Not null values are accepted on mandatory fields: " + this.message;
				break;
			case 222:
				this.message = "Invalid input: " + this.message;
				break;
		}

		return this.message;
	}
}
