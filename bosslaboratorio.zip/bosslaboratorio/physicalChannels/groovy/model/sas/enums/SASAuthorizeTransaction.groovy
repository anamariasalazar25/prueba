package physicalChannels.groovy.model.sas.enums;

import physicalChannels.groovy.model.sas.interfaces.SASInterface;

public enum SASAuthorizeTransaction implements SASInterface {
	
	//DB-ENR
	tipoPersona("rua_ind_012", 1, 1, "RUA", true),
	tipoProdCta("dua_8byte_string_004", 8, 8, "DUA", true),
	
	tipoPersonaSMH("smh_cust_type", 1, 1, "SMH", false),
	tipoPersonaMultiSMH("smh_multi_org_name", 8, 8, "SMH", false),
	tipoProdCtaSMH("smh_acct_type", 2, 2, "SMH", false),
	tipoProdCtaAQD("aqd_acct_relationship", 1, 1, "AQD", false),
	tipoProdCtaTPP("tpp_acct_type", 2, 2, "TPP", false),
	
	agreementId("rua_10byte_string_002", 10, 10, "RUA", false),
	appliedCount("rua_numeric_001", 8, 8, "RUA", false),
	branchId("hbb_branch_id", 4, 4, "HBB", false),
	branchUser("hbb_staff_id", 10, 10, "HBB", false),
	channelId("rua_2byte_string_007", 2, 2, "RUA", true),
	checkNumber("rua_20byte_string_001", 10, 10, "RUA", false),//
	daviplataTerminalNum("dua_8byte_string_006", 4, 4, "DUA", false),
	differentialIndicator("tab_file_ref", 8, 8, "TAB", false),//
	entryCount("tab_entry_count", 6, 6, "TAB", false),
	payeeAccountNumber("tpp_acct_num", 34, 34, "TPP", false),
	payeeAccountType("rua_4byte_string_001", 4, 4, "RUA", false),
	payeeBankId("tpp_bank_num", 15, 15, "TPP", false),//
	payeeIdentificationNumber("rua_20byte_string_003", 20, 20, "RUA", false),
	payeeIdentificationType("rua_2byte_string_004", 2, 2, "RUA", false),
	payeerAccountNumber("aqo_acct_num", 34, 34, "AQO", false),
	payeerBankId("rua_4byte_string_002", 4, 4, "RUA", false),
	payeerCardNumber("hqo_card_num", 20, 20, "HQO", false),
	phoneNumber("hpb_ani_num", 32, 32, "HPB", false),
	referenceNumber1("tbt_billing_ref_num", 32, 32, "TBT", false),
	referenceNumber2("tpp_num", 32, 32, "TPP", false),
	selfCustomerIndicator("tbt_self_acct_ind", 1, 1, "TBT", false),
	terminalId("hct_term_id", 8, 8, "HCT", false),
	totalDebit("tab_total_debit", 22, 22, "TAB", false),
	transactionalMean("rua_2byte_string_008", 2, 2, "RUA", true),
	transactionAmount("tbt_tran_amt", 22, 22, "TBT", false),
	transactionCity("hct_term_post_code", 10, 10, "HCT", false),///////
	transactionCode("rua_10byte_string_001", 6, 6, "RUA", false),
	transactionCountryCode("hct_term_cntry_code", 3, 3, "HCT", true),//
	transactionCurrencyCode("tbt_tran_curr_code", 3, 3, "TBT", true),
	transactionDate("rqo_tran_date_alt", 8, 8, "RQO", true),//
	transactionId("tbt_ref_num", 32, 32, "TBT", false),
	transactionTime("rqo_tran_time_alt", 11, 11, "RQO", true),//
	transactionDateGMT("rqo_tran_date", 8, 8, "RQO", true),//
	transactionTimeGMT("rqo_tran_time", 11, 11, "RQO", true),//
	transactionUtcIndicator("rqo_tran_utc_flag", 1, 1, "RQO", true),
	transactionMotiveConcept("rua_4byte_string_004", 4, 4, "RUA", true), 

	//BOSS
	transactionAmountTCA("tca_client_amt", 22, 22, "TCA", false),
	transactionAmountTBT("tbt_mod_amt", 22, 22, "TBT", false),
	transactionCurrencyCodeTCA("tca_client_curr_code", 3, 3, "TCA", true),
	transactionIdTCA("tca_ref_num", 32, 32, "TCA", false),
	transactionIdTNG("dua_40byte_string_003", 32, 32, "TNG", false),
	activityTypeSMH("smh_activity_type", 2, 2, "SMH", false),
	transTypeTBT("tbt_tran_type", 1, 1, "TBT", false),
	channelTypeSMH("smh_channel_type", 1, 1, "SMH", false),
	posEntryModeSMH("smh_authenticate_mtd", 2, 2, "SMH", false),
	posEntryModeUCM("ucm_card_present", 1, 1, "UCM", false),
	reveralIndicator("tca_reversal_ind", 1, 1, "TCA", false),
	tppPayeePayerInd("tpp_payee_payer_ind", 1, 1, "TPP", false),
	
	// STRATUS
	balance("aqd_avail_bal", 22, 22, "AQD", true),
	
	transStatusTBT("tbt_tran_status", 1, 1, "TBT", false),	
	bankTypeTPP("tpp_bank_type", 1, 1, "TPP", false),
	billCatTBT("tbt_bill_cat", 2, 2, "TBT", false),
	
	codRespuestaVal("tca_auth_sys_dec", 1, 1, "TCA", false),
		

	private final String authTrans;
	private final Integer minLength;
	private final Integer maxLength;
	private final String segment;
	private final Boolean req;
	
	private SASAuthorizeTransaction(final String authTrans, final Integer minLength, final Integer maxLength, final String segment, final Boolean req) {
		this.authTrans = authTrans;
		this.minLength = minLength;
		this.maxLength = maxLength;
		this.segment = segment;
		this.req = req;
	}

	public static SASInterface valueOfElement(String name) {
		
		try {
			def val = SASAuthorizeTransaction.valueOf(name);
			return val;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@Override
	public String getAtt() {
		return this.authTrans;
	}
	
	@Override
	public Integer getMinLength() {
		return this.minLength;
	}
	
	@Override
	public Integer getMaxLength() {
		return this.maxLength;
	}
	
	@Override
	public String getSegment() {
		return this.segment;
	}
	
	@Override
	public Boolean getReq() {
		return this.req;
	}
}
