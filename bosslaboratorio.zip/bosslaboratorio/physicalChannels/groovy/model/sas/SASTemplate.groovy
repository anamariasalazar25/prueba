package physicalChannels.groovy.model.sas;

import java.util.Map;

import org.slf4j.Logger

import java.util.HashMap;
import java.util.ArrayList;

import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;

import physicalChannels.groovy.tools.values.Segments;
import physicalChannels.groovy.model.enums.CodTrnx;
import physicalChannels.groovy.tools.Common;
import physicalChannels.groovy.tools.deserializers.DatesFormats;

@XmlAccessorType(XmlAccessType.NONE)
public abstract class SASTemplate {
	
	private static final Logger logger = LoggerFactory.getLogger("physicalChannelslog");
	
	private static ArrayList validSegments = null;
	
	/**
	 * Map SASTemplate java object attributes to SAS fields
	 * @return HashMap with SAS fields
	 */
	public abstract Map<String,Object> obtainSASFormat();

	/**
	 * Map SASTemplate java object attributes to SAS fields
	 * @param object SASTemplate object
	 * @param enumer SAS enumeration mapper
	 * @return HashMap with object SAS fields
	 */
	protected <T,S> Map<String,Object> sasValidation(T object, S enumer) {
		
		def attrsMap = Common.getObjectAttList(object);
		if(attrsMap.containsKey("validSegments")) this.validSegments = attrsMap.get("validSegments");
		
		if(this.validSegments != null) {
					
			Map<String,Object> sasMap = new HashMap<String, Object>();
			
			for(att in attrsMap) {
				
				def attKey = att.key;
				def attVal = att.value;
				
				if(attVal instanceof SASTemplate == false) {
							
					if(attVal != null) {
						try {
							
							def sasValue = enumer.valueOfElement(attKey);
							
							if (sasValue != null && validSegments.contains(sasValue.getSegment())) {
								sasMap.put(sasValue.getAtt(), attVal.toString());
								
								/*if(attVal instanceof CodTrnx == true) {
									sasMap.put(sasValue.getAtt(), Common.fillStringWithSpace(attVal.toString(), 6));
								}
								
								else {
								}*/
							}
						}
						
						catch(Exception e) {
							logger.error(e.getMessage() + ": " + att.key);
						}
					}		
				}
				
				else {
					sasMap.putAll(att.value.obtainSASFormat());
				}
				
			}
			return sasMap;
		}
		return null;
    }
}
