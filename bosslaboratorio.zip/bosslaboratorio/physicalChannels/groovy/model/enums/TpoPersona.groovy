package physicalChannels.groovy.model.enums;

import com.google.gson.annotations.SerializedName;
 
public enum TpoPersona {
	
	P("P", "I", "CF_PERSONAS"),
	E("E", "B", "CF_EMPRESAS"),
	P03CA("P", "I", "NACIONAL"),
	E03CA("E", "B", "NACIONAL"),
	P03NM("P", "I", "NO_TX_TC_TD"),
	E03NM("E", "B", "NO_TX_TC_TD")
	
	private final String tpoPersonaName;
	private final String tpoPersonaSMH;
	private final String tpoPersonaMulti;
	
	private TpoPersona(final String tpoPersonaName, final String tpoPersonaSMH, final String tpoPersonaMulti) {
		this.tpoPersonaName = tpoPersonaName;
		this.tpoPersonaSMH = tpoPersonaSMH;
		this.tpoPersonaMulti = tpoPersonaMulti;
	}
	
	@Override
	public String toString() {
		return this.tpoPersonaName;
	}
}
