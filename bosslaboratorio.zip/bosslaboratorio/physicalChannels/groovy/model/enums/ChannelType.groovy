package physicalChannels.groovy.model.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

@XmlEnum
public enum ChannelType {

        @XmlEnumValue("00") OFICINA("00", "H"),
        @XmlEnumValue("03") ATM("03", "C"),
        @XmlEnumValue("05") TEL_ROJO("05", "P"),
        @XmlEnumValue("22") KIOSKO("22", "H"),
        @XmlEnumValue("24") CORRESPONSALES("24", "H"), //Adicion canal 24 rdb stratus
        @XmlEnumValue("26") MULTISERV("26", "C"),
        @XmlEnumValue("32") H2H("32", "B"),
        @XmlEnumValue("33") APP_ACTIVO_PROC_ESP("33", "H"),
        @JsonEnumDefaultValue DEFAULT(null, null)


        private final String channelName;
        private final String channelSMH;

        private ChannelType(final String channelName, final String channelSMH) {
                this.channelName = channelName;
                this.channelSMH = channelSMH;
        }

        @Override
        public String toString() {
                return this.channelName;
        }
}