package physicalChannels.groovy.model.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

@XmlEnum
public enum TransMeanType {
	
	@XmlEnumValue("00") AUTOMATICO("00", "NC"),
	@XmlEnumValue("01") TALONARIO("01", "NC"),
	@XmlEnumValue("03") TAR_DEBITO("03", "CD"),
	@XmlEnumValue("04") CLAVE_VIR("04", "NC"),
	@XmlEnumValue("05") CHEQUERA("05", "NC"),
	@XmlEnumValue("10") COD_BARRAS("10", "NC"),
	@XmlEnumValue("11") TAR_DEBITO_CHIP("11", "CD"),
	@XmlEnumValue("13") CLAVE_EMP("13", "NC"),
	@XmlEnumValue("14") VOL_ESPECIAL("14", "NC"),
	@XmlEnumValue("15") OPER_OFI("15", "NC"),
	@XmlEnumValue("16") COM_VOZ("16", "NC"),
	@XmlEnumValue("17") DAVI_MON("17", "NC"),
	@XmlEnumValue("18") RET_SIN_TAR("18", "NC"),
	@XmlEnumValue("99") OTROS("99", "NC"),
	@XmlEnumValue("?") RET_OR("?", "NC"),
	@XmlEnumValue("null") DEFAULT("", "NC")
	
	
	private final String transMeanName;
	private final String transMeanSMH;

	private TransMeanType(final String transMeanName, final String transMeanSMH) {
		this.transMeanName = transMeanName;
		this.transMeanSMH = transMeanSMH;
	}
	
	@Override
	public String toString() {
		return this.transMeanName;
	}
}
