package physicalChannels.groovy.model.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

@XmlEnum
public enum UtcInd {
	
	Y("Y"),
	M("M"),
	@JsonEnumDefaultValue DEFAULT(null)

	
	private final String utcIndicator;

	private UtcInd(final String utcIndicator) {
		this.utcIndicator = utcIndicator;
	}
	
	@Override
	public String toString() {
		return this.utcIndicator;
	}
}
