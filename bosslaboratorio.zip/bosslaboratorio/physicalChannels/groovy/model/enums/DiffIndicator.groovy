package physicalChannels.groovy.model.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

@XmlEnum
public enum DiffIndicator {
	
	@XmlEnumValue("1") DIFF1("1"),
	@XmlEnumValue("2") DIFF2("2"),
	@XmlEnumValue("3") DIFF3("3"),
	@JsonEnumDefaultValue DEFAULT(null)
	
	
	private final String diffIndicator;

	private DiffIndicator(final String diffIndicator) {
		this.diffIndicator = diffIndicator;
	}
	
	@Override
	public String toString() {
		return this.diffIndicator;
	}
}
