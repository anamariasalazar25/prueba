package physicalChannels.groovy.model.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

@XmlEnum
public enum TransMotiveConcept {
	
	@XmlEnumValue("0006") MOT1("0006"),
	@XmlEnumValue("0061") MOT2("0061"),
	@XmlEnumValue("0319") MOT3("0319"),
	@JsonEnumDefaultValue DEFAULT(null)
	
	
	private final String transMotCon;

	private TransMotiveConcept(final String transMotCon) {
		this.transMotCon = transMotCon;
	}
	
	@Override
	public String toString() {
		return this.transMotCon;
	}
}
