package physicalChannels.groovy.model.enums;

public enum CodRespuesta {
	
	APROBADA("1"),
	DECLINADA("4")
	
	
	private final String codRespuestaTCA;
	
	private CodRespuesta(final String codRespuestaTCA) {
		this.codRespuestaTCA = codRespuestaTCA;
	}
	
	public static CodRespuesta codValueOf(String codRespuesta){

		for(CodRespuesta value : values()) {
						
			if(codRespuesta.equals("00")) {
				return CodRespuesta.APROBADA;;
			}
			
			return CodRespuesta.DECLINADA;
		}

	}
	
	@Override
	public String toString() {
		return this.codRespuestaTCA;
	}
}
