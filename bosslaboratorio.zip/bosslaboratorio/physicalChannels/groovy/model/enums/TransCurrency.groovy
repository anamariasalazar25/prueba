package physicalChannels.groovy.model.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

@XmlEnum
public enum TransCurrency {
	
	@XmlEnumValue("170") COP("170"),
	@JsonEnumDefaultValue DEFAULT(null)
	
	
	private final String transCurrency;

	private TransCurrency(final String transCurrency) {
		this.transCurrency = transCurrency;
	}
	
	@Override
	public String toString() {
		return this.transCurrency;
	}
}
