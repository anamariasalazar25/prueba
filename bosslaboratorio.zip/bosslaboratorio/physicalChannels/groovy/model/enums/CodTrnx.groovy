package physicalChannels.groovy.model.enums

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

@XmlEnum
public enum CodTrnx {
	
	@XmlEnumValue("002020") RETIRO_1("002020", "P", "CA/CW", "Retiros", "R"),
	@XmlEnumValue("002022") RETIRO_2("002022", "P", "CA/CW", "Retiros", "N"),
    @XmlEnumValue("002130") RETIRO_5("002130", "P", "CW", "Retiros", "N"), //Adicion cod trnx rdb stratus
	@XmlEnumValue("005260") TRANS_1("005260", "T", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("005270") TRANS_2("005270", "T", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("005600") RET_EFEC_CUENTA_SIN_TAR("005600", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("005602") RET_CHEQUE("005602", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("005604") RET_EFEC_CUENTA_TAR("005604", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("005608") RET_AFC_TAR("005608", "P", "CA/CW", "Retiros", "N"),
	@XmlEnumValue("005614") RET_CHEQUE_CUENTA_TAR("005614", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("005622") RET_EFEC_CUENTA_SIN_TAR_CON_SUPERV_1("005622", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("005632") RETIRO_3("005632", "P", "CA/CW", "Retiros", "N"),
	@XmlEnumValue("005642") RET_EFEC_CUENTA_SIN_TAR_CON_SUPERV_2("005642", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("005644") RET_EFEC_CUENTA_CON_TAR_CON_SUPERV("005644", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("005648") RETIRO_4("005648", "P", "CA/CW", "Retiros", "N"),
	@XmlEnumValue("005652") PAGO_CHEQUE_VENT_CON_SUPERV("005652", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("005654") RET_CHEQUE_CUENTA_TAR_CON_SUPERV("005654", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("005656") RET_CUENTA_JURIDICA("005656", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("005658") RET_PERSONA_JURIDICA_CHEQUE("005658", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("005660") NOTA_DEBITO("005660", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("005680") DEBITO_1("005680", "B", "BF", "Egreso", "N"),
	@XmlEnumValue("005682") TRANS_3("005682", "T", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("005686") TRANS_4("005686", "T", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("005688") DEV_CHEQUE("005688", "", "BF", "Egreso", "N"),
	@XmlEnumValue("005695") TRANS_5("005695", "T", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("005698") DEPOSITO_1("005698", "", "DP", "Ingresos", "N"),
	@XmlEnumValue("005770") NOTA_CRED_CUENTA_CORR_AHOR("005770", "", "DP", "Pago Ingresos", "N"),
	@XmlEnumValue("005780") NOTA_CRED_TAR_CRED("005780", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("005798") DEPOSITO_2("005798", "", "DP", "Ingresos", "N"),
	@XmlEnumValue("009660") DEBITO_2("009660", "", "BF", "Egresos", "N"),
	@XmlEnumValue("009710") INGRESOS("009710", "", "DP", "Ingresos", "N"),
	@XmlEnumValue("009738") REC_PLAN_ASIS("009738", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("009750") REC_SERV("009750", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("009770") CREDITO("009770", "", "DP", "Ingresos", "N"),
	@XmlEnumValue("000378") ACT_CHEQ_TALON("000378", "", "NM", "No Valor", "N"),
	@XmlEnumValue("000524") CAMBIO_CLAVE_BM("000524", "", "NM", "No Valor", "N"),
	@XmlEnumValue("003536") CAMBIO_CLAVE_SERV("003536", "", "NM", "No Valor", "N"),
	@XmlEnumValue("003538") CAMBIO_CLAVE_CAFE("003538", "", "NM", "No Valor", "N"),
	@XmlEnumValue("009090") CAMBIO_CLAVE1("009090", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005050") CAMBIO_SALDO("005050", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005150") CONS_ESTADO_CUENTA("005150", "", "NM", "No Valor", "N"),
	@XmlEnumValue("000320") BLOQUEO_CTA("000320", "", "NM", "Aceptar", "N"),
	@XmlEnumValue("000526") BLOQUEO_DESBLOQ_BM("000526", "", "NM", "No Valor", "N"),
	@XmlEnumValue("003537") BLOQUEO_CLAVE_SERV("003537", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005700") CONSIG_EFEC_CTA_AHO_CORR("005700", "", "NM", "No Valor", "N"),
	@XmlEnumValue("007525") ACTIVA_BLQTX("007525", "", "NM", "No Valor", "N"),
	@XmlEnumValue("000372") ASIG_TAR("000372", "", "NM", "No Valor", "N"),
	@XmlEnumValue("000398") DEROG_TAR("000398", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005100") CON_SALDO_1("005100", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005110") CON_SALDO_2("005110", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005111") CON_SALDO_3("005111", "", "NM", "No Valor", "N"),
	@XmlEnumValue("000124") CON_CUENTA_TAR("000124", "", "NM", "No Valor", "N"),
	@XmlEnumValue("000358") CON_CHEQ_DEV("000358", "", "NM", "No Valor", "N"),
	@XmlEnumValue("001706") ASOC_DEB_AUT("001706", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005104") CON_SALDO_CTA_TAR("005104", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005113") CON_SALDO_CTA_BOL("005113", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005128") CON_SALDO_CAN_TAR("005128", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005360") CAN_PROD("005360", "", "NM", "No Valor", "N"),
	@XmlEnumValue("000300") APER_CTA_1("000300", "", "NM", "No Valor", "N"),
	@XmlEnumValue("000334") APER_CTA_2("000334", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005300") APER_CTA_3("005300", "", "NM", "No Valor", "N"),
	@XmlEnumValue("000310") NOV_EXENTO("000310", "", "NM", "No Valor", "N"),
	@XmlEnumValue("000350") BLOQ_CTA("000350", "", "NM", "No Valor", "N"),
	@XmlEnumValue("000360") BLOQ_TAR("000360", "", "NM", "No Valor", "N"),
	@XmlEnumValue("000444") AUTH_TAR("000444", "", "NM", "No Valor", "N"),
	@XmlEnumValue("002024") AUTORIZA_DON("002024", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005060") CON_COBRO_1("005060", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005086") CON_COBRO_2("005086", "", "NM", "No Valor", "N"),
	@XmlEnumValue("901000") DONACION_CUENTA_AHO("901000", "", null,  "Egreso", "N"),
	@XmlEnumValue("902000") DONACION_CUENTA_CORR("901000", "", null,  "Egreso", "N"),
	@XmlEnumValue("005740") DEPO_CHEQ_OTRAS_PLAZAS("005740", "", "DP", "Ingresos", "N"),
	@XmlEnumValue("011000") REVERSO("011000", "?", null, "Ingresos", "N"),
	@XmlEnumValue("003100") CONS_PER_NATU("003100", "", "NM", "No Valor", "N"),
	@XmlEnumValue("003189") CONS_TITS_CUENTAS("003189", "", "NM", "No Valor", "N"),
	@XmlEnumValue("004822") CONS_TAR_CRED("004822", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005102") CONS_TIT_CUENTAS("005102", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005126") CONS_SALDO_CAN_CUENTA("005126", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005138") CONS_CUENTAS("005138", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005151") CONS_CHEQUE_CHEQUERA("005151", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005160") CONS_CHEQUERAS1("005160", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005163") CONS_CHEQUERAS2("005163", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005190") CONS_DIVISAS("005190", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005194") CONS_LIQUID_TRANS("005194", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005702") CONSIG_EFEC_CTA_AHO_AFC("005702", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005704") CONSIG_EFEC_TAR_CTA_AHO_CTE("005704", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005710") CONSIG_CHEQUE_LOC_SIN_TAR("005710", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005714") CONSIG_CHEQUE_LOC_CON_TAR("005714", "", "NM", "No Valor", "N"),
	@XmlEnumValue("311000") CONS_SALDO_CTA_AHO("311000", "", "NM", "No Valor", "N"),
	@XmlEnumValue("312000") CONS_SALDO_CTA_CORR("312000", "", "NM", "No Valor", "N"),
	@XmlEnumValue("313000") CONS_SALDO_CRED("313000", "", "NM", "No Valor", "N"),
	@XmlEnumValue("810000") CAMBIO_CLAVE2("810000", "", "NM", "No Valor", "N"),
	@XmlEnumValue("001726") PAGO_PROD_CRED_FM("001726", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("004373") PAGO_SERV_PUB("004373", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("004812") PAGO_TAR_CRED("004812", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("005220") TRANS_MONED("005220", "T", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("007502") REC_CONVENIOS("007502", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("007508") PAGO_CONVENIOS("007508", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("007516") PAGO_TDC("007516", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("161000") PAGO_SERV_CTA_AHOR("161000", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("162000") PAGO_SERV_CTA_CORR("162000", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("701000") TRANS_AHO_DAVI("701000", "T", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("701099") TRANS_AHO_OTROS_BANCOS("701099", "T", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("702000") TRANS_CORR_DAVI("702000", "T", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("702099") TRANS_CORR_OTROS_BANCOS("702099", "T", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("005612") RET_CHEQUE_CTA_SIN_TAR("005612", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("012000") RET_CTA_CORR("012000", "P", "CW", "Retiros", "N"),
	@XmlEnumValue("015000") RET_SIN_MEDIO("015000", "P", "CW", "Retiros", "N"),

	@XmlEnumValue("000382") REC_CEL("000382", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("000400") ASIG_CL_WEB("000400", "", "NM", "No Valor", "N"),
	@XmlEnumValue("001151") ASIG_ACT_TJCRE("001151", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005074") CAMB_NUM_DEST("005074", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005111") CON_SAL_CTAAHO("005111", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005355") CON_SAL_CTACRE("005355", "", "NM", "No Valor", "N"),
	@XmlEnumValue("005382") ACT_CHEQ("005382", "", "NM", "No Valor", "N"),
	@XmlEnumValue("006262") TRANSFER("006262", "T", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("006464") TRANSFER_OTR("006464", "T", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("007510") PAG_SERV_TJDEB("007510", "B", "BF", "Pagos/Transferencias", "N"),
	@XmlEnumValue("ActivCTR") ACTIV_CTR("ActivCTR", "", "NM", "No Valor", "N"),
	@XmlEnumValue("AsignClOlv") ASIGN_CL_OLV("AsignClOlv", "", "NM", "No Valor", "N"),
	@XmlEnumValue("AsignCTR") ASIGN_CTR("AsignCTR", "", "NM", "No Valor", "N"),
	@XmlEnumValue("CambClaTR") CAMB_CLA_TR("CambClaTR", "", "NM", "No Valor", "N"),
	@XmlEnumValue("CambClVirt") CAMB_CL_VIRT("CambClVirt", "", "NM", "No Valor", "N"),
	@XmlEnumValue("CambCVMono") CAMB_CV_MONO("CambCVMono", "", "NM", "No Valor", "N"),
	@XmlEnumValue("CambSegCla") CAMB_SEG_CLA("CambSegCla", "", "NM", "No Valor", "N"),
	@XmlEnumValue("ReenvOTPGi") REENV_OTP_GI("ReenvOTPGi", "", "NM", "No Valor", "N"),
	
	private final String codTrnx;
	private final String transTypeTBT;
	private final String actTypeSMH;
	private final String categCreada;
	private final String reversalIndicator;
	
	private CodTrnx(final String codTrnx, final String transTypeTBT, final String actTypeSMH, final String categCreada, 
		final String reversalIndicator) {
		
		this.codTrnx = codTrnx;
		this.transTypeTBT = transTypeTBT;
		this.actTypeSMH = actTypeSMH;
		this.categCreada = categCreada;
		this.reversalIndicator = reversalIndicator;
	}
	
	
	@Override
	public String toString() {
		return this.codTrnx;
	}

}
