package physicalChannels.groovy.model.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

@XmlEnum
public enum TransCountry {
	
	@XmlEnumValue("170") COLOMBIA("170"),
	@JsonEnumDefaultValue DEFAULT(null)
	
	
	private final String transCountry;

	private TransCountry(final String transCountry) {
		this.transCountry = transCountry;
	}
	
	@Override
	public String toString() {
		return this.transCountry;
	}
}
