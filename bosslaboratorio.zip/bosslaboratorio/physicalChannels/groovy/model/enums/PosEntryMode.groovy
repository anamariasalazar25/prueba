package physicalChannels.groovy.model.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

@XmlEnum
public enum PosEntryMode {

        @XmlEnumValue("05") POS1("05", "CP", "0"),
        @XmlEnumValue("90") POS2("90", "CD", "0"),
        @XmlEnumValue("03") POS3("03", "NC", "1"),
        @XmlEnumValue("00") POS4("00", "NC", "1"), //Adicion pos entry mode rdb stratus
        @JsonEnumDefaultValue DEFAULT("", "NC", null)


        private final String posEntryMode;
        private final String posEntryModeSMH;
        private final String posEntryModeUCM;

        private PosEntryMode(final String posEntryMode, final String posEntryModeSMH, final String posEntryModeUCM) {
                this.posEntryMode = posEntryMode;
                this.posEntryModeSMH = posEntryModeSMH;
                this.posEntryModeUCM = posEntryModeUCM;
        }

        @Override
        public String toString() {
                return this.posEntryMode;
        }
}