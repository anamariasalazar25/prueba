package physicalChannels.groovy.model.enums

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

@XmlEnum
public enum TpoProducto {
	
	@XmlEnumValue("0550") DAMAS_CUENTA_AHO("0550", "CS", "S", "SV"),
	@XmlEnumValue("0560") CUENTA_CORR("0560", "CS", "C", "CK"),
	@XmlEnumValue("0570") FIJO_DIARIO_AHO("0570", "CS", "S", "SV"),
	@XmlEnumValue("01") CTA_CTE_DEF("01", "CS", "C", "CK"),
	@XmlEnumValue("03") CTA_AHO_DEF("03", "CS", "S", "SV"),
	@XmlEnumValue("") ADMIN_EFEC("", "NA", "C", "NA"),
	@JsonEnumDefaultValue DEFAULT(null, null, null, null)
	
	
	private final String tpoProductoName;
	private final String tpoProductoSMH;
	private final String tpoProductoAQD;
	private final String tpoProductoTPP;
	
	
	private TpoProducto(final String tpoProductoName, final String tpoProductoSMH, final String tpoProductoAQD, final String tpoProductoTPP) {
		this.tpoProductoName = tpoProductoName;
		this.tpoProductoSMH = tpoProductoSMH;
		this.tpoProductoAQD = tpoProductoAQD;
		this.tpoProductoTPP = tpoProductoTPP;
	}
	
	public static TpoProducto textValueOf(String tpoProducto){

		for(TpoProducto value : values()) {
			if(value.tpoProductoName.equals(tpoProducto)) {
				return value;
			}
		}
		return TpoProducto.DAMAS_CUENTA_AHO;
	}
		
	
	@Override
	public String toString() {
		return this.tpoProductoName;
	}
}
