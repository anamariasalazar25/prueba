package physicalChannels.groovy.model.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

@XmlEnum
public enum BankType {
	
	@XmlEnumValue("00") OFICINA("00", "L"),
	@XmlEnumValue("?") PCBANK("?", "S"),
	@XmlEnumValue("03") ATM("03", "H"),
	@XmlEnumValue("05") TEL_ROJO("05", "F"),
	@XmlEnumValue("22") KIOSKO("22", "G"),
	@XmlEnumValue("26") MULTISERV("26", " "),
	@JsonEnumDefaultValue DEFAULT(null, null)
	
	
	private final String bankTypeName;
	private final String bankTypeTPP;

	private BankType(final String bankTypeName, final String bankTypeTPP) {
		this.bankTypeName = bankTypeName;
		this.bankTypeTPP = bankTypeTPP;
	}
	
	@Override
	public String toString() {
		return this.bankTypeName;
	}
}
