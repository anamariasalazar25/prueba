package physicalChannels.groovy.model.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

@XmlEnum
public enum Response {
	
	@XmlEnumValue("00") DIFF1("00"),
	@XmlEnumValue("76") DIFF2("76"),
	@XmlEnumValue("91") DIFF3("91"),
	@XmlEnumValue("96") DIFF3("96")
	
	
	private final String response;

	private Response(final String response) {
		this.response = response;
	}
	
	@Override
	public String toString() {
		return this.response;
	}
}
