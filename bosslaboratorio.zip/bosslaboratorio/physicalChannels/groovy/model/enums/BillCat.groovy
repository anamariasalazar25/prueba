package physicalChannels.groovy.model.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

@XmlEnum
public enum BillCat {
	
	@XmlEnumValue("0509") MC0509("PAG_SERV_CORP", "SV"),
	@XmlEnumValue("0010") MC0010("PAG_SERV_PUB", "UT"),
	@XmlEnumValue("0061") MC0061("PAG_PROD_CRE", "ML"),
	@XmlEnumValue("0062") MC0062("PAG_TARJ_CRE", "CA"),
	@XmlEnumValue("0080") MC0080("PAGO_PROV", "SV"),
	@XmlEnumValue("0248") MC0248("REC_CONV", "OT"),	
	@JsonEnumDefaultValue DEFAULT(null, null)
		
	private final String billCatName;
	private final String billCatTBT;

	private BillCat(final String billCatName, final String billCatTBT) {
		this.billCatName = billCatName;
		this.billCatTBT = billCatTBT;
	}
	
	@Override
	public String toString() {
		return this.billCatName;
	}
}
