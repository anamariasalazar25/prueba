package physicalChannels.groovy.model.enums

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

@XmlEnum
public enum TpoProductoDestino {
	
	@XmlEnumValue("01") CTA_CTE_DEF("01", "CK"),
	@XmlEnumValue("03") CTA_AHO_DEF("03", "SV"),
	@XmlEnumValue("04") FM("04", "SV"),
	@XmlEnumValue("05") TARJETA_CREDITO("05", "CC"),
	@XmlEnumValue("0600") FONDO_INVERSION("0600", "IV"),
	@JsonEnumDefaultValue DEFAULT(null, null)
		
	private final String tpoProductoName;
	private final String tpoProductoTPP;
		
	private TpoProductoDestino(final String tpoProductoName, final String tpoProductoTPP) {
		this.tpoProductoName = tpoProductoName;
		this.tpoProductoTPP = tpoProductoTPP;
	}
	
	public static TpoProductoDestino textValueOf(String tpoProducto){

		for(TpoProductoDestino value : values()) {
			if(value.tpoProductoName.equals(tpoProducto)) {
				return value;
			}
		}
		return TpoProductoDestino.DEFAULT;
	}
		
	
	@Override
	public String toString() {
		return this.tpoProductoName;
	}
}
