package physicalChannels.groovy.model

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

import physicalChannels.groovy.model.enums.CodTrnx;
import physicalChannels.groovy.model.enums.ChannelType;
import physicalChannels.groovy.model.enums.TpoPersona;
import physicalChannels.groovy.model.enums.TpoProducto;
import physicalChannels.groovy.model.enums.TpoProductoDestino;
import physicalChannels.groovy.model.enums.PosEntryMode;
import physicalChannels.groovy.model.enums.UtcInd;
import physicalChannels.groovy.model.enums.TransCurrency;
import physicalChannels.groovy.model.enums.TransCountry;
import physicalChannels.groovy.model.enums.DiffIndicator;
import physicalChannels.groovy.model.sas.SASTemplate;
import physicalChannels.groovy.model.sas.enums.SASAuthorizeTransaction;
import physicalChannels.groovy.model.enums.CodRespuesta;
import physicalChannels.groovy.model.enums.BillCat;
import com.sas.davivienda.efm.commons.util.FMUtils;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="AuthorizeTransaction", namespace="http://www.sas.boss/PhysicalChannelService/")
public class AuthorizeTransaction extends SASTemplate {
	
	private static final Logger logger = LoggerFactory.getLogger("physicalChannelslog");
	
	
	public AuthorizeTransaction() {}
	
	def TpoPersona tipoPersona;
	def TpoProducto tipoProdCta;
	def TpoProductoDestino tipoProdCtaDestino;
	
	//@XmlElement (name = "codRespuesta") def String codRespuesta;
	
	@XmlElement (name = "agreementId") def String agreementId;
	@XmlElement (name = "appliedCount") def Integer appliedCount;
	@XmlElement (name = "branchId") def String branchId;
	@XmlElement (name = "branchUser") def String branchUser;
	@XmlElement (name = "channelId") def ChannelType channelId;
	@XmlElement (name = "checkNumber") def String checkNumber;
	@XmlElement (name = "daviplataTerminalNum") def String daviplataTerminalNum;
	@XmlElement (name = "differentialIndicator") def DiffIndicator differentialIndicator;
	@XmlElement (name = "entryCount") def Integer entryCount;
	@XmlElement (name = "payeeAccountNumber") def String payeeAccountNumber;
	@XmlElement (name = "payeeAccountType") def String payeeAccountType;
	@XmlElement (name = "payeeBankId") def String payeeBankId;
	@XmlElement (name = "payeeIdentificationNumber") def String payeeIdentificationNumber;
	@XmlElement (name = "payeeIdentificationType") def String payeeIdentificationType;
	@XmlElement (name = "payeerAccountNumber") def String payeerAccountNumber;
	@XmlElement (name = "payeerBankId") def String payeerBankId;
	@XmlElement (name = "payeerCardNumber") def String payeerCardNumber;
	@XmlElement (name = "phoneNumber") def String phoneNumber;
	@XmlElement (name = "posEntryMode") def PosEntryMode posEntryMode;
	@XmlElement (name = "referenceNumber1") def String referenceNumber1;
	@XmlElement (name = "referenceNumber2") def String referenceNumber2;
	@XmlElement (name = "selfCustomerIndicator") def String selfCustomerIndicator;
	@XmlElement (name = "terminalId") def String terminalId;
	@XmlElement (name = "totalDebit") def String totalDebit;
	@XmlElement (name = "transactionalMean") def String transactionalMean;
	@XmlElement (name = "transactionAmount") def String transactionAmount;
	@XmlElement (name = "transactionCity") def String transactionCity;
	@XmlElement (name = "transactionCode") def CodTrnx transactionCode;
	@XmlElement (name = "transactionCountryCode") def TransCountry transactionCountryCode;
	@XmlElement (name = "transactionCurrencyCode") def TransCurrency transactionCurrencyCode;
	@XmlElement (name = "transactionDate") def String transactionDate;
	@XmlElement (name = "transactionId") def String transactionId;
	@XmlElement (name = "transactionTime") def String transactionTime;
	@XmlElement (name = "transactionUtcIndicator") def UtcInd transactionUtcIndicator;
	@XmlElement (name = "transactionMotiveConcept") def String transactionMotiveConcept;
	
	@XmlElement (name = "productoOriginador") def String productoOriginador;
	@XmlElement (name = "atmCode") def String atmCode;
	
	def String balance;
	def String transStatusTBT;
	def String bankTypeTPP;
	def String billCatTBT;
	def String transactionDateGMT;
	def String transactionTimeGMT;
	def String payeerAccountType;
	
	// 	Valores válidos en el fingerprint
	def ArrayList validSegments;
	
	
	public String getPayeeAccountNumber(){
		if(this.payeeAccountNumber != null && payeeAccountNumber.contains("-")){
			return this.payeeAccountNumber.substring(3);
		}
		return this.payeeAccountNumber;
	}
	
	public String getPayeerAccountNumber(){
		if(this.payeerAccountNumber != null && payeerAccountNumber.contains("-")){
			return this.payeerAccountNumber.substring(3);
		}
		return this.payeerAccountNumber;
	}

	public String getPayeerAccountType(){
		if(this.payeerAccountNumber != null && payeerAccountNumber.contains("-")){
			return this.payeerAccountNumber.substring(0,2);
		}
		return '03';
	}

	public String getPayeerCardNumber(){
		if(this.payeerCardNumber != null && this.payeerCardNumber.contains("-")){
			return this.payeerCardNumber.substring(3);
		}
		return this.payeerCardNumber;
	}

	public String getProductoOriginador(){
		return FMUtils.hasValue(this.payeerCardNumber) ? "DEBIT_CARD" : "ACCOUNT_NUM";
	}

	public String getTipoPersonaSMH() {
		if(this.tipoPersona != null) return this.tipoPersona.tpoPersonaSMH;
		
		return "";
	}
	
	public String getTipoPersonaMultiSMH() {
		if(this.tipoPersona != null) return this.tipoPersona.tpoPersonaMulti;
		
		return "";
	}
	
	public String getTipoProdCtaSMH() {
		if(this.tipoProdCta != null) return this.tipoProdCta.tpoProductoSMH;
		
		return "";
	}
	
	public String getTipoProdCtaAQD() {
		if(this.tipoProdCta != null) return this.tipoProdCta.tpoProductoAQD;
		
		return "";
	}
	
	public String getTipoProdCtaTPP() {

		String tipoProdCtaTpp = "";
		
		tipoProdCtaDestino = TpoProductoDestino.textValueOf(payeeAccountType);
		
		/*
		if (payeeAccountType != null){
			tipoProdCtaTpp = "03".equals(payeeAccountType) ? "SV" : "CK";
		}*/
		//if(this.tipoProdCta != null) return this.tipoProdCta.tpoProductoTPP;
		
		return tipoProdCtaDestino.tpoProductoTPP;
	}
	
	public String getActivityTypeSMH() {
		
		String channel = this.channelId.toString();
		
		if(this.transactionCode != null) {
			if("32".equals(channel)) {
				return "AB";
			}

			if("CA/CW".equals(this.transactionCode.actTypeSMH)) {
				if("03".equals(channel) || "26".equals(channel)) {
					return "CA";
				}else{
					return "CW";
				}
			}
			
			return this.transactionCode.actTypeSMH;
		}
		
		return "";
	}
	
	public String getTransTypeTBT() {
		if(this.transactionCode != null) return this.transactionCode.transTypeTBT;
		
		return "";
	}

	public String getTransactionAmountTCA(){
		return this.transactionAmount;
	}
	
	public String getTransactionAmountTBT(){
		return this.transactionAmount;
	}

	public String getTransactionCurrencyCodeTCA(){
		return this.transactionCurrencyCode;
	}

	public String getTransactionIdTCA(){
		return this.transactionId;
	}

	public String getTransactionIdTNG(){
		return this.transactionId;
	}
	
	public String getChannelTypeSMH() {
		if(this.channelId != null) return this.channelId.channelSMH;
		
		return "";
	}
	
	public String getPosEntryModeSMH() {

		String authMethod = PosEntryMode.DEFAULT.posEntryModeSMH;
		String channelId = this.channelId;

		if(("03".equals(channelId) || "26".equals(channelId)) && this.posEntryMode != null){
			authMethod = this.posEntryMode.posEntryModeSMH;
		}
		
		return authMethod;
	}
	
	public String getPosEntryModeUCM() {
		if(this.posEntryMode != null) return this.posEntryMode.posEntryModeUCM;
		
		return PosEntryMode.DEFAULT.posEntryModeUCM;
	}
	
	public String getReveralIndicator() {
		if(this.transactionCode != null) return this.transactionCode.reversalIndicator;
		
		return "N";
	}
	
	/*public String getCodRespuestaVal() {
		return CodRespuesta.codValueOf(this.codRespuesta);
	}*/
	
	public String getTppPayeePayerInd() {
		
		if(this.activityTypeSMH.equals("BF")) {
			return "E";
		}
		
		if(this.activityTypeSMH.equals("DP")) {
			return "R";
		}
		
		return null;
	}
	
	public String getBillCatTBT() {
		String billCat = "";
		
		if(this.transactionMotiveConcept != null && this.activityTypeSMH.equals("BF")) {
			try {
				billCat = BillCat.("MC".concat(this.transactionMotiveConcept)).billCatTBT;
			}catch(Exception e){}
		}
		return billCat;
	}
	
	@Override
	public Map<String,Object> obtainSASFormat() {
		return super.sasValidation(this, SASAuthorizeTransaction);
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", AuthorizeTransaction.class.getSimpleName() + "{", "}")
			.add("agreementId='" + this.agreementId + "'")
			.add("appliedCount='" + this.appliedCount + "'")
			.add("branchId='" + this.branchId + "'")
			.add("branchUser='" + this.branchUser + "'")
			.add("channelId='" + this.channelId + "'")
			.add("branchId='" + this.branchId + "'")
			.add("checkNumber='" + this.checkNumber + "'")
			.add("daviplataTerminalNum='" + this.daviplataTerminalNum + "'")
			.add("differentialIndicator='" + this.differentialIndicator + "'")
			.add("entryCount='" + this.entryCount + "'")
			.add("payeeAccountNumber='" + this.payeeAccountNumber + "'")
			.add("payeeAccountType='" + this.payeeAccountType + "'")
			.add("payeeBankId='" + this.payeeBankId + "'")
			.add("payeeIdentificationNumber='" + this.payeeIdentificationNumber + "'")
			.add("payeeIdentificationType='" + this.payeeIdentificationType + "'")
			.add("payeerAccountNumber='" + this.payeerAccountNumber + "'")
			.add("payeerAccountType='" + this.payeerAccountType + "'")
			.add("payeerBankId='" + this.payeerBankId + "'")
			.add("payeerCardNumber='" + this.payeerCardNumber + "'")
			.add("phoneNumber='" + this.phoneNumber + "'")
			.add("posEntryMode='" + this.posEntryMode + "'")
			.add("referenceNumber1='" + this.referenceNumber1 + "'")
			.add("referenceNumber2='" + this.referenceNumber2 + "'")
			.add("selfCustomerIndicator='" + this.selfCustomerIndicator + "'")
			.add("terminalId='" + this.terminalId + "'")
			.add("totalDebit='" + this.totalDebit + "'")
			.add("transactionalMean='" + this.transactionalMean + "'")
			.add("transactionAmount='" + this.transactionAmount + "'")
			.add("transactionCity='" + this.transactionCity + "'")
			.add("transactionCode='" + this.transactionCode + "'")
			.add("transactionCountryCode='" + this.transactionCountryCode + "'")
			.add("transactionCurrencyCode='" + this.transactionCurrencyCode + "'")
			.add("transactionDate='" + this.transactionDate + "'")
			.add("transactionId='" + this.transactionId + "'")
			.add("transactionTime='" + this.transactionTime + "'")
			.add("transactionUtcIndicator='" + this.transactionUtcIndicator + "'")
			.add("transactionMotiveConcept='" + this.transactionMotiveConcept + "'")
			.toString();
	}
}
