package physicalChannels.groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import javax.xml.soap.SOAPMessage;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.MimeHeaders;
import java.nio.charset.Charset;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBIntrospector;
import javax.xml.bind.Unmarshaller;

import org.w3c.dom.Document;

import physicalChannels.groovy.model.enums.CodTrnx;
import physicalChannels.groovy.model.AuthorizeTransaction;
import physicalChannels.groovy.tools.XMLBuilderFormat;
import physicalChannels.groovy.tools.checks.AuthTransactionChecks;
import physicalChannels.groovy.tools.Common;
import physicalChannels.groovy.exceptions.PhysicalChannelException;
import com.sas.davivienda.efm.commons.exceptions.EFMException;
import com.sas.davivienda.efm.commons.util.FMUtils;

public class InputProcessor implements Processor{
		
	private static final Logger logger = LoggerFactory.getLogger("physicalChannelslog");
	
	public void process(Exchange exchange) {
		
		try {

			String body = exchange.getIn().getBody(String.class);

			AuthorizeTransaction authTransaction = (AuthorizeTransaction) XMLBuilderFormat.getXMLMappingObject(body, "authorizeTransaction");
		
			// ChannelId original value
			String channelId = authTransaction.getChannelId().channelName;
			exchange.setProperty("channelId", channelId);
			exchange.setProperty("productoOriginador", authTransaction.getProductoOriginador());
			exchange.setProperty("atmCode", authTransaction.getAtmCode());

			String productNumber = authTransaction.payeerAccountNumber;
			String cardNumber = authTransaction.payeerCardNumber;
			String trxMean = "ACCOUNT_NUM";
			String productType = "03";

			if(FMUtils.hasValue(cardNumber)){
				productNumber = cardNumber;
				trxMean = "DEBIT_CARD";
			}

			Map<String,Object> authTransactionMap = Common.objectToMap(authTransaction);

			if(productNumber.contains("-")){
				productType = productNumber.substring(0,1);
				productNumber = productNumber.substring(3);
			}

			authTransactionMap.put("productId",productNumber);
			authTransactionMap.put("productType",productType);
			exchange.setProperty("trxMean", trxMean);
			
			// successful operation
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			exchange.getIn().setBody(authTransactionMap);
			exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");

		}catch(Exception e) {
			e.printStackTrace();
			logger.error("ERRR-InputProcessor: {}",e.getMessage());
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 400);
			exchange.getIn().setBody(null);
			exchange.setProperty("codResponse", "96");
		}

		finally {
			exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
		}

	}
}
