package physicalChannels.groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import javax.xml.soap.SOAPMessage;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.MimeHeaders;
import java.nio.charset.Charset;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBIntrospector;
import javax.xml.bind.Unmarshaller;

import org.w3c.dom.Document;

import physicalChannels.groovy.model.enums.CodTrnx;
import physicalChannels.groovy.model.AuthorizeTransaction;
import physicalChannels.groovy.tools.XMLBuilderFormat;
import physicalChannels.groovy.tools.checks.AuthTransactionChecks;
import physicalChannels.groovy.tools.Common;
import physicalChannels.groovy.exceptions.PhysicalChannelException;
import com.sas.davivienda.efm.commons.exceptions.EFMException;
import com.sas.davivienda.efm.commons.util.FMUtils;

public class InputProcessor implements Processor{
		
	private static final Logger logger = LoggerFactory.getLogger("physicalChannelslog");
	
	public void process(Exchange exchange) {
		
		try {

			String body = exchange.getIn().getBody(String.class);

			AuthorizeTransaction authTransaction = (AuthorizeTransaction) XMLBuilderFormat.getXMLMappingObject(body, "authorizeTransaction");

			logger.info("### REQ-FROM-CHANNEL: {}",authTransaction);
			StringBuilder trxInfoLog = new StringBuilder();
			trxInfoLog.append("mti:0200")
						.append(", channelId:").append(authTransaction.channelId)
						.append(", transactionCode:").append(authTransaction.transactionCode)
						.append(", date:").append(authTransaction.transactionDate)
						.append(", time:").append(authTransaction.transactionTime)
						.append(", ref-num:").append(authTransaction.transactionId)
						.append(", amt:").append(authTransaction.transactionAmount);

			exchange.setProperty("trxInfoLog", trxInfoLog.toString());
			logger.info("req-from-channel: {}",trxInfoLog.toString());

			// ChannelId original value
			String channelId = authTransaction.getChannelId().channelName;
			exchange.setProperty("channelId", channelId);
			exchange.setProperty("trxMean", authTransaction.getProductoOriginador());
			exchange.setProperty("atmCode", authTransaction.getAtmCode());

			Map<String,Object> authTransactionMap = Common.objectToMap(authTransaction);
			AuthTransactionChecks.checkAccounts(authTransaction, authTransactionMap);
			
			exchange.setProperty("isEnrichedByProductNumber", AuthTransactionChecks.isEnrichedByProductNumber(authTransaction, authTransactionMap));

			// successful operation
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			exchange.getIn().setBody(authTransactionMap);
			exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");

		}catch(Exception e) {
			e.printStackTrace();
			logger.error("ERRR-InputProcessor: {}",e.getMessage());
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			exchange.getIn().setBody(null);
			exchange.setProperty("codResponse", "96");
		}

		finally {
			exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
		}
	}
}
