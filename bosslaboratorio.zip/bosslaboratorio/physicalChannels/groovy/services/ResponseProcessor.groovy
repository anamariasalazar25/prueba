package daviplata.groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Map;
import com.sas.davivienda.efm.commons.util.FMResponseHelper

public class ResponseProcessor implements Processor {
	
	private static final Logger logger = LoggerFactory.getLogger("physicalChannelslog");
		
	public void process(Exchange exchange) {
		
		Map<String,String> responseMap = new HashMap<String, String>();

		try {
			String responseCode = exchange.getProperty("codResponse"); 
			Map<String,String> outputMap = exchange.getIn().getBody();
			String trxInfoLog = exchange.getProperty("trxInfoLog",String.class);
			StringBuilder infoLogBuilder = new StringBuilder();

			if(outputMap != null){
				responseCode = FMResponseHelper.getResponseCode(exchange);
			}

			responseMap.put("codResponse",responseCode);
			infoLogBuilder.append(trxInfoLog).append(" resp-code:").append(responseCode);
			exchange.setProperty("trxInfoLog",infoLogBuilder.toString());

		}catch(Exception e) {
			logger.error("Error ResponseProcessor: {}","96");
			responseMap.put("codResponse","96");
		}finally {
			exchange.getIn().setBody(responseMap);
		}
	}
}