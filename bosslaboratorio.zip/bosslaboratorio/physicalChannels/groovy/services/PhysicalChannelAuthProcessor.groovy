package physicalChannels.groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import javax.xml.soap.SOAPMessage;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.MimeHeaders;
import java.nio.charset.Charset;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBIntrospector;
import javax.xml.bind.Unmarshaller;

import org.w3c.dom.Document;

import physicalChannels.groovy.model.enums.CodTrnx;
import physicalChannels.groovy.model.AuthorizeTransaction;
import physicalChannels.groovy.tools.Common;
import physicalChannels.groovy.tools.checks.AuthTransactionChecks;
import physicalChannels.groovy.exceptions.PhysicalChannelException;

public class PhysicalChannelAuthProcessor implements Processor {
		
	private static final Logger logger = LoggerFactory.getLogger("physicalChannelslog");
	
	public void process(Exchange exchange) {
		
		try {

			HashMap<String, String> authTransMapBody = (HashMap<String, String>) exchange.getProperty("inputMsg");
			
			AuthorizeTransaction authTransaction = (AuthorizeTransaction) Common.hashMapToObject(authTransMapBody, AuthorizeTransaction.class);
			
			if(authTransaction == null) {
				throw new PhysicalChannelException(222, "Invalid FingerPrint");
			}
			
			// Stratus/DB-Enrich
			AuthTransactionChecks.authTransEnrichment(authTransaction, exchange);
	
			authTransaction = AuthTransactionChecks.checkAuthTransAttributes(authTransaction);
			
			if(authTransaction == null) {
				throw new PhysicalChannelException(222, "Invalid FingerPrint");
			}

			String channelId = exchange.getProperty("channelId");

			if(channelId != null && ("03".equals(channelId) || "26".equals(channelId))){
				AuthTransactionChecks.completeATMTransaction(authTransaction, exchange);
			}
			
			//System.out.println(authTransaction.toString());
			Map<String,Object> sasAuthTransactionMap = authTransaction.obtainSASFormat();

			// successful operation
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			sasAuthTransactionMap.putAll(authTransMapBody);
			AuthTransactionChecks.getMessageTypeTran(sasAuthTransactionMap, channelId, exchange);
			
			sasAuthTransactionMap.put("rqo_tran_utc_flag","Y");
			exchange.getIn().setBody(sasAuthTransactionMap);
			
			exchange.setProperty("codResponse", "00");
			exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
		}

		catch(Exception e) {
			logger.error("ERR-PhysicalChannelProcessor: {} ",e.getMessage());
			exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
			exchange.getIn().setBody(null);
			exchange.setProperty("codResponse", "96");
		}

	}
}
