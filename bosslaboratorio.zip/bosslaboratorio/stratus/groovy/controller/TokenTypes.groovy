package stratus.groovy.controller;

public enum TokenTypes {
	
	// Token COF y MIT
	C0("C0"),
	
	//Token usados en la transaccion anterior
	CZ("CZ"),
	SC("SC"),
	TK("TK"),
	B0("B0"),
	
	// Se agregran los 5 tokens de MoneySend del control de cambios, se adiciona la llave del TOKEN C4
	SI("SI"),
	SJ("SJ"),
	SK("SK"),
	CH("CH"), // Se modifica estructura del token en el evolutivo COF y MIT
	C4("C4"), // Se modifica estructura del token en el evolutivo COF y MIT
	
	private final String code;
	
	private TokenTypes(final String code) {
		this.code = code;
	}
	
	public static TokenTypes tokenValueOf(String code){

		for(TokenTypes value : values()) {
						
			if(value.code.equals(code)) {
				return value;
			}
		}
		return null;
	}
	
	@Override
	public String toString() {
		return this.code;
	}
	
	
}
