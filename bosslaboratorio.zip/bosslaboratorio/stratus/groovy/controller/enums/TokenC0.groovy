package stratus.groovy.controller.enums;

public enum TokenC0 {
	
	// Nombre del campo, tipo, longitud, posición inicial, posicion final, campo sas
	// Mapeo de campos evolutivo COF y MIT
	TERM_POSTAL_CDE("AN", 10, 9, 18, "hbb_branch_post_code"),
	MOTO_FLG("AN", 1, 19, 19, "rua_ind_008"), 
	CVD_FLD_PRESENT("AN", 1, 22, 22, "rua_ind_015"), 
	SAF_OR_FORCE_POST("AN", 1, 23, 23, "rur_ind_002"), 
	AUTHN_COLL_IND("AN", 1, 24, 24, "rua_ind_016"), 
	FRD_PRN_FLG("AN", 1, 25, 25, "rua_ind_031"), 
	CAVV_AAV_RSLT_CDE("AN", 1, 26, 26, "rua_ind_017"), 
	
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenC0(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
