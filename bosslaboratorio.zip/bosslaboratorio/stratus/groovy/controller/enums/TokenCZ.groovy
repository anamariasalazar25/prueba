package stratus.groovy.controller.enums;

public enum TokenCZ {
	
	ATC_VALID_IND("AN", 1, 13, 13, "rua_ind_025"),
	CRD_AUTHN_IND("AN", 1, 14, 14, "rua_ind_026"),
	FORM_FACTR_IND("AN", 8, 5, 12, "dua_8byte_string_010"),
	
	
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	private TokenCZ(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
