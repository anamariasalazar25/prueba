package stratus.groovy.controller.enums;

public enum TokenB0 {
	
	RSN_CDE("AN", 2, 112, 113, "dmx_ind_02_tag"),
	LGTH_TYPE_BINARY_16_SIGNED("AN", 3, 1, 3, "rua_3byte_string_002"),
	RSK("AN", 4, 110, 113, "rur_4byte_string_002"),
	
	
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	private TokenB0(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
