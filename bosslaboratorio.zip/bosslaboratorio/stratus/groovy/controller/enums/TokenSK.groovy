package stratus.groovy.controller.enums;

public enum TokenSK {
	
	// Mapeo de los campos relacionados en el Excel MoneySend
	// Nombre del campo, tipo, longitud, posición inicial, posición final, campo sas
	 FRMT_CODE("AN", 2, 1, 2, "dmx_n8_01_tag"),
	 UNIQUE_REF_NUM("AN", 19, 6, 24, "tpp_num"),
	 FUND_SRC("AN", 2, 25, 26, "dmx_n22_03_tag"),
	 PARTICIPANT_ID("AN", 30, 27, 56, "dee_entity_id_5"),
	 TXN_RSN("AN", 2, 122, 123, "dmx_ind_05_tag");
	
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenSK(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
