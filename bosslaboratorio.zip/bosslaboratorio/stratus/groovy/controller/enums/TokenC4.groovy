package stratus.groovy.controller.enums;

public enum TokenC4 {
	
	// Nombre del campo, tipo, longitud, posición inicial, posicion final, campo sas
	// Mapeo de campos evolutivo COF y MIT
	TERM_ATTEND_IND("AN", 1, 1, 1, "rua_ind_001"),
	TERM_OPER_IND("AN", 1, 2, 2, "rua_ind_002"),
	TERM_LOC_IND("AN", 1, 3, 3, "rua_ind_003"),
	CRDHLDR_PRESENT_IND("AN", 1, 4, 4, "rua_ind_020"),
	CRD_PRESENT_IND("AN", 1, 5, 5, "rua_ind_018"),
	CRD_CAPTR_IND("AN", 1, 6, 6, "rua_ind_019"),
	TXN_STAT_IND("AN", 1, 7, 7, "rua_ind_024"),
	TXN_SEC_IND("AN", 1, 8, 8, "rua_ind_010"),
	TXN_RTN_IND("AN", 1, 9, 9, "rua_ind_011"),
	CRDHLDR_ACTVT_TERM_IND_COF_MIT("AN", 1, 10, 10, "rua_ind_021"),
	TERM_INPUT_CAP_IND("AN", 1, 11, 11, "rua_ind_022"),
	CRDHLDR_ID_METHOD("AN", 1, 12, 12, "rua_ind_023"),

	// Mapeo de los campos MoneySend
	CRDHLDR_ACTVT_TERM_IND("AN", 1, 10, 10, "rua_ind_028");
		 		
	// Estructura de la información contenida en el Token
	private final String type;
	private final Integer length;
	private final Integer startPos;
	private final Integer finalPos;	
	private final String sasValue;
	
	// Método invocado en TokenCheck para leer la estructura y los valores en el cuerpo del token
	private TokenC4(final String type, final Integer length, final Integer startPos, final Integer finalPos, final String sasValue) {
		this.type = type;
		this.length = length;
		this.startPos = startPos;
		this.finalPos = finalPos;
		this.sasValue = sasValue;
	}
}
