package stratus.groovy.controller;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import stratus.groovy.controller.Token;
import stratus.groovy.controller.TokenTypes;
import stratus.groovy.controller.enums.TokenCZ;
import stratus.groovy.controller.enums.TokenSC;
import stratus.groovy.controller.enums.TokenTK;
import stratus.groovy.controller.enums.TokenB0;
import stratus.groovy.controller.enums.TokenSI;
import stratus.groovy.controller.enums.TokenSJ;
import stratus.groovy.controller.enums.TokenSK;
import stratus.groovy.controller.enums.TokenCH;
import stratus.groovy.controller.enums.TokenC4;
import stratus.groovy.controller.enums.TokenC0;

public class TokenChecks {
	
	private static final Logger logger = LoggerFactory.getLogger("strlog");
	
	private static final tokensValue = [
		
		// Token COF y MIT
		"C0": TokenC0,
		
		// Tokens usados en la transaccion anterior
		"CZ": TokenCZ,
		"SC": TokenSC,
		"TK": TokenTK,
		"B0": TokenB0,
		
	    // Se agregran los 5 tokens de MoneySend del control de cambios, se adiciona la llave del TOKEN C4
		"SI": TokenSI,
		"SJ": TokenSJ,
		"SK": TokenSK,
		"CH": TokenCH, // Se modifica estructura del token en el evolutivo COF y MIT
		"C4": TokenC4, // Se modifica estructura del token en el evolutivo COF y MIT		
		
	];
		
	public static Map <String, String> createTokensValues(String tokenInfo, String tokenType) {
		
		Map <String, String> sasMap = new HashMap <String, String>();
		try {
			def tokensEnum = tokensValue[tokenType].values();
			
			for(def tokenValue: tokensEnum) {
				sasMap.put(tokenValue.sasValue, tokenInfo.substring(tokenValue.startPos - 1, tokenValue.finalPos))
			}
		}catch(Exception e) {
			logger.info("Length of {} token received is less than expected - {}",tokenType,e.getMessage());
		}
		return sasMap;
	}
	
	public static Map <String, String> checkTokenValues(Token token) {

		// Check token type
		TokenTypes tokenType = TokenTypes.tokenValueOf(token.getCode());
				
		if(tokenType == null) {
			return null;
		}
		
		// Check token info size
		int tokenInfoSize = token.getInfo().length();
		
		if(tokenInfoSize != tokenInfoSize) {
			return null;
		}
		
		return createTokensValues(token.getInfo(), tokenType.code);
	}
	
}
