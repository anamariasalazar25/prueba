package stratus.groovy.controller;

import java.util.List;

import stratus.groovy.controller.Common;

public class Token {
	
	public Token(String token) {
		this.token = token;
		
		setValues();
	}
	
	private String token;
	private String code;
	private Integer length;
	private String info;

	public void setValues() {
		
		List<String> tokenValues = Common.splitStringBySpace(this.token);
		
		String codeLength = tokenValues.get(0);
		
		this.code = codeLength.substring(0, 2);
		this.length = Integer.parseInt(codeLength.substring(2, codeLength.length()));
		
		// info = token without tokenCode+tokenLength
		this.info = this.token.replace(codeLength+" ", "");		
	}	
	
	public String getCode() {
		return this.code;
	}
	
	public String getLength() {
		return this.length;
	}
	
	public String getInfo() {
		return this.info;
	}
	
	@Override
	public String toString() {
		return new StringJoiner(", ", Token.class.getSimpleName() + "{", "}")
			.add("code='" + this.code + "'")
			.add("length='" + this.length + "'")
			.add("info='" + this.info + "'")
			.toString();
	}
	
	
}
