package stratus.groovy.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.apache.commons.lang.StringUtils;

import com.sas.davivienda.efm.commons.exceptions.EFMException;
import stratus.groovy.model.implementation.*;
import stratus.groovy.model.interfaces.IStratusToken;

/**
 * 
 *
 */
public class AdditionalDataProcessor {

	private static final Logger logger = LoggerFactory.getLogger("strlog");
	private List<IStratusToken> stratusTokens = new ArrayList<>();
	private static final int ADDTIONAL_DATA_LEN = 2000;
	
	
	@Resource
	@Qualifier("chVerifyFromEcomFlag")
	private Map<String, String> chVerifyFromEcomFlag;

	/**
	 * 
	 */
	public AdditionalDataProcessor() {
		logger.info("Init strAdditionalDataProcessor");
		
		stratusTokens.add(new TokenB0());
		stratusTokens.add(new TokenBM());
		stratusTokens.add(new TokenC0());
		stratusTokens.add(new TokenC4());
		stratusTokens.add(new TokenF4());
		stratusTokens.add(new TokenFB());
		stratusTokens.add(new TokenQX());
		stratusTokens.add(new TokenQY());
		stratusTokens.add(new TokenQZ());
	}

	/**
	 * 
	 * @param exchange
	 * @throws EFMException
	 */
	public void mapAdditionalData(Exchange exchange) {

		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");

		try {
			String additionalData = inputMsg.get("pos_additional_data");

			if(additionalData != null) {
				if(additionalData.length()<ADDTIONAL_DATA_LEN){
					additionalData = StringUtils.rightPad(additionalData, ADDTIONAL_DATA_LEN);
					inputMsg.put("pos_additional_data",additionalData);
				}

				for(IStratusToken strToken: stratusTokens) {
					strToken.mapTokenData(inputMsg,additionalData);
				}
			}else {
				logger.info("Not additional data field was found in message");
			}	
			
		} catch (Exception e) {
			logger.error("ERR-AdditionalDataProcessor: {}", e.toString());
		}
	}
	
}
