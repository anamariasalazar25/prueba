package com.fadosol.integration.groovy;

import java.util.Map;

import javax.annotation.Resource;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sas.davivienda.efm.commons.dto.ISOCountry
import com.sas.davivienda.efm.commons.exceptions.EFMException;
import com.sas.davivienda.efm.commons.mapper.DIANComplementaryCodeMapper;
import com.sas.davivienda.efm.commons.dto.DIANComplementaryCode;
import com.sas.davivienda.efm.commons.mapper.ISOCountryMapper;
import com.sas.davivienda.efm.commons.util.FMAPIFieldMapper
import com.sas.davivienda.efm.commons.util.FMDateFormatter;
import com.sas.davivienda.efm.commons.util.FMUtils;
import stratus.groovy.tools.CardAcceptorLocationParser;

public class TransactionDataProcessor {

	private static final Logger logger = LoggerFactory.getLogger("strlog");
	private static final String STRATUS_DATETIME = "yyyyMMddHHmmss";

	@Resource
	@Qualifier("strActivityTypeFromTranType")
	private Map<String, String> strActivityTypeFromTranType;

	@Resource
	@Qualifier("strEnrProdTypeFromStrProdType")
	private Map<String,String> strEnrProdTypeFromStrProdType;
	
	/**
	 *
	 */
	public TransactionDataProcessor() {
		logger.info("Init TransactionDataProcessor");
	}

	/**
	 *
	 * @param exchange
	 * @throws EFMException
	 */
	public void mapTransactionData(Exchange exchange) {

		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");
		boolean areRequiredFieldsWrong = false;
				
		try {
			
			String mti = inputMsg.get("message_type");
			exchange.setProperty("mti", mti);
			String trxRefNum = inputMsg.get("transaction_number");
			String trxCode = inputMsg.get("transaction_code");
			String responseCode = inputMsg.get("response_code");
			
			if(FMUtils.isNullOrEmpty(trxCode) || trxCode.length() < 6) {
				areRequiredFieldsWrong = true;
				throw new EFMException("trxcode null or invalid");
			}
			
			String terminalType = inputMsg.get("terminal_type");
			
			//Payeer
			String cardNum = inputMsg.get("card_num");
			if(FMUtils.isNullOrEmpty(cardNum) || cardNum.length() < 7) {
				areRequiredFieldsWrong = true;
				throw new EFMException("Card null or invalid");
			}

			inputMsg.put("issuer_bin", cardNum.substring(0, 6));
			String sasActivityType = strActivityTypeFromTranType.get(trxCode.substring(0, 2));
			
			exchange.setProperty("sasActivityType", sasActivityType);
			
			String trxAmt = inputMsg.get("transaction_amount");
			inputMsg.put("transaction_amount",FMUtils.addDecimalSeparator(trxAmt));
			
			String gmtTranDate = inputMsg.get("gmt_tran_date");
			String gmtTranTime = inputMsg.get("gmt_tran_time");
			
			String gmtTranDatetime = gmtTranDate.concat(gmtTranTime);
			FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(gmtTranDatetime, "sas_gmt_tran_date", "sas_gmt_tran_time", inputMsg, STRATUS_DATETIME);
			
			String sourceDatetime = inputMsg.get("datetime_country_source");
			FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(sourceDatetime, "sas_source_tran_date", "sas_source_tran_time", inputMsg, STRATUS_DATETIME);
			
			String colombianDatetime = inputMsg.get("datetime_colombian_time");
			FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(colombianDatetime, "sas_colombian_tran_date", "sas_colombian_tran_time", inputMsg, STRATUS_DATETIME);
			
			StringBuilder loggerInfo = new StringBuilder();
			loggerInfo.append("mti:").append(mti)
						.append(", tran-code:").append(trxCode)
						.append(", tran-date:").append(gmtTranDate)
						.append(", tran-time:").append(gmtTranTime)
						.append(", local-datetime:").append(colombianDatetime)
						.append(", ref-num:").append(trxRefNum)
						.append(", amt:").append(trxAmt)
						.append(", response-code:").append(responseCode).toString();
						
			exchange.setProperty("trxInfoLog", loggerInfo);
			
			String transactionCity = inputMsg.get("transaction_city");
			String merchantCountryCode = inputMsg.get("merchant_country_code");

			CardAcceptorLocationParser.mapLocationInformation(inputMsg);

			String productType = inputMsg.get("str_product_type");
			productType = strEnrProdTypeFromStrProdType.get(productType);
			inputMsg.put("productId",cardNum);
			inputMsg.put("productType",productType);

		}catch (Exception e) {
			logger.error("ERR-TransactionDataProcessor: {}", e.toString());
			
			if(areRequiredFieldsWrong) {
				throw new EFMException(e.toString());
			}
		}
	}
	
}
