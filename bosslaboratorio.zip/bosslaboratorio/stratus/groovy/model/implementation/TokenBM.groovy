package stratus.groovy.model.implementation;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.DAVTokenizedDataParser;
import com.sas.davivienda.efm.commons.util.FMAPIFieldMapper
import com.sas.davivienda.efm.commons.util.FMUtils

import stratus.groovy.model.interfaces.IStratusToken;

public class TokenBM implements IStratusToken {

	private static final Logger logger = LoggerFactory.getLogger("strlog");
	private static final String TOKEN_NAME = "! BM";
	
	@Override
	public void mapTokenData(Map<String,String> inputMsg, String additionalData) {
		
		def tokenData = getTokenData(additionalData);
		
		if(FMUtils.hasValue(tokenData)) {
			
			try {
				FMAPIFieldMapper.mapStringValueByLen(tokenData, "token_bm", 6, inputMsg);
			}catch(Exception e) {
				//TODO -- test purpose only
				e.printStackTrace();
				logger.error("ERR-TKBM: {}",e.toString());
			}
		}
	}

	/**
	 * 
	 * @param additionalData
	 * @return
	 */
	public String getTokenData(String additionalData) {
		return additionalData.contains(TOKEN_NAME) ? DAVTokenizedDataParser.getStratusTokenData(additionalData, TOKEN_NAME) : "";
	}
}
