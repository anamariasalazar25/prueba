package stratus.groovy.model.implementation;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.DAVTokenizedDataParser;
import com.sas.davivienda.efm.commons.util.FMUtils;

import stratus.groovy.model.interfaces.IStratusToken;

public class TokenC4 implements IStratusToken {

	private static final Logger logger = LoggerFactory.getLogger("strlog");
	private static final String TOKEN_NAME = "! C4";
	
	@Override
	public void mapTokenData(Map<String,String> inputMsg, String additionalData) {
		String tokenData = getTokenData(additionalData);
		
		if(FMUtils.hasValue(tokenData)) {
			try {
				
				String[] dataSplit = tokenData.split("");
				
				inputMsg.put("rua_ind_001", dataSplit[0]);
				inputMsg.put("rua_ind_002", dataSplit[1]);
				inputMsg.put("rua_ind_003", dataSplit[2]);
				inputMsg.put("rua_ind_010", dataSplit[7]);
				inputMsg.put("rua_ind_011", dataSplit[8]);
				inputMsg.put("rua_ind_018", dataSplit[4]);
				inputMsg.put("rua_ind_019", dataSplit[5]);
				inputMsg.put("rua_ind_020", dataSplit[3]);
				inputMsg.put("rua_ind_021", dataSplit[9]);
				inputMsg.put("rua_ind_022", dataSplit[10]);
				inputMsg.put("rua_ind_023", dataSplit[11]);
				inputMsg.put("rua_ind_024", dataSplit[6]);
								
			}catch(Exception e) {
				//TODO -- test purpose only
				e.printStackTrace();
				logger.error("ERR-TKC4: {}",e.toString());
			}
		}
	}
	
	/**
	 * 
	 * @param additionalData
	 * @return
	 */
	public String getTokenData(String additionalData) {
		return additionalData.contains(TOKEN_NAME) ? DAVTokenizedDataParser.getStratusTokenData(additionalData, TOKEN_NAME) : "";
	}

}
