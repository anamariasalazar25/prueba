package stratus.groovy.model.implementation;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.DAVTokenizedDataParser;
import com.sas.davivienda.efm.commons.util.FMAPIFieldMapper
import com.sas.davivienda.efm.commons.util.FMUtils;

import stratus.groovy.model.interfaces.IStratusToken;

public class TokenQY implements IStratusToken {

	private static final Logger logger = LoggerFactory.getLogger("strlog");
	private static final String TOKEN_NAME = "! QY";
	
	@Override
	public void mapTokenData(Map<String,String> inputMsg, String additionalData) {
		String tokenData = getTokenData(additionalData);
		
		if(FMUtils.hasValue(tokenData)) {
			try {
				
				int tokenDataLen = tokenData.length(); 
				
				if(tokenDataLen > 160 && tokenDataLen <= 200) {
					inputMsg.put("token_qy_pt1", tokenData.substring(0, 80));
					inputMsg.put("token_qy_pt2", tokenData.substring(80, 160));
					inputMsg.put("token_qy_pt3", tokenData.substring(160, tokenDataLen));
				}
				
			}catch(Exception e) {
				//TODO -- test purpose only
				e.printStackTrace();
				logger.error("ERR-TKQY: {}",e.toString());
			}
		}
	}
	
	/**
	 * 
	 * @param additionalData
	 * @return
	 */
	public String getTokenData(String additionalData) {
		return additionalData.contains(TOKEN_NAME) ? DAVTokenizedDataParser.getStratusTokenData(additionalData, TOKEN_NAME) : "";
	}
}
