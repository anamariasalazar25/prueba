package stratus.groovy.model.implementation;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.exceptions.EFMException;
import com.sas.davivienda.efm.commons.util.DAVTokenizedDataParser;
import com.sas.davivienda.efm.commons.util.FMUtils;

import stratus.groovy.model.interfaces.IStratusToken;

public class TokenB0 implements IStratusToken {

	private static final Logger logger = LoggerFactory.getLogger("strlog");
	private static final String TOKEN_NAME = "! B0";
	//REDEBAN
	private static final String RDB_ID = "0034";		//0007
	private static final int RDB_SCORE_INIT_POSITION = 210;
	private static final int RDB_SCORE_FINAL_POSITION = 213;
	private static final int RDB_ECOM_SEC_LVL_INIT_POSITION = 80;
	private static final int RDB_ECOM_SEC_LVL_FINAL_POSITION = 83;
	//CREDIBANCO
	private static final String CBN_ID = "0031";		//0090
	private static final int CBN_SCORE_INIT_POSITION = 109;
	private static final int CBN_SCORE_FINAL_POSITION = 111;
	
	@Override
	public void mapTokenData(Map<String,String> inputMsg, String additionalData) {
		
		String tokenData = getTokenData(additionalData);
		String netCode = inputMsg.get("network_code");
		
		if(FMUtils.hasValue(tokenData) && FMUtils.hasValue(netCode)) {
			
			try {
												
				switch(netCode) {
					case RDB_ID:
						mapScoreValue(inputMsg, tokenData, RDB_SCORE_INIT_POSITION, RDB_SCORE_FINAL_POSITION, "score_master");
						mapEcomSecValue(inputMsg, tokenData, RDB_ECOM_SEC_LVL_INIT_POSITION, RDB_ECOM_SEC_LVL_FINAL_POSITION);
					break;
					case CBN_ID:
						mapScoreValue(inputMsg, tokenData, CBN_SCORE_INIT_POSITION, CBN_SCORE_FINAL_POSITION, "score_visa");
						//mapEcomSecValue(inputMsg, tokenData, CBN_ECOM_SEC_LVL_INIT_POSITION, CBN_ECOM_SEC_LVL_FINAL_POSITION);
					break;
					default:
					break;
				}
				
			}catch(Exception e) {
				//TODO -- test purpose only
				e.printStackTrace();
				logger.error("ERR-TKB0: {}",e.toString());
			}
		}
	}

	/**
	 *
	 * @param additionalData
	 * @return
	 */
	public String getTokenData(String additionalData) {
		String tokenData = "";
		try {
			tokenData = additionalData.contains(TOKEN_NAME) ? DAVTokenizedDataParser.getStratusTokenData(additionalData, TOKEN_NAME) : "";
		} catch (EFMException e) {
			logger.error("ERR-TKB0: {}",e.toString());
		}
		return tokenData;
	}
	
	/**
	 *
	 * @param inputMsg
	 * @param tokenData
	 * @param ini
	 * @param fin
	 */
	public void mapScoreValue(Map<String,String> inputMsg, String tokenData, int ini, int fin, String scoreType) {
		String scoreValue = tokenData.length() > fin ? tokenData.substring(ini, fin) : "";
		
		if(FMUtils.hasValue(scoreValue)) {
			
			if("score_visa".equals(scoreType)) {
				int scoreLen = scoreValue.length();
				scoreValue = scoreLen > 2 ? scoreValue.substring(scoreLen-2,scoreLen): scoreValue;
			}
			inputMsg.put(scoreType, scoreValue);
		}
	}
	
	/**
	 *
	 * @param inputMsg
	 * @param tokenData
	 * @param ini
	 * @param fin
	 */
	public void mapEcomSecValue(Map<String,String> inputMsg, String tokenData, int ini, int fin) {
		
		String ecomSecLvl = tokenData.length() > fin ? tokenData.substring(ini, fin) : "";
		
		if(FMUtils.hasValue(ecomSecLvl)) {
			inputMsg.put("ecom_sec_lvl", ecomSecLvl);
		}
	}
}
