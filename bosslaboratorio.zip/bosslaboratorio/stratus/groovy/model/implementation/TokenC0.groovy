package stratus.groovy.model.implementation;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.DAVTokenizedDataParser;
import com.sas.davivienda.efm.commons.util.FMUtils

import stratus.groovy.model.interfaces.IStratusToken;

public class TokenC0 implements IStratusToken {

	private static final Logger logger = LoggerFactory.getLogger("strlog");
	private static final String TOKEN_NAME = "! C0";
	
	@Override
	public void mapTokenData(Map<String,String> inputMsg, String additionalData) {
		def tokenData = getTokenData(additionalData)
		
		if(FMUtils.hasValue(tokenData)) {
			try {
				def ecomFlg = tokenData.substring(18, 19);
				inputMsg.put("ecom_flg", ecomFlg);
				
				def cvdFldPresent = tokenData.substring(21, 22);
				inputMsg.put("cvd_fld_present", cvdFldPresent);
				
				def authCollInd = tokenData.substring(23, 24);
				inputMsg.put("auth_coll_ind", authCollInd);
				
				def cavvAavRsltCde = tokenData.substring(25, 26);
				inputMsg.put("cavv_avv_rslt_cde", cavvAavRsltCde);


				def motoFlg = tokenData.substring(18, 19);
				inputMsg.put("moto_flg", motoFlg);

				def sasOrForcePost = tokenData.substring(22, 23);
				inputMsg.put("sas_or_force_post", sasOrForcePost);

				def frdPrnFlg = tokenData.substring(24, 25);
				inputMsg.put("frd_prn_flg", frdPrnFlg);

				def termPostalCde = tokenData.substring(8, 18);
				inputMsg.put("term_postal_cde", termPostalCde);

								
			}catch(Exception e) {
				//TODO -- test purpose only
				e.printStackTrace();
				logger.error("ERR-TKC0: {}",e.toString());
			}
		}
	}
	
	/**
	 * 
	 * @param additionalData
	 * @return
	 */
	public String getTokenData(String additionalData) {
		return additionalData.contains(TOKEN_NAME) ? DAVTokenizedDataParser.getStratusTokenData(additionalData, TOKEN_NAME) : "";
	}

}
