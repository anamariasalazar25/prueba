package com.fadosol.integration.groovy;

import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.sas.davivienda.efm.commons.dto.TableCardMedia;
import com.sas.davivienda.efm.commons.util.FMUtils;

/**
 * 
 *
 */
public class CardRelatedDataProcessor {
	
	private static final Logger logger = LoggerFactory.getLogger("strlog");
	
	@Resource
	@Qualifier("cardMediaFromPOSEntryMode")
	private List<TableCardMedia> cardMediaFromPOSEntryMode;
	
	@Resource
	@Qualifier("strCardPresentFromPosEntryMode")
	private Map<String, String> strCardPresentFromPosEntryMode;
	
	@Resource
	@Qualifier("strUcmCatFromTerminalType")
	private Map<String, String> strUcmCatFromTerminalType;
	
	@Resource
	@Qualifier("strUcmTermPanEntryCapFromPosEntry")
	private Map<String, String> strUcmTermPanEntryCapFromPosEntry;
	
	@Resource
	@Qualifier("strCustPresentFromPosConditionCode")
	private Map<String, String> strCustPresentFromPosConditionCode;
	
	@Resource
	@Qualifier("strAuthSchemeFromIssuerBin")
	private Map<String,String> strAuthSchemeFromIssuerBin;
	
	@Resource
	@Qualifier("chVerifyFromEcomFlag")
	private Map<String, String> chVerifyFromEcomFlag;
	
	/**
	 * 
	 */
	public CardRelatedDataProcessor() {
		logger.info("Init strCardRelatedDataProcessor");
	}
	
	/**
	 * 
	 * @param exchange
	 */
	public void mapCardRelatedData(Exchange exchange) {
		
		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");
		
		try {
			String posEntryMode = inputMsg.get("pos_entry_mode");
			String terminalType = inputMsg.get("terminal_type");
			String panEntryCap = inputMsg.get("pan_entry_capability");
			String pinEntryCap = inputMsg.get("pin_entry_capability");
			String nationalInternational = inputMsg.get("national_international");
			String issuerBin = inputMsg.get("issuer_bin");
			String ecomFlg = inputMsg.get("ecom_flg");
			String posConditionCode = inputMsg.get("pos_condition_code");
			
			String custPresent = strCustPresentFromPosConditionCode.get(posConditionCode);
			if(FMUtils.isNullOrEmpty(custPresent)){
				custPresent = '1';
			}

			inputMsg.put("ucm_cust_present", custPresent);
			
			if(FMUtils.hasValue(posEntryMode) && posEntryMode.length() >= 2) {
				String panEntryMode = posEntryMode.substring(0, 2);
				inputMsg.put("card_media", getCardMedia(panEntryMode,pinEntryCap));
				inputMsg.put("ucm_card_present", strCardPresentFromPosEntryMode.get(panEntryMode));
				inputMsg.put("ucm_pos", panEntryMode);
				inputMsg.put("pan_entry_cap", strUcmTermPanEntryCapFromPosEntry.get(panEntryMode));
			}

			if(FMUtils.hasValue(ecomFlg)) {
				inputMsg.put("ucm_ch_evrfy", getSASEcomFlagEquivalent(ecomFlg));
			}
			
			String ucmCat = strUcmCatFromTerminalType.get(terminalType);
			String ucmScheme = getauthSchemeFromIssuerBin(nationalInternational,issuerBin.charAt(0));
			inputMsg.put("ucm_cat", ucmCat);
			
			inputMsg.put("ucm_scheme", ucmScheme);
			inputMsg.put("issuer_bin", issuerBin);
		}catch(Exception e) {
			//TODO -- test purpose only
			e.printStackTrace();
			logger.info("ERR-CardRelatedDataProcessor: {}", e.toString());
		}
	}
	
	/**
	 * 
	 * @param posEntryMode
	 * @return
	 */
	public String getCardMedia(String panEntryMode, String pinEntryMode) {
		
		String cardMedia = "";
		String pinEntry = "";
		
		if("05".equals(panEntryMode) || "07".equals(panEntryMode)) {
			pinEntry = pinEntryMode;
		}
		
		TableCardMedia tableCardMedia = new TableCardMedia(panEntryMode, pinEntry);
		int index = cardMediaFromPOSEntryMode.indexOf(tableCardMedia);
		
		if(index > -1) {
			TableCardMedia inputCardMedia = cardMediaFromPOSEntryMode.get(index);
			cardMedia = inputCardMedia.getCardMedia();
		}
		return cardMedia;
	}
	
	/**
	 * 
	 * @param nationalInternational
	 * @param issuerBin
	 * @return
	 */
	public String getauthSchemeFromIssuerBin(String nationalInternational, char issuerBin) {
		String authScheme = "L";
		
		if("INT".equalsIgnoreCase(nationalInternational)) {
			authScheme = strAuthSchemeFromIssuerBin.get(String.valueOf(issuerBin));
			authScheme = FMUtils.hasValue(authScheme)? authScheme: "O";
		}
		return authScheme;
	}

	/**
	 * 	
	 * @param ecomFlag
	 * @return
	 */
	public String getSASEcomFlagEquivalent(String ecomFlag) {
		String ecomFlagEquivalent = chVerifyFromEcomFlag.get(ecomFlag);
		return FMUtils.isNullOrEmpty(ecomFlagEquivalent) ? "2" : ecomFlagEquivalent;
	}
	
}
