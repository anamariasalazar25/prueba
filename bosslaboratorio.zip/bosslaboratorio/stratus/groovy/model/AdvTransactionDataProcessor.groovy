import java.util.Map;

import javax.annotation.Resource;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import com.sas.davivienda.efm.commons.dto.ISOCountry;
import com.sas.davivienda.efm.commons.exceptions.EFMException;
import com.sas.davivienda.efm.commons.mapper.DIANComplementaryCodeMapper;
import com.sas.davivienda.efm.commons.dto.DIANComplementaryCode;
import com.sas.davivienda.efm.commons.mapper.ISOCountryMapper;
import com.sas.davivienda.efm.commons.util.FMAPIFieldMapper;
import com.sas.davivienda.efm.commons.util.FMUtils;
import stratus.groovy.model.enums.TpoPersona;
import stratus.groovy.tools.CardAcceptorLocationParser;
import stratus.groovy.model.enums.ChannelType;

/**
 *
 *
 */
public class AdvTransactionDataProcessor {

	private static final Logger logger = LoggerFactory.getLogger("strlog");
	private static final String STRATUS_DATETIME = "yyyyMMddHHmmss";

	@Resource
	@Qualifier("strActivityTypeFromTranType")
	private Map<String, String> strActivityTypeFromTranType;

	@Resource
	@Qualifier("strEnrProdTypeFromStrProdType")
	private Map<String,String> strEnrProdTypeFromStrProdType;

	public AdvTransactionDataProcessor() {
		logger.info("Init AdvTransactionDataProcessor");
	}

	/**
	 *
	 * @param exchange
	 * @throws EFMException
	 */
	public void mapTransactionData(Exchange exchange) throws EFMException {

		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");
		boolean areRequiredFieldsWrong = false;
				
		try {
			
			String mti = inputMsg.get("message_type");
			exchange.setProperty("mti",mti);
			String trxRefNum = inputMsg.get("transaction_number");
			String trxCode = inputMsg.get("transaction_code");
			String payeerAccountNum = inputMsg.get("acct_num_payeer");
			String posEntryMode = inputMsg.get("pos_entry_mode");
			String channelId = inputMsg.get("channel");
			String responseCode = inputMsg.get("response_code");
			String motive = inputMsg.get("motive");
			String reference1 = inputMsg.get("reference1");
			String sasActivityType = inputMsg.get("sas_activity_type");
			String officeCode = inputMsg.get("office_code");
			String officeName = inputMsg.get("office_name");
			String terminalId = inputMsg.get("terminal_id");

			if (posEntryMode != null && posEntryMode.length() > 2){
				posEntryMode = posEntryMode.substring(0,2);
				inputMsg.put("pos_entry_mode", posEntryMode);
			}

			inputMsg.put("acct_num", payeerAccountNum);
			
			String trxAmt = inputMsg.get("transaction_amount");

			if (trxAmt != null){
				inputMsg.put("transaction_amt",FMUtils.addDecimalSeparator(trxAmt));
			}
			/* Corrigen el incidente de saldo disponible sin cifras decimales*/
			String aqdAvailBal = inputMsg.get("balance");

			if (aqdAvailBal != null){
				inputMsg.put("aqd_Avail_Balance",FMUtils.addDecimalSeparator(aqdAvailBal));
			}

			String tranDate = inputMsg.get("gmt_tran_date");
			String tranTime = inputMsg.get("gmt_tran_time");
			
			String tranDatetime = tranDate.concat(tranTime);
			FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(tranDatetime, "sas_gmt_tran_date", "sas_gmt_tran_time", inputMsg, STRATUS_DATETIME);
			FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(tranDatetime, "sas_colombian_tran_date", "sas_colombian_tran_time", inputMsg, STRATUS_DATETIME);

			inputMsg.put("transaction_datetime",tranDatetime);
			
			StringBuilder loggerInfo = new StringBuilder();
			
			loggerInfo.append("mti:").append(mti)
						.append(", tran-code:").append(trxCode)
						.append(", channel:").append(channelId)
						.append(", tran-date:").append(tranDate)
						.append(", tran-time:").append(tranTime)
						.append(", local-datetime:").append(tranDatetime)
						.append(", ref-num:").append(trxRefNum)
						.append(", amt:").append(trxAmt)
						.append(", motive:").append(motive)
						.append(", response-code:").append(responseCode).toString();
						
			exchange.setProperty("trxInfoLog", loggerInfo);
			
			String transactionCity = inputMsg.get("transaction_city");
			String merchantCountryCode = inputMsg.get("merchant_country_code");

			CardAcceptorLocationParser.mapLocationInformation(inputMsg);

			inputMsg.put("sas_channel_type", getChannelType(channelId));
			inputMsg.put("sas_auth_method", getAuthenticateMethod(posEntryMode));
			
			exchange.setProperty("isResponseRequired",false);
			inputMsg.put("sas_resp_req","0");

			inputMsg.put("productId", payeerAccountNum);
			String productType = inputMsg.get("acct_type_payeer");
			productType = strEnrProdTypeFromStrProdType.get(productType);
			inputMsg.put("productType", productType);

			inputMsg.put("office_code", officeCode);
			inputMsg.put("office_name", officeName);
			inputMsg.put("terminal_id", terminalId);

			if (sasActivityType == "NM"){
				if (reference1 != null && reference1.substring(0,14) == "00000000000000"){
					String codBloqueo = reference1.substring(14,16);
					inputMsg.put("cod_bloqueo", codBloqueo);
				}
			}
			
			if (sasActivityType == "DP"){
				if (reference1 != null){
					String nroCredito = reference1;
					inputMsg.put("tpp_num", nroCredito);
				}
				inputMsg.put("tpp_acct_type", productType);
				inputMsg.put("tpp_acct_num", payeerAccountNum);

			}
						
			exchange.getIn().setBody(inputMsg);

		}catch (Exception e) {
			logger.error("ERR-AdvTransactionDataProcessor: {}", e.toString());
			
			if(areRequiredFieldsWrong) {
				throw new EFMException(e.toString());
			}
		}
	}
	
	public String getAuthenticateMethod(String posEntryMode){
		String authMethod = "NC";

		switch(posEntryMode) {
			case "05":
				authMethod = "CP";
			break;
			case "90":
				authMethod = "CD";
			break;
			default:
			break;
		}
		return authMethod;
	}

	public String getChannelType(String channelId){
		ChannelType sasChannelType = ChannelType.getIfPresent("CH_"+channelId);
		return sasChannelType == null ? ChannelType.DEFAULT.getSASChannelType() : sasChannelType.getSASChannelType();
	}

	public void getMultiOrgTrx(Exchange exchange){
		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");

		String integSource = exchange.getProperty("integSource");
		String custType = inputMsg.get("dbenr_prod_type");
		if(FMUtils.isNullOrEmpty(custType)){
			custType = "P";
		}

		String channelType = "VIRTUAL-CHANNEL".equals(integSource) ? "VC" : "PC";
		String channelPersonRelationship = channelType + "_" + custType;

		if("PC".equals(channelType)){
			String channelId = inputMsg.get("channel");
			String activityType = inputMsg.get("sas_activity_type");

			if("03".equals(channelId)){
				channelPersonRelationship += "_" +  channelId + "_" + activityType;
			}
		}

		//logger.info("channelPersonRelationship: {}",channelPersonRelationship);
		TpoPersona tipoPersona = TpoPersona.valueOf(channelPersonRelationship);

		//logger.info("tipoPersona: {}, multiorg: {}, channelId:{}",tipoPersona.tpoPersonaSMH,tipoPersona.tpoPersonaMulti,inputMsg.get("channel").toString());
		
		inputMsg.put("smh_multi_org_name", tipoPersona.tpoPersonaMulti);
		inputMsg.put("smh_cust_type", tipoPersona.tpoPersonaSMH);
	}

}
