import java.util.Map;
import javax.annotation.Resource;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.sas.davivienda.efm.commons.util.FMUtils;

/**
 * System Message Header Segment
 */
public class HeaderDataProcessor {
	
	private static final Logger logger = LoggerFactory.getLogger("strlog");
		
	@Resource
	@Qualifier("strAcctTypeFromRPR")
	private Map<String, String> strAccountTypeFromSubProduct;
		
	@Resource
	@Qualifier("strAuthenticateMethodFromCardMedia")
	private Map<String, String> authenticateMethodFromCardMedia;
	
	@Resource
	@Qualifier("strResponseRequiredFromTranType")
	private Map<String, String>	strResponseRequiredFromTranType;
	
	public HeaderDataProcessor() {
		logger.info("Init strHeaderData");
	}
	
	/**
	 * 
	 * @param inputMsg
	 */
	public void mapHeaderData(Exchange exchange) {
		
		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");

		try {
			
			String dbenrProdType = inputMsg.get("dbenr_prod_type");
			String sasCustType = FMUtils.hasValue(dbenrProdType) && "E".equals(dbenrProdType) ? "B" : "I";
			
			String dbenrProdCode = inputMsg.get("dbenr_prod_cod");
			String sasAcctType = FMUtils.hasValue(dbenrProdCode) ? strAccountTypeFromSubProduct.get(dbenrProdCode) : "CS";
			
			String cardMedia = inputMsg.get("card_media");
			String sasAuthMethod = getAuthenticateMethodFromCardMedia(cardMedia);
			
			String sasActivityType = exchange.getProperty("sasActivityType");
			
			String nationalInternational = inputMsg.get("national_international");
			if(FMUtils.hasValue(nationalInternational)) {
				inputMsg.put("nal_internal", nationalInternational.substring(0, 1));
			}
			
			inputMsg.put("sas_cust_type", sasCustType);
			inputMsg.put("sas_channel_type", "C");
			inputMsg.put("sas_acct_type", sasAcctType);
			inputMsg.put("sas_auth_method", sasAuthMethod);
			inputMsg.put("sas_activity_type", sasActivityType);
			inputMsg.put("sas_multi_org", getMultiOrgNode(sasActivityType, nationalInternational));
			
			String respRequired =  getResponseRequired(inputMsg);
                       exchange.setProperty("isResponseRequired","1".equals(respRequired));
                       inputMsg.put("sas_resp_req",respRequired);

                       logger.info("####sas_resp_req: {}, isResponseRequired: {}", respRequired, "1".equals(respRequired));
            						
		}catch(Exception e) {
			//TODO -- test purpose only
			e.printStackTrace();
			logger.info("ERR-HeaderDataProcessor: {}", e.toString());
		}finally{
                       exchange.getIn().setBody(inputMsg);
               }
	}
	
	/**
	 * 
	 * @param cardMedia
	 * @return
	 */
	public String getAuthenticateMethodFromCardMedia(String cardMedia) {
		String authenticateMethod = "";
		authenticateMethod = authenticateMethodFromCardMedia.get(cardMedia);
		return FMUtils.hasValue(authenticateMethod) ? authenticateMethod : "CD";
	}
	
	/**
	 * 
	 * @param activityType
	 * @param nationalInternationalInd
	 * @return
	 */
	public String getMultiOrgNode(String activityType, String nationalInternationalInd) {
		String multiOrgNode = "";
		
		switch(activityType) {
			case "CA": case "BF":
				multiOrgNode = FMUtils.hasValue(nationalInternationalInd) && "INT".equals(nationalInternationalInd) ? "INTERNAL" : "NACIONAL";
			break;
			case "NM": case "DP":
				multiOrgNode = "NO_TX_TC_TD";
			break;
			default:
			break;
		}
		return multiOrgNode;
	}
	
	/**
	 * 
	 * @param inputMsg
	 */
	public String getResponseRequired(Map<String, String> inputMsg) {
		
		String mti = inputMsg.get("message_type");
		String trxCode = inputMsg.get("transaction_code");
		String trxType = trxCode.substring(0,2);
		String respRequired = "0";
		
		if("0200".equals(mti)) {
			respRequired = strResponseRequiredFromTranType.get(trxType);	
		}
		logger.info("####transaction_code: {}, sas_resp_req: {}", trxCode, respRequired);

		return respRequired;
	}
}
