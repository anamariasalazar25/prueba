package stratus.groovy.model.enums;

public enum TpoPersona {
	
	PC_P("I", "CF_PERSONAS"),
	PC_E("B", "CF_EMPRESAS"),
	VC_P("I", "CV_PERSONAS"),
	VC_E("B", "CV_EMPRESAS"),
	PC_P_03_CA("I", "NACIONAL"),
	PC_E_03_CA("B", "NACIONAL"),
	PC_P_03_NM("I", "NO_TX_TC_TD"),
	PC_E_03_NM("B", "NO_TX_TC_TD")
	
	private final String tpoPersonaSMH;
	private final String tpoPersonaMulti;
	
	private TpoPersona(final String tpoPersonaSMH, final String tpoPersonaMulti) {
		this.tpoPersonaSMH = tpoPersonaSMH;
		this.tpoPersonaMulti = tpoPersonaMulti;
	}
	
	@Override
	public String toString() {
		return this.tpoPersonaMulti;
	}
}
