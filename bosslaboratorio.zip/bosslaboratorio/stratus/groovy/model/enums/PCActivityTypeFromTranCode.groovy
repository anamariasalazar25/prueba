package stratus.groovy.model.enums;

import com.google.common.base.Enums;

public enum PCActivityTypeFromTranCode {
	
	PC_000000("CA","Retiro sin Medio (declinación)"),
	PC_000124("NM","Consulta de Cuenta con Tarjeta"),
	PC_000133("NM","Consulta de Producto"),
	PC_000300("NM","Apertura de cuenta"),               // migración adv de Monitor 
	PC_000350("NM","Bloqueo o desbloqueo de cuenta"),   // migración adv de Monitor 
	PC_000358("NM","Consulta y novedad de oficina de radicación"),
	PC_000372("NM","Asignación - Activación Tarjeta"),
	PC_000382("BF","Recargas a Celular (Comcel, movistar, tigo)"),
	PC_000394("NM","Cambio de Clave"),
	PC_000396("NM","Cambio de Clave"),
	PC_000398("NM","Derogación Tarjete Débito"),        // migración adv de Monitor 
	PC_000400("NM","Asignación clave web"),
	PC_000602("CA","Retiro sin Medio (declinación)"),
	PC_000700("NM","Asignación Tarjeta Débito"),        // migración adv de Monitor
	PC_001151("NM","Asignación - Activación Tarjeta Crédito"),
	PC_001706("NM","Asociación Débito Automático"),
	PC_001726("BF","Pago producto Crédito FM"),
	PC_002020("CW","Retiro en ATM con tarjeta"),
	PC_002022("CW","Retiro en ATM sin medio"),
	PC_002021("CW","Reverso retiro en ATM con tarjeta"),
	PC_002024("CW","Retiro en ATM con Donación"),
	PC_002130("CW","Retiro en Corresponsales sin medio"), //Adicion cod trnx rdb stratus
	PC_003100("NM","Consulta Persona Natural"),
	PC_003189("NM","Consulta Titulares Cuentas"),
	PC_004373("BF","Pago de Servicios Públicos"),
	PC_004812("BF","Pago Tarjeta de Crédito"),
	PC_004822("NM","Consulta Tarjeta de Crédito"),
	PC_005050("NM","Consulta de Saldo"),
	PC_005060("NM","Consulta de Cobros"),
	PC_005074("NM","Cambiar numero destinatario Giro"),
	PC_005100("NM","Consulta de saldos para Cuenta Corriente sin tarjeta"),
	PC_005102("NM","Consulta Titular Cuentas"),
	PC_005104("NM","Consulta saldo de cuenta con tarjeta"),
	PC_005110("NM","Consulta de Saldo Caja Supervisor"),
	PC_005111("NM","Consulta de Saldo Cta Ahorros"),
	PC_005113("NM","Consulta de Saldo Bolsillo"),
	PC_005126("NM","Consulta Saldo Cancelación con Tarjeta"),
	PC_005128("NM","Consulta Saldo Cancelación con Tarjeta"),
	PC_005138("NM","Consulta Cuentas"),
	PC_005150("NM","Consulta Estado de un Cheque"),
	PC_005151("NM","Consulta Cheque-Chequera"),
	PC_005160("NM","Consulta Chequeras"),
	PC_005163("NM","Consulta Chequeras"),
	PC_005190("NM","Consulta de Divisas "),
	PC_005194("NM","Consulta Liquidación Transferencia"),
	PC_005220("BF","Transferencia a Monedero"),
	PC_005260("BF","Transferencias"),
	PC_005270("DP","Abono Aut Trnsf Intnal Bancomex"),  // migración adv de Monitor 
	PC_005300("NM","Apertura de cuenta"),               // migración adv de Monitor 
	PC_005355("NM","Consulta de Saldo Crédito"),
	PC_005360("NM","Cancelación de Producto"),
	PC_005382("NM","Activacion chequera"),
	PC_005600("CW","Retiro en Efectivo a Cuentas sin Tarjeta"),
	PC_005602("CW","Pago de Cheque por Ventanilla"),
	PC_005604("CW","Retiro en efectivo a cuentas con tarjeta "),
	PC_005608("CW","Retiro AFC con Tarjeta"),
	PC_005612("CW","Retiro en Cheque a cuentas sin tarjeta "),
	PC_005614("CW","Retiro en Cheque a cuentas con tarjeta "),
	PC_005622("CW","Retiro en Efectivo a Cuentas sin Tarjeta - Con Supervisión"),
	PC_005632("CW","Retiro en Cheque a cuentas sin tarjeta + Ind. Autorizado"),
	PC_005642("CW","Retiro en Efectivo a Cuentas sin Tarjeta - Con Supervisión"),
	PC_005644("CW","Retiro en efectivo a cuentas con tarjeta- Con Supervisión "),
	PC_005648("CW","Retiro en Cheque a cuentas sin tarjeta- Con Supervisión "),
	PC_005652("CW","Pago de Cheque por Ventanilla con Supervision"),
	PC_005654("CW","Retiro en Cheque a cuentas con tarjeta- Con Supervisión "),
	PC_005656("CW","Retiros Cuenta Ahorros/Corriente Jurídica"),
	PC_005658("CW","Retiro Persona Jurídica Cheque"),
	PC_005660("BF","Nota Débito"),
	PC_005680("BF","Nota Débito Supervisada"),
	PC_005682("BF","Transferencias"),
	PC_005683("BF","Pago Planilla Asistida"),
	PC_005686("BF","Transferencias o Abono x Uso Cupo Crediexpress"), 
	PC_005698("DP","Pago Cheque Por Canje"),
	PC_005700("NM","Consignación Efectivo. Cta. Ahorro/Cta Cte"),
	PC_005702("NM","Consignación Efectivo. Cta. Ahorro AFC"),
	PC_005704("NM","Consignación Efectivo Tarjeta. Cta. Ahorro/Cta Cte"),
	PC_005710("NM","Consignación En Cheques Locales Sin tarjeta Cta. Ahorro/Cte"),
	PC_005714("NM","Consignación En Cheques Locales Con Tarjeta Cta. Ahorro/Cte"),
	PC_005740("DP","Depósito Cheque Otras Plazas"),
	PC_005770("DP","Nota Crédito Cta- Cte/Ahor. o Abono Aut. Trnsf Intnal x Bancomex"),
	PC_005780("BF","Nota Crédito Tarjeta de Crédito"),
	PC_006262("BF","Transferencia"),
	PC_006464("BF","Transferencia a Cuentas de Otros Bancos"),
	PC_007500("BF","Recaudos"),
	PC_007501("BF","Reversión Recaudo"),
	PC_007504("BF","Recaudos"),
	PC_007502("BF","Recaudo de Convenios"),
	PC_007508("BF","Pago de Servicios"),
	PC_007510("BF","Pago Servicios con Tarjeta Debito"),
	PC_005798("DP","Nota credito ajuste cheque"),
	PC_009090("NM","Cambio de Clave"),
	PC_009660("BF","Notas débito (declinaciones)"),
	PC_009770("DP","Ventas Diners/Amex/Visa/Mastercard"),   // migración adv de Monitor 
	PC_ActivCTR("NM","Activación clave de teléfono rojo"),
	PC_AsignClOlv("NM","Asignación clave por olvido"),
	PC_AsignCTR("NM","Asignación clave de teléfono rojo"),
	PC_CambClaTR("NM","Cambio Clave Teléfono Rojo"),
	PC_CambClVirt("NM","Cambio Clave Virtual"),
	PC_CambCVMono("NM","Cambio Clave Virtual Monoproducto"),
	PC_CambSegCla("NM","Cambio De Segunda Clave"),
	PC_ReenvOTPGi("NM","Reenvio de OTP para novedad en giro"),
	
	private final String sasActivityType;
	private final String description;
		
	private PCActivityTypeFromTranCode(final String sasActivityType, final String description) {
		this.sasActivityType = sasActivityType;
		this.description = description;
	}
	
	public static PCActivityTypeFromTranCode getIfPresent(String name) {
		return Enums.getIfPresent(PCActivityTypeFromTranCode.class, name).orNull();
	}
	
	public String getSASActivityType(){
		return sasActivityType;
	}
}
