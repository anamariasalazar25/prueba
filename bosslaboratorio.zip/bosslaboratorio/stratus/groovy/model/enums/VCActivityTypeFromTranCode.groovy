package stratus.groovy.model.enums;

import com.google.common.base.Enums;

public enum VCActivityTypeFromTranCode {
	
	VC_000124("NM","Consulta de Cuenta con Tarjeta"),
	VC_000132("NM","Consulta productos"),
	VC_000133("NM","Consulta de productos"),
	VC_000350("NM","Bloqueo y Desbloqueo de cuenta"),
	VC_000352("NM","Novedad Marcación Empresarial"),
	VC_000372("NM","Asignación - Activación Tarjeta"),
	VC_000374("NM","Inscripción de cuentas ACH"),
	VC_000382("BF","Recargas a Celular (Comcel, movistar, tigo)"),
	VC_000394("NM","Cambios de clave"),
	VC_000396("NM","Cambio de Clave"),
	VC_000400("NM","Asignación clave web"),
	VC_001151("NM","Asignación - Activación Tarjeta Crédito"),
	VC_001706("NM","Asociación Débito Automático"),
	VC_001726("BF","Pago producto Crédito FM"),
	VC_003100("NM","Consulta Persona Natural"),
	VC_003189("NM","Consulta Titulares Cuentas"),
	VC_004373("BF","Pago de Servicios Públicos"),
	VC_004812("BF","Pago Tarjeta de Crédito"),
	VC_004822("NM","Consulta Tarjeta de Crédito"),
	VC_005050("NM","Consulta de Saldo"),
	VC_005060("NM","Consulta cobros"),
	VC_005074("NM","Cambiar numero destinatario Giro"),
	VC_005100("NM","Consulta de saldos para Cuenta Corriente sin tarjeta"),
	VC_005102("NM","Consulta Titular Cuentas"),
	VC_005104("NM","Consulta saldo de cuenta con tarjeta"),
	VC_005111("NM","Consulta de Saldo Cta Ahorros"),
	VC_005113("NM","Consulta saldo Bolsillo "),
	VC_005126("NM","Consulta Saldo Cancelación con Tarjeta"),
	VC_005128("NM","Consulta Saldo Cancelación con Tarjeta"),
	VC_005138("NM","Consulta Cuentas"),
	VC_005150("NM","Consulta Estado de un Cheque"),
	VC_005151("NM","Consulta Cheque-Chequera"),
	VC_005160("NM","Consulta Chequeras"),
	VC_005163("NM","Consulta Chequeras"),
	VC_005190("NM","Consulta de Divisas "),
	VC_005194("NM","Consulta Liquidación Transferencia"),
	VC_005220("BF","Transferencia a Monedero"),
	VC_005260("BF","Transferencias"),
	VC_005262("NM","Recaudo con debito a cuenta"),  // Adicionada para iniciativa Seguro Hogar Soat
	VC_005355("NM","Consulta de Saldo Crédito"),
	VC_005360("NM","Cancelación de Producto"),
	VC_005382("NM","Activacion chequera"),
	VC_005660("BF","Nota Débito"),
	VC_005680("BF","Nota Débito Supervisada"),
	VC_005682("BF","Transferencias"),
	VC_005683("BF","Pagos Planilla Asistida"),
	VC_005686("BF","Transferencias"),
	VC_005700("NM","Consignación Efectivo. Cta. Ahorro/Cta Cte"),
	VC_005702("NM","Consignación Efectivo. Cta. Ahorro AFC"),
	VC_005704("NM","Consignación Efectivo Tarjeta. Cta. Ahorro/Cta Cte"),
	VC_005710("NM","Consignación En Cheques Locales Sin tarjeta Cta. Ahorro/Cte"),
	VC_005714("NM","Consignación En Cheques Locales Con Tarjeta Cta. Ahorro/Cte"),
	VC_005780("BF","Nota Crédito Tarjeta de Crédito"),
	VC_006262("BF","Transferencia"),
	VC_006464("BF","Transferencia a Cuentas de Otros Bancos"),
	VC_006502("BF","Adelanto o transferencia a daviplata"),
	VC_007500("BF","Recaudo"),
	VC_007501("BF","Reversión Recaudo"),
	VC_007502("BF","Recaudo de Convenios"),
	VC_007504("BF","Recaudo"),
	VC_007508("BF","Pago de Servicios"),
	VC_007510("BF","Pago Servicios con Tarjeta Debito"),
	VC_009090("NM","Cambio de Clave"),
		
	private final String sasActivityType;
	private final String description;
	 
	private VCActivityTypeFromTranCode(final String sasActivityType, final String description) {
		this.sasActivityType = sasActivityType;
		this.description = description;
	}
	
	public static VCActivityTypeFromTranCode getIfPresent(String name) {
		return Enums.getIfPresent(VCActivityTypeFromTranCode.class, name).orNull();
	}
	
	public String getSASActivityType(){
		return sasActivityType;
	}
}
