import javax.annotation.Resource

import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.ApplicationContext
import org.springframework.context.support.ClassPathXmlApplicationContext
import com.sas.davivienda.efm.commons.util.FMUtils
import com.sas.davivienda.efm.commons.util.FMAPIFieldMapper
import com.sas.davivienda.efm.commons.util.FMDateFormatter
import java.text.SimpleDateFormat;

/**
 *
 * 
 *
 */
public class DatabaseParser {

	@Resource
	@Qualifier("portfolioFromComSegment")
	private Map<String,String> portfolioFromComSegment;

	private static final Logger logger = LoggerFactory.getLogger("DatabaseParser");

	public DatabaseParser() {
		logger.info("DatabaseParser");
	}

	/**
	 * 
	 * @param exchange
	 */
	public void mapDatabaseData(Exchange exchange) {

		Map<String,Object> inputMsg = exchange.getProperty("inputMsg",Map.class);
		Map<String,Object> databaseResultList = exchange.getIn().getBody();

		if(databaseResultList == null || databaseResultList.isEmpty()) {
			logger.error("No se encontraron registros para el producto en base de datos");
		}else {

			try {
				def prodNum = databaseResultList.get("CAMPO.NRO_PRODUCTO");
				def idType = databaseResultList.get("CAMPO.COD_TIPO_ID");
				def idNumber = databaseResultList.get("CAMPO.NRO_IDENTIFICACION");
                def custNumber = "";
                if(idType != null && idNumber != null){
                    custNumber = idType.concat(idNumber);
                }
				def productType = databaseResultList.get("CAMPO.TIPO_PRODUCTO"); 	//TIPO_PERSONA
				def productCode = databaseResultList.get("CAMPO.COD_PRODUCTO");		//TIPO_PRODUCTO_CTA
				def productDesc = databaseResultList.get("CAMPO.DESCRIPCION_SUBPRODUCTO");
				def cardStatusCode = databaseResultList.get("CAMPO.COD_ESTADO_TD");
				def accountStatusCode = databaseResultList.get("CAMPO.COD_ESTADO_TC");
				def effectCode = databaseResultList.get("REG.CAMPO.CODIGO_VIGENCIA");
				def lastBlockingAccountDate = databaseResultList.get("CAMPO.FECHA_ULTIMO_BLOQUEO");
				def lastBlockingDate = databaseResultList.get("CAMPO.FECHA_ULTIMO_BLOQUEO_TD");
				def currentRegistBranch = databaseResultList.get("CAMPO.OFICINA_RADICACION_ACTUAL");
				def issueDate = databaseResultList.get("CAMPO.FECHA_EMISION");
				def acctOpeningDate = databaseResultList.get("CAMPO.FECHA_APERTURA");
				def reissuedCardNum = databaseResultList.get("CAMPO.NRO_NUEVO_PRODUCTO_REEXPEDIDO");
				def rprSubproduct = databaseResultList.get("CAMPO.COD_SUBPRODUCTO");
				def commercialSegment = databaseResultList.get("CAMPO.COD_SEGMENTO_COM");
				def commercialSegmentDesc = databaseResultList.get("CAMPO.SEGMENTO_COM");
				def subSegmentCode = databaseResultList.get("CAMPO.COD_SUBSEGMENTO_COM");
				def subsegmentDesc = databaseResultList.get("CAMPO.SUBSEGMENTO_COM");
				def emailAddress = databaseResultList.get("CAMPO.CORREO_ELECTRONICO");
				def principalPhoneNum = databaseResultList.get("CAMPO.TELEFONO_PRINCIPAL");
				def principalMobilePhone = databaseResultList.get("CAMPO.CELULAR_PRINCIPAL");
				def birthDate = databaseResultList.get("CAMPO.FECHA_NACIMIENTO");
				def updateDate = databaseResultList.get("CAMPO.FECHA_MODIFICACION");
				def affiliationDate = databaseResultList.get("CAMPO.FECHA_VINCULACION");
				def registBranch = databaseResultList.get("CAMPO.OFICINA_RADICACION");
				def countryCode = databaseResultList.get("CAMPO.PAIS_ISO");
				def city = databaseResultList.get("CAMPO.CIUDAD");
				def gender = databaseResultList.get("CAMPO.SEXO");
				def updateDataDate = databaseResultList.get("CAMPO.FECHA_ACTUALIZACION_DATO");
				def changeRegistrationDate = databaseResultList.get("CAMPO.REGISTRO_NOVEDAD");
				def whichCard = databaseResultList.get("CAMPO.INDICADOR_TARJETA_AMPARADA");
				def cityCode = databaseResultList.get("CAMPO.CODIGO_CIUDAD");
				def cardTypeCode = databaseResultList.get("REG.CAMPO.TIPO_TARJETA");
				def cardTypeDescription = databaseResultList.get("CAMPO.DESCRIPCION_TIPO_TARJETA");
                
                FMAPIFieldMapper.mapStringValueByLen(prodNum, "dbenr_prod_num", 34, inputMsg);					//aqo_acct_num
				FMAPIFieldMapper.mapStringValueByLen(idType, "dbenr_id_type", 2, inputMsg);						//rua_2byte_string_002
				FMAPIFieldMapper.mapStringValueByLen(idNumber, "dbenr_id_number", 20, inputMsg);				//rua_20byte_string_002
				FMAPIFieldMapper.mapStringValueByLen(custNumber, "dbenr_cust_num", 22, inputMsg);				//xqo_cust_num
				FMAPIFieldMapper.mapStringValueByLen(productType, "dbenr_prod_type", 1, inputMsg);				//rua_ind_012
				FMAPIFieldMapper.mapStringValueByLen(productCode, "dbenr_prod_code", 10, inputMsg);				//rua_10byte_string_004
				FMAPIFieldMapper.mapStringValueByLen(productDesc, "dbenr_prod_desc", 30, inputMsg);				//rur_30byte_string_002
				FMAPIFieldMapper.mapStringValueByLen(cardStatusCode, "dbenr_card_status_code", 10, inputMsg);	//rua_10byte_string_005
				FMAPIFieldMapper.mapStringValueByLen(accountStatusCode, "dbenr_acct_status_code", 2, inputMsg);	//rua_2byte_string_001
				FMAPIFieldMapper.mapStringValueByLen(effectCode, "dbenr_effect_code", 2, inputMsg);				//rua_2byte_string_003
				
				if(lastBlockingAccountDate != null) { FMAPIFieldMapper.mapStringDateSASDate(String.valueOf(lastBlockingAccountDate), "dbenr_last_blocking_acct_date", inputMsg);} 	//rua_10byte_string_003
				if(lastBlockingDate != null) { FMAPIFieldMapper.mapStringDateSASDate(String.valueOf(lastBlockingDate), "dbenr_last_blocking_date", inputMsg);} 	//rua_10byte_string_006
				if(acctOpeningDate != null) { FMAPIFieldMapper.mapStringDateSASDate(String.valueOf(acctOpeningDate), "dbenr_acct_openning_date", inputMsg);} 	//rua_10byte_string_008
				FMAPIFieldMapper.mapStringValueByLen(currentRegistBranch, "dbenr_current_regist_branch", 8, inputMsg);											//dua_8byte_string_008
				if(issueDate != null) { FMAPIFieldMapper.mapStringDateSASDate(String.valueOf(issueDate), "dbenr_issue_date", inputMsg);}						//rua_10byte_string_007
				FMAPIFieldMapper.mapStringValueByLen(reissuedCardNum, "dbenr_reissued_card_num", 20, inputMsg); 												//rua_20byte_string_004
				FMAPIFieldMapper.mapStringValueByLen(rprSubproduct, "dbenr_rpr_subproduct", 4, inputMsg); 														//rua_4byte_string_003
				FMAPIFieldMapper.mapStringValueByLen(commercialSegment, "dbenr_commercial_segment_code", 8, inputMsg); 											//dua_8byte_string_001
				FMAPIFieldMapper.mapStringValueByLen(commercialSegmentDesc, "dbenr_commercial_segment_desc", 30, inputMsg); 									//rur_30byte_string_003
				commercialSegment = FMUtils.truncateIfHasWrongLenght(commercialSegment, 2);
				def portfolioIndicator = portfolioFromComSegment.get(commercialSegment);
				inputMsg.put("dbenr_port_ind", portfolioIndicator);
				FMAPIFieldMapper.mapStringValueByLen(subSegmentCode, "dbenr_subsegment_code", 8, inputMsg); 													//dua_8byte_string_002
				FMAPIFieldMapper.mapStringValueByLen(subsegmentDesc, "dbenr_subsegment_desc", 30, inputMsg); 													//rur_30byte_string_004
				FMAPIFieldMapper.mapStringValueByLen(emailAddress, "dbenr_email_address", 80, inputMsg); 														//dua_80byte_string_001
				FMAPIFieldMapper.mapStringValueByLen(principalPhoneNum, "dbenr_phone", 15, inputMsg); 															//xqo_phone
				FMAPIFieldMapper.mapStringValueByLen(principalMobilePhone, "dbenr_principal_mobile_phone", 20, inputMsg); 										//rua_20byte_string_005
				if(birthDate != null) {	inputMsg.put("dbenr_birth_date",FMDateFormatter.getSASDateFormat(String.valueOf(birthDate))); }							//xqo_cust_birth_dt
				if(updateDate != null) { FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(String.valueOf(updateDate), "dbenr_update_date", "dbenr_update_time", inputMsg); }						//dua_10byte_string_001,dua_10byte_string_002
				if(affiliationDate !=null) { FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(String.valueOf(affiliationDate), "dbenr_affiliation_date", "dbenr_affiliation_time", inputMsg); }	//dua_10byte_string_003,dua_10byte_string_004
				FMAPIFieldMapper.mapStringValueByLen(registBranch, "dbenr_branch", 15, inputMsg);				//aqo_branch_id
				FMAPIFieldMapper.mapStringValueByLen(countryCode, "dbenr_country_code", 3, inputMsg);			//aqo_acct_cntry_code,xqo_cust_cntry_code
				FMAPIFieldMapper.mapStringValueByLen(city, "dbenr_cust_city", 60, inputMsg);					//xqo_cust_city
				FMAPIFieldMapper.mapStringValueByLen(gender, "dbenr_gender", 30, inputMsg);						//rur_30byte_string_001
				if(updateDataDate != null) { FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(String.valueOf(updateDataDate), "dbenr_update_data_date", "dbenr_update_data_time", inputMsg); }						//dua_10byte_string_005,dua_10byte_string_006
				if(changeRegistrationDate != null) { FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(String.valueOf(changeRegistrationDate), "dbenr_change_regist_date", "dbenr_change_regist_time", inputMsg); }	//dua_10byte_string_007,dua_10byte_string_008
				FMAPIFieldMapper.mapStringValueByLen(String.valueOf(whichCard), "dbenr_which_card", 1, inputMsg);				//hct_which_card
                FMAPIFieldMapper.mapStringValueByLen(getDaneCode(cityCode), "dbenr_city_code", 15, inputMsg);				//xqo_cust_post_code, hct_ch_post_code
				FMAPIFieldMapper.mapStringValueByLen(cardTypeDescription, "dbenr_card_type_desc", 60, inputMsg);
				FMAPIFieldMapper.mapStringValueByLen(cardTypeCode, "dbenr_card_type_code", 2, inputMsg);		//rua_2byte_string_006
				
			}catch(Exception e) {
				//TODO -- test purpose only
				e.printStackTrace();
				logger.info("ERR-DatabaseDataProcessor - db-enrichment: {}", e.toString());
			}
		}
	}

	/**
	 * 
	 * @param prodType
	 * @return
	 */
	public String getSASCustType(String prodType) {
		return "E".equals(prodType)? "B" : "I";
	}
	
	/**
	 * 
	 * @return
	 */
	public Map<String, Object> getProductNumber(Exchange exchange) {
		
		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");
		
		String productId = inputMsg.get("card_number");
		
		Map<String, Object> queryParams = new HashMap<String, Object>();
		queryParams.put("productId", productId);
		
		return queryParams;
	}
   
   /**
	 * 
	 * @param cityCode
	 * @return
	 */
	public String getDaneCode(String cityCode) {
		
		String daneCode = "";
		
		if(FMUtils.hasValue(cityCode) && cityCode.length() == 11) {
			String countryCode = cityCode.substring(0,3);
			daneCode = "169".equals(countryCode) ? cityCode.substring(3, 8): "";
		}
		
		return daneCode;
	}
	
	/**
	 * 
	 * @param exchange
	 * @return
	 */
	public Map<String,Object> getUpdateInfo(Exchange exchange){
		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");
	        
                Map<String, Object> updateParams = new HashMap<String, Object>();

                String tranDate = inputMsg.get("sas_gmt_tran_date");
		String tranTime = inputMsg.get("sas_gmt_tran_time");
		String trxRefNum = inputMsg.get("transaction_number");
		String productId = inputMsg.get("card_number");
		String responseCode = inputMsg.get("response_code");
		
		updateParams.put("productId", productId);
		updateParams.put("referenceNumber", trxRefNum);
		Date dateNow = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String strDateNow = formatter.format(dateNow);
		
		tranDate = tranDate.substring(6, 8).concat("/").concat(tranDate.substring(4, 6)).concat("/").concat(tranDate.substring(0, 4));
		tranTime = "01/01/1970 ".concat(tranTime);
		
		updateParams.put("tranDate", tranDate);
		updateParams.put("tranTime", tranTime);
		updateParams.put("responseCode", responseCode);
		
		updateParams.put("dateNow", strDateNow);	
                
                return updateParams;
	}
}
