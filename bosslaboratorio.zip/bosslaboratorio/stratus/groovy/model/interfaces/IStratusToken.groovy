package stratus.groovy.model.interfaces;

import java.util.Map;

public interface IStratusToken {

	public void mapTokenData(Map<String,String> inputMsg, String additionalData);
}
