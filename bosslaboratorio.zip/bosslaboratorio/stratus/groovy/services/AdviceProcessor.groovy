import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Map;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Qualifier;
import com.sas.davivienda.efm.commons.util.FMUtils;
import com.sas.davivienda.efm.commons.exceptions.EFMException;
import stratus.groovy.model.enums.PCActivityTypeFromTranCode;
import stratus.groovy.model.enums.PCActivityTypeFromMotive;
import stratus.groovy.model.enums.VCActivityTypeFromTranCode;
import stratus.groovy.model.enums.CAActivityTypeFromTranCode;
import stratus.groovy.model.enums.ChannelType;
import stratus.groovy.model.enums.AccountType;

public class AdviceProcessor implements Processor {

	private static final Logger logger = LoggerFactory.getLogger("strlog");

	public void process(Exchange exchange) throws EFMException {
		
		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");

		try {
			String channelId = inputMsg.get("channel");
			String transactionalMean = inputMsg.get("transactional_mean");
			String motive = inputMsg.get("motive");
			String tranCode = inputMsg.get("transaction_code");
			String strAcctType = inputMsg.get("acct_type_payeer");
			String integrationSource = "APPROVED_TX";
			boolean adviceForUpdate = true;
			String sasActivityType = "";
			
			AccountType accountType = AccountType.getIfPresent("ACC_"+strAcctType);
			if(accountType == null){
				throw new EFMException("Account type could not be calculated - strAcctType: "+strAcctType);
			}
			
			String sasAccountType = accountType.sasAccountType;
									
			if(channelId in ["02","33"] 
				|| (channelId in ["03"]    && transactionalMean in ["18"])
				|| (tranCode in ["000300", "005300", "009090"] && channelId in ["01"])
				|| (tranCode in ["000350", "000372", "000398", "000700"] && channelId in ["01","11","16","37"])
				|| (tranCode in ["000394"] && channelId in ["01"])
				|| (tranCode in ["005260", "005270", "005770", "005780", "009770"] && channelId in ["00", "16"] && motive in ["0146","0147"])
				|| (tranCode in ["005682","005686"]  && channelId in ["01"] && motive in ["0169"])
				|| (tranCode in ["005698"] && channelId in ["02", "11"])
				|| (tranCode in ["005770", "009770"] && channelId in ["00"] && motive in ["0136"])
				|| (tranCode in ["005770", "009770"] && channelId in ["33"] && motive in ["0585", "0690"])
				|| (tranCode in ["009770"] && channelId in ["11"] && motive in ["0192", "0201", "0243", "0244", "0245", "0844", "0845"])
			){
				adviceForUpdate = false;
				
				sasActivityType = getActivityTypeForPChannel(tranCode,channelId,motive);
				
				if(FMUtils.isNullOrEmpty(sasActivityType)){
					PCActivityTypeFromMotive pcActivityType = PCActivityTypeFromMotive.getIfPresent("PC_"+motive);
					
					if(pcActivityType == null){
						throw new EFMException("Activitytype couldnt be calculated - trancode, motive: "+trancode+", "+motive);
					}
					sasActivityType = pcActivityType.getSASActivityType();
				}
			}else{
				ChannelType channelType = ChannelType.getIfPresent("CH_"+channelId);
				
				if(channelType == null) {
					channelType = ChannelType.DEFAULT;
				}
				
				integrationSource = channelType.getIntegration();
				
				switch(integrationSource) {
					case "PHYSICAL-CHANNEL":
						sasActivityType = getActivityTypeForPChannel(tranCode,channelId,motive);
					break;
					case "VIRTUAL-CHANNEL":
						VCActivityTypeFromTranCode vcActivityType = VCActivityTypeFromTranCode.getIfPresent("VC_"+tranCode);
						
						if(vcActivityType == null) {throw new EFMException("VC Activity type could not be calculated - tranCode: " + tranCode);}
						sasActivityType = vcActivityType.getSASActivityType();
					break;
					case "CLIENTS-APIS":
						CAActivityTypeFromTranCode caActivityType = CAActivityTypeFromTranCode.getIfPresent("CA_"+tranCode);
						
						if(caActivityType == null) {throw new EFMException("CA Activity type could not be calculated - tranCode: " + tranCode);}
						sasActivityType = caActivityType.getSASActivityType();
					break;
				}
					
				if(FMUtils.isNullOrEmpty(sasActivityType)){
					String message = "Activity type could not be calculated - tranCode: " + tranCode;
					throw new EFMException(message);
				}
				if(logger.isDebugEnabled()){logger.info("channelId: {}, integSource: {}",channelId, integrationSource);}
			}
			
			inputMsg.put("sas_acct_type", sasAccountType);
			inputMsg.put("sas_activity_type", sasActivityType);
			
			String transactionType = sasAccountType.concat(sasActivityType);
			exchange.setProperty("transactionType",transactionType);
			exchange.setProperty("integSource",integrationSource);
			
		}catch(Exception e) {
			String errorMsg = "ERROR - AdviceProcessor: " + e.toString();
			throw new EFMException(errorMsg);
		}
	}

	public String getActivityTypeForPChannel(String tranCode, String channelId, String motive){
		String sasActivityType = "";
		
		PCActivityTypeFromTranCode pcActivityType = PCActivityTypeFromTranCode.getIfPresent("PC_"+tranCode);
						
		if(pcActivityType == null) {throw new EFMException("Activity type could not be calculated - tranCode: " + tranCode);}
		
		sasActivityType = pcActivityType.getSASActivityType();
		logger.info("sasActivityType: {},channelId: {}", sasActivityType,channelId);
		if("CW".equals(sasActivityType) && "03".equals(channelId)){
			sasActivityType = "CA";
		}
		if( (tranCode in ["005682", "005686"] && motive in ["0169"])
		  ||(tranCode in ["005260", "005780"] && motive in ["0146"])
		  ){
			sasActivityType = "DP";
		}
		return sasActivityType;
	}
	
}
