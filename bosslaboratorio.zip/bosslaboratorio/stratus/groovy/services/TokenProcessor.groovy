package stratus.groovy.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import stratus.groovy.controller.Token;
import stratus.groovy.controller.TokenChecks;
import stratus.groovy.controller.Common;

public class TokenProcessor implements Processor {

	private static final Logger logger = LoggerFactory.getLogger("strlog");
	List<String> tokenizationCodes = Arrays.asList("B0","CZ","SC","TK","SI","SJ","SK","CH","C4");

	public void process(Exchange exchange) {
		
		try {

			Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");
			
			if(inputMsg != null && inputMsg.get("pos_additional_data") != null){
				String generalTokenString = inputMsg.get("pos_additional_data");

				// Delete EOF
				if (generalTokenString.endsWith("EOF")) {
					generalTokenString = generalTokenString.substring(0, generalTokenString.length() - 3);
				}
			
				String tokenString = Common.getSubstringByChar(generalTokenString, "!");
			
				if(logger.isDebugEnabled()){logger.info("#####==== TOKENPROCESSOR tokenString: {}",tokenString);}
				
				if(tokenString != null) {
					List<String> tokens = Common.splitString(tokenString, "!");
					
					for(String token : tokens) {
						
						// remove white-space from the beginning of the token string
						token = token.replaceFirst("^\\s*", "");
						
						if(token.length() > 0 && tokenizationCodes.contains(token.substring(0,2))) {
							Token tokenObject = new Token(token);

							if(logger.isDebugEnabled()){logger.info("tokenObject: {}",tokenObject.toString());}
							
							Map <String, String> sasMapToken = TokenChecks.checkTokenValues(tokenObject);
							
							if(sasMapToken == null) {
								logger.error("Invalid token");
							}
							if(logger.isDebugEnabled()){logger.info("sasMapToken: {}",sasMapToken.toString());}
							inputMsg.putAll(sasMapToken);
						}
					}
				}
			}
		}

		catch(Exception e) {
			logger.error("Error on TokenProcessor: {}", e.getMessage());
		}
	}

}
