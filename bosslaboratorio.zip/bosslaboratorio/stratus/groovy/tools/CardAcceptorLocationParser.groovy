package stratus.groovy.tools;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.davivienda.efm.commons.util.FMUtils
import com.sas.davivienda.efm.commons.util.FMAPIFieldMapper
import com.sas.davivienda.efm.commons.enums.SASCitiesCodes
import com.sas.davivienda.efm.commons.enums.SASCitiesNames
import com.sas.davivienda.efm.commons.enums.SASCountryCodesAlpha2
import com.sas.davivienda.efm.commons.enums.SASCountryCodesAlpha3

import org.apache.camel.Exchange;

import javax.annotation.Resource

public class CardAcceptorLocationParser {

	private static final Logger logger = LoggerFactory.getLogger("CardAcceptorLocationParser");
	
	public static void mapLocationInformation(java.util.Map<String,String> inputMsg) {
		
		String merchantCountryCode = inputMsg.get("merchant_country_code"); 
		String transactionCity = inputMsg.get("transaction_city");;
		String terminalType = inputMsg.get("terminal_type"); 
		String termPostCode = "";
		String countryName = "";
		String isoCountryCode = "";

		try{
			if (FMUtils.hasValue(merchantCountryCode) && "CO".equals(merchantCountryCode) && (FMUtils.hasValue(transactionCity) && transactionCity.length() >= 5)) {
				String firstTwoDigits = transactionCity.substring(0, 2);
				
				String trxCity = "00".equals(firstTwoDigits) ? transactionCity.substring(2) : transactionCity.substring(0,5);
				
				if(FMUtils.getNumericValue(trxCity) > 0) {
					SASCitiesCodes cityCodes = SASCitiesCodes.getIfPresent("C_"+trxCity);
					if(cityCodes != null) {
						transactionCity = cityCodes.getOfficialName();
						termPostCode = cityCodes.getNumericCode();
						inputMsg.put("term_city_code", termPostCode);
						inputMsg.put("merchant_state", termPostCode.substring(0,2));
					}
				}
			}

			if (FMUtils.hasValue(merchantCountryCode)) {
				SASCountryCodesAlpha2 alpha2Eq = SASCountryCodesAlpha2.getIfPresent(merchantCountryCode);
				isoCountryCode = alpha2Eq == null ? "" :alpha2Eq.getNumericCode();
				countryName = alpha2Eq == null ? "" :alpha2Eq.getOfficialName();
			}
		}catch(Exception e){
			logger.info("Error processing merchant location: {}",e.toString());
		}

		FMAPIFieldMapper.mapStringValueByLen(transactionCity, "city_name", 60, inputMsg);
		FMAPIFieldMapper.mapStringValueByLen(countryName, "country_name", 30, inputMsg);
		inputMsg.put("term_iso_country_code", isoCountryCode);
		
		String mcc = inputMsg.get("mcc");
		
		if(FMUtils.hasValue(terminalType) && "02".equals(terminalType)) {
			inputMsg.put("acquirer_bin", "");

			if(FMUtils.isNullOrEmpty(mcc)){
				mcc = "6011";
			}
		}
		
		inputMsg.put("mcc", mcc);
	}

}
