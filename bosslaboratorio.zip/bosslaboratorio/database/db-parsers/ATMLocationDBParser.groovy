import javax.annotation.Resource

import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.ApplicationContext
import org.springframework.context.support.ClassPathXmlApplicationContext
import com.sas.davivienda.efm.commons.util.FMUtils
import com.sas.davivienda.efm.commons.util.FMAPIFieldMapper
import com.sas.davivienda.efm.commons.util.FMDateFormatter
import java.text.SimpleDateFormat;

/**
 *
 * 
 *
 */
public class DebitCardDBParser {

	@Resource
	@Qualifier("portfolioFromComSegment")
	private Map<String,String> portfolioFromComSegment;

	private static final Logger logger = LoggerFactory.getLogger("DatabaseParser");

	public DebitCardDBParser() {
		logger.info("init DebitCardDBParser");
	}

	/**
	 * 
	 * @param exchange
	 */
	public void mapDatabaseData(Exchange exchange) {

		Map<String,Object> inputMsg = exchange.getProperty("enrichedMsgBody",Map.class);
		Map<String,Object> databaseResultList = exchange.getIn().getBody();

		if(databaseResultList == null || FMUtils.mapHasAllEmptyValues(databaseResultList)) {
			String message = "No se encontraron registros para la terminal en base de datos";
			exchange.setProperty("dbEnrError", message);
		}else {

			try {
				def atmName = databaseResultList.get("CAMPO.NOMBRE_CAJERO");
				def atmCityName = databaseResultList.get("CAMPO.CIUDAD_ATM");
				def atmCityCode = databaseResultList.get("CAMPO.COD_DANE_CIUDAD");
				
				FMAPIFieldMapper.mapStringValueByLen(atmName, "dbenr_atm_name", 34, inputMsg);				//hct_term_owner_name
				FMAPIFieldMapper.mapStringValueByLen(atmCityName, "dbenr_atm_city_name", 34, inputMsg);		//hct_term_city
				FMAPIFieldMapper.mapStringValueByLen(atmCityCode, "dbenr_atm_city_code", 15, inputMsg);		//hct_term_post_code

				if(FMUtils.hasValue(atmCityCode)){
					FMAPIFieldMapper.mapStringValueByLen(atmCityCode.substring(0,2), "dbenr_atm_state", 15, inputMsg);	//hct_term_state
				}
				
				
			}catch(Exception e) {
				//TODO -- test purpose only
				e.printStackTrace();
				logger.error("ERR-DebitCardDBParser - dbenrichment: {}", e.toString());
			}
		}
	}

	
   /**
	 * 
	 * @param cityCode
	 * @return
	 */
	public String getDaneCode(String cityCode) {
		String daneCode = "";
		
		if(FMUtils.hasValue(cityCode) && cityCode.length() == 11) {
			String countryCode = cityCode.substring(0,3);
			daneCode = "169".equals(countryCode) ? cityCode.substring(3, 8): "";
		}
		return daneCode;
	}
	
	/**
	 * 
	 * @param exchange
	 * @return
	 */
	public Map<String, Object> getAtmCode(Exchange exchange) {
		Map<String, Object> dbRequest = new HashMap<String, Object>();
		def inputMsg = exchange.getProperty("inputMsg");
		String terminalId = inputMsg.get("terminalId");
		logger.info("terminalId: {}",terminalId); 
		dbRequest.put("atmCode", terminalId);
		return dbRequest;
	}
}
