import javax.annotation.Resource

import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.ApplicationContext
import org.springframework.context.support.ClassPathXmlApplicationContext
import com.sas.davivienda.efm.commons.util.FMUtils
import com.sas.davivienda.efm.commons.util.FMAPIFieldMapper
import com.sas.davivienda.efm.commons.util.FMDateFormatter

public class CreditCardDBParser {

	@Resource
	@Qualifier("portfolioFromComSegment")
	private Map<String,String> portfolioFromComSegment;

	private static final Logger logger = LoggerFactory.getLogger("DatabaseParser");

	public CreditCardDBParser() {
		logger.info("init CreditCardDBParser");
	}

	public void mapDatabaseData(Exchange exchange) {

		Map<String,Object> enrichedMsgBody = exchange.getProperty("enrichedMsgBody",Map.class);
		Map<String,Object> databaseResultList = exchange.getIn().getBody();
		String integSource = exchange.getProperty("integSource");

		if(databaseResultList == null || FMUtils.mapHasAllEmptyValues(databaseResultList)) {
			String productId = exchange.getProperty("productId");
			String message = "No se obtuvo informacion en base de datos del producto: " +
						  ((productId != null && productId.length() > 4) ? productId.substring(productId.length()-4): productId);
			exchange.setProperty("dbEnrError", message);
		}else {

			try {
				//MVP
				def productType = databaseResultList.get("CAMPO.TIPO_PRODUCTO");
				def idType = databaseResultList.get("CAMPO.COD_TIPO_ID");
				def idNumber = databaseResultList.get("CAMPO.NRO_IDENTIFICACION");
				def cupoGlobal = databaseResultList.get("CAMPO.CUPO_GLOBAL");
				def commercialSegment = databaseResultList.get("CAMPO.COD_SEGMENTO_COM");
				def paisIso = databaseResultList.get("CAMPO.PAIS_ISO");

				productType = FMUtils.truncateIfHasWrongLenght(productType, 1);
				idType = FMUtils.truncateIfHasWrongLenght(idType, 2);
				idNumber = FMUtils.truncateIfHasWrongLenght(idNumber, 20);
				paisIso = FMUtils.truncateIfHasWrongLenght(paisIso, 3);

				//Map MVP
				enrichedMsgBody.put("rua_ind_012",productType);

				if("POSTILION".equals(integSource)){
					enrichedMsgBody.put("smh_cust_type", getSASCustType(productType));
					enrichedMsgBody.put("rua_2byte_string_002", idType);
					enrichedMsgBody.put("rua_20byte_string_002", idNumber);
				}
				enrichedMsgBody.put("xqo_cust_num", idType.concat(idNumber));
				
				if(cupoGlobal!=null){
					enrichedMsgBody.put("aqc_credit_limit", String.valueOf(cupoGlobal));
				}
				
				enrichedMsgBody.put("aqo_acct_cntry_code", paisIso);
				enrichedMsgBody.put("xqo_cust_cntry_code", paisIso);

				//ITR1
				def productCode = databaseResultList.get("CAMPO.COD_PRODUCTO");
				def productDesc = databaseResultList.get("CAMPO.DESCRIPCION_PRODUCTO");
				def cardStatusCode = databaseResultList.get("CAMPO.COD_ESTADO_TC");
				def lastBlocking = databaseResultList.get("CAMPO.ULTIMO_BLOQUEO");
				def lastBlockingDate = databaseResultList.get("CAMPO.FECHA_ULTIMO_BLOQUEO");
				def currentRegistBranch = databaseResultList.get("CAMPO.OFICINA_RADICACION_ACTUAL");
				def issueDate = databaseResultList.get("CAMPO.FECHA_EMISION");
				def reissuedCardNum = databaseResultList.get("CAMPO.NRO_NUEVO_PRODUCTO_REEXPEDIDO");
				def agreementCode = databaseResultList.get("CAMPO.COD_CONVENIO");
				def rprSubproduct = databaseResultList.get("CAMPO.COD_SUBPRODUCTO");
				def updateDataDate = databaseResultList.get("CAMPO.FECHA_ACTUALIZACION_DATO");
				def city = databaseResultList.get("CAMPO.CIUDAD");
				def principalMobilePhone = databaseResultList.get("CAMPO.CELULAR_PRINCIPAL");
				def affiliationDate = databaseResultList.get("CAMPO.FECHA_VINCULACION");
				def principalPhoneNum = databaseResultList.get("CAMPO.TELEFONO_PRINCIPAL");
				def emailAddress = databaseResultList.get("CAMPO.CORREO_ELECTRONICO");
				def birthDate = databaseResultList.get("CAMPO.FECHA_NACIMIENTO");
				def gender = databaseResultList.get("CAMPO.SEXO");
				def changeRegistrationDate = databaseResultList.get("CAMPO.REGISTRO_NOVEDAD");
				def updateDate = databaseResultList.get("CAMPO.FECHA_MODIFICACION");
				def registBranch = databaseResultList.get("CAMPO.OFICINA_RADICACION");
				def commercialSegmentDesc = databaseResultList.get("CAMPO.SEGMENTO_COM");
				def subSegmentCode = databaseResultList.get("CAMPO.COD_SUBSEGMENTO_COM");
				def subsegmentDesc = databaseResultList.get("CAMPO.SUBSEGMENTO_COM");
				def chCityCode = databaseResultList.get("CAMPO.CODIGO_CIUDAD");
				def whichCard = databaseResultList.get("CAMPO.IND_TARJETA_AMPARADA");

				//Map ITR-1
				FMAPIFieldMapper.mapStringValueByLen(productCode, "rua_10byte_string_004", 10, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(productDesc, "rur_30byte_string_002", 30, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(cardStatusCode, "rua_10byte_string_005", 10, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(lastBlocking, "rua_2byte_string_005", 2, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(currentRegistBranch, "dua_8byte_string_008", 8, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(reissuedCardNum, "rua_20byte_string_004", 20, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(agreementCode, "rua_4byte_string_004", 4, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(rprSubproduct, "rua_4byte_string_003", 4, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(city, "xqo_cust_city", 60, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(principalMobilePhone, "rua_20byte_string_005", 20, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(principalPhoneNum, "xqo_phone", 15, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(emailAddress, "dua_80byte_string_001", 80, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(gender, "rur_30byte_string_001", 30, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(registBranch, "aqo_branch_id", 15, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(commercialSegment, "dua_8byte_string_001", 8, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(commercialSegmentDesc, "rur_30byte_string_003", 30, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(subSegmentCode, "dua_8byte_string_002", 8, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(subsegmentDesc, "rur_30byte_string_004", 30, enrichedMsgBody);
				FMAPIFieldMapper.mapStringValueByLen(getDaneCode(chCityCode), "hct_ch_post_code", 15, enrichedMsgBody);

				subSegmentCode = FMUtils.truncateIfHasWrongLenght(subSegmentCode, 2);
				def portfolioIndicator = portfolioFromComSegment.get(subSegmentCode);
				enrichedMsgBody.put("aqo_port_ind", portfolioIndicator);
				
				//DATE FIELDS
				if(lastBlockingDate != null) { FMAPIFieldMapper.mapStringDateSASDate(String.valueOf(lastBlockingDate), "rua_10byte_string_006", enrichedMsgBody); }
				if(issueDate != null) { FMAPIFieldMapper.mapStringDateSASDate(String.valueOf(issueDate), "rua_10byte_string_007", enrichedMsgBody); }
				if(updateDataDate != null) { FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(String.valueOf(updateDataDate), "dua_10byte_string_005", "dua_10byte_string_006", enrichedMsgBody); }
				if(affiliationDate !=null) { FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(String.valueOf(affiliationDate), "dua_10byte_string_003", "dua_10byte_string_004", enrichedMsgBody); }
				if(changeRegistrationDate != null) { FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(String.valueOf(changeRegistrationDate), "dua_10byte_string_007", "dua_10byte_string_008", enrichedMsgBody); }
				if(updateDate != null) { FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(String.valueOf(updateDate), "dua_10byte_string_001", "dua_10byte_string_002", enrichedMsgBody); }
				if(birthDate != null) {	enrichedMsgBody.put("xqo_cust_birth_dt",FMDateFormatter.getSASDateFormat(String.valueOf(birthDate))); }
				if(whichCard != null) {	FMAPIFieldMapper.mapStringValueByLen(String.valueOf(whichCard), "hct_which_card", 1, enrichedMsgBody); }

				exchange.setProperty("inputMsg",enrichedMsgBody);

			}catch(Exception e) {
				//TODO -- test purpose only
				e.printStackTrace();
				logger.error("ERR-CreditDBParser - dbenrichment: {}", e.toString());
			}finally {
				exchange.getIn().setBody(enrichedMsgBody);
			}
		}
	}

	/**
	 * 
	 * @param prodType
	 * @return
	 */
	public String getSASCustType(String prodType) {
		return "E".equals(prodType)? "B" : "I";
	}
	
	/**
	 * 
	 * @param exchange
	 * @return
	 */
	public Map<String, Object> getProductNumber(Exchange exchange) {
		Map<String, Object> dbRequest = new HashMap<String, Object>();
		String productId = exchange.getProperty("productId");
		dbRequest.put("productId", productId);
		return dbRequest;
	}
    
    /**
	 * 
	 * @param cityCode
	 * @return
	 */
	public String getDaneCode(String cityCode) {
		String daneCode = "";
		
		if(FMUtils.hasValue(cityCode) && cityCode.length() == 11) {
			String countryCode = cityCode.substring(0,3);
			daneCode = "169".equals(countryCode) ? cityCode.substring(3, 8): "";
		}
		return daneCode;
	}
	
	/**
	 *
	 * @param exchange
	 * @return
	 */
	public Map<String, Object> getUpdateInfo(Exchange exchange) {
		Map<String, Object> dbRequest = new HashMap<String, Object>();

		try{
			String productId = exchange.getProperty("productId");
			String dateNow = exchange.getProperty("dateNow");
			String referenceNumber = exchange.getProperty("referenceNumber");
			String tranDateLocal = exchange.getProperty("tranDateLocal");
			String tranTimeLocal = exchange.getProperty("tranTimeLocal");
			String authorizationIdResponse = exchange.getProperty("authorizationIdResponse");
			String processingCode = exchange.getProperty("processingCode");

			dbRequest.put("productId", productId);
			dbRequest.put("dateNow", dateNow);
			dbRequest.put("referenceNumber", referenceNumber);
			dbRequest.put("tranDateLocal", tranDateLocal);
			dbRequest.put("tranTimeLocal", tranTimeLocal);
			dbRequest.put("authorizationIdResponse", authorizationIdResponse);
			dbRequest.put("processingCode", processingCode);
		}catch(Exception e){
			logger.error("ERR-CrebitCardDBParser: {}",e.toString());
		}
		return dbRequest;
	}

}
