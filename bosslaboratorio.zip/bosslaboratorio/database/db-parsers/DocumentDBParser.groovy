import javax.annotation.Resource

import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.ApplicationContext
import org.springframework.context.support.ClassPathXmlApplicationContext
import com.sas.davivienda.efm.commons.util.FMUtils
import com.sas.davivienda.efm.commons.util.FMAPIFieldMapper
import com.sas.davivienda.efm.commons.util.FMDateFormatter
import java.text.SimpleDateFormat;

/**
 *
 * 
 *
 */
public class DocumentDBParser {

	@Resource
	@Qualifier("portfolioFromComSegment")
	private Map<String,String> portfolioFromComSegment;

	private static final Logger logger = LoggerFactory.getLogger("DocumentDatabaseParser");

	public DocumentDBParser() {
		logger.info("init AccountDBParser");
	}

	/**
	 * 
	 * @param exchange
	 */
	public void mapDatabaseData(Exchange exchange) {

		Map<String,Object> inputMsg = exchange.getProperty("inputMsg",Map.class);
		Map<String,Object> databaseResultList = exchange.getIn().getBody();

		if(databaseResultList == null || FMUtils.mapHasAllEmptyValues(databaseResultList)) {
			String documentId = inputMsg.get("rua_20byte_string_002");
			String documentType = inputMsg.get("rua_2byte_string_002");
			String message = "No se obtuvo informacion en base de datos del beneficiario: " +
							 ((documentId != null && documentId.length() > 4) ? documentId.substring(documentId.length()-4): documentId) +
							", tipo: " + documentType;
			exchange.setProperty("dbEnrError", message);
		}else {

			try {
				
				def idType = databaseResultList.get("CAMPO.COD_TIPO_ID");
				def idNumber = databaseResultList.get("CAMPO.NRO_IDENTIFICACION");
				def custNumber = "";
				if(idType != null && idNumber != null){
					custNumber = idType.concat(idNumber);
				}
				
				def commercialSegment = databaseResultList.get("CAMPO.COD_SEGMENTO_COM");
				def commercialSegmentDesc = databaseResultList.get("CAMPO.SEGMENTO_COM");
				def subSegmentCode = databaseResultList.get("CAMPO.COD_SUBSEGMENTO_COM");
				def subsegmentDesc = databaseResultList.get("CAMPO.SUBSEGMENTO_COM");
				def emailAddress = databaseResultList.get("CAMPO.CORREO_ELECTRONICO");
				def principalPhoneNum = databaseResultList.get("CAMPO.TELEFONO_PRINCIPAL");
				def principalMobilePhone = databaseResultList.get("CAMPO.CELULAR_PRINCIPAL");
				def birthDate = databaseResultList.get("CAMPO.FECHA_NACIMIENTO");
				def updateDate = databaseResultList.get("CAMPO.FECHA_MODIFICACION");
				def affiliationDate = databaseResultList.get("CAMPO.FECHA_VINCULACION");
				def currentRegistBranch = databaseResultList.get("CAMPO.OFICINA_RADICACION");
				def countryCode = databaseResultList.get("CAMPO.PAIS_ISO");
				def city = databaseResultList.get("CAMPO.CIUDAD");
				def gender = databaseResultList.get("CAMPO.SEXO");
				def updateDataDate = databaseResultList.get("CAMPO.FECHA_ACTUALIZACION_DATO");
				def changeRegistrationDate = databaseResultList.get("CAMPO.REGISTRO_NOVEDAD");
				def cityCode = databaseResultList.get("CAMPO.CODIGO_CIUDAD");

				FMAPIFieldMapper.mapStringValueByLen(custNumber, "dbenr_cust_num", 22, inputMsg);				//xqo_cust_num
				FMAPIFieldMapper.mapStringValueByLen(commercialSegment, "dbenr_commercial_segment_code", 8, inputMsg); 											//dua_8byte_string_001
				FMAPIFieldMapper.mapStringValueByLen(commercialSegmentDesc, "dbenr_commercial_segment_desc", 30, inputMsg); 									//rur_30byte_string_003
				FMAPIFieldMapper.mapStringValueByLen(subSegmentCode, "dbenr_subsegment_code", 8, inputMsg); 													//dua_8byte_string_002
				FMAPIFieldMapper.mapStringValueByLen(subsegmentDesc, "dbenr_subsegment_desc", 30, inputMsg); 													//rur_30byte_string_004
				FMAPIFieldMapper.mapStringValueByLen(emailAddress, "dbenr_email_address", 80, inputMsg); 														//dua_80byte_string_001
				FMAPIFieldMapper.mapStringValueByLen(principalPhoneNum, "dbenr_phone", 15, inputMsg); 															//xqo_phone
				FMAPIFieldMapper.mapStringValueByLen(principalMobilePhone, "dbenr_principal_mobile_phone", 20, inputMsg); 										//rua_20byte_string_005
				if(birthDate != null) {	inputMsg.put("dbenr_birth_date",FMDateFormatter.getSASDateFormat(String.valueOf(birthDate))); }							//xqo_cust_birth_dt
				if(updateDate != null) { FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(String.valueOf(updateDate), "dbenr_update_date", "dbenr_update_time", inputMsg); }						//dua_10byte_string_001,dua_10byte_string_002
				if(affiliationDate !=null) { FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(String.valueOf(affiliationDate), "dbenr_affiliation_date", "dbenr_affiliation_time", inputMsg); }	//dua_10byte_string_003,dua_10byte_string_004
				FMAPIFieldMapper.mapStringValueByLen(currentRegistBranch, "dbenr_current_regist_branch", 8, inputMsg);											//dua_8byte_string_008
				FMAPIFieldMapper.mapStringValueByLen(countryCode, "dbenr_country_code", 3, inputMsg);			//aqo_acct_cntry_code,xqo_cust_cntry_code
				FMAPIFieldMapper.mapStringValueByLen(city, "dbenr_cust_city", 60, inputMsg);					//xqo_cust_city
				FMAPIFieldMapper.mapStringValueByLen(gender, "dbenr_gender", 30, inputMsg);						//rur_30byte_string_001
				if(updateDataDate != null) { FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(String.valueOf(updateDataDate), "dbenr_update_data_date", "dbenr_update_data_time", inputMsg); }						//dua_10byte_string_005,dua_10byte_string_006
				if(changeRegistrationDate != null) { FMAPIFieldMapper.mapStringDateToSeparateSASDateTime(String.valueOf(changeRegistrationDate), "dbenr_change_regist_date", "dbenr_change_regist_time", inputMsg); }	//dua_10byte_string_007,dua_10byte_string_008
				FMAPIFieldMapper.mapStringValueByLen(getDaneCode(cityCode), "dbenr_city_code", 15, inputMsg);				//xqo_cust_post_code, hct_ch_post_code
				
				subSegmentCode = FMUtils.truncateIfHasWrongLenght(subSegmentCode, 2);
				def portfolioIndicator = portfolioFromComSegment.get(subSegmentCode);
				inputMsg.put("dbenr_port_ind", portfolioIndicator);

			}catch(Exception e) {
				//TODO -- test purpose only
				e.printStackTrace();
				logger.error("ERR-AccountDBParser - dbenrichment: {}", e.toString());
			}
		}
	}

	/**
	 * 
	 * @return
	 */
	public Map<String, Object> getQueryParams(Exchange exchange) {
		
		Map<String, String> inputMsg = (Map<String, String>) exchange.getProperty("inputMsg");
		
		String idNumber = inputMsg.get("rua_20byte_string_002");
		String idType = inputMsg.get("rua_2byte_string_002");
		
		Map<String, Object> queryParams = new HashMap<String, Object>();
		queryParams.put("idNumber", idNumber);
		queryParams.put("idType", idType);

		if(logger.isDebugEnabled()){logger.info("queryParams: {}",queryParams);}

		return queryParams;
	}
   
   /**
	 * 
	 * @param cityCode
	 * @return
	 */
	public String getDaneCode(String cityCode) {
		
		String daneCode = "";
		
		if(FMUtils.hasValue(cityCode) && cityCode.length() == 11) {
			String countryCode = cityCode.substring(0,3);
			daneCode = "169".equals(countryCode) ? cityCode.substring(3, 8): "";
		}
		
		return daneCode;
	}

}
