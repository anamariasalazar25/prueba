import javax.annotation.Resource

import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.context.ApplicationContext
import org.springframework.context.support.ClassPathXmlApplicationContext
import com.sas.davivienda.efm.commons.util.FMUtils
import com.sas.davivienda.efm.commons.util.FMAPIFieldMapper
import com.sas.davivienda.efm.commons.util.FMDateFormatter
import java.text.SimpleDateFormat;

/**
 *
 * 
 *
 */
public class PayeeAccountDBParser {

	private static final Logger logger = LoggerFactory.getLogger("DatabaseParser");

	public PayeeAccountDBParser() {
		logger.info("init PayeeAccountDBParser");
	}

	/**
	 * 
	 * @param exchange
	 */
	public void mapDatabaseData(Exchange exchange) {

		Map<String,Object> inputMsg = exchange.getProperty("inputMsg",Map.class);
		Map<String,Object> databaseResultList = exchange.getIn().getBody();

		if(databaseResultList == null || FMUtils.mapHasAllEmptyValues(databaseResultList)) {
			String payeeProductType = inputMsg.get("payeeAccountType");
			String payeeProductId = inputMsg.get("payeeAccountNumber");
			String message = "No se obtuvo informacion en base de datos del beneficiario: " +
							 ((payeeProductId != null && payeeProductId.length() > 4) ? payeeProductId.substring(payeeProductId.length()-4): payeeProductId) +
							", tipo: " + payeeProductType;
			exchange.getIn().setHeader("payeeDbEnrError", message);
		}else {

			try {
				def payeeAccountNum = databaseResultList.get("CAMPO.NRO_CTA");
				def payeeIdType = databaseResultList.get("CAMPO.TIPO_ID");
				def payeeIdNumber = databaseResultList.get("CAMPO.NRO_ID");
				
				if(FMUtils.hasValue(payeeAccountNum)) { FMAPIFieldMapper.mapStringValueByLen(payeeAccountNum, "tpp_acct_num", 34, inputMsg);}

				def payerIdType = inputMsg.get("dbenr_id_type");
				def payerIdNumber = inputMsg.get("dbenr_id_number");
				String selfCustomerInd = inputMsg.get("tbt_self_acct_ind");

				if(FMUtils.isNullOrEmpty(selfCustomerInd)){
					if(FMUtils.hasValue(payeeIdType) && FMUtils.hasValue(payeeIdNumber) && FMUtils.hasValue(payerIdType) && FMUtils.hasValue(payerIdNumber)){
						selfCustomerInd = payeeIdType.equals(payerIdType) && payeeIdNumber.equals(payerIdNumber) ? "Y" : "N";
					}
				}
				inputMsg.put("tbt_self_acct_ind",selfCustomerInd);
			}catch(Exception e) {
				//TODO -- test purpose only
				e.printStackTrace();
				logger.error("ERR-PayeeAccountDBParser - dbenrichment: {}", e.toString());
			}
		}
	}
	
	/**
	 * 
	 * @param exchange
	 * @return
	 */
	public Map<String, Object> getQueryParams(Exchange exchange) {
		Map<String, Object> queryParams = new HashMap<String, Object>();

		def inputMsg = exchange.getProperty("inputMsg");

		String payeeProductId = inputMsg.get("payeeAccountNumber");
		String payeeAccountType = inputMsg.get("payeeAccountType");

		queryParams.put("payeeProductId", payeeProductId);
		queryParams.put("payeeProductType", payeeAccountType);

		if(logger.isDebugEnabled()){logger.info("query-params-payee: {}",queryParams);}

		return queryParams;
	}

	
}
